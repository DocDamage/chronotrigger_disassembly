# Next Session Start Here

1. Read `notes/community_research_first.md`
2. Open these in order:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `dossiers/CD_dossier.md`
   - `dossiers/D1_dossier.md`
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - `chrono_trigger_disasm_pass84.md`
   - `chrono_trigger_labels_pass84.md`
   - `chrono_trigger_disasm_pass85.md`
   - `chrono_trigger_labels_pass85.md`
3. Active top-of-stack seam after pass 85:
   - find the first exact reader(s) of `CD23 / CD24 / CD25 / CD2D / CD2E`
   - decide whether the `5DA0..5DA5` family is best described as a live vector, record, pose bundle, or another stricter noun once a real consumer is found
   - decide whether the indexed `CAEA..CAF5` family is a queued snapshot bank, per-slot record family, or another stricter destination noun once a real reader is found
   - return to the first exact external reader(s) of `CDC8` and `CE0F`
   - keep freezing the remaining late auxiliary families only after these local control/state bytes are tighter
4. Specific cleanup targets:
   - confirm whether auxiliary token `0xE6` uses only `00/01` or multiple live nonzero values for `CFFF`
   - explain why `D1:F431` clears only positive `0x1x` descriptor headers while sparing the signed `0x8x` family
   - tighten the final nouns of the `2040/20A0/2120/21A0/2240/22A0/2320/23A0` page families
   - tighten the exact roles of `A101`, `2A21.bit1`, and the `0575.bit6` toggle in `D1:E70A`
   - decide whether `7E:5D80..5DFF` should stay a generic indexed counter strip or be tightened further once a real consumer is found
5. Runtime confirmation shortlist:
   - live values written by auxiliary token `0xE6` into `CFFF`
   - first exact consumer(s) of `CD23 / CD24 / CD25 / CD2D / CD2E`
   - first exact consumer(s) of `5DA0..5DA5`
   - first exact consumer(s) of `CAEA..CAF5`
   - first exact consumer(s) of `CDC8`
   - first exact consumer(s) of `CE0F`
