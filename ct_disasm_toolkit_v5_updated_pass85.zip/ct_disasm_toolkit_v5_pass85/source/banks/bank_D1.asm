; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_D1
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; D1:5800  top-status=strong  labels=7
; =============================================================================
; [strong] pass 44 :: ct_d1_tilemap_template_default_0b40_0180
; qualifier: strong
; notes: Default/reset ROM template copied into `0B40` by `C1:1C3A`. Same size as the upload buffer and structurally part of the same tilemap-template family.
; source: chrono_trigger_labels_pass44.md
D1_5800_ct_d1_tilemap_template_default_0b40_0180:
    ; TODO: reconstruct body / data for D1:5800

; [provisional] pass 46 :: / D1:5A50 / D1:5BD0  ct_d1_alt_base_strip_layout_family      [strengthened context]
; notes: Pass 46 strengthens their caller-context roles: `5800` = default/base restore through `C1:1C3A` `5A50` = latched alternate via `A86A` `5BD0` = transition/reset alternate in later state-advance paths
; source: chrono_trigger_labels_pass46.md
D1_5800_D1_5A50_D1_5BD0_ct_d1_alt_base_strip_layout_family_strengthened_context:
    ; TODO: reconstruct body / data for D1:5800

; [provisional] pass 46 :: ct_d1_base_strip_template_default
; qualifier: provisional
; notes: Caller context strongly suggests the default/base restore variant. Final gameplay-facing mode name still open.
; source: chrono_trigger_labels_pass46.md
D1_5800_ct_d1_base_strip_template_default:
    ; TODO: reconstruct body / data for D1:5800

; [provisional] pass 45 :: / D1:5A50 / D1:5BD0  ct_d1_alt_base_strip_layout_family        [provisional]
; notes: The three templates are clearly alternate base layouts within the same 32x6 strip region. Exact gameplay/UI mode names are still unresolved.
; source: chrono_trigger_labels_pass45.md
D1_5800_D1_5A50_D1_5BD0_ct_d1_alt_base_strip_layout_family_provisional:
    ; TODO: reconstruct body / data for D1:5800

; [provisional] pass 45 :: / D1:5A50 / D1:5BD0  ct_d1_tilemap_template_family_16x12_words [withdrawn]
; notes: Pass 45 corrects this earlier provisional geometry. The safer keepable geometry is `32x6`, not `16x12`.
; source: chrono_trigger_labels_pass45.md
D1_5800_D1_5A50_D1_5BD0_ct_d1_tilemap_template_family_16x12_words_withdrawn:
    ; TODO: reconstruct body / data for D1:5800

; [unspecified] pass 45 :: / D1:5A50 / D1:5BD0  ct_d1_base_strip_template_family_32x6     [strong]
; notes: Corrected geometrically in this pass. All three `0x0180`-byte base templates are best modeled as 32-word by 6-row strip layouts. Used as the base tilemap copied into `0B40` before dynamic patching and upload.
; source: chrono_trigger_labels_pass45.md
D1_5800_D1_5A50_D1_5BD0_ct_d1_base_strip_template_family_32x6_strong:
    ; TODO: reconstruct body / data for D1:5800

; [unspecified] pass 44 :: / D1:5A50 / D1:5BD0  ct_d1_tilemap_template_family_16x12_words [provisional]
; notes: The three source blocks are best interpreted as a 192-word (likely 16x12) template family. This matrix interpretation fits both the dense row-structured data and the fixed-size VRAM upload,
; source: chrono_trigger_labels_pass44.md
D1_5800_D1_5A50_D1_5BD0_ct_d1_tilemap_template_family_16x12_words_provisional:
    ; TODO: reconstruct body / data for D1:5800

; =============================================================================
; D1:59FC  top-status=strong  labels=1
; =============================================================================
; [strong] pass 45 :: ct_d1_panel_segment_template_6x7_words
; qualifier: strong
; notes: Unique ROM source table used by `C1:0929`. Resolves cleanly as 6 rows of 7 words. Tile values form a compact border/interior segment template rather than logic data.
; source: chrono_trigger_labels_pass45.md
D1_59FC_ct_d1_panel_segment_template_6x7_words:
    ; TODO: reconstruct body / data for D1:59FC

; =============================================================================
; D1:5A50  top-status=strong  labels=2
; =============================================================================
; [strong] pass 44 :: ct_d1_tilemap_template_alt_a_0b40_0180
; qualifier: strong
; notes: Alternate ROM template variant copied into `0B40` by the `0EA1..0EB1` path. Followed by `INC $99E2`, proving it feeds the same upload path as the default template.
; source: chrono_trigger_labels_pass44.md
D1_5A50_ct_d1_tilemap_template_alt_a_0b40_0180:
    ; TODO: reconstruct body / data for D1:5A50

; [provisional] pass 46 :: ct_d1_base_strip_template_latched_alt
; qualifier: provisional
; notes: Single-shot alternate selected when `A86A` is nonzero, then that latch is cleared. Kept provisional until the higher-level mode name is pinned.
; source: chrono_trigger_labels_pass46.md
D1_5A50_ct_d1_base_strip_template_latched_alt:
    ; TODO: reconstruct body / data for D1:5A50

; =============================================================================
; D1:5BD0  top-status=strong  labels=2
; =============================================================================
; [strong] pass 44 :: ct_d1_tilemap_template_alt_b_0b40_0180
; qualifier: strong
; notes: Alternate ROM template variant copied into `0B40` by the `1301..1315`, Followed by `INC $99E2`, proving it feeds the same upload path as the default template.
; source: chrono_trigger_labels_pass44.md
D1_5BD0_ct_d1_tilemap_template_alt_b_0b40_0180:
    ; TODO: reconstruct body / data for D1:5BD0

; [provisional] pass 46 :: ct_d1_base_strip_template_transition_alt
; qualifier: provisional
; notes: Copied in later state-transition/reset paths with surrounding controller bookkeeping. Strong structural role, but final mode name still unresolved.
; source: chrono_trigger_labels_pass46.md
D1_5BD0_ct_d1_base_strip_template_transition_alt:
    ; TODO: reconstruct body / data for D1:5BD0

; =============================================================================
; D1:646C  top-status=strong  labels=1
; =============================================================================
; [strong] pass 79 :: ct_d1_auxiliary_descriptor_pointer_table
; qualifier: strong structural
; notes: `15D5` multiplies the descriptor id by two and reads a pointer from this table. The returned pointer seeds one active runtime slot in the optional auxiliary descriptor stage.
; source: chrono_trigger_labels_pass79.md
D1_646C_ct_d1_auxiliary_descriptor_pointer_table:
    ; TODO: reconstruct body / data for D1:646C
    ; known span hint: D1:646C..D1:652B

; =============================================================================
; D1:E70A  top-status=strong  labels=1
; =============================================================================
; [strong] pass 83 :: ct_d1_optional_exchange_secondary_and_tertiary_palette_band_pairs
; qualifier: strong structural
; notes: Clears `A101`. Tests `2A21.bit1`; when set, toggles bit `0x40` in `0575`. Exchanges the full 48-word pairs `2120..217F <-> 21A0..21FF` and `2320..237F <-> 23A0..23FF`. Decrements direct-page `$40` and returns. Strongest safe reading: selector-sensitive band-exchange helper.
; source: chrono_trigger_labels_pass83.md
D1_E70A_ct_d1_optional_exchange_secondary_and_tertiary_palette_band_pairs:
    ; TODO: reconstruct body / data for D1:E70A
    ; known span hint: D1:E70A..D1:E77B

; =============================================================================
; D1:E899  top-status=strong  labels=1
; =============================================================================
; [strong] pass 82 :: ct_d1_fill_palette_band_pairs_2040_2240_and_2120_2320_with_7fff_sentinel
; qualifier: strong
; notes: Fills `7E:2040..20FF` and `7E:2240..22FF` with `0x7FFF`. Then fills `7E:2120..217F` and `7E:2320..237F` with the same sentinel. Exact structural role: paired palette-band/table sentinel initializer.
; source: chrono_trigger_labels_pass82.md
D1_E899_ct_d1_fill_palette_band_pairs_2040_2240_and_2120_2320_with_7fff_sentinel:
    ; TODO: reconstruct body / data for D1:E899
    ; known span hint: D1:E899..D1:E8C0

; =============================================================================
; D1:E8C1  top-status=strong  labels=1
; =============================================================================
; [strong] pass 82 :: ct_d1_fill_palette_band_pair_21a0_23a0_with_7fff_sentinel
; qualifier: strong
; notes: Fills `7E:21A0..21FF` and `7E:23A0..23FF` with `0x7FFF`. Exact smaller sibling of `D1:E899`.
; source: chrono_trigger_labels_pass82.md
D1_E8C1_ct_d1_fill_palette_band_pair_21a0_23a0_with_7fff_sentinel:
    ; TODO: reconstruct body / data for D1:E8C1
    ; known span hint: D1:E8C1..D1:E8D4

; =============================================================================
; D1:E91A  top-status=strong  labels=1
; =============================================================================
; [strong] pass 82 :: ct_d1_promote_first_48color_palette_band_and_restore_active_3record_descriptor_slab
; qualifier: strong structural
; notes: Copies `7E:2040..209F` into `7E:20A0..20FF` and `7E:22A0..22FF`, then clears `7E:2040..209F` and `7E:2240..229F`. Copies `7E:0544..0567` back into `7E:0520..0543`. Adds `0x30` to the `+1` byte of each copied 12-byte record. Seeds `0520/052C/0538` and `CD2F..CD31` with `0x30`. Clears `CD32..CD34` and `CDC8`. Increments `CE12`. Strongest safe reading: promote/copy helper for one palette-band pair plus one active descriptor slab restore/arm step.
; source: chrono_trigger_labels_pass82.md
D1_E91A_ct_d1_promote_first_48color_palette_band_and_restore_active_3record_descriptor_slab:
    ; TODO: reconstruct body / data for D1:E91A
    ; known span hint: D1:E91A..D1:E983

; =============================================================================
; D1:E984  top-status=strong  labels=1
; =============================================================================
; [strong] pass 82 :: ct_d1_seed_first_48color_palette_band_from_d0_fd00_and_snapshot_active_descriptor_slab_outward
; qualifier: strong structural
; notes: Increments `CDC8` and `CE0F`. Copies ROM data from `D0:FD00..FD5F` into `7E:2040..209F` and `7E:2240..229F`. Copies `7E:0520..0543` outward into `7E:0544..0567`. Subtracts `0x30` from the `+1` byte of each copied 12-byte record. Seeds `0548/0554/0560` with `0x0100`. Seeds `0544/0550/055C` and `CD32..CD34` with `0x30`. Increments `CE12`. Strongest safe reading: complementary seed/snapshot helper paired with `D1:E91A`.
; source: chrono_trigger_labels_pass82.md
D1_E984_ct_d1_seed_first_48color_palette_band_from_d0_fd00_and_snapshot_active_descriptor_slab_o:
    ; TODO: reconstruct body / data for D1:E984
    ; known span hint: D1:E984..D1:E9EB

; =============================================================================
; D1:F260  top-status=strong  labels=1
; =============================================================================
; [strong] pass 84 :: ct_d1_reset_control_cluster_state_including_ce0f_ce12_and_cfff
; qualifier: strong structural
; notes: Exact writes in this subsection clear `CE0E / CE0F / CE10 / CE12 / CFFF` and seed neighboring D1 control bytes. Strongest safe reading: local reset/init subsection for the D1 palette/control cluster.
; source: chrono_trigger_labels_pass84.md
D1_F260_ct_d1_reset_control_cluster_state_including_ce0f_ce12_and_cfff:
    ; TODO: reconstruct body / data for D1:F260
    ; known span hint: D1:F260..D1:F297

; =============================================================================
; D1:F411  top-status=strong  labels=1
; =============================================================================
; [strong] pass 83 :: ct_d1_snapshot_palette_descriptor_header_bytes_8slots_to_cd2f_cd36
; qualifier: strong
; notes: Walks the 8-slot `0520 + n*0C` descriptor queue. Copies the first byte of each slot (`0520/052C/0538/0544/0550/055C/0568/0574`) into `CD2F..CD36`. Exact structural role: descriptor-header shadow helper.
; source: chrono_trigger_labels_pass83.md
D1_F411_ct_d1_snapshot_palette_descriptor_header_bytes_8slots_to_cd2f_cd36:
    ; TODO: reconstruct body / data for D1:F411
    ; known span hint: D1:F411..D1:F426

; =============================================================================
; D1:F427  top-status=strong  labels=1
; =============================================================================
; [strong] pass 83 :: ct_d1_select_descriptor_header_suspend_or_restore_by_cfff
; qualifier: strong structural
; notes: Reads `CFFF`. `CFFF != 0` jumps to the shadow-and-suspend path at `D1:F431`. `CFFF == 0` jumps to the restore path at `D1:F457`.
; source: chrono_trigger_labels_pass83.md
D1_F427_ct_d1_select_descriptor_header_suspend_or_restore_by_cfff:
    ; TODO: reconstruct body / data for D1:F427
    ; known span hint: D1:F427..D1:F430

; =============================================================================
; D1:F431  top-status=strong  labels=1
; =============================================================================
; [strong] pass 83 :: ct_d1_arm_ce12_shadow_descriptor_headers_and_suspend_family_10_slots
; qualifier: strong structural
; notes: Returns immediately when `CE12 != 0`. Otherwise increments `CE12`, snapshots all 8 descriptor headers through `D1:F411`, and scans the full 8-slot queue. Clears only non-negative `0x1x` header bytes in `0520 + n*0C`. Strongest safe reading: one-shot shadow-and-suspend path for the positive palette-animation family.
; source: chrono_trigger_labels_pass83.md
D1_F431_ct_d1_arm_ce12_shadow_descriptor_headers_and_suspend_family_10_slots:
    ; TODO: reconstruct body / data for D1:F431
    ; known span hint: D1:F431..D1:F456

; =============================================================================
; D1:F457  top-status=strong  labels=1
; =============================================================================
; [strong] pass 83 :: ct_d1_restore_shadowed_descriptor_headers_from_cd2f_cd36_and_clear_ce12
; qualifier: strong structural
; notes: Returns immediately when `CE12 == 0`. Otherwise clears `CE12` and restores `CD2F..CD36` back into the first byte of all 8 descriptor slots. Strongest safe reading: one-shot restore half paired with `D1:F431`.
; source: chrono_trigger_labels_pass83.md
D1_F457_ct_d1_restore_shadowed_descriptor_headers_from_cd2f_cd36_and_clear_ce12:
    ; TODO: reconstruct body / data for D1:F457
    ; known span hint: D1:F457..D1:F473

