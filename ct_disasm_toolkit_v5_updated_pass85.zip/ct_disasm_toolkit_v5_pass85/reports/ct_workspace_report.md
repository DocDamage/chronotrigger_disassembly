# Chrono Trigger Workspace Report

## Current top-of-stack
- Latest pass: **85**
- Current live seam: **Late auxiliary token/control family around `CD:18CF..1917` plus the first real consumers of `CD23 / CD24 / CD25 / CD2D / CD2E`, followed by the external-reader hunt for `CDC8 / CE0F`.**
- Completion estimate: **~60.9%**

## Label database
- Total label rows: **582**
- Strong: **387**
- Provisional: **126**
- Alias: **0**
- Caution: **2**
- Runtime evidence rows: **0**

## Coverage worksheets
- Master C1 global opcode worksheet rows: **170**
- Selector-control worksheet rows: **83**
- Service-7 wrapper worksheet rows: **8**

## Xref cache
- Hot targets cached: **33**

## Generated artifacts
- `reports/ct_completion_score.md`
- `reports/ct_conflict_report.md`
- `reports/code_data_score.md`
- `graph/ct_knowledge_graph_summary.md`
- `dossiers/CD_dossier.md`
- `dossiers/D1_dossier.md`
- `asm_skeleton/banks/`

## Immediate next work
1. Re-read the community context note before doing new naming work.
2. Follow the new pass-85 local-control seam before jumping back to broader bank hunts.
3. Find the first exact reader(s) of `CD23 / CD24 / CD25 / CD2D / CD2E`.
4. Then return to the first exact external reader(s) of `CDC8 / CE0F`.

## Still required for full disassembly
- Complete bank-by-bank code/data separation
- Finish global opcode and VM coverage
- Finish decompressor grammar / format work
- Freeze subsystem ownership boundaries across banks
- Build a rebuildable source tree and validate against ROM fingerprints
