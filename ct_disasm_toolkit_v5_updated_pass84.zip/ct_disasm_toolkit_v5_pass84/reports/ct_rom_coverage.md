# ROM / WRAM Coverage View

Lower-bound coverage only. Point labels count as a single byte unless a wider range is explicitly known.

## 7E
- Covered bytes: **4931** / 65536 (**7.524%**)
- Labels: **200**  strong=77 provisional=79 caution=1 alias=0

## C0
- Covered bytes: **454** / 65536 (**0.693%**)
- Labels: **3**  strong=1 provisional=1 caution=0 alias=0

## C1
- Covered bytes: **13045** / 65536 (**19.905%**)
- Labels: **215**  strong=186 provisional=18 caution=1 alias=0

## C3
- Covered bytes: **853** / 65536 (**1.302%**)
- Labels: **2**  strong=2 provisional=0 caution=0 alias=0

## CC
- Covered bytes: **369** / 65536 (**0.563%**)
- Labels: **13**  strong=10 provisional=2 caution=0 alias=0

## CD
- Covered bytes: **2315** / 65536 (**3.532%**)
- Labels: **59**  strong=58 provisional=1 caution=0 alias=0

## CF
- Covered bytes: **1** / 65536 (**0.002%**)
- Labels: **1**  strong=1 provisional=0 caution=0 alias=0

## D0
- Covered bytes: **96** / 65536 (**0.146%**)
- Labels: **1**  strong=1 provisional=0 caution=0 alias=0

## D1
- Covered bytes: **735** / 65536 (**1.122%**)
- Labels: **23**  strong=15 provisional=6 caution=0 alias=0

## FD
- Covered bytes: **818** / 65536 (**1.248%**)
- Labels: **21**  strong=11 provisional=8 caution=0 alias=0

