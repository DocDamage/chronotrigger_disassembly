# Next Session Start Here

1. Read `notes/community_research_first.md`
2. Open these in order:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `dossiers/D1_dossier.md`
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - `chrono_trigger_disasm_pass83.md`
   - `chrono_trigger_labels_pass83.md`
   - `chrono_trigger_disasm_pass84.md`
   - `chrono_trigger_labels_pass84.md`
3. Active top-of-stack seam after pass 84:
   - confirm whether auxiliary token `0xE6` uses only `00/01` or multiple live nonzero mode bytes for `CFFF`
   - find exact external reader(s) of `CDC8` and `CE0F`
   - explain why `D1:F431` clears only positive `0x1x` descriptor headers while sparing the signed `0x8x` family
   - keep freezing the late auxiliary token cluster around `0xE3..0xE8`
   - then return to the remaining unresolved `0x88..0x9F` auxiliary families only after this D1 control neighborhood is tighter
4. Specific cleanup targets:
   - decide whether `7E:CFFF` should stay “mode byte” or be tightened further once real stream values are observed
   - decide whether `CDC8` is best described as a phase byte, latch byte, or another stricter noun once its reader is found
   - decide whether `CE0F` is a counter, epoch byte, arm latch, or another stricter noun once its reader is found
   - tighten the final nouns of the `2040/20A0/2120/21A0/2240/22A0/2320/23A0` page families
   - tighten the exact roles of `A101`, `2A21.bit1`, and the `0575.bit6` toggle in `D1:E70A`
5. Runtime confirmation shortlist:
   - live values written by auxiliary token `0xE6` into `CFFF`
   - whether the primary-slot helpers only use `0` and `1` in practice
   - first exact consumer(s) of `CDC8`
   - first exact consumer(s) of `CE0F`
   - live visual effect of the `D1:F431 / F457` gate on descriptor-driven palette behavior
