# Knowledge Graph Summary

- Nodes: **1009**
- Edges: **1412**

## Bank coverage from label graph
- `7E` -> **241** label-linked nodes
- `C1` -> **223** label-linked nodes
- `CD` -> **69** label-linked nodes
- `D1` -> **43** label-linked nodes
- `FD` -> **23** label-linked nodes
- `CC` -> **13** label-linked nodes
- `C0` -> **3** label-linked nodes
- `C3` -> **2** label-linked nodes
- `CE` -> **2** label-linked nodes
- `CF` -> **1** label-linked nodes
- `D0` -> **1** label-linked nodes

## Runtime-confirmed addresses
- none yet

## Strong current graph take
- The graph is now good enough to tie pass evidence, bank ownership, master opcode coverage, and imported runtime proof together in one place.

