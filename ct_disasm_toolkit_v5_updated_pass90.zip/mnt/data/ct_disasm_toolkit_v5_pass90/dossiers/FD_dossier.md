# Bank FD Dossier

- Label rows: **23**
- Latest pass touching bank: **75**

## Status mix
- provisional: **9**
- strong: **12**
- unspecified: **2**

## Top labels carried in this bank
- `FD:A8A5`  **ct_fd_service7_lane_block_is_eligible**  (strong, pass 42)
- `FD:A8CE`  **ct_fd_service7_clear_canonical_record_lane**  (strong, pass 42)
- `FD:A8FE`  **ct_fd_service7_clear_occupied_lane_and_refresh_service2**  (strong, pass 42)
- `FD:A93C`  **ct_fd_service7_dispatch_enabled_lane_clear_phase**  (strong, pass 42)
- `FD:A95F`  **ct_fd_service7_dispatch_enabled_lane_refresh_phase**  (strong, pass 42)
- `FD:A8FE`  **ct_fd_service7_clear_occupied_lane_and_refresh_service2**  (strong, pass 43)
- `FD:B820..FD:B850`  **ct_fd_seed_visible_lane_readiness_from_speed_like_stat**  (strong, pass 51)
- `FD:B8C0..FD:B8E0`  **ct_fd_seed_visible_lane_readiness_sibling_family**  (provisional, pass 51)
- `FD:B820..FD:B850`  **ct_fd_seed_primary_visible_lane_readiness_from_config_and_speed**  (strong, pass 52)
- `FD:B820..FD:B850`  **old wording “seed ... from speed-like stat”                 [soft-replaced]**  (unspecified, pass 52)
- `FD:B8C0..FD:B8E0`  **ct_fd_seed_sibling_visible_lane_readiness_from_config_and_speed**  (provisional, pass 52)
- `FD:A811`  **ct_fd_runtime_tail_slot_record_ptr_table**  (provisional, pass 53)
- `FD:B800..FD:B94F`  **ct_fd_seed_battle_slot_readiness_head_and_tail_partitions**  (strong, pass 53)
- `FD:B8F5..FD:B93A`  **ct_fd_normalize_head_readiness_work_before_visible_export**  (provisional, pass 53)
- `FD:B8F5..FD:B93A`  **ct_fd_normalize_head_readiness_work_before_visible_export**  (unspecified, pass 54)
- `FD:B8F7..FD:B93A`  **ct_fd_normalize_active_battle_slot_readiness_to_minimum_one_before_head_export**  (strong, pass 54)
- `FD:B91B..FD:B939`  **ct_fd_subtract_selected_minimum_minus_one_from_active_positive_readiness_entries**  (provisional, pass 54)
- `FD:B24D..FD:B27E`  **ct_fd_initialize_head_battle_slot_occupant_maps_from_party_state**  (provisional, pass 55)
- `FD:B28F..FD:B2A3`  **ct_fd_rebuild_visible_head_battler_to_slot_inverse_map**  (provisional, pass 55)
- `FD:B2A3..B2DD`  **ct_build_tail_live_and_canonical_occupant_maps**  (strong, pass 56)
- `FD:ACEE..FD:ACFC`  **ct_fd_clear_ad9b_and_transient_ad9c_packet_workspace**  (strong, pass 74)
- `FD:ABA2..FD:AC6D`  **ct_fd_accumulate_slot_descriptor_vectors_and_optional_unique_token_queues**  (provisional, pass 75)
- `FD:AC6E..FD:ACEE`  **ct_fd_consume_pending_slot_queue_and_attempt_admission_materialization**  (provisional, pass 75)

## Highest-value open work
- deeper ownership around readiness/timer normalization and seeding families
- decompressor/data-format work remains outside the currently solved timer and lane helpers

## Notes
- Generated from the persistent label DB. Use this as the fast bank-local briefing before reopening pass notes.

