# Rebuild / Diff Report

Assembler-bound rebuild comparison is not available yet.

## Current status
- Source tree scaffold exists in `source/`.
- Freeze map exists in `state/range_freeze.json`.
- This report will switch to real byte-diff mode once a rebuilt ROM is supplied.

## Expected next step
- Original ROM: `/mnt/data/Chrono Trigger (USA).sfc`
- Rebuilt ROM target: `/mnt/data/ct_disasm_toolkit_v5_pass90/build/rebuild/chrono_trigger_rebuilt.sfc`

Run again with both ROMs present to get a real byte-difference report.
