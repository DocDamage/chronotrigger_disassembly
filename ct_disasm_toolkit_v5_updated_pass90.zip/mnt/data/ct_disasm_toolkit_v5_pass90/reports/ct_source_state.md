# Source State Report

- Total label rows represented: **591**
- Frozen/stable ranges: **409**

## Banks
- 7E: `source/banks/wram_7E.asm`  groups=139 rows=221
- C0: `source/banks/bank_C0.asm`  groups=3 rows=3
- C1: `source/banks/bank_C1.asm`  groups=195 rows=215
- C3: `source/banks/bank_C3.asm`  groups=2 rows=2
- CC: `source/banks/bank_CC.asm`  groups=10 rows=13
- CD: `source/banks/bank_CD.asm`  groups=67 rows=69
- CE: `source/banks/bank_CE.asm`  groups=2 rows=2
- CF: `source/banks/bank_CF.asm`  groups=1 rows=1
- D0: `source/banks/bank_D0.asm`  groups=1 rows=1
- D1: `source/banks/bank_D1.asm`  groups=34 rows=43
- FD: `source/banks/bank_FD.asm`  groups=18 rows=21

## Notes
- This is a scaffold-first source tree, not a byte-perfect assembled disassembly yet.
- Use the rebuild/diff report to track assembler integration progress.
