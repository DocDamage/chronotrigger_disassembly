# Range Freeze Summary

This file is the V5 range lock / freeze map.

- Total frozen/stable ranges: **409**

## 7E
- Entries: **92**
- `7E:0300..7E:0302` :: **confirmed** :: ct_c3_unpack_source_pointer
- `7E:0303..7E:0305` :: **confirmed** :: ct_c3_unpack_destination_pointer
- `7E:0306..7E:0307` :: **confirmed** :: ct_c3_unpack_output_size_or_destination_advance
- `7E:0520..7E:0543` :: **confirmed** :: ct_palette_effect_descriptor_active_slab_3x12byte_records
- `7E:0520..7E:057F` :: **confirmed** :: ct_palette_effect_descriptor_queue_8x12byte_records
- `7E:0544..7E:0567` :: **confirmed** :: ct_palette_effect_descriptor_secondary_slab_3x12byte_records
- `7E:0568..7E:057F` :: **confirmed** :: ct_palette_effect_descriptor_tail_slab_2x12byte_records
- `7E:0B40` :: **confirmed** :: / 00:0B40  ct_c1_tilemap_staging_buffer_vram7a00_0180        [strong]
- `7E:0B40` :: **confirmed** :: / 00:0B40  ct_c1_tilemap_strip_buffer_32x6_words_vram7a00     [strong]
- `7E:2D00..7E:2DFF` :: **confirmed** :: ct_c1_service04_packed_fragment_row_stream_workspace
- `7E:2D00..7E:2DFF` :: **confirmed** :: ct_c1_service04_packed_tile_row_or_tile_batch_workspace
- `7E:5D9B` :: **confirmed** :: ct_cd_optional_auxiliary_descriptor_stage_active_flag
- `7E:5DA0..7E:5DA5` :: **confirmed** :: ct_cd_auxiliary_current_sixbyte_live_vector
- `7E:5DA0..7E:5DA5` :: **confirmed** :: ct_cd_d1_current_three_pair_point_bundle
- `7E:5E2F.bit0` :: **confirmed** :: ct_c1_lane_low_hp_critical_flag                      [strong]
- `7E:5E30` :: **confirmed** :: ct_c1_lane_current_hp
- `7E:5E32` :: **confirmed** :: ct_c1_lane_max_hp
- `7E:93EE` :: **confirmed** :: ct_c1_service7_record_status_flags
- `7E:93EF` :: **confirmed** :: ct_c1_service7_record_aux_flags
- `7E:93F3` :: **confirmed** :: ct_c1_service7_record_lane_pair
- ... 72 more

## C0
- Entries: **1**
- `C0:FD00..C0:FDFF` :: **confirmed** :: ct_c0_bit_reverse_lookup_256

## C1
- Entries: **186**
- `C1:011B` :: **confirmed** :: ct_c1_lsr3_entry
- `C1:011F` :: **confirmed** :: ct_c1_format_u16_as_three_decimal_tile_bytes_949d_949f
- `C1:0174` :: **confirmed** :: ct_c1_format_u16_as_two_decimal_tile_bytes_949e_949f
- `C1:06F0` :: **confirmed** :: ct_c1_render_scaled_lane_bar_into_0cc0
- `C1:07BD` :: **confirmed** :: ct_c1_blit_companion_strip_template_a_into_0cc0_pair29
- `C1:07EE` :: **confirmed** :: ct_c1_blit_companion_strip_template_b_into_0cc0_pair29
- `C1:081F` :: **confirmed** :: ct_c1_compose_three_slot_panel_strip_into_0b40
- `C1:086D` :: **confirmed** :: ct_c1_clear_current_companion_strip_slice_0cc0
- `C1:08E8` :: **confirmed** :: ct_c1_update_current_companion_strip_slice
- `C1:0929` :: **confirmed** :: ct_c1_blit_6row_panel_segment_into_0b40_merge_left_border
- `C1:0958` :: **confirmed** :: ct_c1_rebuild_companion_record_buffer_0e80
- `C1:09B0` :: **confirmed** :: ct_c1_emit_fixed_format_companion_record
- `C1:104E` :: **confirmed** :: ct_c1_blank_leading_zero_decimal_tiles_949d_949e
- `C1:1918` :: **confirmed** :: ct_c1_refresh_current_0e80_lane_marker_glyphs
- `C1:1B19` :: **confirmed** :: ct_c1_service1_enqueue_lane_and_mark_record_active
- `C1:1B69` :: **confirmed** :: ct_c1_promote_pending_lane_into_active_roster
- `C1:1BAA` :: **confirmed** :: ct_c1_service2_remove_lane_and_reseat_active_controller
- `C1:1C3A` :: **confirmed** :: ct_c1_service2_restore_default_tilemap_template_0b40
- `C1:1C3A` :: **confirmed** :: ct_c1_service2_restore_workspace_template_0b40
- `C1:2BBC` :: **confirmed** :: relation-query mode `05`
- ... 166 more

## C3
- Entries: **2**
- `C3:0002..C3:0004` :: **confirmed** :: ct_c3_unpack_stream_to_caller_selected_wram_buffer_veneer
- `C3:0557..C3:08A8` :: **confirmed** :: ct_c3_unpack_packed_stream_to_wram_via_2180_and_return_output_size

## CC
- Entries: **10**
- `CC:2E31` :: **confirmed** :: ct_cc_battle_speed_page_speed_to_readiness_seed_adjust_table
- `CC:2E31` :: **confirmed** :: ct_cc_speed_like_stat_to_readiness_bonus_table
- `CC:8B08..CC:8C53` :: **confirmed** :: ct_late_selector_control_pointer_records
- `CC:94A0` :: **confirmed** :: ct_cc_companion_record_template_table
- `CC:F903` :: **confirmed** :: ct_cc_decimal_digit_tile_table_73_to_7c
- `CC:FA23..CC:FA3F` :: **confirmed** :: ct_cc_companion_strip_lane_anchor_offset_family
- `CC:FA41` :: **confirmed** :: ct_cc_companion_strip_template_a_6x7_bytes
- `CC:FA6B` :: **confirmed** :: ct_cc_companion_strip_template_b_6x7_bytes
- `CC:FADD` :: **confirmed** :: ct_cc_companion_strip_lane_block_offsets_0000_0080_0100
- `CC:FAE9` :: **confirmed** :: ct_cc_companion_record_lane_marker_offsets_0002_0082_0102

## CD
- Entries: **68**
- `CD:0015..CD:0017` :: **confirmed** :: ct_cd_build_first_four_packed_fragment_row_sections_into_2d00_veneer
- `CD:0018..CD:001A` :: **confirmed** :: ct_cd_optional_selector_driven_auxiliary_fragment_stage_veneer
- `CD:002A..CD:002C` :: **confirmed** :: ct_cd_build_last_two_packed_fragment_row_sections_into_2d00_veneer
- `CD:0D28..CD:0D32` :: **confirmed** :: ct_cd_optional_selector_driven_auxiliary_fragment_stage
- `CD:0D33..CD:0D5F` :: **confirmed** :: ct_cd_clear_auxiliary_fragment_work_tables_and_expand_ca93_descriptor_list
- `CD:0EBD..CD:0F9F` :: **confirmed** :: ct_cd_init_auxiliary_fragment_stage_by_selector_and_battle_layout
- `CD:1308..CD:1313` :: **confirmed** :: ct_cd_packed_fragment_row_section_base_offsets_000c_000e_0010_0012_0014_0016
- `CD:1314..CD:1322` :: **confirmed** :: ct_cd_build_last_two_packed_fragment_row_sections_into_2d00
- `CD:1323..CD:13C8` :: **confirmed** :: ct_cd_build_first_four_packed_fragment_row_sections_into_2d00
- `CD:13E6..CD:13ED` :: **confirmed** :: ct_cd_tile_orientation_mode_ptr_table_direct_hflip_vflip_hvflip
- `CD:13EE..CD:13F5` :: **confirmed** :: ct_cd_materialize_tile_then_apply_hv_flip_composite_path
- `CD:13F6..CD:1444` :: **confirmed** :: ct_cd_materialize_tile_then_apply_vertical_flip_to_both_plane_halves
- `CD:1445..CD:1484` :: **confirmed** :: ct_cd_materialize_tile_then_apply_horizontal_flip_via_c0_fd00_bit_reverse
- `CD:1488..CD:1508` :: **confirmed** :: ct_cd_materialize_base_tile_planes_and_masked_upper_half_from_d0_source_block
- `CD:1509..CD:15D4` :: **confirmed** :: ct_cd_materialize_one_32byte_4bpp_tile_block_from_d0_source_with_optional_second_block_merge
- `CD:15D5..CD:1608` :: **confirmed** :: ct_cd_expand_one_auxiliary_descriptor_id_into_one_active_runtime_slot
- `CD:1609..CD:16A5` :: **confirmed** :: ct_cd_tick_two_auxiliary_descriptor_runtime_slots_and_interpret_ready_tokens
- `CD:1654..CD:169F` :: **confirmed** :: ct_cd_interpret_one_auxiliary_stream_token_and_derive_d0_tile_block_request_or_dispatch_command
- `CD:16A6..CD:16B4` :: **confirmed** :: ct_cd_dispatch_one_auxiliary_command_token_80_ff_by_low7_id
- `CD:16B5..CD:17A6` :: **confirmed** :: ct_cd_auxiliary_command_token_ptr_table_80_ff
- ... 48 more

## CE
- Entries: **2**
- `CE:E000..CE:E08D` :: **confirmed** :: ct_ce_mirror_selected_0x6c_band_between_primary_and_shadow_eight_table_raster_target_bundles
- `CE:E18E..CE:E1A4` :: **confirmed** :: ct_ce_clear_cd47_cdc6_work_strip_only_when_cdc8_nonzero

## CF
- Entries: **1**
- `CF:E380` :: **confirmed** :: ct_cf_upload_pending_tilemap_0b40_to_vram_7a00

## D0
- Entries: **1**
- `D0:FD00..D0:FD5F` :: **confirmed** :: ct_d0_palette_band_seed_block_48colors_for_d1_e984

## D1
- Entries: **35**
- `D1:5800` :: **confirmed** :: ct_d1_tilemap_template_default_0b40_0180
- `D1:59FC` :: **confirmed** :: ct_d1_panel_segment_template_6x7_words
- `D1:5A50` :: **confirmed** :: ct_d1_tilemap_template_alt_a_0b40_0180
- `D1:5BD0` :: **confirmed** :: ct_d1_tilemap_template_alt_b_0b40_0180
- `D1:646C..D1:652B` :: **confirmed** :: ct_d1_auxiliary_descriptor_pointer_table
- `D1:E70A..D1:E77B` :: **confirmed** :: ct_d1_optional_exchange_secondary_and_tertiary_palette_band_pairs
- `D1:E899..D1:E8C0` :: **confirmed** :: ct_d1_fill_palette_band_pairs_2040_2240_and_2120_2320_with_7fff_sentinel
- `D1:E8C1..D1:E8D4` :: **confirmed** :: ct_d1_fill_palette_band_pair_21a0_23a0_with_7fff_sentinel
- `D1:E91A..D1:E983` :: **confirmed** :: ct_d1_promote_first_48color_palette_band_and_restore_active_3record_descriptor_slab
- `D1:E984..D1:E9EB` :: **confirmed** :: ct_d1_seed_first_48color_palette_band_from_d0_fd00_and_snapshot_active_descriptor_slab_outward
- `D1:EC27..D1:EC5B` :: **confirmed** :: ct_d1_build_four_endpoint_pairs_from_mulhi_and_current_5da0_5da1_pair_then_call_f9af
- `D1:EDCD..D1:EE95` :: **confirmed** :: ct_d1_expand_current_5da0_5da1_axis_pair_by_cd3a_cd3b_into_four_plane_span_strips
- `D1:EDCD..D1:EE2F` :: **confirmed** :: ct_d1_stamp_clamped_lower_edge_byte_into_selected_primary_or_shadow_four_lane_family
- `D1:EE33..D1:EE95` :: **confirmed** :: ct_d1_fill_selected_primary_or_shadow_companion_word_lane_across_clamped_span
- `D1:EEA6..D1:EEC4` :: **confirmed** :: ct_d1_seed_descending_word_ramp_into_primary_c15f_lane_family_from_cd3a
- `D1:EEC5..D1:F107` :: **confirmed** :: ct_d1_build_primary_four_lane_curve_profile_from_cef48e_e500_and_center_words
- `D1:EF63..D1:EFCF` :: **confirmed** :: ct_d1_store_signed_profile_sample_into_primary_c15d_and_c161_lanes_and_prime_secondary_multiply
- `D1:F0E9..D1:F107` :: **confirmed** :: ct_d1_store_signed_profile_sample_into_primary_c15f_and_c163_lanes
- `D1:F260..D1:F297` :: **confirmed** :: ct_d1_reset_control_cluster_state_including_ce0f_ce12_and_cfff
- `D1:F331..D1:F410` :: **confirmed** :: ct_d1_seed_local_lane_and_raster_workspace_then_invoke_four_stage_followup_pipeline
- ... 15 more

## FD
- Entries: **11**
- `FD:A8A5` :: **confirmed** :: ct_fd_service7_lane_block_is_eligible
- `FD:A8CE` :: **confirmed** :: ct_fd_service7_clear_canonical_record_lane
- `FD:A8FE` :: **confirmed** :: ct_fd_service7_clear_occupied_lane_and_refresh_service2
- `FD:A93C` :: **confirmed** :: ct_fd_service7_dispatch_enabled_lane_clear_phase
- `FD:A95F` :: **confirmed** :: ct_fd_service7_dispatch_enabled_lane_refresh_phase
- `FD:ACEE..FD:ACFC` :: **confirmed** :: ct_fd_clear_ad9b_and_transient_ad9c_packet_workspace
- `FD:B2A3..B2DD` :: **confirmed** :: ct_build_tail_live_and_canonical_occupant_maps
- `FD:B800..FD:B94F` :: **confirmed** :: ct_fd_seed_battle_slot_readiness_head_and_tail_partitions
- `FD:B820..FD:B850` :: **confirmed** :: ct_fd_seed_primary_visible_lane_readiness_from_config_and_speed
- `FD:B820..FD:B850` :: **confirmed** :: ct_fd_seed_visible_lane_readiness_from_speed_like_stat
- `FD:B8F7..FD:B93A` :: **confirmed** :: ct_fd_normalize_active_battle_slot_readiness_to_minimum_one_before_head_export

