; Chrono Trigger bank D1 skeleton
; Generated from current evidence. This is not a complete reassemblable bank yet.

.bank $D1

; D1:5800 [strong] pass 44
ct_d1_tilemap_template_default_0b40_0180:
    ; TODO: lift real code/data for D1:5800
    ; Default/reset ROM template copied into `0B40` by `C1:1C3A`. Same size as the upload buffer and structurally part of the same tilemap-templat

; D1:5800 [unspecified] pass 44
__D1_5A50___D1_5BD0__ct_d1_tilemap_template_family_16x12_words__provisional_:
    ; TODO: lift real code/data for D1:5800
    ; The three source blocks are best interpreted as a 192-word (likely 16x12) template family. This matrix interpretation fits both the dense ro

; D1:5800 [unspecified] pass 45
__D1_5A50___D1_5BD0__ct_d1_base_strip_template_family_32x6______strong_:
    ; TODO: lift real code/data for D1:5800
    ; Corrected geometrically in this pass. All three `0x0180`-byte base templates are best modeled as 32-word by 6-row strip layouts. Used as the

; D1:5800 [provisional] pass 45
__D1_5A50___D1_5BD0__ct_d1_tilemap_template_family_16x12_words__withdrawn_:
    ; TODO: lift real code/data for D1:5800
    ; Pass 45 corrects this earlier provisional geometry. The safer keepable geometry is `32x6`, not `16x12`.

; D1:5800 [provisional] pass 45
__D1_5A50___D1_5BD0__ct_d1_alt_base_strip_layout_family_________provisional_:
    ; TODO: lift real code/data for D1:5800
    ; The three templates are clearly alternate base layouts within the same 32x6 strip region. Exact gameplay/UI mode names are still unresolved.

; D1:5800 [provisional] pass 46
__D1_5A50___D1_5BD0__ct_d1_alt_base_strip_layout_family_______strengthened_context_:
    ; TODO: lift real code/data for D1:5800
    ; Pass 46 strengthens their caller-context roles: `5800` = default/base restore through `C1:1C3A` `5A50` = latched alternate via `A86A` `5BD0`

; D1:5800 [provisional] pass 46
ct_d1_base_strip_template_default:
    ; TODO: lift real code/data for D1:5800
    ; Caller context strongly suggests the default/base restore variant. Final gameplay-facing mode name still open.

; D1:59FC [strong] pass 45
ct_d1_panel_segment_template_6x7_words:
    ; TODO: lift real code/data for D1:59FC
    ; Unique ROM source table used by `C1:0929`. Resolves cleanly as 6 rows of 7 words. Tile values form a compact border/interior segment templat

; D1:5A50 [strong] pass 44
ct_d1_tilemap_template_alt_a_0b40_0180:
    ; TODO: lift real code/data for D1:5A50
    ; Alternate ROM template variant copied into `0B40` by the `0EA1..0EB1` path. Followed by `INC $99E2`, proving it feeds the same upload path a

; D1:5A50 [provisional] pass 46
ct_d1_base_strip_template_latched_alt:
    ; TODO: lift real code/data for D1:5A50
    ; Single-shot alternate selected when `A86A` is nonzero, then that latch is cleared. Kept provisional until the higher-level mode name is pinn

; D1:5BD0 [strong] pass 44
ct_d1_tilemap_template_alt_b_0b40_0180:
    ; TODO: lift real code/data for D1:5BD0
    ; Alternate ROM template variant copied into `0B40` by the `1301..1315`, Followed by `INC $99E2`, proving it feeds the same upload path as the

; D1:5BD0 [provisional] pass 46
ct_d1_base_strip_template_transition_alt:
    ; TODO: lift real code/data for D1:5BD0
    ; Copied in later state-transition/reset paths with surrounding controller bookkeeping. Strong structural role, but final mode name still unre

; D1:646C..D1:652B [strong] pass 79
ct_d1_auxiliary_descriptor_pointer_table:
    ; TODO: lift real code/data for D1:646C..D1:652B
    ; `15D5` multiplies the descriptor id by two and reads a pointer from this table. The returned pointer seeds one active runtime slot in the op

; D1:E70A..D1:E77B [strong] pass 83
ct_d1_optional_exchange_secondary_and_tertiary_palette_band_pairs:
    ; TODO: lift real code/data for D1:E70A..D1:E77B
    ; Clears `A101`. Tests `2A21.bit1`; when set, toggles bit `0x40` in `0575`. Exchanges the full 48-word pairs `2120..217F <-> 21A0..21FF` and `

; D1:E899..D1:E8C0 [strong] pass 82
ct_d1_fill_palette_band_pairs_2040_2240_and_2120_2320_with_7fff_sentinel:
    ; TODO: lift real code/data for D1:E899..D1:E8C0
    ; Fills `7E:2040..20FF` and `7E:2240..22FF` with `0x7FFF`. Then fills `7E:2120..217F` and `7E:2320..237F` with the same sentinel. Exact struct

; D1:E8C1..D1:E8D4 [strong] pass 82
ct_d1_fill_palette_band_pair_21a0_23a0_with_7fff_sentinel:
    ; TODO: lift real code/data for D1:E8C1..D1:E8D4
    ; Fills `7E:21A0..21FF` and `7E:23A0..23FF` with `0x7FFF`. Exact smaller sibling of `D1:E899`.

; D1:E91A..D1:E983 [strong] pass 82
ct_d1_promote_first_48color_palette_band_and_restore_active_3record_descriptor_slab:
    ; TODO: lift real code/data for D1:E91A..D1:E983
    ; Copies `7E:2040..209F` into `7E:20A0..20FF` and `7E:22A0..22FF`, then clears `7E:2040..209F` and `7E:2240..229F`. Copies `7E:0544..0567` bac

; D1:E984..D1:E9EB [strong] pass 82
ct_d1_seed_first_48color_palette_band_from_d0_fd00_and_snapshot_active_descriptor_slab_outward:
    ; TODO: lift real code/data for D1:E984..D1:E9EB
    ; Increments `CDC8` and `CE0F`. Copies ROM data from `D0:FD00..FD5F` into `7E:2040..209F` and `7E:2240..229F`. Copies `7E:0520..0543` outward 

; D1:EC27..D1:EC5B [strong] pass 86
ct_d1_build_four_endpoint_pairs_from_mulhi_and_current_5da0_5da1_pair_then_call_f9af:
    ; TODO: lift real code/data for D1:EC27..D1:EC5B
    ; Reads one immediate/index through `[$40]`, transforms the `4217` multiply-result high byte, builds four endpoint pairs in `CD0D..CD1B`, uses

; D1:EDCD..D1:EE95 [strong] pass 86
ct_d1_expand_current_5da0_5da1_axis_pair_by_cd3a_cd3b_into_four_plane_span_strips:
    ; TODO: lift real code/data for D1:EDCD..D1:EE95
    ; Selector `[$40] == 0` path uses `5DA0` and `CD3A`, clamps low/high bounds, and fills one of two four-plane strip families with the computed 

; D1:EDCD..D1:EE2F [strong] pass 89
ct_d1_stamp_clamped_lower_edge_byte_into_selected_primary_or_shadow_four_lane_family:
    ; TODO: lift real code/data for D1:EDCD..D1:EE2F
    ; Reads one selector byte from `[$40]` and takes this path only when that selector is zero. Computes `low = max(0, 5DA0 - CD3A)` and `high = m

; D1:EE33..D1:EE95 [strong] pass 89
ct_d1_fill_selected_primary_or_shadow_companion_word_lane_across_clamped_span:
    ; TODO: lift real code/data for D1:EE33..D1:EE95
    ; This is the selector-nonzero path from the same local cluster. Computes `low = max(0, 5DA1 - CD3B)` and `high = min(0xD4, 5DA1 + CD3B)`. If 

; D1:EEA6..D1:EEC4 [strong] pass 89
ct_d1_seed_descending_word_ramp_into_primary_c15f_lane_family_from_cd3a:
    ; TODO: lift real code/data for D1:EEA6..D1:EEC4
    ; Computes `Y = (0xC0 - CD3A) * 4`. With `A=0`, stores ascending 16-bit values `0, 1, 2, ...` into `C15F + Y`, stepping backwards by 4 each it

; D1:EEC5..D1:F107 [strong] pass 89
ct_d1_build_primary_four_lane_curve_profile_from_cef48e_e500_and_center_words:
    ; TODO: lift real code/data for D1:EEC5..D1:F107
    ; Updates `CD3A` from the stream byte at `[$40]`. Derives `4B = 0x60 - CD3A`, `4D = (0x60 - CD3A) >> 1`, `45 = 7C * 4`, `47 = 7C * 2`. Builds 

; D1:EF63..D1:EFCF [strong] pass 89
ct_d1_store_signed_profile_sample_into_primary_c15d_and_c161_lanes_and_prime_secondary_multiply:
    ; TODO: lift real code/data for D1:EF63..D1:EFCF
    ; Sign-extends the sampled byte when required. Adds it to baseline table word `E500,Y`. Stores the result to both `C15D,Y` and `C161,Y`. Then 

; D1:F0E9..D1:F107 [strong] pass 89
ct_d1_store_signed_profile_sample_into_primary_c15f_and_c163_lanes:
    ; TODO: lift real code/data for D1:F0E9..D1:F107
    ; Sign-extends the sampled byte when required. Adds it to center word `51`. Stores the result to both `C15F,Y` and `C163,Y`. Strongest safe re

; D1:F260..D1:F297 [strong] pass 84
ct_d1_reset_control_cluster_state_including_ce0f_ce12_and_cfff:
    ; TODO: lift real code/data for D1:F260..D1:F297
    ; Exact writes in this subsection clear `CE0E / CE0F / CE10 / CE12 / CFFF` and seed neighboring D1 control bytes. Strongest safe reading: loca

; D1:F331..D1:F410 [strong] pass 90
ct_d1_seed_local_lane_and_raster_workspace_then_invoke_four_stage_followup_pipeline:
    ; TODO: lift real code/data for D1:F331..D1:F410
    ; Clears `C861 / C862`. Seeds `CD46` from `2A21.bit0` as exact `00` vs `FD`. Seeds exact constants into `C14F / C150`, `BEA1 / BEA5 / BEA9`, `

; D1:F411..D1:F426 [strong] pass 83
ct_d1_snapshot_palette_descriptor_header_bytes_8slots_to_cd2f_cd36:
    ; TODO: lift real code/data for D1:F411..D1:F426
    ; Walks the 8-slot `0520 + n*0C` descriptor queue. Copies the first byte of each slot (`0520/052C/0538/0544/0550/055C/0568/0574`) into `CD2F..

; D1:F427..D1:F430 [strong] pass 83
ct_d1_select_descriptor_header_suspend_or_restore_by_cfff:
    ; TODO: lift real code/data for D1:F427..D1:F430
    ; Reads `CFFF`. `CFFF != 0` jumps to the shadow-and-suspend path at `D1:F431`. `CFFF == 0` jumps to the restore path at `D1:F457`.

; D1:F431..D1:F456 [strong] pass 83
ct_d1_arm_ce12_shadow_descriptor_headers_and_suspend_family_10_slots:
    ; TODO: lift real code/data for D1:F431..D1:F456
    ; Returns immediately when `CE12 != 0`. Otherwise increments `CE12`, snapshots all 8 descriptor headers through `D1:F411`, and scans the full 

; D1:F457..D1:F473 [strong] pass 83
ct_d1_restore_shadowed_descriptor_headers_from_cd2f_cd36_and_clear_ce12:
    ; TODO: lift real code/data for D1:F457..D1:F473
    ; Returns immediately when `CE12 == 0`. Otherwise clears `CE12` and restores `CD2F..CD36` back into the first byte of all 8 descriptor slots. 

; D1:F474..D1:F47B [strong] pass 90
ct_d1_lookup_c0fe00_byte_indexed_by_a_plus_7c:
    ; TODO: lift real code/data for D1:F474..D1:F47B
    ; Exact body: `ADC $7C ; TAX ; LDA C0:FE00,X ; RTS`. Strongest safe reading: tiny lookup helper over table `C0:FE00`, indexed by `A + 7C`.

; D1:F47C..D1:F4BF [strong] pass 90
ct_d1_stage_negated_masked_pair_into_ca5a_ca5c_from_stream_and_c0fe00_lookup:
    ; TODO: lift real code/data for D1:F47C..D1:F4BF
    ; Reads two exact stream-side bytes through `[$40]` / `[$40],Y`. Uses `D1:F474` to fetch lookup bytes from `C0:FE00` indexed by `A + 7C`. Appl

; D1:F5CD..D1:F5F2 [strong] pass 86
ct_d1_snapshot_current_5da0_5da5_three_pair_bundle_into_indexed_caea_record:
    ; TODO: lift real code/data for D1:F5CD..D1:F5F2
    ; Exact body copies `5DA0/5DA2/5DA4/5DA1/5DA3/5DA5` into `CAEA/CAEE/CAF2/CAEC/CAF0/CAF4` using the immediate byte from `[$40]` as X index. Str

; D1:F5F6..D1:F676 [strong] pass 88
ct_d1_mirror_selected_0x70_band_between_primary_and_shadow_companion_raster_target_bundles:
    ; TODO: lift real code/data for D1:F5F6..D1:F676
    ; Mirrors one selected `0x70` window between the exact root families below, in `X += 4` steps. Exact primary roots: `C163 / C1D3 / C243 / C2B3

; D1:F83D..D1:F8EA [strong] pass 90
ct_d1_seed_c030_c090_c0f0_c120_quartet_table_family_and_tail_sentinels:
    ; TODO: lift real code/data for D1:F83D..D1:F8EA
    ; Clears `C02F..C14E` across an exact `0x0120`-byte span. Builds 24 exact 4-byte records in the `C030/C031` and `C090/C091` neighborhoods usin

; D1:F8EB..D1:F91B [strong] pass 87
ct_d1_sort_four_row_column_point_pairs_by_column_byte_ascending:
    ; TODO: lift real code/data for D1:F8EB..D1:F91B
    ; Exact body is a four-pass bubble-sort-style loop comparing `13/15/17/19` and swapping the paired bytes `12/14/16/18` in lockstep. Strongest 

; D1:F91C..D1:F971 [strong] pass 87
ct_d1_compute_four_signed_row_per_column_edge_steps_for_cd0d_fourpoint_bundle:
    ; TODO: lift real code/data for D1:F91C..D1:F971
    ; Calls `F972` four times and stores the returned signed steps into local slope slots `03 / 05 / 07 / 09`. Exact edge schedule is `(12,13)->(1

; D1:F972..D1:F9AE [strong] pass 87
ct_d1_compute_signed_row_per_column_step_via_hw_divide:
    ; TODO: lift real code/data for D1:F972..D1:F9AE
    ; Uses `4204/4206` and reads quotient `4214` after taking the signed row delta between `0B` and `0C` and the column delta in `0D`. Restores si

; D1:F9AF..D1:F9E6 [strong] pass 87
ct_d1_load_cd0d_fourpoint_bundle_set_cc64_target_selector_sort_and_dispatch_column_rasterizer:
    ; TODO: lift real code/data for D1:F9AF..D1:F9E6
    ; Saves `X` into `CC64`, loads `CD0D..CD1B` into `12..19`, calls `F8EB`, temporarily sets `DB=00`, then calls `F9E7`. Strongest safe reading: 

; D1:F9E7..D1:FB67 [strong] pass 87
ct_d1_column_rasterize_sorted_fourpoint_bundle_into_wram_port_target_in_three_cases:
    ; TODO: lift real code/data for D1:F9E7..D1:FB67
    ; Chooses among three exact cases from `13 == 15` and the middle-row ordering test `16 ? 14`. All three cases call `CD:38B2` with start column

; D1:FD80..D1:FE46 [strong] pass 88
ct_d1_transform_and_mirror_selected_0x70_band_between_companion_raster_target_bundles:
    ; TODO: lift real code/data for D1:FD80..D1:FE46
    ; Uses the exact same root families as `D1:F5F6..F676`, but applies `EOR #$FFFF ; XBA` before every store. `7C.bit0` again chooses direction. 

