# Global Opcode 2C

- Status: **strong**
- Dispatch address: **C1:98C4**
- Evidence pass: **67**
- Notes: Exact single-byte RTS alias

## Matching label evidence
- pass 67: `C1:98C4..C1:98C4` **ct_global_opcode_2C_rts_noop_alias** (strong)
  - Exact single-byte `RTS`.
