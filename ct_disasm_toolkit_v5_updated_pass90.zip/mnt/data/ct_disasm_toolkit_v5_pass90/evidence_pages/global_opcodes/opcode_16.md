# Global Opcode 16

- Status: **strong**
- Dispatch address: **C1:95D6**
- Evidence pass: **66**
- Notes: Exact alias of the unconditional JSR $8C3E ; RTS replay step

## Matching label evidence
- pass 66: `C1:95D6..C1:95D9` **ct_global_opcode_16_unconditional_tail_replay_step_alias** (strong)
  - Exact alias of the unconditional `8C3E ; RTS` replay step.
