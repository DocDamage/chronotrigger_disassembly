# Global Opcode 7B

- Status: **strong structural**
- Dispatch address: **C1:A9E9**
- Evidence pass: **71**
- Notes: Nonhead masked AE70 -> ADA1 selector family for record[+1D] & 0x02, scanning live slots 3..10 and skipping the primary-seed slot indexed by B18B.

## Matching label evidence
- pass 71: `C1:A9E9..C1:AA24` **ct_global_opcode_7B_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1D_mask_02** (strong)
  - Uses the shared nonhead FD-offset/mask pipeline. Tests `record[+1D] & 0x02`. Skips the primary-seed slot indexed by `B18B`.
