# Global Opcode 01

- Status: **strong structural**
- Dispatch address: **C1:8EAB**
- Evidence pass: **63**
- Notes: Calls AC14; filters selected entries through FD:A80B-rooted records using +1D sign gate and +3 <= (+5 >> 1); accepted entries incremented in AECC then finalized through AE21/AEFD/8C3E when AF24==0

## Matching label evidence
- pass 63: `C1:8EAB..C1:8F10` **ct_global_opcode_01_filter_selected_entries_by_fd_record_threshold** (strong)
  - Calls `AC14`, so operand `+1` is an inline selector-control byte. Uses the resulting `AECC/AECB` selected list as input. For each selected entry: resolves a structured-record base via `FD:A80B` requires record byte `+1D` to be non-negative accepts only when record byte `+3` is less than or equal to `(record byte +5) >> 1` Accepted entries are incremented in-place in `AECC`. Writes accepted-count back to `AECB`. Runs `AE21`, then if `AF24 == 0` runs `AEFD` and `8C3E`. Empty input selection does **not** force `AF24 = 1`. Best carried as a selector-driven filtered-list transform, not a pure boolean gate.
