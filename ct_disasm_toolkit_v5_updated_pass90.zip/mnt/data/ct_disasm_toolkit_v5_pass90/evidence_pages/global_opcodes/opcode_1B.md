# Global Opcode 1B

- Status: **strong structural**
- Dispatch address: **C1:96A5**
- Evidence pass: **66**
- Notes: Counts non-FF entries in AEFF[0..2]; effective success predicate is visible-head live count <= operand1

## Matching label evidence
- pass 66: `C1:96A5..C1:96D3` **ct_global_opcode_1B_gate_tail_replay_on_visible_head_live_count_at_or_below_immediate** (strong)
  - Counts non-`FF` entries in `AEFF[0..2]`. Uses `operand+1 + 1` internally, so the effective success predicate is: visible-head live count `<= operand+1`
