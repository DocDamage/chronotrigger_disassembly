# Global Opcode 1D

- Status: **strong structural**
- Dispatch address: **C1:9728**
- Evidence pass: **66**
- Notes: Calls AC14, uses AECC[0] as selected entry index, reads AF02[selected], and operand2 selects presence vs absence polarity

## Matching label evidence
- pass 66: `C1:9728..C1:975B` **ct_global_opcode_1D_gate_tail_replay_on_selected_tail_live_presence_mode** (strong)
  - Calls `AC14`. Uses `AECC[0]` as the selected entry index. Reads `AF02[selected]`. Operand `+2` selects presence vs absence polarity.
