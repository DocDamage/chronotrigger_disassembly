# Global Opcode 70

- Status: **strong structural**
- Dispatch address: **C1:A765**
- Evidence pass: **71**
- Notes: Scans occupied nonhead live slots 3..10, compares nonzero FD record word +3, stores the minimum-value slot in AECC[0], and forces AECB = 1.

## Matching label evidence
- pass 71: `C1:A765..C1:A7A8` **ct_global_opcode_70_select_one_nonhead_occupied_live_slot_by_min_nonzero_fd_record_word_03** (strong)
  - Scans occupied live slots `3..10`. Resolves each slot through `FD:A80B + slot*2`. Compares the 16-bit word at `record + 3`. Keeps the smallest nonzero value and stores the corresponding slot into `AECC[0]`. Forces `AECB = 1`.
