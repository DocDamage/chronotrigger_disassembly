# Global Opcode 12

- Status: **strong structural**
- Dispatch address: **C1:9474**
- Evidence pass: **65**
- Notes: Direct current-slot record gate: uses X=B252*4, tests B19E[X]&F0 against class 0x40/0x50 and B19F[X] against operand2; operand3 selects both-match vs both-differ mode

## Matching label evidence
- pass 65: `C1:9474..C1:94D1` **ct_global_opcode_12_gate_tail_replay_on_current_b19e_b19f_pair_mode** (strong)
  - Direct current-slot gate, not a relation-query wrapper. Computes `X = B252 * 4`. Reads: `B19E[X] & 0xF0` `B19F[X]` Operand `+1` selects target high nibble `0x40` vs `0x50`. Operand `+2` selects exact second-byte compare value. Operand `+3 == 0` -> both comparisons must match. Operand `+3 != 0` -> both comparisons must differ.
