# Global Opcode 6A

- Status: **strong structural**
- Dispatch address: **C1:A663**
- Evidence pass: **70**
- Notes: Visible-only FD-record selector via shared AE70/ADA1 pipeline; tests record[+20] & 0x10, inherits shared nonnegative record[+1D] gate, then reduces.

## Matching label evidence
- pass 70: `C1:A663..C1:A692` **ct_global_opcode_6A_select_visible_entries_by_fd_record_byte_20_mask_10** (strong)
  - Uses the shared visible FD-offset/mask pipeline. Tests `record[+20] & 0x10`. Also inherits the shared nonnegative `record[+1D]` gate.
