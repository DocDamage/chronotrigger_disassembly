# Global Opcode 4F

- Status: **strong**
- Dispatch address: **C1:9E63**
- Evidence pass: **68**
- Notes: If operand1 nonzero calls JSL CD0033, then writes B3B8=2 and returns

## Matching label evidence
- pass 68: `C1:9E63..C1:9E77` **ct_global_opcode_4F_optional_cd0033_then_set_continuation_2** (strong)
  - If operand 1 is nonzero, calls `JSL $CD0033`. Then writes `B3B8 = 2` and returns.
