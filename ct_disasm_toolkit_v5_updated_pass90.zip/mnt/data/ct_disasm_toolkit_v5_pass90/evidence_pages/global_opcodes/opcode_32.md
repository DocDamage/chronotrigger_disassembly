# Global Opcode 32

- Status: **strong structural**
- Dispatch address: **C1:9967**
- Evidence pass: **68**
- Notes: Reads CC:[B1D2+1] via current stream pointer, stores raw inline byte in AEE4, returns without local pointer advance

## Matching label evidence
- pass 68: `C1:9967..C1:9977` **ct_global_opcode_32_capture_inline_param1_to_aee4** (strong)
  - Reads the current stream byte at `CC:[B1D2 + 1]`. Stores it into `AEE4`. Does not locally advance `B1D2`. Best current reading: tiny inline-parameter capture body for later follow-up state.
