# Global Opcode 0D

- Status: **provisional structural**
- Dispatch address: **C1:92A3**
- Evidence pass: **65**
- Notes: Calls AC14; skips current subject slot; marks selected entries whose mode-05 relation result against current subject leaves 9872==0 (close-Y / abs delta < 0x20), reduces through AE21, then hits a residual 9872 / operand1 replay gate

## Matching label evidence
- pass 65: `C1:92A3..C1:9313` **ct_global_opcode_0D_mark_non_subject_selected_entries_by_relation_mode05_zero_then_reduce** (provisional)
  - Calls `AC14`. Sets current subject slot `986F = B252 + 3`. Uses relation-query mode `05`. Skips the subject slot if it appears in the selected list. Marks selected entries whose mode-`05` result leaves `9872 == 0`. Mode `05` is now known strongly enough to be the close-Y / `abs(subject_y - arg_y) < 0x20` predicate. Marked candidates are reduced through `AE21`. Final replay gate still depends on residual `9872` plus operand `+1`, so the top-level human-facing contract should stay provisional.
