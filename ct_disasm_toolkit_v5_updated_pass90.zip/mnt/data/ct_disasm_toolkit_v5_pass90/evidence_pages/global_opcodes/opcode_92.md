# Global Opcode 92

- Status: **strong structural**
- Dispatch address: **C1:8975**
- Evidence pass: **72**
- Notes: Lane-derived timed-state updater. Uses B17B or AEC7 -> B163 lane mapping; sets AFCC and AF3D from B0EA; decrements B05B; on expiry reloads 0x0A and clears AFCC.

## Matching label evidence
- pass 72: `C1:8975..C1:89B8` **ct_global_opcode_92_update_lane_afcc_b05b_and_clear_afcc_on_expiry** (strong)
  - Uses `B17B` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `AFCC[lane] = 1` and copies `B0EA[lane] -> AF3D[lane]`. Decrements `B05B[lane]` and reloads it to `0x0A` on expiry. Clears `AFCC[lane]` when the countdown expires.
