# Global Opcode 0A

- Status: **strong structural**
- Dispatch address: **C1:918E**
- Evidence pass: **64**
- Notes: Calls AC14; if multiple selected entries, chooses first match found in B23A order vector; succeeds only when immediate mask has no overlap with chosen entry record byte at immediate offset; success -> 8C3E, failure -> AF24=1

## Matching label evidence
- pass 64: `C1:918E..C1:91F8` **ct_global_opcode_0A_gate_tail_replay_on_priority_selected_entry_record_mask_clear** (strong)
  - Calls `AC14`. Empty selection -> failure. If only one entry is selected, uses it directly. If multiple entries are selected, reduces them to one chosen entry using WRAM vector `B23A[0..7]`. Operand `+1` is a record-byte offset. Operand `+2` is an immediate mask. Succeeds only when the chosen entry's `FD:A80B` record byte at that offset has no overlapping bits with the mask. Success goes directly to `8C3E`. Failure sets `AF24 = 1`.
