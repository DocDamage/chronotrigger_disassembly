# Global Opcode 9E

- Status: **strong structural**
- Dispatch address: **C1:AFC1**
- Evidence pass: **72**
- Notes: Internal alias into the same late-pack helper tail used by 9D. Falls through to PLX ; STX $2C ; RTS. Not a clean standalone top-level command body.

## Matching label evidence
- pass 72: `C1:AFC1..C1:AFCB` **ct_global_opcode_9E_late_pack_helper_internal_alias_call_c92a_and_plx_return** (strong)
  - Internal alias into the same helper tail used by `9D`. Falls through to `PLX ; STX $2C ; RTS`. Not a clean standalone top-level command body.
