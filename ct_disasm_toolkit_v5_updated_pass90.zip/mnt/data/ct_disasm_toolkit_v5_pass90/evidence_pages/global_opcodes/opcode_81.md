# Global Opcode 81

- Status: **strong**
- Dispatch address: **C1:AACC**
- Evidence pass: **69**
- Notes: Fixed single-entry selector wrapper: writes literal entry 6 into AECC[0], forces AECB = 1, and returns.

## Matching label evidence
- no direct label rows matched yet
