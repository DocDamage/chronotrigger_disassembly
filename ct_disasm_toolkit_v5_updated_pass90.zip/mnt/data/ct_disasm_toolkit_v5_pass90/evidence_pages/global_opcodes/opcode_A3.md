# Global Opcode A3

- Status: **strong structural**
- Dispatch address: **C1:AFF8**
- Evidence pass: **72**
- Notes: Internal alias after B4AA segment selection. Loads the current opcode byte into B239 and falls into shared dispatch.

## Matching label evidence
- pass 72: `C1:AFF8..C1:B002` **ct_global_opcode_A3_late_pack_executor_internal_alias_after_segment_select** (strong)
  - Internal alias after `B4AA` segment selection. Fetches the current opcode byte into `B239` and falls into the shared dispatch path.
