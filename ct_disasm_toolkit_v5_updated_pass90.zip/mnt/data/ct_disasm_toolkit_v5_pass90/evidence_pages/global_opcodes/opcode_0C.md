# Global Opcode 0C

- Status: **strong structural**
- Dispatch address: **C1:925D**
- Evidence pass: **65**
- Notes: Calls AC14; seeds relation-query mode 04 with current subject slot B252+3 and AECC[0]; operand1 selects whether 9872 must be zero or nonzero; success writes AECB=1 then replays through 8C3E

## Matching label evidence
- pass 65: `C1:925D..C1:92A2` **ct_global_opcode_0C_gate_tail_replay_on_relation_mode04_current_subject_vs_selection_head** (strong)
  - Calls `AC14`. Empty selection -> `AF24 = 1`. Seeds relation-query mode `04` with: `986F = B252 + 3` `9870 = AECC[0]` Calls service `5` through `JSR $0003`. Operand `+1` selects the final zero/nonzero polarity of `9872`. Success writes `AECB = 1` and continues through `8C3E`.
