# Global Opcode 15

- Status: **strong structural**
- Dispatch address: **C1:959A**
- Evidence pass: **66**
- Notes: Current-slot quad-record gate over B1A0[current*4] & operand1; operand3 selects full-mask match vs non-match

## Matching label evidence
- pass 66: `C1:959A..C1:95D5` **ct_global_opcode_15_gate_tail_replay_on_current_b1a0_mask_match_mode** (strong)
  - Computes `X = B252 * 4`. Reads `B1A0[X]`. Operand `+1` is a required mask. Operand `+3 == 0` -> require full-mask containment. Operand `+3 != 0` -> require non-match.
