# Global Opcode 18

- Status: **provisional structural**
- Dispatch address: **C1:95FA**
- Evidence pass: **66**
- Notes: Calls AC14, scans selected entries, resolves FD:A80B-rooted value into LDA ($0A),Y indirect lookup, breaks on equality with operand1, then AE21/AEFD/8C3E; pointer-base setup still needs caution

## Matching label evidence
- pass 66: `C1:95FA..C1:9651` **ct_global_opcode_18_reduce_selected_entries_by_indirect_table_byte_equals_immediate** (provisional)
  - Calls `AC14`. Scans selected entries in `AECC`. Resolves an `FD:A80B` record-rooted value and uses it as the `Y` component of `LDA ($0A),Y`. On equality with operand `+1`, reduces through `AE21`, then `AEFD`, then `8C3E`. Keep provisional because the base-pointer setup through `$0A/$0B` still wants harder confirmation. Important context: master opcodes `23..28` all alias back to this same body.
