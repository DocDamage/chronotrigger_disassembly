# Global Opcode 87

- Status: **strong**
- Dispatch address: **C1:AB4E**
- Evidence pass: **69**
- Notes: Fixed single-entry selector wrapper: writes literal entry 0 into AECC[0], forces AECB = 1, and returns.

## Matching label evidence
- pass 58: `C1:AB4E..C1:AB90` **ct_fixed_single_entry_selector_wrappers_0_through_6** (strong)
  - Family of tiny wrappers: `AECC = literal` `AECB = 1` `RTS` Covered literal values: `0..6`.
