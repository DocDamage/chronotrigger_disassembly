# Global Opcode 5C

- Status: **provisional structural**
- Dispatch address: **C1:A452**
- Evidence pass: **69**
- Notes: If DP scratch $24 is zero, refreshes/clears visible live-slot occupants through B279 for entries 0..2, then randomly chooses one occupied visible-head slot and exposes it in AECC[0]; leaves AECB = 0 on failure.

## Matching label evidence
- pass 69: `C1:A452..C1:A4AE` **ct_global_opcode_5C_select_random_visible_head_live_slot_after_optional_refresh** (provisional)
  - If DP scratch `$24` is zero, runs `B279` across visible entries `0..2` before the selection attempt. Then randomly chooses one occupied visible-head live slot. Exposes the chosen visible slot in `AECC[0]`. Leaves `AECB = 0` on failure. The exact higher-level noun of the `$24` gate still wants one more caller-context pass.
