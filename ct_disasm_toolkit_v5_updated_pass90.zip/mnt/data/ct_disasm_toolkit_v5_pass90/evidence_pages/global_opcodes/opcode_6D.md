# Global Opcode 6D

- Status: **strong structural**
- Dispatch address: **C1:A6ED**
- Evidence pass: **69**
- Notes: Scans AEFF[3..10], appends occupied non-head live slot indices into AECC, and stores the count in AECB.

## Matching label evidence
- pass 69: `C1:A6ED..C1:A708` **ct_global_opcode_6D_select_nonhead_occupied_live_slots** (strong)
  - Scans `AEFF[3..10]`. Appends occupied non-head live slot indices into `AECC`. Stores the resulting count in `AECB`.
