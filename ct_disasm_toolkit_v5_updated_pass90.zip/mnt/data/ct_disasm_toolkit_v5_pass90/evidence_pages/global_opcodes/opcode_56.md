# Global Opcode 56

- Status: **strong**
- Dispatch address: **C1:A396**
- Evidence pass: **68**
- Notes: Thin wrapper around fused long helper FD:A990 plus AC46/AD09/AD35 and optional CD0033

## Matching label evidence
- pass 68: `C1:A396..C1:A3D0` **ct_global_opcode_56_wrapper_fused_fd_a990** (strong)
  - Promoted master ownership of the old group-2 `16` thin wrapper around `FD:A990`.
