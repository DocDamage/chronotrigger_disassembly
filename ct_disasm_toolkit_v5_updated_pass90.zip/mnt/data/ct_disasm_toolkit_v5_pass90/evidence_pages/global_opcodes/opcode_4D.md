# Global Opcode 4D

- Status: **strong**
- Dispatch address: **C1:9DCE**
- Evidence pass: **68**
- Notes: Operand bits drive B320, 5E4A flag writes, 96F1/96F2/96F3 clears, and optional JSL CD0033

## Matching label evidence
- pass 68: `C1:9DCE..C1:9E61` **ct_global_opcode_4D_bitmask_state_control** (strong)
  - Promoted master ownership of the old group-2 `0D` state-control body. Operand bits drive a mix of per-slot and global control writes.
