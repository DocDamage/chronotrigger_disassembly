# Global Opcode 19

- Status: **strong**
- Dispatch address: **C1:9652**
- Evidence pass: **66**
- Notes: Exact alias of the unconditional JSR $8C3E ; RTS replay step

## Matching label evidence
- pass 66: `C1:9652..C1:9655` **ct_global_opcode_19_unconditional_tail_replay_step_alias** (strong)
  - Exact alias of the unconditional `8C3E ; RTS` replay step.
