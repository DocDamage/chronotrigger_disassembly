# Global Opcode 57

- Status: **strong**
- Dispatch address: **C1:A3F6**
- Evidence pass: **69**
- Notes: Exact single-byte RTS alias at the start of the promoted selector-control slice.

## Matching label evidence
- pass 69: `C1:A3F6` **ct_global_opcode_57_rts_noop_alias** (strong)
  - Exact single-byte RTS alias. First entry in the promoted selector-control master slice.
