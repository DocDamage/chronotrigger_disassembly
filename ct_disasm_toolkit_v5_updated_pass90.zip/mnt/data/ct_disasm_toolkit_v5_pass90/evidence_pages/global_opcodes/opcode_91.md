# Global Opcode 91

- Status: **strong structural**
- Dispatch address: **C1:88C5**
- Evidence pass: **74**
- Notes: Lane-derived dual-path packet caller. Uses B179[1] or AEC7 -> B163 lane mapping; requires 5E4A.bit7 set and 5E4B.bit6 clear; computes a scaled amount, mirrors it into transient AD9C/AD9E mode-3 workspace, queues the live packet through EBF8, then runs the shared 7F follow-up/apply tail and clears the workspace through FD:ACEE.

## Matching label evidence
- pass 74: `C1:88C5..C1:8974` **ct_global_opcode_91_compute_scaled_lane_delta_queue_live_packet_and_run_followup_7f_tail** (strong)
  - Uses `B179[1]` or `AEC7` through the `B163` lane mapping. Requires `5E4A.bit7` set and `5E4B.bit6` clear for the packet path. Sets `AFC1[lane] = 1` and `AF32[lane] = B0DF[lane] + 5E64[lane_block]`. Computes a scaled amount through `5E32/33`, a `5E64`-derived scale, and `C92A`. Mirrors that amount into transient packet workspace at `AD9C[offset]` with mode `3` in `AD9E[offset]`. Clears `B202`, queues the live packet through `EBF8`, then runs `A=0x7F ; JSR 895B ; JSL FD:ACEE`. Strongest safe reading: scaled lane-derived dual-path packet caller with shared `7F` follow-up/apply tail.
- pass 72: `C1:88C5..C1:8974` **ct_global_opcode_91_conditionally_seed_afc1_af32_and_ad9c_from_lane_geometry** (strong)
  - Uses `B179[1]` or fallback `AEC7`, then maps through `B163` to a lane ID. Requires `5E4A.bit7` set and `5E4B.bit6` clear for the helper path. Sets `AFC1[lane] = 1`, computes `AF32[lane] = B0DF[lane] + 5E64[lane_block]`. Seeds `AD9C/AD9E` and runs the `EBF8` helper chain. Clears `B186` with `AND #$17FF` before return.
