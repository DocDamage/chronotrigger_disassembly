# Global Opcode 98

- Status: **strong structural**
- Dispatch address: **C1:8A9F**
- Evidence pass: **74**
- Notes: Lane-derived helper/seed gate. Uses B179[8] or AEC7 -> B163 lane mapping; copies B12C -> AF7F with status-based halve/double transforms from 5E4D|5E52 and 5E4B; when 5E4B.bit4 is set it seeds AD89=1, B1FD=lane, B202=0 and directly runs EBF8 -> EC7F, giving the one-point primary-route packet fast path.

## Matching label evidence
- pass 74: `C1:8A9F..C1:8B0F` **ct_global_opcode_98_capture_lane_b12c_variant_into_af7f_and_optionally_apply_one_point_primary_delta** (strong)
  - Uses `B179[8]` or `AEC7` through the `B163` lane mapping. Captures `B12C[lane] -> AF7F[lane]` with status-based halve/double transforms. When `5E4B.bit4` is set, seeds `AD89 = 1`, `B1FD = lane`, `B202 = 0`, then runs `EBF8 -> EC7F` directly. Because the packet is primary-route and unsigned, this is the direct one-point primary-stat decrement fast path.
- pass 72: `C1:8A9F..C1:8B0F` **ct_global_opcode_98_capture_lane_b12c_variant_into_af7f_and_optionally_run_ec7f** (strong)
  - Uses `B179[8]` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `B00E[lane] = 1` and copies `B12C[lane] -> AF7F[lane]`. Applies status-based halve/double transforms from lane-block flags. Clears `B186` with `AND #$1FEF`. Optionally runs the `EBF8 -> EC7F` helper chain when `5E4B.bit4` is set.
