# Global Opcode 35

- Status: **strong**
- Dispatch address: **C1:997D**
- Evidence pass: **68**
- Notes: Exact single-byte RTS alias

## Matching label evidence
- no direct label rows matched yet
