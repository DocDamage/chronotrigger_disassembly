# Global Opcode 02

- Status: **strong structural**
- Dispatch address: **C1:8F11**
- Evidence pass: **63**
- Notes: operand1 chooses selector-control 01 (visible/head) vs 16 (non-head); operands2-3 filter 5E4A + selected*0x80 + offset by required bitmask; survivors finalize through AE21/AEFD/8C3E

## Matching label evidence
- pass 63: `C1:8F11..C1:8F81` **ct_global_opcode_02_filter_head_or_nonhead_selected_entries_by_lane_flag_mask** (strong)
  - Operand `+1` chooses which fixed selector-control byte is dispatched through `AC2C`: operand1 `== 0` -> selector-control `0x01` -> visible/head occupied entries (`A3F7`) operand1 `!= 0` -> selector-control `0x16` -> non-head occupied entries (`A6ED`) Operands `+2/+3` are used as: byte offset inside the lane block required bitmask For each selected entry: reads `5E4A + selected_entry*0x80 + operand2` accepts only when `(byte & operand3) == operand3` Accepted entries are incremented in-place in `AECC`. Zero survivors -> `AF24 = 1`. Successful survivors finalize through `AE21`, `AEFD`, and `8C3E`.
