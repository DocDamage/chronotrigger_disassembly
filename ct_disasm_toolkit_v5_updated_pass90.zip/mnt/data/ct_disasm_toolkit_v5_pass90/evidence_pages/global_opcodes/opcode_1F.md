# Global Opcode 1F

- Status: **strengthened structural**
- Dispatch address: **C1:9765**
- Evidence pass: **66**
- Notes: Calls AC14, seeds relation-query mode 0E with current subject slot and AECC[0], operand1 selects zero/nonzero gate on 9872, success forces AECB=1 then replays

## Matching label evidence
- pass 66: `C1:9765..C1:97AA` **ct_global_opcode_1F_gate_tail_replay_on_relation_mode0E_current_subject_vs_selection_head** (unspecified)
  - Calls `AC14`. Seeds relation-query mode `0E` with: `986F = B252 + 3` `9870 = AECC[0]` Operand `+1` selects the final zero/nonzero gate on `9872`. Success forces `AECB = 1` and continues through `8C3E`. Keep the wrapper label strong-structural, but do not pretend mode `0E`'s underlying noun is already frozen.
