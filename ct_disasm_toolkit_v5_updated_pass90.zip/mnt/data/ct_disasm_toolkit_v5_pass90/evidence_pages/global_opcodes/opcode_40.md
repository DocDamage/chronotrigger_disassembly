# Global Opcode 40

- Status: **strong**
- Dispatch address: **C1:99B8**
- Evidence pass: **68**
- Notes: Promoted master ownership of old group-2 opcode 00; writes B3B8=2 and returns

## Matching label evidence
- pass 68: `C1:99B8..C1:99BD` **ct_global_opcode_40_set_group2_continuation_2** (strong)
  - Writes `B3B8 = 2` and returns.
