# Global Opcode 48

- Status: **provisional**
- Dispatch address: **C1:9C6E**
- Evidence pass: **68**
- Notes: Promoted master ownership of old group-2 opcode 08 body

## Matching label evidence
- no direct label rows matched yet
