# Global Opcode 9B

- Status: **strong**
- Dispatch address: **C1:8C08**
- Evidence pass: **72**
- Notes: Exact RTS alias.

## Matching label evidence
- pass 72: `C1:8C08` **ct_global_opcode_9B_rts_alias** (strong)
  - Exact `RTS` entry.
