# Global Opcode 89

- Status: **strong**
- Dispatch address: **C1:AB64**
- Evidence pass: **69**
- Notes: Fixed single-entry selector wrapper: writes literal entry 2 into AECC[0], forces AECB = 1, and returns.

## Matching label evidence
- no direct label rows matched yet
