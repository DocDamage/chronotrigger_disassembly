# Global Opcode 5E

- Status: **strong structural**
- Dispatch address: **C1:A4E0**
- Evidence pass: **69**
- Notes: Promoted master/global ownership of the pass-30 relation-query target selector for mode 01.

## Matching label evidence
- pass 69: `C1:A4E0..C1:A507` **ct_global_opcode_5E_select_target_relation_mode_01** (strong)
  - Promoted master/global ownership of the pass-30 relation-query target selector for mode `01`.
