# Global Opcode 2F

- Status: **strong**
- Dispatch address: **C1:9961**
- Evidence pass: **67**
- Notes: Exact single-byte RTS alias

## Matching label evidence
- pass 67: `C1:9961..C1:9961` **ct_global_opcode_2F_rts_noop_alias** (strong)
  - Exact single-byte `RTS`.
