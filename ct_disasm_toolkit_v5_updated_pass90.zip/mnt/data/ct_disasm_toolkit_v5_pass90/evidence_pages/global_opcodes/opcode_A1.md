# Global Opcode A1

- Status: **strong structural**
- Dispatch address: **C1:AFE2**
- Evidence pass: **72**
- Notes: Internal alias in the late-pack executor common path. Clears AF24, probes byte +4 for the FE chained-second-subop case, and falls into segment selection.

## Matching label evidence
- pass 72: `C1:AFE2..C1:AFEC` **ct_global_opcode_A1_late_pack_executor_internal_alias_clear_af24_and_probe_second_subop** (strong)
  - Internal alias in the common late-pack executor path. Clears `AF24`, probes byte `+4` for the `FE` chained-subop case, and falls into the shared segment selector path.
