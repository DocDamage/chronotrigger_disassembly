# Global Opcode 6B

- Status: **strong structural**
- Dispatch address: **C1:A693**
- Evidence pass: **70**
- Notes: Visible-only FD-record selector via shared AE70/ADA1 pipeline; tests record[+01] & 0x08, inherits shared nonnegative record[+1D] gate, then reduces.

## Matching label evidence
- pass 70: `C1:A693..C1:A6C2` **ct_global_opcode_6B_select_visible_entries_by_fd_record_byte_01_mask_08** (strong)
  - Uses the shared visible FD-offset/mask pipeline. Tests `record[+01] & 0x08`. Also inherits the shared nonnegative `record[+1D]` gate.
