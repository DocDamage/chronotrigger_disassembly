# Global Opcode 58

- Status: **strong structural**
- Dispatch address: **C1:A3F7**
- Evidence pass: **69**
- Notes: Scans AEFF[0..2], appends occupied visible-head live slot indices into AECC, and stores the count in AECB.

## Matching label evidence
- pass 69: `C1:A3F7..C1:A410` **ct_global_opcode_58_select_visible_head_occupied_live_slots** (strong)
  - Scans `AEFF[0..2]`. Appends occupied visible-head live slot indices into `AECC`. Stores the resulting count in `AECB`.
