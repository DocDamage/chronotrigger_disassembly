# Global Opcode 96

- Status: **strong**
- Dispatch address: **C1:8A9D**
- Evidence pass: **72**
- Notes: Exact RTS alias.

## Matching label evidence
- pass 72: `C1:8A9D` **ct_global_opcode_96_rts_alias** (strong)
  - Exact `RTS` entry.
