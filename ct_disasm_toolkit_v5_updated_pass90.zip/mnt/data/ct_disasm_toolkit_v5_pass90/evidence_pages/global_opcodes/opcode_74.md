# Global Opcode 74

- Status: **strong structural**
- Dispatch address: **C1:A855**
- Evidence pass: **71**
- Notes: Nonhead AE70 -> ADA1 selector family for nonzero FD record byte +1E across occupied live slots 3..10, with no B18B exclusion.

## Matching label evidence
- pass 71: `C1:A855..C1:A888` **ct_global_opcode_74_select_nonhead_occupied_live_slots_by_nonzero_fd_record_byte_1E** (strong)
  - Nonhead counterpart of global `61`. Uses the shared `AE70 -> ADA1` reducer path. No `B18B` exclusion.
