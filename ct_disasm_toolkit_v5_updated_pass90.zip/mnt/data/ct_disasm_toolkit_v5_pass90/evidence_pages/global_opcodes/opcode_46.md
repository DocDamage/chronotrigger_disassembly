# Global Opcode 46

- Status: **provisional**
- Dispatch address: **C1:9B8C**
- Evidence pass: **68**
- Notes: Promoted master ownership of old group-2 opcode 06 body

## Matching label evidence
- no direct label rows matched yet
