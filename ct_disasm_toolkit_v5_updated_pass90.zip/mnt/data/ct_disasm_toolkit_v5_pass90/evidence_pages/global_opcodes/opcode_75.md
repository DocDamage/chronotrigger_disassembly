# Global Opcode 75

- Status: **strong structural**
- Dispatch address: **C1:A889**
- Evidence pass: **71**
- Notes: Nonhead AE70 -> ADA1 selector family for nonzero FD record byte +1F; scans live slots 3..10 and skips the primary-seed slot indexed by B18B.

## Matching label evidence
- pass 71: `C1:A889..C1:A8C4` **ct_global_opcode_75_select_nonhead_occupied_live_slots_excluding_primary_seed_by_nonzero_fd_record_byte_1F** (strong)
  - Tests `record[+1F]` through the shared `AE70 -> ADA1` reducer path. Skips the primary-seed slot indexed by `B18B`.
