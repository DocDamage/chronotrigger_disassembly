# Global Opcode A2

- Status: **strong structural**
- Dispatch address: **C1:AFED**
- Evidence pass: **72**
- Notes: Internal alias inside the CMP #$FE / B1CF second-subop arming logic of the late-pack executor.

## Matching label evidence
- pass 72: `C1:AFED..C1:AFF7` **ct_global_opcode_A2_late_pack_executor_internal_alias_arm_second_subop_flag** (strong)
  - Internal alias in the same common path. Lives inside the `CMP #$FE` / `B1CF` second-subop arming logic.
