# Global Opcode 94

- Status: **strong structural**
- Dispatch address: **C1:8A05**
- Evidence pass: **72**
- Notes: Lane-derived timed-state updater. Uses B17D or AEC7 -> B163 lane mapping; sets AFE2 and AF53 from B100; decrements B071; on expiry reloads 0x0A, clears 5E4D.bit6 for that lane block, and clears AFE2.

## Matching label evidence
- pass 72: `C1:8A05..C1:8A50` **ct_global_opcode_94_update_lane_afe2_b071_and_release_5E4D_bit6_on_expiry** (strong)
  - Uses `B17D` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `AFE2[lane] = 1` and copies `B100[lane] -> AF53[lane]`. Decrements `B071[lane]` and reloads it to `0x0A` on expiry. Clears `5E4D + lane*0x80` bit `0x40` and clears `AFE2[lane]` on expiry.
