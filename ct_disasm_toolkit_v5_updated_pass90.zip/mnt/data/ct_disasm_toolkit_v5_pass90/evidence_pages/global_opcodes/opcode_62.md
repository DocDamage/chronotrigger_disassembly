# Global Opcode 62

- Status: **strong structural**
- Dispatch address: **C1:A555**
- Evidence pass: **70**
- Notes: Visible-only FD-record selector via shared AD68/AE70/ADA1 pipeline; tests nonzero record[+1F], inherits shared nonnegative record[+1D] gate, then reduces.

## Matching label evidence
- pass 70: `C1:A555..C1:A55E` **ct_global_opcode_62_select_visible_entries_by_nonzero_fd_record_byte_1F** (strong)
  - Sets selector offset `0x1F`. Uses the shared visible FD-offset family at `AD68`. Also inherits the shared nonnegative `record[+1D]` gate.
