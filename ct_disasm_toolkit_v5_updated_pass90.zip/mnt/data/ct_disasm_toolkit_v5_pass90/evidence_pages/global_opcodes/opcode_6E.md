# Global Opcode 6E

- Status: **strong structural**
- Dispatch address: **C1:A709**
- Evidence pass: **69**
- Notes: Promoted master/global ownership of the pass-30 relation-query target selector for mode 02.

## Matching label evidence
- pass 69: `C1:A709..C1:A736` **ct_global_opcode_6E_select_target_relation_mode_02** (strong)
  - Promoted master/global ownership of the pass-30 relation-query target selector for mode `02`.
