# Global Opcode 84

- Status: **strong**
- Dispatch address: **C1:AAED**
- Evidence pass: **69**
- Notes: Fixed single-entry selector wrapper: writes literal entry 9 into AECC[0], forces AECB = 1, and returns.

## Matching label evidence
- no direct label rows matched yet
