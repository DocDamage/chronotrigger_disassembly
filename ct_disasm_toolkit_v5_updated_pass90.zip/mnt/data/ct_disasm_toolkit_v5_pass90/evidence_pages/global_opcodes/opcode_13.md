# Global Opcode 13

- Status: **strong structural**
- Dispatch address: **C1:94D2**
- Evidence pass: **66**
- Notes: Current-slot quad-record gate over B19E[current*4] bit4; operand1 bit0 chooses target bit state and operand3 selects equality vs inequality

## Matching label evidence
- pass 66: `C1:94D2..C1:9513` **ct_global_opcode_13_gate_tail_replay_on_current_b19e_bit4_match_mode** (strong)
  - Computes `X = B252 * 4`. Reads `B19E[X] & 0x10`. Operand `+1` bit `0` selects the target bit state (`0x00` vs `0x10`). Operand `+3` selects equality vs inequality. Success continues through `8C3E`; failure sets `AF24 = 1`.
