# Global Opcode 95

- Status: **strong structural**
- Dispatch address: **C1:8A51**
- Evidence pass: **72**
- Notes: Lane-derived timed-state updater. Uses B17E or AEC7 -> B163 lane mapping; sets AFED and AF5E from B10B; decrements B07C; on expiry reloads 0x0A, clears 5E4E.bit6 for that lane block, and clears AFED.

## Matching label evidence
- pass 72: `C1:8A51..C1:8A9C` **ct_global_opcode_95_update_lane_afed_b07c_and_release_5E4E_bit6_on_expiry** (strong)
  - Uses `B17E` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `AFED[lane] = 1` and copies `B10B[lane] -> AF5E[lane]`. Decrements `B07C[lane]` and reloads it to `0x0A` on expiry. Clears `5E4E + lane*0x80` bit `0x40` and clears `AFED[lane]` on expiry.
