# Global Opcode 0E

- Status: **provisional structural**
- Dispatch address: **C1:9314**
- Evidence pass: **65**
- Notes: Calls AC14; seeds relation mode with operand2+06; skips current subject slot; marks entries whose parameterized relation result leaves 9872==0, reduces through AE21, then hits a residual 9872 / operand1 replay gate

## Matching label evidence
- pass 65: `C1:9314..C1:938C` **ct_global_opcode_0E_mark_non_subject_selected_entries_by_parameterized_relation_mode_zero_then_reduce** (provisional)
  - Same structural family as `0D`. Seeds relation mode with `986E = operand2 + 0x06`. Skips the current subject slot. Marks selected entries whose query leaves `9872 == 0`. Reduces them through `AE21`. Final replay gate still depends on residual `9872` plus operand `+1`.
