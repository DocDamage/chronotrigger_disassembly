# Global Opcode 29

- Status: **strong structural**
- Dispatch address: **C1:9810**
- Evidence pass: **67**
- Notes: Calls AC14, reads one inline byte, stores AEE5->5E0D[current] and AECC[0]->5E15[current]

## Matching label evidence
- pass 67: `C1:9810..C1:9839` **ct_global_opcode_29_persist_selected_head_and_inline_param_to_current_5e15_5e0d** (strong)
  - Advances the stream, calls `AC14`, reads one inline byte, and stores: `AEE5 -> 5E0D[current]` `AECC[0] -> 5E15[current]` Strong bridge to later seeded group-2 opcode `01`.
