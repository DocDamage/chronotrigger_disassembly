# Global Opcode 86

- Status: **strong**
- Dispatch address: **C1:AB03**
- Evidence pass: **59**
- Notes: Scans tail slots with AF15.bit7 set, collects withheld-tail candidate slot indices into AECC, and randomly reduces multiple candidates to one exposed slot in AECC[0].

## Matching label evidence
- pass 69: `C1:AB03..C1:AB49` **ct_global_opcode_86_build_withheld_tail_candidate_list_and_random_reduce_to_one** (strong)
  - Promoted master/global ownership of the pass-57 withheld-tail selector body.
- pass 58: `C1:AB03..C1:AB49` **ct_build_withheld_tail_candidate_list_and_random_reduce_to_one** (caution)
  - Keep the pass-57 label. Pass 58 now places it inside the same selector-wrapper family as: fixed single-entry wrappers the visible-slot min selector the live-tail selector at `ABC9`
- pass 57: `C1:AB03..C1:AB49` **ct_build_withheld_tail_candidate_list_and_random_reduce_to_one** (strong)
  - Scans all 8 tail entries. Collects slot indices with `AF15.bit7` set into `AECC`. Stores the candidate count in `AECB`. If `AECB >= 2`, uses the existing RNG helper at `AF22` to choose one candidate, stores it in `AECC[0]`, fills the rest of `AECC[1..]` with `FF`, and forces `AECB = 1`. This is a real deferred-tail candidate selector, not a generic scan.
