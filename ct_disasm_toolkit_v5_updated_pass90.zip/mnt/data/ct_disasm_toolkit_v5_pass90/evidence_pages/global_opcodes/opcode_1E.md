# Global Opcode 1E

- Status: **strong structural**
- Dispatch address: **C1:975C**
- Evidence pass: **66**
- Notes: Always runs 8C3E then always sets AF24=1

## Matching label evidence
- pass 66: `C1:975C..C1:9764` **ct_global_opcode_1E_unconditional_tail_replay_then_abort** (strong)
  - Always runs `8C3E`. Then always writes `AF24 = 1`.
