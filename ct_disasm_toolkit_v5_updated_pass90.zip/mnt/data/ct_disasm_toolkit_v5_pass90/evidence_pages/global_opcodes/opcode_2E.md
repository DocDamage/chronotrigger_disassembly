# Global Opcode 2E

- Status: **strong**
- Dispatch address: **C1:9960**
- Evidence pass: **67**
- Notes: Exact single-byte RTS alias

## Matching label evidence
- pass 67: `C1:9960..C1:9960` **ct_global_opcode_2E_rts_noop_alias** (strong)
  - Exact single-byte `RTS`.
