# Global Opcode A0

- Status: **strong correction**
- Dispatch address: **C1:AFD7**
- Evidence pass: **72**
- Notes: Correction to earlier toolkit wording: the master pointer lands two bytes inside the real CC:8B08 pointer-load sequence, so A0 is an internal late-pack executor alias, not the clean top-level initializer.

## Matching label evidence
- pass 72: `C1:AFD7..C1:AFE1` **ct_global_opcode_A0_late_pack_executor_internal_alias_after_cc_record_load** (strong)
  - The master pointer lands two bytes inside the real `CC:8B08` pointer-load sequence. Keep as an internal late-pack executor alias, not as the clean top-level initializer.
- pass 69: `C1:AFD7..C1:B08E` **ct_global_opcode_A0_execute_late_selector_pack_and_capture_tail_result** (strong)
  - Promoted master/global ownership of the pass-60 late selector-pack executor.
- pass 60: `C1:AFD7..C1:B08E` **ct_execute_late_selector_pack_and_capture_tail_result** (strong)
  - Top-level late-family executor proved in this pass. Loads a pointer from `ct_late_selector_control_pointer_records`. Uses `B4AA` to select/adjust the current FE/FF-delimited segment. Reads the current sub-op byte into `B239`. Dispatches the sub-op through `B80D`. Optionally dispatches a second chained sub-op at `+4` when `B1CF != 0`. Captures the resulting `AF24` status into tail-local scratch/status arrays. May chain to another FE-delimited segment.
