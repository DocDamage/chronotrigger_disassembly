# Global Opcode 17

- Status: **strong structural**
- Dispatch address: **C1:95DA**
- Evidence pass: **66**
- Notes: Calls AF22 with A=0x64 and succeeds only when returned value is below operand1

## Matching label evidence
- pass 66: `C1:95DA..C1:95F9` **ct_global_opcode_17_gate_tail_replay_on_rng_percent_below_immediate** (strong)
  - Calls the known RNG helper at `AF22` with `A = 0x64`. Succeeds only when the returned value is below operand `+1`.
