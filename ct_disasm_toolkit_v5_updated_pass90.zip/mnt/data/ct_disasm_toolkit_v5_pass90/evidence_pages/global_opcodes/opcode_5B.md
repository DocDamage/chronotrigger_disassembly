# Global Opcode 5B

- Status: **strong structural**
- Dispatch address: **C1:A43D**
- Evidence pass: **69**
- Notes: Reads the current quad-record byte B19E + 4*B252, masks to the low nibble, writes that value into AECC[0], and forces AECB = 1.

## Matching label evidence
- pass 69: `C1:A43D..C1:A451` **ct_global_opcode_5B_select_current_quad_record_low_nibble_entry** (strong)
  - Reads `B19E + 4*B252`. Masks to the low nibble. Stores that value into `AECC[0]`. Forces `AECB = 1`.
