# Global Opcode 73

- Status: **strong structural**
- Dispatch address: **C1:A819**
- Evidence pass: **71**
- Notes: Nonhead AE70 -> ADA1 selector family for nonzero FD record byte +1E; scans live slots 3..10 and skips the primary-seed slot indexed by B18B.

## Matching label evidence
- pass 71: `C1:A819..C1:A854` **ct_global_opcode_73_select_nonhead_occupied_live_slots_excluding_primary_seed_by_nonzero_fd_record_byte_1E** (strong)
  - Tests `record[+1E]` through the shared `AE70 -> ADA1` reducer path. Also inherits the shared nonnegative `record[+1D]` gate. Skips the primary-seed slot indexed by `B18B`.
