# Global Opcode 7F

- Status: **strong**
- Dispatch address: **C1:AAB6**
- Evidence pass: **69**
- Notes: Fixed single-entry selector wrapper: writes literal entry 4 into AECC[0], forces AECB = 1, and returns.

## Matching label evidence
- no direct label rows matched yet
