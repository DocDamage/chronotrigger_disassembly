# Global Opcode 5A

- Status: **strong structural**
- Dispatch address: **C1:A42E**
- Evidence pass: **69**
- Notes: Writes B252 + 3 into AECC[0], forces AECB = 1, and returns.

## Matching label evidence
- pass 69: `C1:A42E..C1:A43C` **ct_global_opcode_5A_select_current_tail_local_live_slot** (strong)
  - Writes `B252 + 3` into `AECC[0]`. Forces `AECB = 1`.
