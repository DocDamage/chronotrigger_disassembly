# Global Opcode 4B

- Status: **provisional**
- Dispatch address: **C1:9D1B**
- Evidence pass: **68**
- Notes: Promoted master ownership of old group-2 opcode 0B body

## Matching label evidence
- no direct label rows matched yet
