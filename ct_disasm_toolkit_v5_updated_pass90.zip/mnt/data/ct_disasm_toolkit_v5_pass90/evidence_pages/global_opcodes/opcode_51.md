# Global Opcode 51

- Status: **strong**
- Dispatch address: **C1:9F5A**
- Evidence pass: **68**
- Notes: Uses B18B-selected base offset from FD:A80B, then writes four odd/even operand pairs; optional CD0033

## Matching label evidence
- pass 68: `C1:9F5A..C1:9FD1` **ct_global_opcode_51_group_base_write4_pairs** (strong)
  - Promoted master ownership of the old group-2 `11` writer body.
