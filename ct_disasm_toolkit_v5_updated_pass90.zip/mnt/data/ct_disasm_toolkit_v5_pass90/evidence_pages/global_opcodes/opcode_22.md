# Global Opcode 22

- Status: **strong structural**
- Dispatch address: **C1:97D5**
- Evidence pass: **66**
- Notes: Calls AC14, uses AECC[0] as selected entry index, reads B158[selected], and operand2 selects < threshold vs >= threshold

## Matching label evidence
- pass 66: `C1:97D5..C1:980F` **ct_global_opcode_22_gate_tail_replay_on_selected_b158_threshold_mode** (strong)
  - Calls `AC14`. Uses `AECC[0]` as the selected entry index. Reads `B158[selected]`. Operand `+1` is the threshold. Operand `+2 == 0` -> success on `< threshold` Operand `+2 != 0` -> success on `>= threshold`
