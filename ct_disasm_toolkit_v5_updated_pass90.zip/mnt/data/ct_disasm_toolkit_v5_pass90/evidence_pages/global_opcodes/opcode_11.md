# Global Opcode 11

- Status: **strong structural**
- Dispatch address: **C1:942A**
- Evidence pass: **65**
- Notes: Direct current-slot record gate: uses X=B252*4, reads B19E[X]&F0, operand1 selects target class 0x40 vs 0x50, operand3 selects equality vs inequality

## Matching label evidence
- pass 65: `C1:942A..C1:9473` **ct_global_opcode_11_gate_tail_replay_on_current_b19e_upper_nibble_class** (strong)
  - Direct current-slot gate, not a relation-query wrapper. Computes `X = B252 * 4`. Reads `B19E[X] & 0xF0`. Operand `+1` selects target class `0x40` vs `0x50`. Operand `+3` selects equality vs inequality. Success continues through `8C3E`; failure sets `AF24 = 1`.
