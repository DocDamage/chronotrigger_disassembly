# Global Opcode 08

- Status: **strong structural**
- Dispatch address: **C1:90BE**
- Evidence pass: **64**
- Notes: Calls AC14; marks selected entries whose FD:A80B-rooted record word at +3 <= immediate 16-bit threshold; marked candidates are reduced through AE21 then continue through AEFD/8C3E

## Matching label evidence
- pass 64: `C1:90BE..C1:912F` **ct_global_opcode_08_mark_selected_entries_by_fd_record_word3_le_immediate_then_reduce** (strong)
  - Calls `AC14`. Empty selection -> failure. Reads a 16-bit immediate threshold. For each selected entry: resolves the `FD:A80B` record base reads the 16-bit field at record offset `+3` marks the entry in `AECC` with bit 7 when `record_word_+3 <= immediate_word` Stores the number of marked entries in `AECB`. Then calls `AE21`, `AEFD`, and `8C3E` on success.
