# Global Opcode 9A

- Status: **strong structural**
- Dispatch address: **C1:8BB9**
- Evidence pass: **72**
- Notes: Lane-derived timed-state updater. Uses B179[0x0A] or AEC7 -> B163 lane mapping; sets B024 and AF95 from B142; decrements B0B3; on expiry reloads 0x0A, clears 5E4E.bit2 for that lane block, and clears B024.

## Matching label evidence
- pass 72: `C1:8BB9..C1:8C07` **ct_global_opcode_9A_update_lane_b024_b0b3_and_release_5E4E_bit2_on_expiry** (strong)
  - Uses `B179[0x0A]` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `B024[lane] = 1` and copies `B142[lane] -> AF95[lane]`. Decrements `B0B3[lane]` and reloads it to `0x0A` on expiry. Clears `5E4E + lane*0x80` bit `0x04` and clears `B024[lane]` on expiry.
