# Global Opcode 6C

- Status: **strong structural**
- Dispatch address: **C1:A6C3**
- Evidence pass: **70**
- Notes: Computes current tail-local live slot as B252 + 3, then selects every other occupied live tail slot 3..10 into AECC and stores the count in AECB.

## Matching label evidence
- pass 70: `C1:A6C3..C1:A6EC` **ct_global_opcode_6C_select_occupied_live_tail_slots_except_current** (strong)
  - Computes the current tail-local live slot as `B252 + 3`. Scans live slots `3..10`. Appends every occupied slot except that current one into `AECC`. Stores the resulting count in `AECB`.
