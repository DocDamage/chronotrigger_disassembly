# Global Opcode 7A

- Status: **strong structural**
- Dispatch address: **C1:A9AD**
- Evidence pass: **71**
- Notes: Nonhead masked AE70 -> ADA1 selector family for record[+21] & 0x40, scanning live slots 3..10 and skipping the primary-seed slot indexed by B18B.

## Matching label evidence
- pass 71: `C1:A9AD..C1:A9E8` **ct_global_opcode_7A_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_21_mask_40** (strong)
  - Uses the shared nonhead FD-offset/mask pipeline. Tests `record[+21] & 0x40`. Skips the primary-seed slot indexed by `B18B`.
