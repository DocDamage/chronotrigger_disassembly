# Global Opcode 37

- Status: **strong**
- Dispatch address: **C1:997F**
- Evidence pass: **68**
- Notes: Exact single-byte RTS alias

## Matching label evidence
- no direct label rows matched yet
