# Global Opcode 4C

- Status: **provisional**
- Dispatch address: **C1:9D72**
- Evidence pass: **68**
- Notes: Promoted master ownership of old group-2 opcode 0C body

## Matching label evidence
- no direct label rows matched yet
