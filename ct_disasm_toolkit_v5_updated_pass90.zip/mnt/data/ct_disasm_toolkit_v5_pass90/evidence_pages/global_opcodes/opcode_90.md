# Global Opcode 90

- Status: **strong structural**
- Dispatch address: **C1:8876**
- Evidence pass: **72**
- Notes: Lane-derived timed-state updater. Uses B179[0] or AEC7 -> B163 lane mapping; sets AFB6 and AF27 from B0D4; decrements B045; on expiry reloads 0x0A, clears 5E4B.bit7 for that lane block, and clears AFB6.

## Matching label evidence
- pass 72: `C1:8876..C1:88C4` **ct_global_opcode_90_update_lane_afb6_b045_and_release_5E4B_bit7_on_expiry** (strong)
  - Uses `B179[0]` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `AFB6[lane] = 1` and copies `B0D4[lane] -> AF27[lane]`. Decrements `B045[lane]` and reloads it to `0x0A` on expiry. Clears `5E4B + lane*0x80` bit `0x80` and clears `AFB6[lane]` when the countdown expires.
