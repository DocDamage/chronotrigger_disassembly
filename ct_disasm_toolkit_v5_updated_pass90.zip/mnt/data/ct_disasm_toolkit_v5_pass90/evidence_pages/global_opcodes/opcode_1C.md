# Global Opcode 1C

- Status: **provisional structural**
- Dispatch address: **C1:96D4**
- Evidence pass: **66**
- Notes: Calls AC14, checks whether AECC[0] is present in AF0A[0..2], may require corresponding AEFF live-head entry, optionally replays via 8C3E, then always writes AF24=1

## Matching label evidence
- pass 66: `C1:96D4..C1:9727` **ct_global_opcode_1C_optionally_replay_on_selected_head_canonical_membership_then_abort** (provisional)
  - Calls `AC14`. Searches `AF0A[0..2]` for a byte equal to `AECC[0]`. Uses operand `+2` plus optional `AEFF[x] != FF` live-head confirmation to decide whether to call `8C3E`. Always exits with `AF24 = 1`, even after replay.
