# Global Opcode 2B

- Status: **strong structural**
- Dispatch address: **C1:983A**
- Evidence pass: **67**
- Notes: Shared body with 2A; when AEE3==2 stores chosen entry -> B16E[current], advances stream twice, and on failure writes B242[current]=FF and AF24=2

## Matching label evidence
- pass 67: `C1:983A..C1:98C3` **ct_global_opcode_2A_2B_ordered_first_choice_persist_shared_body** (strong)
  - Calls `AC14`. If multiple selected entries exist, collapses them to the first entry matching the external priority list in `B23A[0..7]`. Copies the chosen entry into `AECC[0]`. Then splits on `AEE3`: non-`2` path persists into `5E0D[current] / 5E15[current]` `2` path persists into `B16E[current]` Failure writes `B242[current] = FF` and `AF24 = 2`.
