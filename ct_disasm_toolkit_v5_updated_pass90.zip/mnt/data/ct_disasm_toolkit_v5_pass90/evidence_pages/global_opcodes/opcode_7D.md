# Global Opcode 7D

- Status: **strong structural**
- Dispatch address: **C1:AA61**
- Evidence pass: **71**
- Notes: Minimum nonzero FD record word +3 selector over occupied nonhead live slots 3..10, skipping the primary-seed slot indexed by B18B and storing the winning slot in AECC[0].

## Matching label evidence
- pass 71: `C1:AA61..C1:AAAA` **ct_global_opcode_7D_select_one_nonhead_occupied_live_slot_excluding_primary_seed_by_min_nonzero_fd_record_word_03** (strong)
  - Same minimum-word selector family as global `70`. Scans occupied live slots `3..10`. Skips the primary-seed slot indexed by `B18B`. Chooses the smallest nonzero `record_word(+3)` candidate and stores its slot into `AECC[0]`.
