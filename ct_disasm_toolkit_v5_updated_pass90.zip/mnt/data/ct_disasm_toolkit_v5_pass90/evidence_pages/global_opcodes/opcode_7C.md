# Global Opcode 7C

- Status: **strong structural**
- Dispatch address: **C1:AA25**
- Evidence pass: **71**
- Notes: Nonhead masked AE70 -> ADA1 selector family for record[+19] & 0x01, scanning live slots 3..10 and skipping the primary-seed slot indexed by B18B.

## Matching label evidence
- pass 71: `C1:AA25..C1:AA60` **ct_global_opcode_7C_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_19_mask_01** (strong)
  - Uses the shared nonhead FD-offset/mask pipeline. Tests `record[+19] & 0x01`. Skips the primary-seed slot indexed by `B18B`.
