# Global Opcode 93

- Status: **strong structural**
- Dispatch address: **C1:89B9**
- Evidence pass: **72**
- Notes: Lane-derived timed-state updater. Uses B17C or AEC7 -> B163 lane mapping; sets AFD7 and AF48 from B0F5; decrements B066; on expiry reloads 0x0A, clears 5E4D.bit7 for that lane block, and clears AFD7.

## Matching label evidence
- pass 72: `C1:89B9..C1:8A04` **ct_global_opcode_93_update_lane_afd7_b066_and_release_5E4D_bit7_on_expiry** (strong)
  - Uses `B17C` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `AFD7[lane] = 1` and copies `B0F5[lane] -> AF48[lane]`. Decrements `B066[lane]` and reloads it to `0x0A` on expiry. Clears `5E4D + lane*0x80` bit `0x80` and clears `AFD7[lane]` on expiry.
