# Global Opcode 9D

- Status: **strong structural**
- Dispatch address: **C1:AFB6**
- Evidence pass: **72**
- Notes: Internal alias entry in the late-pack helper lead-in. Seeds DP scratch from FD:BA61 and falls into the C92A / PLX return tail. Not a clean standalone top-level command body.

## Matching label evidence
- pass 72: `C1:AFB6..C1:AFC0` **ct_global_opcode_9D_late_pack_helper_internal_alias_seed_dp28_from_fd_ba61** (strong)
  - Internal helper/lead-in alias before the late-pack executor blob. Seeds scratch through `FD:BA61`, `DP28/29`, `C92A`, and a `PLX` return tail. Not a clean standalone top-level command body.
