# Global Opcode 88

- Status: **strong**
- Dispatch address: **C1:AB59**
- Evidence pass: **69**
- Notes: Fixed single-entry selector wrapper: writes literal entry 1 into AECC[0], forces AECB = 1, and returns.

## Matching label evidence
- no direct label rows matched yet
