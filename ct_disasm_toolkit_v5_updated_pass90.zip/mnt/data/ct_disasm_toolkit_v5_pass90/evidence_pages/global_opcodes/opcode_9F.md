# Global Opcode 9F

- Status: **strong structural**
- Dispatch address: **C1:AFCC**
- Evidence pass: **72**
- Notes: Internal alias landing directly in the PLX return tail ahead of the late-pack executor blob. Not a clean standalone top-level command body.

## Matching label evidence
- pass 72: `C1:AFCC..C1:AFD4` **ct_global_opcode_9F_late_pack_helper_internal_alias_plx_return** (strong)
  - Internal alias that lands directly in the `PLX` return tail ahead of the late-pack blob. Not a clean standalone top-level command body.
