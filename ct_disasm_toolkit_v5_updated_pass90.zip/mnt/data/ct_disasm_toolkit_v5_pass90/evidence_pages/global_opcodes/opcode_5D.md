# Global Opcode 5D

- Status: **strong structural**
- Dispatch address: **C1:A4AF**
- Evidence pass: **69**
- Notes: Promoted master/global ownership of the pass-30 relation-query target selector for mode 00.

## Matching label evidence
- pass 69: `C1:A4AF..C1:A4DF` **ct_global_opcode_5D_select_target_relation_mode_00** (strong)
  - Promoted master/global ownership of the pass-30 relation-query target selector for mode `00`.
