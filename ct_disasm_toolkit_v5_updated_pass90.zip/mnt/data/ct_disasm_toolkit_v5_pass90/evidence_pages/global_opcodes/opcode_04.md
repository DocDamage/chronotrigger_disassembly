# Global Opcode 04

- Status: **strong**
- Dispatch address: **C1:8FDA**
- Evidence pass: **63**
- Notes: Scans AF02 live tail occupant map for operand1; operand2 selects require-present vs require-absent; success -> 8C3E, failure -> AF24=1

## Matching label evidence
- pass 63: `C1:8FDA..C1:9012` **ct_global_opcode_04_gate_tail_replay_on_live_tail_occupant_presence_mode** (strong)
  - Scans live tail occupant map `AF02[0..AEC6-1]` for operand1. Operand2 selects the sense: operand2 `== 0` -> success only when operand1 is present operand2 `!= 0` -> success only when operand1 is absent Success -> `JSR $8C3E` Failure -> `AF24 = 1` This is the corrected master-table meaning of global opcode `04`.
