# Global Opcode 8F

- Status: **strong**
- Dispatch address: **C1:ABC9**
- Evidence pass: **59**
- Notes: Scans live tail slots from index 3 up to B252 + 3, collects occupied live-tail slot indices into AECC, and randomly reduces multiple candidates to one exposed slot in AECC[0].

## Matching label evidence
- pass 69: `C1:ABC9..C1:AC13` **ct_global_opcode_8F_build_live_tail_slot_candidate_list_and_random_reduce_to_one** (strong)
  - Promoted master/global ownership of the pass-58 live-tail selector body.
- pass 58: `C1:ABC9..C1:AC13` **ct_build_live_tail_slot_candidate_list_and_random_reduce_to_one** (strong)
  - Scans the unified live occupant map starting at slot index `3`. Uses `B252 + 3` as the upper live-tail bound. Appends non-`FF` live slot indices into `AECC`. If multiple candidates exist, uses `AF22` to choose one and exposes the chosen slot at `AECC[0]`. Forces `AECB = 1`. Strong structural sibling to pass 57's `AB03`, but over the live-tail side.
