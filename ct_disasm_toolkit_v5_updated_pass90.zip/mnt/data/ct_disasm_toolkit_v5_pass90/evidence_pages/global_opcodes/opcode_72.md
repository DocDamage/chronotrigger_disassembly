# Global Opcode 72

- Status: **strong structural**
- Dispatch address: **C1:A7E5**
- Evidence pass: **71**
- Notes: Nonhead AE70 -> ADA1 selector family for positive FD record byte +1D across occupied live slots 3..10, with no B18B exclusion.

## Matching label evidence
- pass 71: `C1:A7E5..C1:A818` **ct_global_opcode_72_select_nonhead_occupied_live_slots_by_positive_fd_record_byte_1D** (strong)
  - Nonhead counterpart of global `60`. Scans occupied live slots `3..10` through `AE70 -> ADA1`. No `B18B` exclusion.
