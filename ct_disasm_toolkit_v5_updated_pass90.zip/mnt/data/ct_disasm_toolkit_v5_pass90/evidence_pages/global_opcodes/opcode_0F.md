# Global Opcode 0F

- Status: **strong structural**
- Dispatch address: **C1:938D**
- Evidence pass: **65**
- Notes: Calls AC14; seeds relation mode 08 with current subject slot B252+3, AECC[0], and packed operand2 bits in 9871; operand1 selects whether 9872 must be zero or nonzero; pre-write 9872=05 is dead before service-5 dispatch

## Matching label evidence
- pass 65: `C1:938D..C1:93E5` **ct_global_opcode_0F_gate_tail_replay_on_relation_mode08_current_subject_vs_selection_head** (strong)
  - Calls `AC14`. Empty selection -> `AF24 = 1`. Seeds relation-query mode `08` with: `986F = B252 + 3` `9870 = AECC[0]` `9871 = (operand2 << 2) | 1` Operand `+1` selects the final zero/nonzero polarity of `9872`. Success continues through `8C3E`. Pre-write `9872 = 05` is dead for normal service-5 flow because `2986` clears `9872` before dispatch.
