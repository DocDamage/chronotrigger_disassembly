# Global Opcode 4E

- Status: **strong**
- Dispatch address: **C1:9E62**
- Evidence pass: **68**
- Notes: Exact single-byte RTS alias

## Matching label evidence
- no direct label rows matched yet
