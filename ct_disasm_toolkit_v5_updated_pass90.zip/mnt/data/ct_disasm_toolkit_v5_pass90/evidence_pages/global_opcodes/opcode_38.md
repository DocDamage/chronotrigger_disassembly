# Global Opcode 38

- Status: **strong**
- Dispatch address: **C1:9980**
- Evidence pass: **68**
- Notes: Exact single-byte RTS alias

## Matching label evidence
- no direct label rows matched yet
