# Global Opcode 03

- Status: **strong structural**
- Dispatch address: **C1:8F87**
- Evidence pass: **63**
- Notes: Calls AC14; filters selected entries by AEFF[selected] == immediate; zero survivors or AE21 short-circuit force AF24=1; success finalizes through AEFD/8C3E

## Matching label evidence
- pass 63: `C1:8F87..C1:8FD9` **ct_global_opcode_03_filter_selected_entries_by_occupant_index_equals_immediate** (strong)
  - Calls `AC14`, so operand `+1` is an arbitrary inline selector-control byte. Requires a non-empty selected list from `AECC/AECB`. Consumes the next immediate byte and accepts only selected entries where: `AEFF[selected_entry] == immediate` Accepted entries are incremented in-place in `AECC`. Zero survivors -> `AF24 = 1`. Successful survivors finalize through `AE21`, `AEFD`, and `8C3E`. Strong structural sibling to opcode `02`, but using arbitrary `AC14` selection plus occupant-equality filtering.
