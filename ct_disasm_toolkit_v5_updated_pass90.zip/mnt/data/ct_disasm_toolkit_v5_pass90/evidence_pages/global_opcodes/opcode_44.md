# Global Opcode 44

- Status: **provisional**
- Dispatch address: **C1:9B47**
- Evidence pass: **68**
- Notes: Promoted master ownership of old group-2 opcode 04 shared variable-control entry A

## Matching label evidence
- no direct label rows matched yet
