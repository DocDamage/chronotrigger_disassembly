# Global Opcode 8E

- Status: **strong structural**
- Dispatch address: **C1:AB9B**
- Evidence pass: **59**
- Notes: Compares visible-head lane values at 5E30, 5EB0, and 5F30, selects one visible entry 0..2, stores it into AECC, and forces AECB = 1.

## Matching label evidence
- pass 69: `C1:AB9B..C1:ABC8` **ct_global_opcode_8E_select_one_visible_entry_0_1_2_by_min_lane_value** (strong)
  - Promoted master/global ownership of the pass-58 visible min selector.
- pass 58: `C1:AB9B..C1:ABC8` **ct_select_one_visible_entry_0_1_2_by_min_lane_value** (strong)
  - Compares three lane-local values: `5E30` `5EB0` `5F30` Selects exactly one visible entry index: `0`, `1`, or `2` Stores that selected entry into `AECC` Forces `AECB = 1` Exact branch polarity / final gameplay noun should still stay cautious, but the structural selector role is now strong.
