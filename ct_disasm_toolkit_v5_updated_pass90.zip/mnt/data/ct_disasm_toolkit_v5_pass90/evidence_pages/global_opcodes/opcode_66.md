# Global Opcode 66

- Status: **strong structural**
- Dispatch address: **C1:A5A3**
- Evidence pass: **70**
- Notes: Visible-only FD-record selector via shared AE70/ADA1 pipeline; tests record[+1E] & 0x80, inherits shared nonnegative record[+1D] gate, then reduces.

## Matching label evidence
- pass 70: `C1:A5A3..C1:A5D2` **ct_global_opcode_66_select_visible_entries_by_fd_record_byte_1E_mask_80** (strong)
  - Uses the shared visible FD-offset/mask pipeline. Tests `record[+1E] & 0x80`. Also inherits the shared nonnegative `record[+1D]` gate.
