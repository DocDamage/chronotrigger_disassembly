# Global Opcode 59

- Status: **strong structural**
- Dispatch address: **C1:A411**
- Evidence pass: **69**
- Notes: Calls global 58 first, then appends occupied live slot indices 3..10 from AEFF into AECC and stores the total count in AECB.

## Matching label evidence
- pass 69: `C1:A411..C1:A42D` **ct_global_opcode_59_select_all_occupied_live_slots** (strong)
  - Calls the `57/58`-band visible selector first. Then appends occupied live slots `3..10` from `AEFF`. Stores the final count in `AECB`.
