# Global Opcode 36

- Status: **strong**
- Dispatch address: **C1:997E**
- Evidence pass: **68**
- Notes: Exact single-byte RTS alias

## Matching label evidence
- no direct label rows matched yet
