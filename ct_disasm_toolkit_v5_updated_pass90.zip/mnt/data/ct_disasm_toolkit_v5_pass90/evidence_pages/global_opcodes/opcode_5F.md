# Global Opcode 5F

- Status: **strong structural**
- Dispatch address: **C1:A508**
- Evidence pass: **69**
- Notes: Compares 5E30, 5EB0, and 5F30, selects one visible entry index 0..2 with the minimum current-HP value, stores it into AECC, and forces AECB = 1.

## Matching label evidence
- pass 69: `C1:A508..C1:A540` **ct_global_opcode_5F_select_one_visible_entry_0_1_2_by_min_current_hp** (strong)
  - Compares visible-head lane values at `5E30`, `5EB0`, and `5F30`. Selects exactly one visible entry index `0..2` with the minimum current-HP value. Stores that result into `AECC[0]`. Forces `AECB = 1`.
