# Global Opcode 41

- Status: **strong structural**
- Dispatch address: **C1:99BE**
- Evidence pass: **68**
- Notes: Seeds one-entry list from 5E15[current], captures AEE4/AEE5, uses unique FD:AB01 helper, finalizes via AC89/ACCE with B3B8=0

## Matching label evidence
- pass 68: `C1:99BE..C1:9A38` **ct_global_opcode_41_seed_single_from_5e15_finalize** (strong)
  - Promoted master ownership of the old group-2 `01` body. Seeds one entry from `5E15[current]`. Captures inline parameters into `AEE4/AEE5`. Uses unique long helper `FD:AB01`. Finalizes through `AC89/ACCE` with `B3B8 = 0`.
