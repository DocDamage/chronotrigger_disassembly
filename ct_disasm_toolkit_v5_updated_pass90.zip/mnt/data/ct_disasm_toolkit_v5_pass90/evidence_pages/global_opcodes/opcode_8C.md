# Global Opcode 8C

- Status: **strong**
- Dispatch address: **C1:AB85**
- Evidence pass: **69**
- Notes: Fixed single-entry selector wrapper: writes literal entry 5 into AECC[0], forces AECB = 1, and returns.

## Matching label evidence
- no direct label rows matched yet
