# Global Opcode 09

- Status: **provisional structural**
- Dispatch address: **C1:9130**
- Evidence pass: **64**
- Notes: Calls AC14; operand1 is record-byte offset, operand2 compare byte; scans selected entries and breaks to AE21 on first FD:A80B-rooted record byte >= immediate; no visible AECC marking in body

## Matching label evidence
- pass 64: `C1:9130..C1:918D` **ct_global_opcode_09_scan_selected_entries_for_fd_record_byte_offset_gte_immediate_then_reduce** (provisional)
  - Calls `AC14`. Empty selection -> failure. Operand `+1` is a byte offset inside the `FD:A80B` record. Operand `+2` is the compare byte. Scans the selected entries and breaks to `AE21` on the first entry where: `record_byte >= immediate` Fails if the scan completes with no hit. This body does **not** mark `AECC` entries itself before calling `AE21`, so the precise final selected-entry effect should remain open.
