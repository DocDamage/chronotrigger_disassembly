# Global Opcode 39

- Status: **strong structural**
- Dispatch address: **C1:9981**
- Evidence pass: **68**
- Notes: Counts slots with AF0D!=FF, AF02==FF, and AF15.bit7 clear; success clears AF24 when count>0 else AF24=2

## Matching label evidence
- pass 68: `C1:9981..C1:99B3` **ct_global_opcode_39_3F_gate_on_materializable_canonical_tail_slot_exists** (strong)
  - Scans 8 tail slots. Accepts only when: `AF0D[x] != FF` `AF02[x] == FF` `AF15.bit7` clear Success clears `AF24`; zero accepted entries force `AF24 = 2`. Exact alias body for global opcodes `39` and `3F`.
