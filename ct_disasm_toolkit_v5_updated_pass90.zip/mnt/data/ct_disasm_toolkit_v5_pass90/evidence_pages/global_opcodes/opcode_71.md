# Global Opcode 71

- Status: **strong structural**
- Dispatch address: **C1:A7A9**
- Evidence pass: **71**
- Notes: Nonhead AE70 -> ADA1 selector family for positive FD record byte +1D; scans live slots 3..10 and skips the primary-seed slot indexed by B18B.

## Matching label evidence
- pass 71: `C1:A7A9..C1:A7E4` **ct_global_opcode_71_select_nonhead_occupied_live_slots_excluding_primary_seed_by_positive_fd_record_byte_1D** (strong)
  - Nonhead counterpart of the pass-70 visible FD-byte selector family. Scans live slots `3..10`. Skips the primary-seed slot indexed by `B18B`. Uses `AE70 -> ADA1` to select/reduce candidates.
