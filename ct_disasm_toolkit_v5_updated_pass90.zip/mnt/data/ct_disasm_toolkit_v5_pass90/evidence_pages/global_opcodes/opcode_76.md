# Global Opcode 76

- Status: **provisional structural**
- Dispatch address: **C1:A8C5**
- Evidence pass: **71**
- Notes: Intended no-exclusion sibling of global 75 through the nonhead AE70 -> ADA1 family, but loop-update byte at C1:A8E9 stores to $0E with STA instead of the expected STX.

## Matching label evidence
- pass 71: `C1:A8C5..C1:A8F8` **ct_global_opcode_76_select_nonhead_occupied_live_slots_by_nonzero_fd_record_byte_1F** (strong)
  - Structurally matches the no-exclusion sibling of global `75`. Intended to test `record[+1F]` through the shared `AE70 -> ADA1` reducer path. But the loop update stores back into `$0E` with `STA $0E` at `C1:A8E9` instead of the expected `STX $0E`. Keep the family interpretation, but preserve explicit caution until runtime confirms the practical behavior.
