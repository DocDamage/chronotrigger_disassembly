# Global Opcode 79

- Status: **strong structural**
- Dispatch address: **C1:A971**
- Evidence pass: **71**
- Notes: Nonhead masked AE70 -> ADA1 selector family for record[+1E] & 0x04, scanning live slots 3..10 and skipping the primary-seed slot indexed by B18B.

## Matching label evidence
- pass 71: `C1:A971..C1:A9AC` **ct_global_opcode_79_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1E_mask_04** (strong)
  - Uses the shared nonhead FD-offset/mask pipeline. Tests `record[+1E] & 0x04`. Skips the primary-seed slot indexed by `B18B`.
