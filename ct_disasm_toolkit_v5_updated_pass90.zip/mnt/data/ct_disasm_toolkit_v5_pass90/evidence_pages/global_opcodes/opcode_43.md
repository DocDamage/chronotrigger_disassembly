# Global Opcode 43

- Status: **strong**
- Dispatch address: **C1:9B46**
- Evidence pass: **68**
- Notes: Exact single-byte RTS alias

## Matching label evidence
- no direct label rows matched yet
