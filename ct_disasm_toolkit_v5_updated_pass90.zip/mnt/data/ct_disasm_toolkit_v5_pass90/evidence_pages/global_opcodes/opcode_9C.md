# Global Opcode 9C

- Status: **strong structural**
- Dispatch address: **C1:8461**
- Evidence pass: **73**
- Notes: Tail-lane service controller over slots 3..10. Invokes 8CF9 to run the current tail selector-control/materialization stream, then refreshes readiness shadow through B158->AFAB, BD6F, and B03A before downstream canonical/head-visible reconciliation and gauge export refresh.

## Matching label evidence
- pass 73: `C1:8461..C1:883B` **ct_service7_tail_lane_admission_reseat_and_readiness_refresh_controller** (strong)
  - Local selector-control ownership of global `9C`. Carries the same upgraded reading: outer controller for eligible tail-lane admission/reseat, readiness-shadow refresh, and downstream canonical/head-visible reconciliation.  the fourth byte in each 4-byte packet record remains unresolved here the final gameplay-facing noun of the `5E34/5E36` pair is still slightly below fully frozen `8CF9` is now structurally strong, but some continuation/result fields like `B242` and `AE55` still want a tighter pass
- pass 73: `C1:8461..C1:883B` **ct_global_opcode_9C_service7_tail_lane_admission_reseat_and_readiness_refresh_controller** (strong)
  - Walks the tail-lane band through `B315/B252/B18B` and the `B179/B163` mapping. Services eligible occupied tail lanes, invoking `8CF9` to run the tail selector-control/materialization stream. On the follow-up path mirrors `B158 -> AFAB`, applies `BD6F` readiness modifiers, and sets `B03A = 1`. Then runs canonical/head-visible reconciliation and readiness-gauge export refresh through helpers such as `B575` and `B725`. Strongest safe reading: service-7 tail-lane admission/reseat plus readiness-refresh controller.
- pass 72: `C1:8461..C1:8625` **ct_global_opcode_9C_service7_lane_controller_and_active_time_update** (strong)
  - Large lane/service controller, not a tiny wrapper. Clears controller scratch, iterates lane-related state through the `B179/B163` mapping, checks occupancy/readiness bytes and lane-block state, and calls already-known service/readiness helpers like `BD6F`, `B575`, and `B725`. Writes readiness/active-time style state such as `B03A`. Final gameplay-facing noun intentionally left open until the helper chain around `8CF9 / B923 / BCE1 / B223` is decoded more tightly.
