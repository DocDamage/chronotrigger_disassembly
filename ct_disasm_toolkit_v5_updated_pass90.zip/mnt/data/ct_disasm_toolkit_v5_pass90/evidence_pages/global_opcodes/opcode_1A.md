# Global Opcode 1A

- Status: **strengthened structural**
- Dispatch address: **C1:9656**
- Evidence pass: **66**
- Notes: Scans AF02 live-tail occupant submap for operand1; alternate mode skips current-slot hits and requires another matching live-tail entry

## Matching label evidence
- pass 66: `C1:9656..C1:96A4` **ct_global_opcode_1A_gate_tail_replay_on_live_tail_occupant_search_mode** (provisional)
  - Scans the live-tail occupant submap `AF02[0..AEC6-1]` for operand `+1`. Dead leading `LDA $B252` should be ignored; the real scan starts from `X = 0`. Operand `+2` enables a mode that skips current-slot hits and requires another matching live-tail entry. Operand `+3` controls the final success gate once a usable match is found.
