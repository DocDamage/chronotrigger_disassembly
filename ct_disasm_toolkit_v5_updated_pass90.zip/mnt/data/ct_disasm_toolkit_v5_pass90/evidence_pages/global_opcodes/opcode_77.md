# Global Opcode 77

- Status: **strong structural**
- Dispatch address: **C1:A8F9**
- Evidence pass: **71**
- Notes: Nonhead masked AE70 -> ADA1 selector family for record[+1E] & 0x02, scanning live slots 3..10 and skipping the primary-seed slot indexed by B18B.

## Matching label evidence
- pass 71: `C1:A8F9..C1:A934` **ct_global_opcode_77_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1E_mask_02** (strong)
  - Uses the shared nonhead FD-offset/mask pipeline. Tests `record[+1E] & 0x02`. Skips the primary-seed slot indexed by `B18B`.
