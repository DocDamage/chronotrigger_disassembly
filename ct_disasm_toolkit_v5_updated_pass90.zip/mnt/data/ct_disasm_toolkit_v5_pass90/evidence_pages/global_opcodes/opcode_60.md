# Global Opcode 60

- Status: **strong structural**
- Dispatch address: **C1:A541**
- Evidence pass: **70**
- Notes: Visible-only FD-record selector via shared AD68/AE70/ADA1 pipeline; practical contract is positive record[+1D], then B23A-ordered reduction with optional A4E0 redirect.

## Matching label evidence
- pass 70: `C1:A541..C1:A54A` **ct_global_opcode_60_select_visible_entries_by_positive_fd_record_byte_1D** (strong)
  - Sets selector offset `0x1D`. Uses the shared visible FD-offset family at `AD68`. Practical contract: positive `record[+1D]`, then reduce.
