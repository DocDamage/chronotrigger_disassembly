# Global Opcode 97

- Status: **strong**
- Dispatch address: **C1:8A9E**
- Evidence pass: **72**
- Notes: Exact RTS alias.

## Matching label evidence
- pass 72: `C1:8A9E` **ct_global_opcode_97_rts_alias** (strong)
  - Exact `RTS` entry.
