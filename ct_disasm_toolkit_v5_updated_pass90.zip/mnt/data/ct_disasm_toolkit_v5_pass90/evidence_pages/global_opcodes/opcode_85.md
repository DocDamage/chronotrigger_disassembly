# Global Opcode 85

- Status: **strong**
- Dispatch address: **C1:AAF8**
- Evidence pass: **69**
- Notes: Fixed single-entry selector wrapper: writes literal entry 10 into AECC[0], forces AECB = 1, and returns.

## Matching label evidence
- pass 58: `C1:AAAB..C1:AAF8` **ct_fixed_single_entry_selector_wrappers_3_through_10** (strong)
  - Family of tiny wrappers: `AECC = literal` `AECB = 1` `RTS` Covered literal values: `3..10`.
