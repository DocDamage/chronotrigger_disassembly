# Global Opcode 14

- Status: **provisional structural**
- Dispatch address: **C1:9514**
- Evidence pass: **66**
- Notes: Two-form current-B19E gate: primary form compares AF0A[B19E low nibble] against operand1 under equality/inequality control; alternate form collapses to current bit4 clear plus operand3 nonzero

## Matching label evidence
- pass 66: `C1:9514..C1:9599` **ct_global_opcode_14_gate_tail_replay_on_current_b19e_bit4_clear_selector_mode** (provisional)
  - Two-form handler. In the primary form (`operand+2 == 0`): requires current `B19E[X]` bit 4 clear uses `B19E[X] & 0x0F` to index `AF0A[...]` compares that byte against operand `+1` operand `+3` selects equality vs inequality In the alternate form (`operand+2 != 0`): still requires current `B19E[X]` bit 4 clear then effectively collapses to: operand `+3 == 0` -> fail operand `+3 != 0` -> success The apparent `01/02/05` compare chain in the alternate branch should not be overclaimed as real content logic.
