# Global Opcode 47

- Status: **provisional**
- Dispatch address: **C1:9B8D**
- Evidence pass: **68**
- Notes: Promoted master ownership of old group-2 opcode 07 body

## Matching label evidence
- no direct label rows matched yet
