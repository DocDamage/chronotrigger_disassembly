# Global Opcode 6F

- Status: **strong structural**
- Dispatch address: **C1:A737**
- Evidence pass: **69**
- Notes: Promoted master/global ownership of the pass-30 relation-query target selector for mode 03.

## Matching label evidence
- pass 69: `C1:A737..C1:A764` **ct_global_opcode_6F_select_target_relation_mode_03** (strong)
  - Promoted master/global ownership of the pass-30 relation-query target selector for mode `03`.
