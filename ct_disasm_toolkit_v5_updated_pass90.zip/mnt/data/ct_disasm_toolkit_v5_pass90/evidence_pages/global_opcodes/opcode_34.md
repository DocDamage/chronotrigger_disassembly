# Global Opcode 34

- Status: **strong**
- Dispatch address: **C1:9979**
- Evidence pass: **68**
- Notes: Exact shared alias of STZ AF24 ; RTS

## Matching label evidence
- no direct label rows matched yet
