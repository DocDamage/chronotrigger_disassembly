; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_FD
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; FD:A811  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 53 :: ct_fd_runtime_tail_slot_record_ptr_table
; qualifier: provisional
; notes: Indexed by the tail seeder through a 16-bit table lookup. Supplies the record source used to read at least: byte `+0x38` (effective speed in pass 52) byte `+0x0A` (source of the tail-only `AF15.bit6` side effect) Exact record family name still wants one more pass.
; source: chrono_trigger_labels_pass53.md
FD_A811_ct_fd_runtime_tail_slot_record_ptr_table:
    ; TODO: reconstruct body / data for FD:A811

; =============================================================================
; FD:A8A5  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_fd_service7_lane_block_is_eligible
; qualifier: strong
; notes: Tests one of three `0x80`-spaced WRAM lane blocks selected by lane ID Uses: `5E4A + lane*0x80`, bit 7 `5E4E + lane*0x80` OR `5E53 + lane*0x80`, bit 7 `5E4B + lane*0x80`, bits `7/2/1` (`#86`) Sets `B3EA = 1` on any qualifying hit.
; source: chrono_trigger_labels_pass42.md
FD_A8A5_ct_fd_service7_lane_block_is_eligible:
    ; TODO: reconstruct body / data for FD:A8A5

; =============================================================================
; FD:A8CE  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_fd_service7_clear_canonical_record_lane
; qualifier: strong
; notes: Computes `X = lane * 7`. Clears canonical fixed-record fields: `93EE + X` `93EF + X` `93F3 + X = FF` Then resets matching lane-carried state via `B158/AFAB/99DD/9F22/B188/B03A`.
; source: chrono_trigger_labels_pass42.md
FD_A8CE_ct_fd_service7_clear_canonical_record_lane:
    ; TODO: reconstruct body / data for FD:A8CE

; =============================================================================
; FD:A8FE  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_fd_service7_clear_occupied_lane_and_refresh_service2
; qualifier: strong
; notes: Strengthened by pass 43. The “refresh service 2” half is now specifically understood as callback into the
; source: chrono_trigger_labels_pass43.md
FD_A8FE_ct_fd_service7_clear_occupied_lane_and_refresh_service2:
    ; TODO: reconstruct body / data for FD:A8FE

; =============================================================================
; FD:A93C  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_fd_service7_dispatch_enabled_lane_clear_phase
; qualifier: strong
; notes: Iterates enabled lanes in `B3E7..B3E9`. Calls `FD:A8CE` for each enabled lane.
; source: chrono_trigger_labels_pass42.md
FD_A93C_ct_fd_service7_dispatch_enabled_lane_clear_phase:
    ; TODO: reconstruct body / data for FD:A93C

; =============================================================================
; FD:A95F  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_fd_service7_dispatch_enabled_lane_refresh_phase
; qualifier: strong
; notes: Iterates enabled lanes in `B3E7..B3E9`. Calls `FD:A8FE` for each enabled lane.
; source: chrono_trigger_labels_pass42.md
FD_A95F_ct_fd_service7_dispatch_enabled_lane_refresh_phase:
    ; TODO: reconstruct body / data for FD:A95F

; =============================================================================
; FD:ABA2  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 75 :: ct_fd_accumulate_slot_descriptor_vectors_and_optional_unique_token_queues
; qualifier: provisional strengthened
; notes: Requires `AF12[slot].bit6` clear and `AF0A[slot] != 0xFF`. Uses `AF0A[slot]` as an index into a 7-byte descriptor family via `DP28=index ; DP2A=7 ; JSL C1:FDBF`. Accumulates record components from `CC:5E00/02/06 + 7*index` into `B28C`, `B2A5`, and `B2DB/B2DD`. Under extra gates, inserts unique 8-bit tokens into the first free entries of `B2A7..B2A9` and `B2AA..B2AC`, setting `B2AF.bit5` when it does so. Final gameplay-facing nouns for those accumulators and token queues remain open.
; source: chrono_trigger_labels_pass75.md
FD_ABA2_ct_fd_accumulate_slot_descriptor_vectors_and_optional_unique_token_queues:
    ; TODO: reconstruct body / data for FD:ABA2
    ; known span hint: FD:ABA2..FD:AC6D

; =============================================================================
; FD:AC6E  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 75 :: ct_fd_consume_pending_slot_queue_and_attempt_admission_materialization
; qualifier: provisional strengthened
; notes: Uses `B3B9` as a nonzero queue gate/cursor seed and mirrors it into `B315`. Pulls pending slot ids from `B3AC[B315]` until exhausted or rejected. Validates pending slots against lane/block flags in the `5E4A/5E4B/5E78/5E7A/5E7B` neighborhood. On accepted slots may set `AFAB[slot]=1`, seeds `B18B=slot` and `AD8E=selected value`, then dispatches the downstream materialization/helper path through `C1:FDC7`. Clears `B3B9` when the queue walk finishes. Exact queue owner noun still wants one more pass.
; source: chrono_trigger_labels_pass75.md
FD_AC6E_ct_fd_consume_pending_slot_queue_and_attempt_admission_materialization:
    ; TODO: reconstruct body / data for FD:AC6E
    ; known span hint: FD:AC6E..FD:ACEE

; =============================================================================
; FD:ACEE  top-status=strong  labels=1
; =============================================================================
; [strong] pass 74 :: ct_fd_clear_ad9b_and_transient_ad9c_packet_workspace
; qualifier: strong structural
; notes: Clears `AD9B`. Clears exactly `0xB0` bytes starting at `AD9C`. This proves the transient packet workspace spans `AD9C..AE4B`.
; source: chrono_trigger_labels_pass74.md
FD_ACEE_ct_fd_clear_ad9b_and_transient_ad9c_packet_workspace:
    ; TODO: reconstruct body / data for FD:ACEE
    ; known span hint: FD:ACEE..FD:ACFC

; =============================================================================
; FD:B24D  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 55 :: ct_fd_initialize_head_battle_slot_occupant_maps_from_party_state
; qualifier: provisional
; notes: The head-map construction is strong. The exact upstream gameplay noun for the `2980` validity source is still left slightly cautious.
; source: chrono_trigger_labels_pass55.md
FD_B24D_ct_fd_initialize_head_battle_slot_occupant_maps_from_party_state:
    ; TODO: reconstruct body / data for FD:B24D
    ; known span hint: FD:B24D..FD:B27E

; =============================================================================
; FD:B28F  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 55 :: ct_fd_rebuild_visible_head_battler_to_slot_inverse_map
; qualifier: strengthened
; notes: Previously only loosely understood as a small inverse/lookup rebuild. Pass 55 freezes the exact source and direction: source: `AEFF[0..2]` destination: `B1BE[battler] = slot`
; source: chrono_trigger_labels_pass55.md
FD_B28F_ct_fd_rebuild_visible_head_battler_to_slot_inverse_map:
    ; TODO: reconstruct body / data for FD:B28F
    ; known span hint: FD:B28F..FD:B2A3

; =============================================================================
; FD:B2A3  top-status=strong  labels=1
; =============================================================================
; [strong] pass 56 :: ct_build_tail_live_and_canonical_occupant_maps
; qualifier: strong
; notes: Iterates 8 source records with stride `0x0C` rooted at `29C4`. Uses: `29C5 + n*0x0C` as the admit/skip gate `29C4 + n*0x0C` as the copied occupant ID `29C6 + n*0x0C` as the secondary live-withhold gate Populates: `AF02..AF09` `AF0D..AF14` `AF15.bit7` `AEC6`
; source: chrono_trigger_labels_pass56.md
FD_B2A3_ct_build_tail_live_and_canonical_occupant_maps:
    ; TODO: reconstruct body / data for FD:B2A3
    ; known span hint: FD:B2A3..FD:B2DD

; =============================================================================
; FD:B800  top-status=strong  labels=1
; =============================================================================
; [strong] pass 53 :: ct_fd_seed_battle_slot_readiness_head_and_tail_partitions
; qualifier: strong
; notes: Unified seed routine for the contiguous readiness arrays. Fixed head loop seeds slots `0..2`. Tail loop seeds the later runtime-slot partition starting at slot `3`. Ends by exporting only head work values (`AFAB..AFAD`) to the visible buffers.
; source: chrono_trigger_labels_pass53.md
FD_B800_ct_fd_seed_battle_slot_readiness_head_and_tail_partitions:
    ; TODO: reconstruct body / data for FD:B800
    ; known span hint: FD:B800..FD:B94F

; =============================================================================
; FD:B820  top-status=strong  labels=3
; =============================================================================
; [strong] pass 52 :: ct_fd_seed_primary_visible_lane_readiness_from_config_and_speed
; qualifier: strong
; notes: Primary visible-lane seed family. Computes page = `($2990 & 7)`. Loads adjustment from `CC:2E31[page*16 + speed - 1]`. Computes final seed: `0x69 - speed*6 + adjustment` Stores to: `B158` `AFAB` Sets `B03A = 1`.
; source: chrono_trigger_labels_pass52.md
FD_B820_ct_fd_seed_primary_visible_lane_readiness_from_config_and_speed:
    ; TODO: reconstruct body / data for FD:B820
    ; known span hint: FD:B820..FD:B850

; [strong] pass 51 :: ct_fd_seed_visible_lane_readiness_from_speed_like_stat
; qualifier: strong
; notes: Iterates selected visible participants. Clamps record byte `+0x38` to `0x10`. Uses the clamped value to index `CC:2E31`. Combines that table value with a `0x69` base and local `$2C` bias term. Stores the result to both `B158` and `AFAB`. Sets `B03A = 1` for the affected visible lane. Strongest safe reading: battle-side visible-lane readiness seed writer keyed by a speed-like stat.
; source: chrono_trigger_labels_pass51.md
FD_B820_ct_fd_seed_visible_lane_readiness_from_speed_like_stat:
    ; TODO: reconstruct body / data for FD:B820
    ; known span hint: FD:B820..FD:B850

; [unspecified] pass 52 :: old wording “seed ... from speed-like stat”                 [soft-replaced]
; notes: Too narrow after config-field/page proof. Replaced by `ct_fd_seed_primary_visible_lane_readiness_from_config_and_speed`.
; source: chrono_trigger_labels_pass52.md
FD_B820_old_wording_seed_from_speed_like_stat_soft_replaced:
    ; TODO: reconstruct body / data for FD:B820
    ; known span hint: FD:B820..FD:B850

; =============================================================================
; FD:B8C0  top-status=provisional  labels=2
; =============================================================================
; [provisional] pass 52 :: ct_fd_seed_sibling_visible_lane_readiness_from_config_and_speed
; qualifier: provisional
; notes: Uses the same core formula as the primary family: `0x69 - speed*6 + adjustment` Stores to: `B15B` `AFAE` Sets `B03D` only when `AF02[slot] != FF`. Also conditionally ORs `#$40` into `AF15[slot]` when record byte `+0x0A` has bit 0 set. Final freeze deferred until the higher-level semantic split between the primary/sibling pairs is tighter.
; source: chrono_trigger_labels_pass52.md
FD_B8C0_ct_fd_seed_sibling_visible_lane_readiness_from_config_and_speed:
    ; TODO: reconstruct body / data for FD:B8C0
    ; known span hint: FD:B8C0..FD:B8E0

; [provisional] pass 51 :: ct_fd_seed_visible_lane_readiness_sibling_family
; qualifier: provisional
; notes: Structural sibling of `FD:B820..B850`. Writes to `B15B/AFAE` and sets `B03D`. Almost certainly the adjacent visible-lane seed family, but still worth one more pass before freezing the final name.
; source: chrono_trigger_labels_pass51.md
FD_B8C0_ct_fd_seed_visible_lane_readiness_sibling_family:
    ; TODO: reconstruct body / data for FD:B8C0
    ; known span hint: FD:B8C0..FD:B8E0

; =============================================================================
; FD:B8F5  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 54 :: ct_fd_normalize_head_readiness_work_before_visible_export
; qualifier: replaced
; notes: Too vague after pass 54. Replaced by: `ct_fd_normalize_active_battle_slot_readiness_to_minimum_one_before_head_export`
; source: chrono_trigger_labels_pass54.md
FD_B8F5_ct_fd_normalize_head_readiness_work_before_visible_export:
    ; TODO: reconstruct body / data for FD:B8F5
    ; known span hint: FD:B8F5..FD:B93A

; =============================================================================
; FD:B8F7  top-status=strong  labels=1
; =============================================================================
; [strong] pass 54 :: ct_fd_normalize_active_battle_slot_readiness_to_minimum_one_before_head_export
; qualifier: strong
; notes: Real post-seed normalization body. Scans the unified work array `AFAB..AFB5`. Selects the smallest eligible **positive** entry. Computes subtractive delta = `(min - 1)`. Subtracts that delta from every eligible positive entry. Leaves zero entries unchanged. Leaves `AEFF == FF` entries unchanged. Runs immediately before the head export at `B93B..B94F`.
; source: chrono_trigger_labels_pass54.md
FD_B8F7_ct_fd_normalize_active_battle_slot_readiness_to_minimum_one_before_head_export:
    ; TODO: reconstruct body / data for FD:B8F7
    ; known span hint: FD:B8F7..FD:B93A

; =============================================================================
; FD:B91B  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 54 :: ct_fd_subtract_selected_minimum_minus_one_from_active_positive_readiness_entries
; qualifier: provisional
; notes: This is the arithmetic heart of the normalization routine. Useful as an internal sublabel if the disassembly later wants finer block labels. Semantics are already well understood; kept provisional only because the project has not yet frozen sub-block naming style consistently.
; source: chrono_trigger_labels_pass54.md
FD_B91B_ct_fd_subtract_selected_minimum_minus_one_from_active_positive_readiness_entries:
    ; TODO: reconstruct body / data for FD:B91B
    ; known span hint: FD:B91B..FD:B939

