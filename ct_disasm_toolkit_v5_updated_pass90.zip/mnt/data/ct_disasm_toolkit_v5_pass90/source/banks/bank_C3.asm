; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_C3
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; C3:0002  top-status=strong  labels=1
; =============================================================================
; [strong] pass 78 :: ct_c3_unpack_stream_to_caller_selected_wram_buffer_veneer
; qualifier: strong
; notes: Exact body is `JMP $0557`. Used by service-04 and many other callers as the standard packed-stream-to-WRAM entry. Caller passes source pointer in `0300..0302`, destination pointer in `0303..0305`, and receives output size in `0306`.
; source: chrono_trigger_labels_pass78.md
C3_0002_ct_c3_unpack_stream_to_caller_selected_wram_buffer_veneer:
    ; TODO: reconstruct body / data for C3:0002
    ; known span hint: C3:0002..C3:0004

; =============================================================================
; C3:0557  top-status=strong  labels=1
; =============================================================================
; [strong] pass 78 :: ct_c3_unpack_packed_stream_to_wram_via_2180_and_return_output_size
; qualifier: strong structural
; notes: Writes destination address through `$2181/$2183` and output bytes through `$2180`, proving it materializes directly into caller-selected WRAM. Contains multiple inner packed decode variants, but all branches are output materializers in the same family. Exit path stores `Y - start_dest_offset` into `0306`, so the returned value is output byte count / destination advance.
; source: chrono_trigger_labels_pass78.md
C3_0557_ct_c3_unpack_packed_stream_to_wram_via_2180_and_return_output_size:
    ; TODO: reconstruct body / data for C3:0557
    ; known span hint: C3:0557..C3:08A8

