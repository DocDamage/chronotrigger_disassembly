; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_D1
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; D1:5800  top-status=strong  labels=7
; =============================================================================
; [strong] pass 44 :: ct_d1_tilemap_template_default_0b40_0180
; qualifier: strong
; notes: Default/reset ROM template copied into `0B40` by `C1:1C3A`. Same size as the upload buffer and structurally part of the same tilemap-template family.
; source: chrono_trigger_labels_pass44.md
D1_5800_ct_d1_tilemap_template_default_0b40_0180:
    ; TODO: reconstruct body / data for D1:5800

; [provisional] pass 46 :: / D1:5A50 / D1:5BD0  ct_d1_alt_base_strip_layout_family      [strengthened context]
; notes: Pass 46 strengthens their caller-context roles: `5800` = default/base restore through `C1:1C3A` `5A50` = latched alternate via `A86A` `5BD0` = transition/reset alternate in later state-advance paths
; source: chrono_trigger_labels_pass46.md
D1_5800_D1_5A50_D1_5BD0_ct_d1_alt_base_strip_layout_family_strengthened_context:
    ; TODO: reconstruct body / data for D1:5800

; [provisional] pass 46 :: ct_d1_base_strip_template_default
; qualifier: provisional
; notes: Caller context strongly suggests the default/base restore variant. Final gameplay-facing mode name still open.
; source: chrono_trigger_labels_pass46.md
D1_5800_ct_d1_base_strip_template_default:
    ; TODO: reconstruct body / data for D1:5800

; [provisional] pass 45 :: / D1:5A50 / D1:5BD0  ct_d1_alt_base_strip_layout_family        [provisional]
; notes: The three templates are clearly alternate base layouts within the same 32x6 strip region. Exact gameplay/UI mode names are still unresolved.
; source: chrono_trigger_labels_pass45.md
D1_5800_D1_5A50_D1_5BD0_ct_d1_alt_base_strip_layout_family_provisional:
    ; TODO: reconstruct body / data for D1:5800

; [provisional] pass 45 :: / D1:5A50 / D1:5BD0  ct_d1_tilemap_template_family_16x12_words [withdrawn]
; notes: Pass 45 corrects this earlier provisional geometry. The safer keepable geometry is `32x6`, not `16x12`.
; source: chrono_trigger_labels_pass45.md
D1_5800_D1_5A50_D1_5BD0_ct_d1_tilemap_template_family_16x12_words_withdrawn:
    ; TODO: reconstruct body / data for D1:5800

; [unspecified] pass 45 :: / D1:5A50 / D1:5BD0  ct_d1_base_strip_template_family_32x6     [strong]
; notes: Corrected geometrically in this pass. All three `0x0180`-byte base templates are best modeled as 32-word by 6-row strip layouts. Used as the base tilemap copied into `0B40` before dynamic patching and upload.
; source: chrono_trigger_labels_pass45.md
D1_5800_D1_5A50_D1_5BD0_ct_d1_base_strip_template_family_32x6_strong:
    ; TODO: reconstruct body / data for D1:5800

; [unspecified] pass 44 :: / D1:5A50 / D1:5BD0  ct_d1_tilemap_template_family_16x12_words [provisional]
; notes: The three source blocks are best interpreted as a 192-word (likely 16x12) template family. This matrix interpretation fits both the dense row-structured data and the fixed-size VRAM upload,
; source: chrono_trigger_labels_pass44.md
D1_5800_D1_5A50_D1_5BD0_ct_d1_tilemap_template_family_16x12_words_provisional:
    ; TODO: reconstruct body / data for D1:5800

; =============================================================================
; D1:59FC  top-status=strong  labels=1
; =============================================================================
; [strong] pass 45 :: ct_d1_panel_segment_template_6x7_words
; qualifier: strong
; notes: Unique ROM source table used by `C1:0929`. Resolves cleanly as 6 rows of 7 words. Tile values form a compact border/interior segment template rather than logic data.
; source: chrono_trigger_labels_pass45.md
D1_59FC_ct_d1_panel_segment_template_6x7_words:
    ; TODO: reconstruct body / data for D1:59FC

; =============================================================================
; D1:5A50  top-status=strong  labels=2
; =============================================================================
; [strong] pass 44 :: ct_d1_tilemap_template_alt_a_0b40_0180
; qualifier: strong
; notes: Alternate ROM template variant copied into `0B40` by the `0EA1..0EB1` path. Followed by `INC $99E2`, proving it feeds the same upload path as the default template.
; source: chrono_trigger_labels_pass44.md
D1_5A50_ct_d1_tilemap_template_alt_a_0b40_0180:
    ; TODO: reconstruct body / data for D1:5A50

; [provisional] pass 46 :: ct_d1_base_strip_template_latched_alt
; qualifier: provisional
; notes: Single-shot alternate selected when `A86A` is nonzero, then that latch is cleared. Kept provisional until the higher-level mode name is pinned.
; source: chrono_trigger_labels_pass46.md
D1_5A50_ct_d1_base_strip_template_latched_alt:
    ; TODO: reconstruct body / data for D1:5A50

; =============================================================================
; D1:5BD0  top-status=strong  labels=2
; =============================================================================
; [strong] pass 44 :: ct_d1_tilemap_template_alt_b_0b40_0180
; qualifier: strong
; notes: Alternate ROM template variant copied into `0B40` by the `1301..1315`, Followed by `INC $99E2`, proving it feeds the same upload path as the default template.
; source: chrono_trigger_labels_pass44.md
D1_5BD0_ct_d1_tilemap_template_alt_b_0b40_0180:
    ; TODO: reconstruct body / data for D1:5BD0

; [provisional] pass 46 :: ct_d1_base_strip_template_transition_alt
; qualifier: provisional
; notes: Copied in later state-transition/reset paths with surrounding controller bookkeeping. Strong structural role, but final mode name still unresolved.
; source: chrono_trigger_labels_pass46.md
D1_5BD0_ct_d1_base_strip_template_transition_alt:
    ; TODO: reconstruct body / data for D1:5BD0

; =============================================================================
; D1:646C  top-status=strong  labels=1
; =============================================================================
; [strong] pass 79 :: ct_d1_auxiliary_descriptor_pointer_table
; qualifier: strong structural
; notes: `15D5` multiplies the descriptor id by two and reads a pointer from this table. The returned pointer seeds one active runtime slot in the optional auxiliary descriptor stage.
; source: chrono_trigger_labels_pass79.md
D1_646C_ct_d1_auxiliary_descriptor_pointer_table:
    ; TODO: reconstruct body / data for D1:646C
    ; known span hint: D1:646C..D1:652B

; =============================================================================
; D1:E70A  top-status=strong  labels=1
; =============================================================================
; [strong] pass 83 :: ct_d1_optional_exchange_secondary_and_tertiary_palette_band_pairs
; qualifier: strong structural
; notes: Clears `A101`. Tests `2A21.bit1`; when set, toggles bit `0x40` in `0575`. Exchanges the full 48-word pairs `2120..217F <-> 21A0..21FF` and `2320..237F <-> 23A0..23FF`. Decrements direct-page `$40` and returns. Strongest safe reading: selector-sensitive band-exchange helper.
; source: chrono_trigger_labels_pass83.md
D1_E70A_ct_d1_optional_exchange_secondary_and_tertiary_palette_band_pairs:
    ; TODO: reconstruct body / data for D1:E70A
    ; known span hint: D1:E70A..D1:E77B

; =============================================================================
; D1:E899  top-status=strong  labels=1
; =============================================================================
; [strong] pass 82 :: ct_d1_fill_palette_band_pairs_2040_2240_and_2120_2320_with_7fff_sentinel
; qualifier: strong
; notes: Fills `7E:2040..20FF` and `7E:2240..22FF` with `0x7FFF`. Then fills `7E:2120..217F` and `7E:2320..237F` with the same sentinel. Exact structural role: paired palette-band/table sentinel initializer.
; source: chrono_trigger_labels_pass82.md
D1_E899_ct_d1_fill_palette_band_pairs_2040_2240_and_2120_2320_with_7fff_sentinel:
    ; TODO: reconstruct body / data for D1:E899
    ; known span hint: D1:E899..D1:E8C0

; =============================================================================
; D1:E8C1  top-status=strong  labels=1
; =============================================================================
; [strong] pass 82 :: ct_d1_fill_palette_band_pair_21a0_23a0_with_7fff_sentinel
; qualifier: strong
; notes: Fills `7E:21A0..21FF` and `7E:23A0..23FF` with `0x7FFF`. Exact smaller sibling of `D1:E899`.
; source: chrono_trigger_labels_pass82.md
D1_E8C1_ct_d1_fill_palette_band_pair_21a0_23a0_with_7fff_sentinel:
    ; TODO: reconstruct body / data for D1:E8C1
    ; known span hint: D1:E8C1..D1:E8D4

; =============================================================================
; D1:E91A  top-status=strong  labels=1
; =============================================================================
; [strong] pass 82 :: ct_d1_promote_first_48color_palette_band_and_restore_active_3record_descriptor_slab
; qualifier: strong structural
; notes: Copies `7E:2040..209F` into `7E:20A0..20FF` and `7E:22A0..22FF`, then clears `7E:2040..209F` and `7E:2240..229F`. Copies `7E:0544..0567` back into `7E:0520..0543`. Adds `0x30` to the `+1` byte of each copied 12-byte record. Seeds `0520/052C/0538` and `CD2F..CD31` with `0x30`. Clears `CD32..CD34` and `CDC8`. Increments `CE12`. Strongest safe reading: promote/copy helper for one palette-band pair plus one active descriptor slab restore/arm step.
; source: chrono_trigger_labels_pass82.md
D1_E91A_ct_d1_promote_first_48color_palette_band_and_restore_active_3record_descriptor_slab:
    ; TODO: reconstruct body / data for D1:E91A
    ; known span hint: D1:E91A..D1:E983

; =============================================================================
; D1:E984  top-status=strong  labels=1
; =============================================================================
; [strong] pass 82 :: ct_d1_seed_first_48color_palette_band_from_d0_fd00_and_snapshot_active_descriptor_slab_outward
; qualifier: strong structural
; notes: Increments `CDC8` and `CE0F`. Copies ROM data from `D0:FD00..FD5F` into `7E:2040..209F` and `7E:2240..229F`. Copies `7E:0520..0543` outward into `7E:0544..0567`. Subtracts `0x30` from the `+1` byte of each copied 12-byte record. Seeds `0548/0554/0560` with `0x0100`. Seeds `0544/0550/055C` and `CD32..CD34` with `0x30`. Increments `CE12`. Strongest safe reading: complementary seed/snapshot helper paired with `D1:E91A`.
; source: chrono_trigger_labels_pass82.md
D1_E984_ct_d1_seed_first_48color_palette_band_from_d0_fd00_and_snapshot_active_descriptor_slab_o:
    ; TODO: reconstruct body / data for D1:E984
    ; known span hint: D1:E984..D1:E9EB

; =============================================================================
; D1:EC27  top-status=strong  labels=1
; =============================================================================
; [strong] pass 86 :: ct_d1_build_four_endpoint_pairs_from_mulhi_and_current_5da0_5da1_pair_then_call_f9af
; qualifier: strong structural
; notes: Reads one immediate/index through `[$40]`, transforms the `4217` multiply-result high byte, builds four endpoint pairs in `CD0D..CD1B`, uses `5DA0` with `-0x10/+0x10`, uses `5DA1` as the paired byte for both records, then calls `D1:F9AF`. Strongest safe reading: D1 helper that converts the current `5DA0/5DA1` pair plus one transformed multiply-derived byte into four coordinate/endpoint pairs for downstream geometry-style processing.
; source: chrono_trigger_labels_pass86.md
D1_EC27_ct_d1_build_four_endpoint_pairs_from_mulhi_and_current_5da0_5da1_pair_then_call_f9af:
    ; TODO: reconstruct body / data for D1:EC27
    ; known span hint: D1:EC27..D1:EC5B

; =============================================================================
; D1:EDCD  top-status=strong  labels=2
; =============================================================================
; [strong] pass 89 :: ct_d1_stamp_clamped_lower_edge_byte_into_selected_primary_or_shadow_four_lane_family
; qualifier: strong structural
; notes: Reads one selector byte from `[$40]` and takes this path only when that selector is zero. Computes `low = max(0, 5DA0 - CD3A)` and `high = min(0xFF, 5DA0 + CD3A)`. If `CD3A < 0x08`, increments `CD3A`. Exact write loop uses only the low byte in `$45`, not the computed high edge. Exact primary roots written when `7C.bit0 == 0`: `C161 / C235 / C309 / C3DD`. Exact shadow roots written when `7C.bit0 != 0`: `C4E1 / C5B5 / C689 / C75D`. Loop advances `X += 4` until `X == 0x00D4`. Strongest safe reading: clamped lower-edge byte stamp into one selected four-lane family.
; source: chrono_trigger_labels_pass89.md
D1_EDCD_ct_d1_stamp_clamped_lower_edge_byte_into_selected_primary_or_shadow_four_lane_family:
    ; TODO: reconstruct body / data for D1:EDCD
    ; known span hint: D1:EDCD..D1:EE2F

; [strong] pass 86 :: ct_d1_expand_current_5da0_5da1_axis_pair_by_cd3a_cd3b_into_four_plane_span_strips
; qualifier: strong structural
; notes: Selector `[$40] == 0` path uses `5DA0` and `CD3A`, clamps low/high bounds, and fills one of two four-plane strip families with the computed byte at stride 4. Selector `[$40] != 0` path uses `5DA1` and `CD3B`, clamps bounds, and clears one of two corresponding four-plane strip families across the computed span. Strongest safe reading: D1 axis-span helper consuming the current `5DA0/5DA1` pair as horizontal/vertical coordinates.
; source: chrono_trigger_labels_pass86.md
D1_EDCD_ct_d1_expand_current_5da0_5da1_axis_pair_by_cd3a_cd3b_into_four_plane_span_strips:
    ; TODO: reconstruct body / data for D1:EDCD
    ; known span hint: D1:EDCD..D1:EE95

; =============================================================================
; D1:EE33  top-status=strong  labels=1
; =============================================================================
; [strong] pass 89 :: ct_d1_fill_selected_primary_or_shadow_companion_word_lane_across_clamped_span
; qualifier: strong structural
; notes: This is the selector-nonzero path from the same local cluster. Computes `low = max(0, 5DA1 - CD3B)` and `high = min(0xD4, 5DA1 + CD3B)`. If `CD3B < 0x09`, increments `CD3B`. Converts `low` and `high` to 4-byte stepped offsets. Exact fill value is `0xFF00`. Exact roots: primary `C163`, shadow `C4E3`, selected by `7C.bit0`. Strongest safe reading: companion clamped-span fill over one selected word lane.
; source: chrono_trigger_labels_pass89.md
D1_EE33_ct_d1_fill_selected_primary_or_shadow_companion_word_lane_across_clamped_span:
    ; TODO: reconstruct body / data for D1:EE33
    ; known span hint: D1:EE33..D1:EE95

; =============================================================================
; D1:EEA6  top-status=strong  labels=1
; =============================================================================
; [strong] pass 89 :: ct_d1_seed_descending_word_ramp_into_primary_c15f_lane_family_from_cd3a
; qualifier: strong structural
; notes: Computes `Y = (0xC0 - CD3A) * 4`. With `A=0`, stores ascending 16-bit values `0, 1, 2, ...` into `C15F + Y`, stepping backwards by 4 each iteration until `Y < 0`. Increments `CD3A` before returning. Strongest safe reading: descending ramp seed for the primary `C15F` lane family controlled by `CD3A`.
; source: chrono_trigger_labels_pass89.md
D1_EEA6_ct_d1_seed_descending_word_ramp_into_primary_c15f_lane_family_from_cd3a:
    ; TODO: reconstruct body / data for D1:EEA6
    ; known span hint: D1:EEA6..D1:EEC4

; =============================================================================
; D1:EEC5  top-status=strong  labels=1
; =============================================================================
; [strong] pass 89 :: ct_d1_build_primary_four_lane_curve_profile_from_cef48e_e500_and_center_words
; qualifier: strong structural
; notes: Updates `CD3A` from the stream byte at `[$40]`. Derives `4B = 0x60 - CD3A`, `4D = (0x60 - CD3A) >> 1`, `45 = 7C * 4`, `47 = 7C * 2`. Builds `4F` and `51` from exact sums of `CA5A + CA5E` and `CA5C + CA60`. Iterates across an exact `0x350` span in `Y += 8` steps. Samples the monotone table at `CE:F48E` and uses `4202 / 4203 / 4217` hardware multiply. Stores signed/profile-adjusted results into the first four primary lanes rooted at `C15D / C15F / C161 / C163`. Strongest safe reading: primary four-lane curve/profile writer feeding the raster-target workspace.
; source: chrono_trigger_labels_pass89.md
D1_EEC5_ct_d1_build_primary_four_lane_curve_profile_from_cef48e_e500_and_center_words:
    ; TODO: reconstruct body / data for D1:EEC5
    ; known span hint: D1:EEC5..D1:F107

; =============================================================================
; D1:EF63  top-status=strong  labels=1
; =============================================================================
; [strong] pass 89 :: ct_d1_store_signed_profile_sample_into_primary_c15d_and_c161_lanes_and_prime_secondary_multiply
; qualifier: strong structural
; notes: Sign-extends the sampled byte when required. Adds it to baseline table word `E500,Y`. Stores the result to both `C15D,Y` and `C161,Y`. Then seeds the next hardware multiply from `CE:F48E` using the `45 / 4D` path. Strongest safe reading: signed sample store helper for the `C15D / C161` primary pair.
; source: chrono_trigger_labels_pass89.md
D1_EF63_ct_d1_store_signed_profile_sample_into_primary_c15d_and_c161_lanes_and_prime_secondary_m:
    ; TODO: reconstruct body / data for D1:EF63
    ; known span hint: D1:EF63..D1:EFCF

; =============================================================================
; D1:F0E9  top-status=strong  labels=1
; =============================================================================
; [strong] pass 89 :: ct_d1_store_signed_profile_sample_into_primary_c15f_and_c163_lanes
; qualifier: strong structural
; notes: Sign-extends the sampled byte when required. Adds it to center word `51`. Stores the result to both `C15F,Y` and `C163,Y`. Strongest safe reading: signed sample store helper for the `C15F / C163` primary pair.
; source: chrono_trigger_labels_pass89.md
D1_F0E9_ct_d1_store_signed_profile_sample_into_primary_c15f_and_c163_lanes:
    ; TODO: reconstruct body / data for D1:F0E9
    ; known span hint: D1:F0E9..D1:F107

; =============================================================================
; D1:F260  top-status=strong  labels=1
; =============================================================================
; [strong] pass 84 :: ct_d1_reset_control_cluster_state_including_ce0f_ce12_and_cfff
; qualifier: strong structural
; notes: Exact writes in this subsection clear `CE0E / CE0F / CE10 / CE12 / CFFF` and seed neighboring D1 control bytes. Strongest safe reading: local reset/init subsection for the D1 palette/control cluster.
; source: chrono_trigger_labels_pass84.md
D1_F260_ct_d1_reset_control_cluster_state_including_ce0f_ce12_and_cfff:
    ; TODO: reconstruct body / data for D1:F260
    ; known span hint: D1:F260..D1:F297

; =============================================================================
; D1:F331  top-status=strong  labels=1
; =============================================================================
; [strong] pass 90 :: ct_d1_seed_local_lane_and_raster_workspace_then_invoke_four_stage_followup_pipeline
; qualifier: strong structural
; notes: Clears `C861 / C862`. Seeds `CD46` from `2A21.bit0` as exact `00` vs `FD`. Seeds exact constants into `C14F / C150`, `BEA1 / BEA5 / BEA9`, `CA04 / CA08 / CA0C / CA10 / CA14`, and `C02B / C02D`. Calls the already-frozen `D1:F411` descriptor-header snapshot helper. Seeds exact stepped table families at `BEAB/BEAD` and `BF6B/BF6D`. Fills both `C161` and `C4E1` with `0x00FF` across an exact `0x0380` span. Clears `BB05` across an exact `0x0180` span. Copies `2030..203E` into `CCEE..CCFC`. Runs the exact tail `CE:EE6E -> D1:F83D -> CD:0235 -> C0:0008`, then increments `CAD3` and returns. Strongest safe reading: local orchestrator for the pass-88/89 lane+raster build pipeline.
; source: chrono_trigger_labels_pass90.md
D1_F331_ct_d1_seed_local_lane_and_raster_workspace_then_invoke_four_stage_followup_pipeline:
    ; TODO: reconstruct body / data for D1:F331
    ; known span hint: D1:F331..D1:F410

; =============================================================================
; D1:F411  top-status=strong  labels=1
; =============================================================================
; [strong] pass 83 :: ct_d1_snapshot_palette_descriptor_header_bytes_8slots_to_cd2f_cd36
; qualifier: strong
; notes: Walks the 8-slot `0520 + n*0C` descriptor queue. Copies the first byte of each slot (`0520/052C/0538/0544/0550/055C/0568/0574`) into `CD2F..CD36`. Exact structural role: descriptor-header shadow helper.
; source: chrono_trigger_labels_pass83.md
D1_F411_ct_d1_snapshot_palette_descriptor_header_bytes_8slots_to_cd2f_cd36:
    ; TODO: reconstruct body / data for D1:F411
    ; known span hint: D1:F411..D1:F426

; =============================================================================
; D1:F427  top-status=strong  labels=1
; =============================================================================
; [strong] pass 83 :: ct_d1_select_descriptor_header_suspend_or_restore_by_cfff
; qualifier: strong structural
; notes: Reads `CFFF`. `CFFF != 0` jumps to the shadow-and-suspend path at `D1:F431`. `CFFF == 0` jumps to the restore path at `D1:F457`.
; source: chrono_trigger_labels_pass83.md
D1_F427_ct_d1_select_descriptor_header_suspend_or_restore_by_cfff:
    ; TODO: reconstruct body / data for D1:F427
    ; known span hint: D1:F427..D1:F430

; =============================================================================
; D1:F431  top-status=strong  labels=1
; =============================================================================
; [strong] pass 83 :: ct_d1_arm_ce12_shadow_descriptor_headers_and_suspend_family_10_slots
; qualifier: strong structural
; notes: Returns immediately when `CE12 != 0`. Otherwise increments `CE12`, snapshots all 8 descriptor headers through `D1:F411`, and scans the full 8-slot queue. Clears only non-negative `0x1x` header bytes in `0520 + n*0C`. Strongest safe reading: one-shot shadow-and-suspend path for the positive palette-animation family.
; source: chrono_trigger_labels_pass83.md
D1_F431_ct_d1_arm_ce12_shadow_descriptor_headers_and_suspend_family_10_slots:
    ; TODO: reconstruct body / data for D1:F431
    ; known span hint: D1:F431..D1:F456

; =============================================================================
; D1:F457  top-status=strong  labels=1
; =============================================================================
; [strong] pass 83 :: ct_d1_restore_shadowed_descriptor_headers_from_cd2f_cd36_and_clear_ce12
; qualifier: strong structural
; notes: Returns immediately when `CE12 == 0`. Otherwise clears `CE12` and restores `CD2F..CD36` back into the first byte of all 8 descriptor slots. Strongest safe reading: one-shot restore half paired with `D1:F431`.
; source: chrono_trigger_labels_pass83.md
D1_F457_ct_d1_restore_shadowed_descriptor_headers_from_cd2f_cd36_and_clear_ce12:
    ; TODO: reconstruct body / data for D1:F457
    ; known span hint: D1:F457..D1:F473

; =============================================================================
; D1:F474  top-status=strong  labels=1
; =============================================================================
; [strong] pass 90 :: ct_d1_lookup_c0fe00_byte_indexed_by_a_plus_7c
; qualifier: strong helper
; notes: Exact body: `ADC $7C ; TAX ; LDA C0:FE00,X ; RTS`. Strongest safe reading: tiny lookup helper over table `C0:FE00`, indexed by `A + 7C`.
; source: chrono_trigger_labels_pass90.md
D1_F474_ct_d1_lookup_c0fe00_byte_indexed_by_a_plus_7c:
    ; TODO: reconstruct body / data for D1:F474
    ; known span hint: D1:F474..D1:F47B

; =============================================================================
; D1:F47C  top-status=strong  labels=1
; =============================================================================
; [strong] pass 90 :: ct_d1_stage_negated_masked_pair_into_ca5a_ca5c_from_stream_and_c0fe00_lookup
; qualifier: strong structural
; notes: Reads two exact stream-side bytes through `[$40]` / `[$40],Y`. Uses `D1:F474` to fetch lookup bytes from `C0:FE00` indexed by `A + 7C`. Applies `AND` with the saved stream byte, then adds the corresponding base stream byte. Stores exact negated 16-bit results into `CA5A,X` and `CA5C,X` for the runtime slot selected by `43`. Advances the stream pointer by 2 before returning. Strongest safe reading: masked-pair staging helper for the `CA5A / CA5C` center-offset seed words.
; source: chrono_trigger_labels_pass90.md
D1_F47C_ct_d1_stage_negated_masked_pair_into_ca5a_ca5c_from_stream_and_c0fe00_lookup:
    ; TODO: reconstruct body / data for D1:F47C
    ; known span hint: D1:F47C..D1:F4BF

; =============================================================================
; D1:F5CD  top-status=strong  labels=1
; =============================================================================
; [strong] pass 86 :: ct_d1_snapshot_current_5da0_5da5_three_pair_bundle_into_indexed_caea_record
; qualifier: strong structural
; notes: Exact body copies `5DA0/5DA2/5DA4/5DA1/5DA3/5DA5` into `CAEA/CAEE/CAF2/CAEC/CAF0/CAF4` using the immediate byte from `[$40]` as X index. Strongest safe reading: D1-side reusable snapshot helper for the current three-pair bundle into one indexed `CAEA..CAF5` record.
; source: chrono_trigger_labels_pass86.md
D1_F5CD_ct_d1_snapshot_current_5da0_5da5_three_pair_bundle_into_indexed_caea_record:
    ; TODO: reconstruct body / data for D1:F5CD
    ; known span hint: D1:F5CD..D1:F5F2

; =============================================================================
; D1:F5F6  top-status=strong  labels=1
; =============================================================================
; [strong] pass 88 :: ct_d1_mirror_selected_0x70_band_between_primary_and_shadow_companion_raster_target_bundles
; qualifier: strong structural
; notes: Mirrors one selected `0x70` window between the exact root families below, in `X += 4` steps. Exact primary roots: `C163 / C1D3 / C243 / C2B3 / C323 / C393 / C403 / C473`. Exact shadow roots: `C4E3 / C553 / C5C3 / C633 / C6A3 / C713 / C783 / C7F3`. `7C.bit0` chooses primary -> shadow vs shadow -> primary. Strongest safe reading: companion selected-band mirror helper for the `0x70` raster-target family.
; source: chrono_trigger_labels_pass88.md
D1_F5F6_ct_d1_mirror_selected_0x70_band_between_primary_and_shadow_companion_raster_target_bundl:
    ; TODO: reconstruct body / data for D1:F5F6
    ; known span hint: D1:F5F6..D1:F676

; =============================================================================
; D1:F83D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 90 :: ct_d1_seed_c030_c090_c0f0_c120_quartet_table_family_and_tail_sentinels
; qualifier: strong structural
; notes: Clears `C02F..C14E` across an exact `0x0120`-byte span. Builds 24 exact 4-byte records in the `C030/C031` and `C090/C091` neighborhoods using running words stepped by `-0x55` and `+0x55`. Builds 12 exact 4-byte records in the `C0F0/C0F1` and `C120/C121` neighborhoods using running words stepped by `-0xAA` and `+0xAA`. Seeds `C0ED = 0xE0` and `C14D = 0xE0`. Clears `C0EB / C0EC / C0EE / C14B / C14C / C14E`. Strongest safe reading: quartet-table seed helper immediately upstream of `CD:0235 / C0:0008`.
; source: chrono_trigger_labels_pass90.md
D1_F83D_ct_d1_seed_c030_c090_c0f0_c120_quartet_table_family_and_tail_sentinels:
    ; TODO: reconstruct body / data for D1:F83D
    ; known span hint: D1:F83D..D1:F8EA

; =============================================================================
; D1:F8EB  top-status=strong  labels=1
; =============================================================================
; [strong] pass 87 :: ct_d1_sort_four_row_column_point_pairs_by_column_byte_ascending
; qualifier: strong structural
; notes: Exact body is a four-pass bubble-sort-style loop comparing `13/15/17/19` and swapping the paired bytes `12/14/16/18` in lockstep. Strongest safe reading: in-place sort of four `(row,column)` point pairs by the second-byte column/X key ascending.
; source: chrono_trigger_labels_pass87.md
D1_F8EB_ct_d1_sort_four_row_column_point_pairs_by_column_byte_ascending:
    ; TODO: reconstruct body / data for D1:F8EB
    ; known span hint: D1:F8EB..D1:F91B

; =============================================================================
; D1:F91C  top-status=strong  labels=1
; =============================================================================
; [strong] pass 87 :: ct_d1_compute_four_signed_row_per_column_edge_steps_for_cd0d_fourpoint_bundle
; qualifier: strong structural
; notes: Calls `F972` four times and stores the returned signed steps into local slope slots `03 / 05 / 07 / 09`. Exact edge schedule is `(12,13)->(16,17)`, `(16,17)->(18,19)`, `(12,13)->(14,15)`, `(14,15)->(18,19)`. Strongest safe reading: edge-step builder for the D1 four-point column-raster work bundle.
; source: chrono_trigger_labels_pass87.md
D1_F91C_ct_d1_compute_four_signed_row_per_column_edge_steps_for_cd0d_fourpoint_bundle:
    ; TODO: reconstruct body / data for D1:F91C
    ; known span hint: D1:F91C..D1:F971

; =============================================================================
; D1:F972  top-status=strong  labels=1
; =============================================================================
; [strong] pass 87 :: ct_d1_compute_signed_row_per_column_step_via_hw_divide
; qualifier: strong structural
; notes: Uses `4204/4206` and reads quotient `4214` after taking the signed row delta between `0B` and `0C` and the column delta in `0D`. Restores sign on the negative path and returns the signed step in `Y`. Strongest safe reading: reusable signed slope helper for the column rasterizer.
; source: chrono_trigger_labels_pass87.md
D1_F972_ct_d1_compute_signed_row_per_column_step_via_hw_divide:
    ; TODO: reconstruct body / data for D1:F972
    ; known span hint: D1:F972..D1:F9AE

; =============================================================================
; D1:F9AF  top-status=strong  labels=1
; =============================================================================
; [strong] pass 87 :: ct_d1_load_cd0d_fourpoint_bundle_set_cc64_target_selector_sort_and_dispatch_column_rasterizer
; qualifier: strong structural
; notes: Saves `X` into `CC64`, loads `CD0D..CD1B` into `12..19`, calls `F8EB`, temporarily sets `DB=00`, then calls `F9E7`. Strongest safe reading: wrapper/dispatcher for rasterizing one four-point work bundle into the selected column target family.
; source: chrono_trigger_labels_pass87.md
D1_F9AF_ct_d1_load_cd0d_fourpoint_bundle_set_cc64_target_selector_sort_and_dispatch_column_raste:
    ; TODO: reconstruct body / data for D1:F9AF
    ; known span hint: D1:F9AF..D1:F9E6

; =============================================================================
; D1:F9E7  top-status=strong  labels=1
; =============================================================================
; [strong] pass 87 :: ct_d1_column_rasterize_sorted_fourpoint_bundle_into_wram_port_target_in_three_cases
; qualifier: strong structural
; notes: Chooses among three exact cases from `13 == 15` and the middle-row ordering test `16 ? 14`. All three cases call `CD:38B2` with start column `0F`, use the signed steps in `03 / 05 / 07 / 09`, and stream paired row values column by column into the selected WRAM-port target. Strongest safe reading: three-case column rasterizer for the sorted four-point bundle.
; source: chrono_trigger_labels_pass87.md
D1_F9E7_ct_d1_column_rasterize_sorted_fourpoint_bundle_into_wram_port_target_in_three_cases:
    ; TODO: reconstruct body / data for D1:F9E7
    ; known span hint: D1:F9E7..D1:FB67

; =============================================================================
; D1:FD80  top-status=strong  labels=1
; =============================================================================
; [strong] pass 88 :: ct_d1_transform_and_mirror_selected_0x70_band_between_companion_raster_target_bundles
; qualifier: strong structural
; notes: Uses the exact same root families as `D1:F5F6..F676`, but applies `EOR #$FFFF ; XBA` before every store. `7C.bit0` again chooses direction. Strongest safe reading: transformed selected-band mirror helper for the same companion `0x70` raster-target family.
; source: chrono_trigger_labels_pass88.md
D1_FD80_ct_d1_transform_and_mirror_selected_0x70_band_between_companion_raster_target_bundles:
    ; TODO: reconstruct body / data for D1:FD80
    ; known span hint: D1:FD80..D1:FE46

