; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_CE
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; CE:E000  top-status=strong  labels=1
; =============================================================================
; [strong] pass 88 :: ct_ce_mirror_selected_0x6c_band_between_primary_and_shadow_eight_table_raster_target_bundles
; qualifier: strong structural
; notes: Reads one byte from `[$40]`, doubles it, computes stop offset `start + 0x006C`, then mirrors that selected band across eight exact root tables. Exact primary roots: `C161 / C1CD / C239 / C2A5 / C311 / C37D / C3E9 / C455`. Exact shadow roots: `C4E1 / C54D / C5B9 / C625 / C691 / C6FD / C769 / C7D5`. When `7C.bit0 != 0`, direction is primary -> shadow; otherwise shadow -> primary. Strongest safe reading: selected-band mirror helper for one `0x6C` raster-target bundle family.
; source: chrono_trigger_labels_pass88.md
CE_E000_ct_ce_mirror_selected_0x6c_band_between_primary_and_shadow_eight_table_raster_target_bun:
    ; TODO: reconstruct body / data for CE:E000
    ; known span hint: CE:E000..CE:E08D

; =============================================================================
; CE:E18E  top-status=strong  labels=1
; =============================================================================
; [strong] pass 86 :: ct_ce_clear_cd47_cdc6_work_strip_only_when_cdc8_nonzero
; qualifier: strong structural
; notes: Exact body: `LDA $CDC8 ; BEQ return ; TDC ; TAX ; REP #$20 ; STZ $CD47,X ; INX ; INX ; CPX #$0080 ; BNE loop ; TDC ; SEP #$20 ; RTL`. Exact behavior: if `CDC8 == 0`, return immediately. If `CDC8 != 0`, clear the exact `0x80`-byte strip `CD47..CDC6`. Strongest safe reading: first exact external `CDC8` reader; nonzero-gated clear helper for one D1-adjacent work strip.
; source: chrono_trigger_labels_pass86.md
CE_E18E_ct_ce_clear_cd47_cdc6_work_strip_only_when_cdc8_nonzero:
    ; TODO: reconstruct body / data for CE:E18E
    ; known span hint: CE:E18E..CE:E1A4

