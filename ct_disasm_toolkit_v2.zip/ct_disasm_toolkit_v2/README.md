# Chrono Trigger ROM Disassembly Toolkit v2

This is the reusable utility/workflow bundle for continuing the Chrono Trigger (USA) ROM disassembly without rebuilding the helper layer again.

v2 adds the practical stuff that helps on day one of a resumed session:
- **starter label database export**
- **opcode tracking CSVs**
- **Windows batch wrappers**
- **session bootstrap helper**
- **workspace templates**
- **carry-forward notes for the current disassembly frontier**

## Current project anchor

This toolkit is aligned to the current project state where:
- **Pass 61** is the latest completed pass
- **`C1:B80D..C1:B95F`** is currently the strongest master bank-C1 opcode dispatch result
- the next live seam is the **early global opcode band** inside that master table
- the session handoff requires **Chrono Trigger community research first** before resuming heavy RE work

These tools are not a fake “complete disassembler.”
They are the actual helper layer for the style of ROM work done in this project:
address conversion, byte dumping, pointer-table inspection, cross-reference scans, pass scaffolding, label extraction, opcode tracking, and session bootstrap.

## Folder layout

### Core scripts
- `scripts/ct_common.py` — shared ROM/address helpers
- `scripts/ct_addr.py` — SNES/PC address conversion
- `scripts/ct_dump_range.py` — range dump with byte/word/long views
- `scripts/ct_find_bytes.py` — byte-pattern search with `??` wildcards
- `scripts/ct_ptr_table.py` — inspect local16 / long24 pointer tables
- `scripts/ct_xrefs.py` — search for callers/xrefs/raw address-byte matches
- `scripts/ct_make_pass.py` — scaffold next pass + labels markdown
- `scripts/ct_pass_index.py` — pass/label inventory
- `scripts/ct_merge_labels.py` — merge label files into one artifact

### v2 additions
- `scripts/ct_export_label_db.py` — export the pass label markdown into a starter CSV database
- `scripts/ct_make_opcode_csv.py` — create starter opcode tracking CSVs
- `scripts/ct_session_bootstrap.py` — one-command bootstrap for a resumed working folder

### Data / tracking
- `data/ct_label_db_starter.csv` — starter label DB exported from passes 32–61
- `data/ct_c1_master_opcode_matrix.csv` — starter master-opcode worksheet
- `data/ct_c1_selector_control_matrix.csv` — starter selector-control worksheet
- `data/ct_service7_wrapper_matrix.csv` — starter service-7 wrapper worksheet
- `data/ct_pass_inventory.csv` — pass/label inventory snapshot
- `data/ct_pack_observed_opcodes.csv` — observed pack-fed global opcode bytes from pass 61
- `data/ct_windows_setup_notes.md` — Windows usage notes

### Windows wrappers
- `windows/run_pass_index.bat`
- `windows/run_label_export.bat`
- `windows/run_make_opcode_csv.bat`
- `windows/run_bootstrap.bat`
- `windows/run_addr.bat`
- `windows/run_dump_range.bat`
- `windows/run_xrefs.bat`

### Workspace / notes
- `workspace/pass_templates/next_pass_checklist.md`
- `notes/next_session_start_here.md`
- `notes/bsnes_trace_targets.md`
- `notes/community_research_first.md`

## Recommended next-session startup

1. Read `notes/community_research_first.md`
2. Read:
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - `chrono_trigger_disasm_pass59.md`
   - `chrono_trigger_disasm_pass60.md`
   - `chrono_trigger_disasm_pass61.md`
3. Run the bootstrap:
   ```bash
   python scripts/ct_session_bootstrap.py --workdir .
   ```
4. Resume on the early global opcode band inside `C1:B80D`

## Windows quick start

From Command Prompt in the toolkit folder:
```bat
windows\run_bootstrap.bat
windows\run_pass_index.bat
windows\run_xrefs.bat C1:B80D calls
```

## Core examples

### Convert addresses
```bash
python scripts/ct_addr.py C1:B80D
python scripts/ct_addr.py 0x31B80D --mode pc-to-snes
```

### Dump the master C1 dispatch area
```bash
python scripts/ct_dump_range.py C1:B80D --length 0xC0 --width 16
python scripts/ct_dump_range.py C1:B80D --length 0x60 --words
```

### Search for callers/xrefs
```bash
python scripts/ct_xrefs.py C1:AC14 --mode calls
python scripts/ct_xrefs.py C1:B80D --mode word --bank C1
python scripts/ct_xrefs.py C1:AFD7 --mode raw
```

### Export the label DB
```bash
python scripts/ct_export_label_db.py --dir . --output data/ct_label_db_starter.csv
```

### Create/refresh opcode tracking files
```bash
python scripts/ct_make_opcode_csv.py --output-dir data
```

## What is still not solved

This toolkit does **not** solve the hard endgame by itself:
- full opcode coverage
- full VM coverage
- decompressor grammar
- bank-by-bank code/data separation
- rebuildable source-tree production
- final verified ROM rebuild parity

It just stops you from wasting the next session rebuilding the utility layer.
