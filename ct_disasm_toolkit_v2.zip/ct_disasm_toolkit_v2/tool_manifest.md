# Toolkit Manifest (v2)

## Core scope
Reusable Chrono Trigger disassembly helper layer plus carry-forward tracking artifacts.

## New in v2
- starter label DB export script and generated CSV
- opcode tracking CSV generators and seeded worksheets
- Windows batch wrappers
- session bootstrap helper
- next-session notes and research-first notes
- bundled copies of the latest top-of-stack handoff/pass files

## Latest aligned pass
- pass 61

## Current live seam
- early global opcode band inside `C1:B80D..C1:B95F`
