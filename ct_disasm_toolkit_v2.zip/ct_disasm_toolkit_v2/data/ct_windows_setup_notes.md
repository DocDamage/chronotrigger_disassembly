# Windows Setup Notes

## Assumptions
- Python is on PATH
- ROM file is in the working folder as:
  `Chrono Trigger (USA).sfc`

## Typical flow
1. Open Command Prompt in the toolkit folder
2. Run:
   - `windows\run_bootstrap.bat`
   - `windows\run_pass_index.bat`
3. Use:
   - `windows\run_addr.bat C1:B80D`
   - `windows\run_dump_range.bat C1:B80D --length 0x80 --width 16`
   - `windows\run_xrefs.bat C1:AC14 calls`

## If your ROM is elsewhere
Use the Python scripts directly and pass `--rom "path\to\Chrono Trigger (USA).sfc"`
