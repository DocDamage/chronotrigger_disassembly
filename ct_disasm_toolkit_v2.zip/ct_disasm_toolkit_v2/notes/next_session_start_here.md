# Next Session Start Here

## Mandatory first move
Refresh context from the Chrono Trigger modding / reverse-engineering community before resuming disassembly.
See `community_research_first.md`.

## Then load project context
Read in this order:
1. `chrono_trigger_master_handoff_session2.md`
2. `chrono_trigger_master_index_handoff.md`
3. `chrono_trigger_disasm_pass59.md`
4. `chrono_trigger_disasm_pass60.md`
5. `chrono_trigger_disasm_pass61.md`
6. latest matching labels files

## Then bootstrap the folder
- Windows: `windows\run_bootstrap.bat`
- Cross-platform:
  ```bash
  python scripts/ct_session_bootstrap.py --workdir .
  ```

## Live technical frontier
- `C1:B80D..C1:B95F` = master bank-C1 opcode dispatch table
- `B85F`, `B88D`, `B8BB` = dispatch slices, not independent roots
- next seam = early global opcode band inside the master table
- secondary seam = exact resume conditions for group-1 vs selector-control continuation
- deferred seam = corrected deferred-tail reinsertion model
