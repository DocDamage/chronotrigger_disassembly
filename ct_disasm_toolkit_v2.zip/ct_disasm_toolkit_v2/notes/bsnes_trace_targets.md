# bsnes / bsnes-plus Trace Targets

Use runtime tracing when static control flow starts to flatten out.

## Good candidates for emulator validation
- suspicious late alias bytes in the master C1 opcode space
- exact runtime-emitted early global opcodes inside `C1:B80D`
- resume path split between:
  - group-1 continuation
  - selector-control continuation
- deferred-tail reinsertion triggers
- tilemap / companion strip mutation triggers if static xrefs stay too wide

## Suggested break/watch points
- `C1:B80D`
- `C1:AC14`
- `C1:AFD7`
- `C1:8C0A`
- WRAM:
  - `7E:B239`
  - `7E:B242`
  - `7E:B24A`
  - `7E:B263`
  - `7E:AEFF`
  - `7E:AF15`
  - `7E:99DD`
  - `7E:9F22`

## What to record
- emitted opcode byte
- caller / resume context
- slot index
- result flag behavior (`AF24`)
- whether later FE-delimited work remains
