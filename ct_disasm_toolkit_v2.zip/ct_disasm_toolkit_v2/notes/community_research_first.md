# Community Research First

Before resuming hard disassembly work, refresh context from the Chrono Trigger modding and reverse-engineering community.

## Why this is mandatory
This project is not operating in a vacuum.
Community material helps prevent dumb mistakes:
- confusing event scripting with the bank-C1 command layer
- collapsing battle-facing logic into map/object logic
- missing established tooling vocabulary around Temporal Flux / Chrono Compressor / debugger workflows
- re-solving already-documented data structures instead of focusing on the unsolved code paths

## Minimum refresh targets
- Chrono Compendium utility / modding pages
- Temporal Flux event and modification vocabulary
- Data Crystal main page + RAM map + enemy AI docs
- Kajar Labs / Chrono Compendium modification forum threads
- bsnes / bsnes-plus / Geiger-style debugger context

## What to extract
- any known naming conventions for battle/menu/event subsystems
- any proven RAM fields touching:
  - readiness / ATB-style gauges
  - roster or active party views
  - menu/panel/tilemap upload paths
- known decompression/compression terminology
- any existing disassembly fragments or symbol sets that overlap current work

## Rule
Use the community for context and sanity checks.
Do **not** let community guesses override ROM proof.
