#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
from pathlib import Path

def run(cmd):
    print("+", " ".join(str(x) for x in cmd))
    subprocess.run(cmd, check=True)

def main() -> None:
    ap = argparse.ArgumentParser(description="Bootstrap a new working folder with pass inventory, label DB, and opcode CSV starters.")
    ap.add_argument("--workdir", default=".", help="Project root with pass/label files")
    args = ap.parse_args()

    root = Path(args.workdir).resolve()
    data = root / "data"
    data.mkdir(exist_ok=True)

    run(["python", "scripts/ct_pass_index.py", "--dir", str(root)])
    run(["python", "scripts/ct_export_label_db.py", "--dir", str(root), "--output", str(data / "ct_label_db_starter.csv")])
    run(["python", "scripts/ct_make_opcode_csv.py", "--output-dir", str(data)])

    print("\nBootstrap complete.")
    print("Next suggested manual reads:")
    print("  - chrono_trigger_master_handoff_session2.md")
    print("  - chrono_trigger_master_index_handoff.md")
    print("  - latest pass + labels")
    print("  - community research notes before resuming disassembly")

if __name__ == "__main__":
    main()
