# Next Session Start Here

1. Read `notes/community_research_first.md`
2. Open these in order:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `dossiers/C1_dossier.md`
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - latest pass + labels
3. Active top-of-stack seam after pass 74:
   - shared fixed-`7F` follow-up tail behind late packet callers
   - primary target helpers:
     - `C1:BFA4`
     - `C1:BF79`
     - remaining `AE91..AE96` consumers
4. Specific cleanup targets:
   - explain who really consumes transient packet-workspace modes `2` and `3`
   - tighten `AE55` beyond bit `3`
   - decode downstream side-effect helpers:
     - `FD:ABA2`
     - `FD:AC6E`
5. Runtime confirmation shortlist:
   - late fixed-`7F` tail from globals `91` and `99`
   - direct `98 -> EBF8 -> EC7F` fast path
   - legacy anomalous opcode `76` / selector `1F`
