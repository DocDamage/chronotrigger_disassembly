# Chrono Trigger Disassembly Completion Score — Pass 88

## Conservative estimate
Overall completion estimate after pass 88: **~61.4%**

## Why it moved
Pass 88 did not add a huge number of new addresses, but it materially improved ownership of one of the nastier late graphics/output seams:

- the `C161 / C163 / C4E1 / C4E3` roots now belong to a real **dual-bundle eight-table raster-target workspace**
- exact mirror helpers for selected `0x6C` and `0x70` bands are now frozen
- `7C.bit0` is now exact as the direction selector for that mirror family

That is a real semantic upgrade even though it does not immediately raise rebuild readiness.

## Current blunt breakdown
- Label semantics: **~76.1%**
- Opcode / handler coverage: **~92.8%**
- Bank/source separation: **~24.3%**
- Rebuild readiness: **~8.6%**

## Honest caution
The project is still nowhere near “fully disassembled” in the strict rebuildable sense.

What is strong now:
- control-plane ownership
- major opcode-family coverage
- late output/raster pipeline structure

What is still expensive:
- byte-accurate source reconstruction
- clean code/data separation across late banks
- assembler-ready rebuild validation
