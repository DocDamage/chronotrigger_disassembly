# Next Session Start Here

1. Read `notes/community_research_first.md`
2. Open these in order:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `dossiers/C1_dossier.md`
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - latest pass + labels
3. Active top-of-stack seam after pass 75:
   - local service dispatcher around `JSR $0003`, especially service id `04`
   - exact field semantics of the 17-byte `CC:213F` records copied into `AEE6..AEF6`
   - exact field semantics of the 7-byte `CC:5E00` records used by `FD:ABA2`
4. Specific cleanup targets:
   - freeze the per-byte nouns inside `AEE6..AEF6`
   - name `B28C / B2A5 / B2DB-B2DD / B2A7..B2AC / B2AF` without hand-waving
   - tighten the queue-owner noun behind `B3AC / B3B9 / B315`
   - re-open the `C1:FDC7` materialization dispatch path from the now-stronger `FD:AC6E` proof
5. Runtime confirmation shortlist:
   - fixed-`7F` tail from globals `91` and `99`
   - current-tail runner at `C1:BFAA`
   - `FD:ABA2` accumulator/token-queue behavior
   - `FD:AC6E` pending queue walk and admission gating
