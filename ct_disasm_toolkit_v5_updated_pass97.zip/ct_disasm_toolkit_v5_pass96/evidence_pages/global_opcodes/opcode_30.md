# Global Opcode 30

- Status: **strong**
- Dispatch address: **C1:9962**
- Evidence pass: **68**
- Notes: Exact shared alias of STZ AF24 ; RTS

## Matching label evidence
- pass 97: `C7:0A98..C7:0AD7` **ct_c7_exact_16_entry_rewrite_table_mapping_opcode_30_3f_low_nibbles_to_synthetic_10_selector_ff_ff_packets** (strong)
  - Exact 16-entry table. Exact entry width: 4 bytes. Exact consumer: bridge body `071D..0733`. Entry `n` is exactly: byte 0 = `0x10` byte 1 = `n` byte 2 = `0xFF` byte 3 = `0xFF` Therefore exact rewritten packets are: `30 -> 10 00 FF FF` `31 -> 10 01 FF FF` `32 -> 10 02 FF FF` ... `3F -> 10 0F FF FF` Strongest safe reading: exact packet-rewrite table that converts the `0x30..0x3F` family into synthetic `{0x10, selector, 0xFF, 0xFF}` headers before redispatch at `0155`.
- pass 97: `C7:071D..C7:0733` **ct_c7_rewrite_opcode_30_3f_family_into_synthetic_10_selector_ff_ff_packets_then_redispatch_at_0155** (strong)
  - Masks exact opcode byte `1E00` to its low nibble. Multiplies by four and indexes the exact 16-entry packet-rewrite table rooted at `C7:0A98`. Loads one exact 16-bit word from `C7:0A98 + index` into `1E00 / 1E01`. Loads one exact 16-bit word from `C7:0A9A + index` into `1E02 / 1E03`. The rewritten header is exact: `1E00 = 0x10` `1E01 = low nibble of original `0x30..0x3F` opcode` `1E02 = 0xFF` `1E03 = 0xFF` Tail-jumps to exact redispatch entry `0155`. Because `0155` redispatches exact opcode `0x10` through gate table `0AD9`, and `0AD9[0] = 01A1`, this bridge lands in the negative-`1E05` special path. Strongest safe reading: exact packet-rewrite + redispatch bridge from the `0x30..0x3F` family into the `01A1` special-path entry.
- pass 96: `C7:071D..C7:0733` **ct_c7_table_drive_opcode_30_3f_family_into_1e00_1e03_then_tail_jump_to_0155** (strong)
  - Masks exact opcode byte `1E00` to its low nibble. Multiplies by four and indexes the exact table rooted at `C7:0A98`. Seeds exact packet bytes `1E02` and `1E00` from that table. Tail-jumps to `0155`, reusing the same low-bank packet sender / dispatcher flow. Strongest safe reading: exact table-driven bridge from the `0x30..0x3F` family into the shared low-bank packet-send path.
