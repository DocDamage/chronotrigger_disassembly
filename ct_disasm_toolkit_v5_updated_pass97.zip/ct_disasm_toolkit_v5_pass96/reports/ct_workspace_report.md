# Chrono Trigger Workspace Report

## Current top-of-stack
- Latest pass: **97**
- Current live seam: **Do not go broad yet. The cleanest next move now is: 1. Go back to CE0F use the now-cleaner C7 control picture to revisit the CDC8 / CFFF / CE0F local control family 2. Find the first clean external reader / reader chain for CE0F that is the highest-value unresolved noun near the old seam 3. Only then widen back out especially toward the larger unresolved WRAM pressure and broader bank-separation work**
- Completion estimate: **~68.3%**

## Label database
- Total label rows: **674**
- Strong: **463**
- Provisional: **141**
- Alias: **1**
- Caution: **2**
- Runtime evidence rows: **0**

## Coverage worksheets
- Master C1 global opcode worksheet rows: **170**
- Selector-control worksheet rows: **83**
- Service-7 wrapper worksheet rows: **8**

## Xref cache
- Hot targets cached: **33**

## Generated artifacts
- `reports/ct_completion_score.md`
- `reports/ct_conflict_report.md`
- `reports/code_data_score.md`
- `graph/ct_knowledge_graph_summary.md`
- `reports/ct_unresolved_dashboard.md`
- `reports/ct_dispatch_family_report.md`
- `reports/ct_apu_packet_summary.md`
- `reports/runtime/runtime_capture_plan.md`
- `reports/ct_runtime_validation.md`
- `reports/ct_source_state.md`
- `reports/ct_rebuild_diff_report.md`
- `asm_skeleton/banks/`

## Immediate next work
1. Read `notes/next_session_start_here.md` and stay on that seam before going broad.
2. Use `reports/ct_dispatch_family_report.md` when you are dealing with veneers, opcode families, or packet dispatchers.
3. Use `reports/ct_apu_packet_summary.md` when the work touches the C7 sound/APU packet side.
4. Import runtime evidence when static ownership proof stalls.
5. Use `reports/runtime/runtime_capture_plan.md` before taking new debugger captures so the traces line up with the live seam.

## Still required for full disassembly
- Complete bank-by-bank code/data separation across the untouched ROM banks
- Finish decompressor grammar / format work
- Freeze subsystem ownership boundaries across banks
- Build a rebuildable source tree and validate against ROM fingerprints
