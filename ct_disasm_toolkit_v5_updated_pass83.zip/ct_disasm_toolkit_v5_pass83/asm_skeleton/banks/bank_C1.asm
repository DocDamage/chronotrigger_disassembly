; Chrono Trigger bank C1 skeleton
; Generated from current evidence. This is not a complete reassemblable bank yet.

.bank $C1

; C1:011B [strong] pass 49
ct_c1_lsr3_entry:
    ; TODO: lift real code/data for C1:011B
    ; Mid-routine entry into the `LSR` helper band. Executes exactly three `LSR A` operations before `RTS`. Corrects pass 48’s earlier loose `>> 8

; C1:011F [strong] pass 48
ct_c1_format_u16_as_three_decimal_tile_bytes_949d_949f:
    ; TODO: lift real code/data for C1:011F
    ; Uses `9499` as the numeric working input. Repeatedly subtracts `0x64` and `0x0A` to derive hundreds/tens/ones. Maps those digits through `CC

; C1:0174 [strong] pass 48
ct_c1_format_u16_as_two_decimal_tile_bytes_949e_949f:
    ; TODO: lift real code/data for C1:0174
    ; Repeatedly subtracts `0x0A` to derive tens and ones. Maps through `CC:F903`. Emits tile bytes to `949E`, `949F` and blanks `949C`, `949D` wi

; C1:0299 [strong] pass 47
ct_c1_rebuild_full_companion_strip_0cc0:
    ; TODO: lift real code/data for C1:0299
    ; Begins by clearing/filling the full paired-byte `0CC0` strip. Stamps layout-dependent fixed glyphs based on `9F20`. Iterates the three lane 

; C1:06F0 [strong] pass 47
ct_c1_render_scaled_lane_bar_into_0cc0:
    ; TODO: lift real code/data for C1:06F0
    ; Uses `FA35[lane] + 0x1A` as the bar anchor. Scales per-lane state through the hardware divide helper at `C1:00D7`. Emits repeated `67` / `6F

; C1:06F0 [unspecified] pass 50
ct_c1_render_lane_active_time_gauge_into_0cc0:
    ; TODO: lift real code/data for C1:06F0
    ; Pass 47 proved this was a scaled segmented bar renderer. Pass 50 tightens the gameplay-facing meaning of that bar through the upstream produ

; C1:06F0 [unspecified] pass 50
old_wording__render_scaled_lane_bar_into_0CC0_______________replaced_:
    ; TODO: lift real code/data for C1:06F0
    ; Too generic after pass 50. The ROM now supports a materially harder gameplay-facing reading: active-time/readiness gauge renderer.

; C1:07BD [strong] pass 46
ct_c1_blit_companion_strip_template_a_into_0cc0_pair29:
    ; TODO: lift real code/data for C1:07BD
    ; Outer loop = 6 rows. Inner loop = 7 source bytes per row. Reads from `CC:FA41`. Writes source byte to `0CC0+Y`, then constant `0x29` to `0CC

; C1:07EE [strong] pass 46
ct_c1_blit_companion_strip_template_b_into_0cc0_pair29:
    ; TODO: lift real code/data for C1:07EE
    ; Same loop shape as `C1:07BD`. Reads from `CC:FA6B` instead of `CC:FA41`. Writes the same paired-byte pattern into the `0CC0` family.

; C1:07FD [strong] pass 45
ct_c1_compose_three_slot_panel_strip_into_0b40:
    ; TODO: lift real code/data for C1:07FD
    ; Checks the three active-roster entries `A6D9 / A6DA / A6DB`. For each occupied entry, calls `C1:0929` with one of three horizontal destinati

; C1:081F [strong] pass 46
ct_c1_compose_three_slot_panel_strip_into_0b40:
    ; TODO: lift real code/data for C1:081F
    ; Corrected entry boundary for the pass-45 panel-strip composer. Begins with `STZ $84`, checks `A6D9/A6DA/A6DB`, selects destination offsets i

; C1:086D [strong] pass 46
ct_c1_clear_current_companion_strip_slice_0cc0:
    ; TODO: lift real code/data for C1:086D
    ; Uses `95D5` to select a local slice. Clears two adjacent columns across six rows inside the `0CC0` companion strip family. Strongest safe re

; C1:08E8 [strong] pass 46
ct_c1_update_current_companion_strip_slice:
    ; TODO: lift real code/data for C1:08E8
    ; Writes back into the same `0CC0 / 0D00` companion-strip family after slice clear. Uses selector tables rooted at `CC:FA23`, `CC:FA29`, and `

; C1:08E8 [unspecified] pass 47
ct_c1_fill_current_companion_strip_slice_from_anchor_table:
    ; TODO: lift real code/data for C1:08E8
    ; Pass 46 proved this was a slice-local `0CC0` update helper. Pass 47 tightens that role: it selects an anchor from `FA23` or `FA29` then fill

; C1:0929 [strong] pass 45
ct_c1_blit_6row_panel_segment_into_0b40_merge_left_border:
    ; TODO: lift real code/data for C1:0929
    ; Dynamic `0B40` patcher using source data from `D1:59FC`. Writes 6 rows with a destination stride of `0x40` bytes per row. Copies either: 7 w

; C1:0958 [strong] pass 46
ct_c1_rebuild_companion_record_buffer_0e80:
    ; TODO: lift real code/data for C1:0958
    ; Clears exactly `0x0180` bytes at `0E80+Y`. Then enters a 3-iteration build loop calling `C1:09B0`. Strongest safe reading: rebuild a full-si

; C1:09B0 [strong] pass 46
ct_c1_emit_fixed_format_companion_record:
    ; TODO: lift real code/data for C1:09B0
    ; Checks the `C1:1580` per-entry control table. Copies 11 bytes from `CC:94A0` to `0B5E + 11*index` using `MVN`. Emits additional paired bytes

; C1:104E [strong] pass 48
ct_c1_blank_leading_zero_decimal_tiles_949d_949e:
    ; TODO: lift real code/data for C1:104E
    ; Converts tile `0x73` at `949D` to `0xFF`. Converts tile `0x73` at `949E` to `0xFF` only when `949D` is already blank. This is a leading-zero

; C1:1918 [strong] pass 47
ct_c1_refresh_current_0e80_lane_marker_glyphs:
    ; TODO: lift real code/data for C1:1918
    ; Clears the old marker block selected by `991F`. Stamps the current marker block selected by `95E5`. Writes `60/61/62/63` plus companion `29`

; C1:1B19 [strong] pass 43
ct_c1_service1_enqueue_lane_and_mark_record_active:
    ; TODO: lift real code/data for C1:1B19
    ; Local service-1 entry for the 3-lane controller. If the current lane is not already active in `A6D9[x]`, maps it through `CC:FAF0`,

; C1:1B69 [strong] pass 43
ct_c1_promote_pending_lane_into_active_roster:
    ; TODO: lift real code/data for C1:1B69
    ; Pulls the head of the pending lane queue at `95D6` into the active roster. Clears `9F38[lane]`, seeds small per-lane state bytes, stores the

; C1:1BAA [strong] pass 43
ct_c1_service2_remove_lane_and_reseat_active_controller:
    ; TODO: lift real code/data for C1:1BAA
    ; Local service-2 entry for the same 3-lane controller. Deletes the input lane from either: the pending-admission queue (`95D6..95D8`), or the

; C1:1C3A [strong] pass 43
ct_c1_service2_restore_workspace_template_0b40:
    ; TODO: lift real code/data for C1:1C3A
    ; Common tail reached from service 2. Copies `0x180` bytes from `D1:5800` into WRAM rooted at `0B40`. Exact high-level meaning of the workspac

; C1:1C3A [strong] pass 44
ct_c1_service2_restore_default_tilemap_template_0b40:
    ; TODO: lift real code/data for C1:1C3A
    ; Strengthened from pass 43. No longer just “restore workspace template.” Specifically restores the default `0x180`-byte tilemap/upload templa

; C1:2BBC [strong] pass 65
relation_query_mode__05_:
    ; TODO: lift real code/data for C1:2BBC
    ; Absolute Y-delta test over `1D23`. Leaves `9872 = 00` when `abs(subject_y - arg_y) < 0x20`. Leaves `9872 = FF` otherwise.

; C1:2BDA [strong] pass 65
relation_query_mode__06_:
    ; TODO: lift real code/data for C1:2BDA
    ; Vertical ordering test over `1D23`. Leaves `9872 = 00` when `subject_y < arg_y`. Leaves `9872 = FF` otherwise.

; C1:2CA7 [unspecified] pass 65
__C1_2CBA___C1_2CCD___C1_2CE0___relation_query_modes__09__0C_____strong_structural_support_:
    ; TODO: lift real code/data for C1:2CA7
    ; These are coarse row/column band predicates over the current subject slot. `09/0A` use `1D23 >> 4`. `0B/0C` use `1D0C >> 4`.  Do not keep de

; C1:2CF3..C1:2D80 [unspecified] pass 66
relation_query_mode__0E__body:
    ; TODO: lift real code/data for C1:2CF3..C1:2D80
    ; This mode is no longer best imagined as a trivial boolean compare. The body pulls projected position pairs from `1D0C/1D23`, computes two su

; C1:431D..C1:432A [strong] pass 76
ct_c1_service04_mode_dispatcher_by_ae92:
    ; TODO: lift real code/data for C1:431D..C1:432A
    ; Loads `AE92`, clamps any value `>= 4` to mode `0`, then dispatches through the jump table at `C1:7A63`. Proven table entries: mode `0` -> `4

; C1:432C..C1:459F [strong] pass 76
ct_c1_service04_mode1_load_current_context_profiles_by_source_slot_and_run_common_emit_tail:
    ; TODO: lift real code/data for C1:432C..C1:459F
    ; Mode-1 front end reached when `AE92 = 1`. Splits immediately on `AE91 < 3` vs `AE91 >= 3`. Head-slot branch uses transformed slot state plus

; C1:45A0..C1:4758 [strong] pass 76
ct_c1_service04_mode2_load_fixed_followup_profiles_by_source_slot_and_run_common_emit_tail:
    ; TODO: lift real code/data for C1:45A0..C1:4758
    ; Mode-2 front end reached when `AE92 = 2`. This is the exact service-04 mode used by `895B`, and therefore by the fixed-`7F` follow-up path a

; C1:475A..C1:475A [strong] pass 77
ct_c1_service04_mode0_noop_rts:
    ; TODO: lift real code/data for C1:475A..C1:475A
    ; Exact body is only `RTS`. This is the true mode-`0` target behind the `431D` service-04 dispatcher. Any `AE92 >= 4` fallback therefore colla

; C1:475B..C1:4832 [strong] pass 77
ct_c1_service04_mode3_load_high_range_fixed_followup_profiles_and_run_common_emit_tail:
    ; TODO: lift real code/data for C1:475B..C1:4832
    ; Computes `X = 7 * (AE93 - 0xBC)`. Loads a 7-byte profile record from `CD:5C26 + 7*(AE93 - 0xBC)` into the same working-byte family used by m

; C1:4833..C1:48E7 [strong] pass 76
ct_c1_service04_common_output_materialization_and_emit_finalize_runner:
    ; TODO: lift real code/data for C1:4833..C1:48E7
    ; Shared convergence tail used by both active service-04 modes proved in this seam. Consumes the working bytes built in the `9877..9885` neigh

; C1:48EC..C1:493F [provisional] pass 76
ct_c1_service04_parse_ce_profile_stream_into_a280_a2a0_work_vectors:
    ; TODO: lift real code/data for C1:48EC..C1:493F
    ; Consumes `9885` as the source index. Walks a bank-`CE` byte stream and partitions entries into the `A280..` and `A2A0..` work-vector familie

; C1:48EC..C1:493F [strong] pass 77
ct_c1_service04_parse_segmented_ce_fragment_group_stream_into_a280_starts_and_a2a0_counts:
    ; TODO: lift real code/data for C1:48EC..C1:493F
    ; Seeds `A280[0] = 9885`, clears local counters, then parses control classes from the top bits of the `CE:0000,X` stream. `0x00..0x1F` high-bi

; C1:4943..C1:49FD [provisional] pass 76
ct_c1_service04_build_one_output_record_batch_into_a2d3_and_a45x_workspace:
    ; TODO: lift real code/data for C1:4943..C1:49FD
    ; Consumed exactly eight times from the shared `4833` runner. Builds one intermediate output batch into the `A2D3..` / `4500..` workspace neig

; C1:4943..C1:49FD [strong] pass 77
ct_c1_service04_decode_one_packed_fragment_batch_into_a2d3_and_a450_quad_workspace:
    ; TODO: lift real code/data for C1:4943..C1:49FD
    ; Uses `A650` to choose the current output-row base through `CC:F7C0`. Uses `A652` as the current cursor into the packed `2D00..` stream. Spli

; C1:8461..C1:8625 [strong] pass 72
ct_global_opcode_9C_service7_lane_controller_and_active_time_update:
    ; TODO: lift real code/data for C1:8461..C1:8625
    ; Large lane/service controller, not a tiny wrapper. Clears controller scratch, iterates lane-related state through the `B179/B163` mapping, c

; C1:8461..C1:883B [strong] pass 73
ct_global_opcode_9C_service7_tail_lane_admission_reseat_and_readiness_refresh_controller:
    ; TODO: lift real code/data for C1:8461..C1:883B
    ; Walks the tail-lane band through `B315/B252/B18B` and the `B179/B163` mapping. Services eligible occupied tail lanes, invoking `8CF9` to run

; C1:8461..C1:883B [strong] pass 73
ct_service7_tail_lane_admission_reseat_and_readiness_refresh_controller:
    ; TODO: lift real code/data for C1:8461..C1:883B
    ; Local selector-control ownership of global `9C`. Carries the same upgraded reading: outer controller for eligible tail-lane admission/reseat

; C1:8876..C1:88C4 [strong] pass 72
ct_global_opcode_90_update_lane_afb6_b045_and_release_5E4B_bit7_on_expiry:
    ; TODO: lift real code/data for C1:8876..C1:88C4
    ; Uses `B179[0]` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `AFB6[lane] = 1` and copies `B0D4[lane] -> AF27[lane]`. Decre

; C1:88C5..C1:8974 [strong] pass 72
ct_global_opcode_91_conditionally_seed_afc1_af32_and_ad9c_from_lane_geometry:
    ; TODO: lift real code/data for C1:88C5..C1:8974
    ; Uses `B179[1]` or fallback `AEC7`, then maps through `B163` to a lane ID. Requires `5E4A.bit7` set and `5E4B.bit6` clear for the helper path

; C1:88C5..C1:8974 [strong] pass 74
ct_global_opcode_91_compute_scaled_lane_delta_queue_live_packet_and_run_followup_7f_tail:
    ; TODO: lift real code/data for C1:88C5..C1:8974
    ; Uses `B179[1]` or `AEC7` through the `B163` lane mapping. Requires `5E4A.bit7` set and `5E4B.bit6` clear for the packet path. Sets `AFC1[lan

; C1:895B..C1:8974 [strong] pass 74
ct_c1_seed_fixed_followup_context_from_a_and_run_ac57_tail:
    ; TODO: lift real code/data for C1:895B..C1:8974
    ; Copies incoming `A` into `AE93`. Seeds fixed context bytes: `AE91 = 0`, `AE92 = 2`, `AE94 = 0`, `AE95 = 0`, `AE96 = 0x80`. Runs `JSR AC57` a

; C1:8975..C1:89B8 [strong] pass 72
ct_global_opcode_92_update_lane_afcc_b05b_and_clear_afcc_on_expiry:
    ; TODO: lift real code/data for C1:8975..C1:89B8
    ; Uses `B17B` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `AFCC[lane] = 1` and copies `B0EA[lane] -> AF3D[lane]`. Decremen

; C1:89B9..C1:8A04 [strong] pass 72
ct_global_opcode_93_update_lane_afd7_b066_and_release_5E4D_bit7_on_expiry:
    ; TODO: lift real code/data for C1:89B9..C1:8A04
    ; Uses `B17C` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `AFD7[lane] = 1` and copies `B0F5[lane] -> AF48[lane]`. Decremen

; C1:8A05..C1:8A50 [strong] pass 72
ct_global_opcode_94_update_lane_afe2_b071_and_release_5E4D_bit6_on_expiry:
    ; TODO: lift real code/data for C1:8A05..C1:8A50
    ; Uses `B17D` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `AFE2[lane] = 1` and copies `B100[lane] -> AF53[lane]`. Decremen

; C1:8A51..C1:8A9C [strong] pass 72
ct_global_opcode_95_update_lane_afed_b07c_and_release_5E4E_bit6_on_expiry:
    ; TODO: lift real code/data for C1:8A51..C1:8A9C
    ; Uses `B17E` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `AFED[lane] = 1` and copies `B10B[lane] -> AF5E[lane]`. Decremen

; C1:8A9D [strong] pass 72
ct_global_opcode_96_rts_alias:
    ; TODO: lift real code/data for C1:8A9D
    ; Exact `RTS` entry.

; C1:8A9E [strong] pass 72
ct_global_opcode_97_rts_alias:
    ; TODO: lift real code/data for C1:8A9E
    ; Exact `RTS` entry.

; C1:8A9F..C1:8B0F [strong] pass 72
ct_global_opcode_98_capture_lane_b12c_variant_into_af7f_and_optionally_run_ec7f:
    ; TODO: lift real code/data for C1:8A9F..C1:8B0F
    ; Uses `B179[8]` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `B00E[lane] = 1` and copies `B12C[lane] -> AF7F[lane]`. Appli

; C1:8A9F..C1:8B0F [strong] pass 74
ct_global_opcode_98_capture_lane_b12c_variant_into_af7f_and_optionally_apply_one_point_primary_delta:
    ; TODO: lift real code/data for C1:8A9F..C1:8B0F
    ; Uses `B179[8]` or `AEC7` through the `B163` lane mapping. Captures `B12C[lane] -> AF7F[lane]` with status-based halve/double transforms. Whe

; C1:8B10..C1:8BB8 [strong] pass 72
ct_global_opcode_99_update_lane_b019_b0a8_and_on_expiry_conditionally_seed_ad9c:
    ; TODO: lift real code/data for C1:8B10..C1:8BB8
    ; Uses `B179[9]` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `B019[lane] = 1` and copies `B137[lane] -> AF8A[lane]`. Appli

; C1:8B10..C1:8BB8 [strong] pass 74
ct_global_opcode_99_update_lane_b019_b0a8_and_on_expiry_queue_secondary_plus5_packet_with_followup_7f_tail:
    ; TODO: lift real code/data for C1:8B10..C1:8BB8
    ; Uses `B179[9]` or `AEC7` through the `B163` lane mapping. Updates `B019/AF8A/B0A8` on the mapped lane with the already-proved timer front en

; C1:8BB9..C1:8C07 [strong] pass 72
ct_global_opcode_9A_update_lane_b024_b0b3_and_release_5E4E_bit2_on_expiry:
    ; TODO: lift real code/data for C1:8BB9..C1:8C07
    ; Uses `B179[0x0A]` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `B024[lane] = 1` and copies `B142[lane] -> AF95[lane]`. De

; C1:8C08 [strong] pass 72
ct_global_opcode_9B_rts_alias:
    ; TODO: lift real code/data for C1:8C08
    ; Exact `RTS` entry.

; C1:8C0A..C1:8C37 [strong] pass 57
ct_iterate_live_unwithheld_tail_entries_for_dispatch:
    ; TODO: lift real code/data for C1:8C0A..C1:8C37
    ; Consumes tail entries only when: `AF15.bit7` is clear `AF02[x] != FF` `B2B6[x] == 0` Passes the live occupant ID in `AF02[x]` to `AFD2`. Con

; C1:8C0A..C1:8CF7 [strong] pass 61
ct_replay_tail_pack_segments_and_record_per_tail_state:
    ; TODO: lift real code/data for C1:8C0A..C1:8CF7
    ; Front-end clears/rebuilds per-tail replay state for the live, unwithheld tail map. Records executed global opcode bytes into `ct_tail_last_e

; C1:8CF9..C1:8EA6 [strong] pass 73
ct_c1_run_tail_lane_selector_control_stream_and_materialize_head_state:
    ; TODO: lift real code/data for C1:8CF9..C1:8EA6
    ; Initializes current-tail context from `AEC8`, `B252`, and `B18B` and clears selection/result scratch. Chooses the command-stream pointer fro

; C1:8EA7..C1:8EAA [strong] pass 62
ct_global_opcode_00_unconditional_tail_replay_step:
    ; TODO: lift real code/data for C1:8EA7..C1:8EAA
    ; Direct body is only: `JSR $8C3E ; RTS`. Global opcode `00` is therefore an unconditional handoff into the tail replay/controller layer. This

; C1:8EAB..C1:8F10 [strong] pass 63
ct_global_opcode_01_filter_selected_entries_by_fd_record_threshold:
    ; TODO: lift real code/data for C1:8EAB..C1:8F10
    ; Calls `AC14`, so operand `+1` is an inline selector-control byte. Uses the resulting `AECC/AECB` selected list as input. For each selected e

; C1:8F11..C1:8F81 [strong] pass 63
ct_global_opcode_02_filter_head_or_nonhead_selected_entries_by_lane_flag_mask:
    ; TODO: lift real code/data for C1:8F11..C1:8F81
    ; Operand `+1` chooses which fixed selector-control byte is dispatched through `AC2C`: operand1 `== 0` -> selector-control `0x01` -> visible/h

; C1:8F87..C1:8FD9 [strong] pass 63
ct_global_opcode_03_filter_selected_entries_by_occupant_index_equals_immediate:
    ; TODO: lift real code/data for C1:8F87..C1:8FD9
    ; Calls `AC14`, so operand `+1` is an arbitrary inline selector-control byte. Requires a non-empty selected list from `AECC/AECB`. Consumes th

; C1:8FDA..C1:9012 [strong] pass 63
ct_global_opcode_04_gate_tail_replay_on_live_tail_occupant_presence_mode:
    ; TODO: lift real code/data for C1:8FDA..C1:9012
    ; Scans live tail occupant map `AF02[0..AEC6-1]` for operand1. Operand2 selects the sense: operand2 `== 0` -> success only when operand1 is pr

; C1:9012..C1:9043 [provisional] pass 57
ct_gate_tail_dispatch_by_live_unwithheld_count:
    ; TODO: lift real code/data for C1:9012..C1:9043
    ; Counts tail entries where: `AF02[x] != FF` `AF15[x] == 0` Compares that count against a descriptor byte from `CC:[B1D2 + 1]`. Dispatches to 

; C1:9013..C1:9043 [strong] pass 62
ct_global_opcode_05_gate_tail_replay_by_live_unwithheld_tail_count_max:
    ; TODO: lift real code/data for C1:9013..C1:9043
    ; Reads one immediate operand byte from `CC:[B1D2 + 1]`. Counts tail entries where: `AF02[x] != FF` and `AF15[x] == 0` Success path is taken w

; C1:9045..C1:9081 [strong] pass 62
ct_global_opcode_06_gate_tail_replay_when_96f1_96f3_triplet_gte_immediate:
    ; TODO: lift real code/data for C1:9045..C1:9081
    ; Reads a 3-byte immediate operand from `CC:[B1D2 + 1..3]`. Compares that operand lexicographically against current WRAM bytes: `96F1` `96F2` 

; C1:9082..C1:90BD [strong] pass 62
ct_global_opcode_07_gate_tail_replay_on_current_b320_compare_mode:
    ; TODO: lift real code/data for C1:9082..C1:90BD
    ; Reads compare byte from `CC:[B1D2 + 1]` and mode byte from `CC:[B1D2 + 2]`. Uses current slot index `B252` to read `B320[B252]`. Proven comp

; C1:90BE..C1:912F [strong] pass 64
ct_global_opcode_08_mark_selected_entries_by_fd_record_word3_le_immediate_then_reduce:
    ; TODO: lift real code/data for C1:90BE..C1:912F
    ; Calls `AC14`. Empty selection -> failure. Reads a 16-bit immediate threshold. For each selected entry: resolves the `FD:A80B` record base re

; C1:9130..C1:918D [provisional] pass 64
ct_global_opcode_09_scan_selected_entries_for_fd_record_byte_offset_gte_immediate_then_reduce:
    ; TODO: lift real code/data for C1:9130..C1:918D
    ; Calls `AC14`. Empty selection -> failure. Operand `+1` is a byte offset inside the `FD:A80B` record. Operand `+2` is the compare byte. Scans

; C1:918E..C1:91F8 [strong] pass 64
ct_global_opcode_0A_gate_tail_replay_on_priority_selected_entry_record_mask_clear:
    ; TODO: lift real code/data for C1:918E..C1:91F8
    ; Calls `AC14`. Empty selection -> failure. If only one entry is selected, uses it directly. If multiple entries are selected, reduces them to

; C1:91F9..C1:925C [provisional] pass 64
ct_global_opcode_0B_scan_selected_entries_for_fd_record_byte_offset_lte_immediate_then_reduce:
    ; TODO: lift real code/data for C1:91F9..C1:925C
    ; Calls `AC14`. Empty selection -> failure. Operand `+1` is a byte offset inside the `FD:A80B` record. Operand `+2` is the compare byte. Scans

; C1:925D..C1:92A2 [strong] pass 65
ct_global_opcode_0C_gate_tail_replay_on_relation_mode04_current_subject_vs_selection_head:
    ; TODO: lift real code/data for C1:925D..C1:92A2
    ; Calls `AC14`. Empty selection -> `AF24 = 1`. Seeds relation-query mode `04` with: `986F = B252 + 3` `9870 = AECC[0]` Calls service `5` throu

; C1:92A3..C1:9313 [provisional] pass 65
ct_global_opcode_0D_mark_non_subject_selected_entries_by_relation_mode05_zero_then_reduce:
    ; TODO: lift real code/data for C1:92A3..C1:9313
    ; Calls `AC14`. Sets current subject slot `986F = B252 + 3`. Uses relation-query mode `05`. Skips the subject slot if it appears in the select

; C1:9314..C1:938C [provisional] pass 65
ct_global_opcode_0E_mark_non_subject_selected_entries_by_parameterized_relation_mode_zero_then_reduce:
    ; TODO: lift real code/data for C1:9314..C1:938C
    ; Same structural family as `0D`. Seeds relation mode with `986E = operand2 + 0x06`. Skips the current subject slot. Marks selected entries wh

; C1:938D..C1:93E5 [strong] pass 65
ct_global_opcode_0F_gate_tail_replay_on_relation_mode08_current_subject_vs_selection_head:
    ; TODO: lift real code/data for C1:938D..C1:93E5
    ; Calls `AC14`. Empty selection -> `AF24 = 1`. Seeds relation-query mode `08` with: `986F = B252 + 3` `9870 = AECC[0]` `9871 = (operand2 << 2)

; C1:93E6..C1:9429 [strong] pass 65
ct_global_opcode_10_gate_tail_replay_on_current_subject_row_column_band_query:
    ; TODO: lift real code/data for C1:93E6..C1:9429
    ; Does not call `AC14`. Selects relation mode `09/0A/0B/0C` from operands `+2/+3`. Uses current subject slot `986F = B252 + 3`. Succeeds only 

; C1:942A..C1:9473 [strong] pass 65
ct_global_opcode_11_gate_tail_replay_on_current_b19e_upper_nibble_class:
    ; TODO: lift real code/data for C1:942A..C1:9473
    ; Direct current-slot gate, not a relation-query wrapper. Computes `X = B252 * 4`. Reads `B19E[X] & 0xF0`. Operand `+1` selects target class `

; C1:9474..C1:94D1 [strong] pass 65
ct_global_opcode_12_gate_tail_replay_on_current_b19e_b19f_pair_mode:
    ; TODO: lift real code/data for C1:9474..C1:94D1
    ; Direct current-slot gate, not a relation-query wrapper. Computes `X = B252 * 4`. Reads: `B19E[X] & 0xF0` `B19F[X]` Operand `+1` selects targ

; C1:94D2..C1:9513 [strong] pass 66
ct_global_opcode_13_gate_tail_replay_on_current_b19e_bit4_match_mode:
    ; TODO: lift real code/data for C1:94D2..C1:9513
    ; Computes `X = B252 * 4`. Reads `B19E[X] & 0x10`. Operand `+1` bit `0` selects the target bit state (`0x00` vs `0x10`). Operand `+3` selects 

; C1:9514..C1:9599 [provisional] pass 66
ct_global_opcode_14_gate_tail_replay_on_current_b19e_bit4_clear_selector_mode:
    ; TODO: lift real code/data for C1:9514..C1:9599
    ; Two-form handler. In the primary form (`operand+2 == 0`): requires current `B19E[X]` bit 4 clear uses `B19E[X] & 0x0F` to index `AF0A[...]` 

; C1:959A..C1:95D5 [strong] pass 66
ct_global_opcode_15_gate_tail_replay_on_current_b1a0_mask_match_mode:
    ; TODO: lift real code/data for C1:959A..C1:95D5
    ; Computes `X = B252 * 4`. Reads `B1A0[X]`. Operand `+1` is a required mask. Operand `+3 == 0` -> require full-mask containment. Operand `+3 !

; C1:95D6..C1:95D9 [strong] pass 66
ct_global_opcode_16_unconditional_tail_replay_step_alias:
    ; TODO: lift real code/data for C1:95D6..C1:95D9
    ; Exact alias of the unconditional `8C3E ; RTS` replay step.

; C1:95DA..C1:95F9 [strong] pass 66
ct_global_opcode_17_gate_tail_replay_on_rng_percent_below_immediate:
    ; TODO: lift real code/data for C1:95DA..C1:95F9
    ; Calls the known RNG helper at `AF22` with `A = 0x64`. Succeeds only when the returned value is below operand `+1`.

; C1:95FA..C1:9651 [provisional] pass 66
ct_global_opcode_18_reduce_selected_entries_by_indirect_table_byte_equals_immediate:
    ; TODO: lift real code/data for C1:95FA..C1:9651
    ; Calls `AC14`. Scans selected entries in `AECC`. Resolves an `FD:A80B` record-rooted value and uses it as the `Y` component of `LDA ($0A),Y`.

; C1:9652..C1:9655 [strong] pass 66
ct_global_opcode_19_unconditional_tail_replay_step_alias:
    ; TODO: lift real code/data for C1:9652..C1:9655
    ; Exact alias of the unconditional `8C3E ; RTS` replay step.

; C1:9656..C1:96A4 [provisional] pass 66
ct_global_opcode_1A_gate_tail_replay_on_live_tail_occupant_search_mode:
    ; TODO: lift real code/data for C1:9656..C1:96A4
    ; Scans the live-tail occupant submap `AF02[0..AEC6-1]` for operand `+1`. Dead leading `LDA $B252` should be ignored; the real scan starts fro

; C1:96A5..C1:96D3 [strong] pass 66
ct_global_opcode_1B_gate_tail_replay_on_visible_head_live_count_at_or_below_immediate:
    ; TODO: lift real code/data for C1:96A5..C1:96D3
    ; Counts non-`FF` entries in `AEFF[0..2]`. Uses `operand+1 + 1` internally, so the effective success predicate is: visible-head live count `<=

; C1:96D4..C1:9727 [provisional] pass 66
ct_global_opcode_1C_optionally_replay_on_selected_head_canonical_membership_then_abort:
    ; TODO: lift real code/data for C1:96D4..C1:9727
    ; Calls `AC14`. Searches `AF0A[0..2]` for a byte equal to `AECC[0]`. Uses operand `+2` plus optional `AEFF[x] != FF` live-head confirmation to

; C1:9728..C1:975B [strong] pass 66
ct_global_opcode_1D_gate_tail_replay_on_selected_tail_live_presence_mode:
    ; TODO: lift real code/data for C1:9728..C1:975B
    ; Calls `AC14`. Uses `AECC[0]` as the selected entry index. Reads `AF02[selected]`. Operand `+2` selects presence vs absence polarity.

; C1:975C..C1:9764 [strong] pass 66
ct_global_opcode_1E_unconditional_tail_replay_then_abort:
    ; TODO: lift real code/data for C1:975C..C1:9764
    ; Always runs `8C3E`. Then always writes `AF24 = 1`.

; C1:9765..C1:97AA [unspecified] pass 66
ct_global_opcode_1F_gate_tail_replay_on_relation_mode0E_current_subject_vs_selection_head:
    ; TODO: lift real code/data for C1:9765..C1:97AA
    ; Calls `AC14`. Seeds relation-query mode `0E` with: `986F = B252 + 3` `9870 = AECC[0]` Operand `+1` selects the final zero/nonzero gate on `9

; C1:97AB..C1:97BF [strong] pass 62
ct_global_opcode_20_gate_tail_replay_on_current_aeb3_nonzero:
    ; TODO: lift real code/data for C1:97AB..C1:97BF
    ; Uses current index `B252`. Reads `AEB3[B252]`. Success only when that byte is nonzero. Success -> `JSR $8C3E` Failure -> `AF24 = 1` Final ga

; C1:97C0..C1:97D4 [strong] pass 62
ct_global_opcode_21_gate_tail_replay_on_current_af15_zero:
    ; TODO: lift real code/data for C1:97C0..C1:97D4
    ; Immediate adjacent sibling of opcode `20`. Uses current index `B252`. Success only when `AF15[B252] == 0`. Success -> `JSR $8C3E` Failure ->

; C1:97D5..C1:980F [strong] pass 66
ct_global_opcode_22_gate_tail_replay_on_selected_b158_threshold_mode:
    ; TODO: lift real code/data for C1:97D5..C1:980F
    ; Calls `AC14`. Uses `AECC[0]` as the selected entry index. Reads `B158[selected]`. Operand `+1` is the threshold. Operand `+2 == 0` -> succes

; C1:9810..C1:9839 [strong] pass 67
ct_global_opcode_29_persist_selected_head_and_inline_param_to_current_5e15_5e0d:
    ; TODO: lift real code/data for C1:9810..C1:9839
    ; Advances the stream, calls `AC14`, reads one inline byte, and stores: `AEE5 -> 5E0D[current]` `AECC[0] -> 5E15[current]` Strong bridge to la

; C1:983A..C1:98C3 [strong] pass 67
ct_global_opcode_2A_2B_ordered_first_choice_persist_shared_body:
    ; TODO: lift real code/data for C1:983A..C1:98C3
    ; Calls `AC14`. If multiple selected entries exist, collapses them to the first entry matching the external priority list in `B23A[0..7]`. Cop

; C1:98C4..C1:98C4 [strong] pass 67
ct_global_opcode_2C_rts_noop_alias:
    ; TODO: lift real code/data for C1:98C4..C1:98C4
    ; Exact single-byte `RTS`.

; C1:98C5..C1:995F [strong] pass 67
ct_global_opcode_2D_random_4way_stream_advance:
    ; TODO: lift real code/data for C1:98C5..C1:995F
    ; Promoted global-master ownership of the already-solved group-1 random 4-way stream-control body. Uses RNG split ranges and `FD:BA4A`-driven 

; C1:9960..C1:9960 [strong] pass 67
ct_global_opcode_2E_rts_noop_alias:
    ; TODO: lift real code/data for C1:9960..C1:9960
    ; Exact single-byte `RTS`.

; C1:9961..C1:9961 [strong] pass 67
ct_global_opcode_2F_rts_noop_alias:
    ; TODO: lift real code/data for C1:9961..C1:9961
    ; Exact single-byte `RTS`.

; C1:9967..C1:9977 [strong] pass 68
ct_global_opcode_32_capture_inline_param1_to_aee4:
    ; TODO: lift real code/data for C1:9967..C1:9977
    ; Reads the current stream byte at `CC:[B1D2 + 1]`. Stores it into `AEE4`. Does not locally advance `B1D2`. Best current reading: tiny inline-

; C1:9981..C1:99B3 [strong] pass 68
ct_global_opcode_39_3F_gate_on_materializable_canonical_tail_slot_exists:
    ; TODO: lift real code/data for C1:9981..C1:99B3
    ; Scans 8 tail slots. Accepts only when: `AF0D[x] != FF` `AF02[x] == FF` `AF15.bit7` clear Success clears `AF24`; zero accepted entries force 

; C1:99B8..C1:99BD [strong] pass 68
ct_global_opcode_40_set_group2_continuation_2:
    ; TODO: lift real code/data for C1:99B8..C1:99BD
    ; Writes `B3B8 = 2` and returns.

; C1:99BE..C1:9A38 [strong] pass 68
ct_global_opcode_41_seed_single_from_5e15_finalize:
    ; TODO: lift real code/data for C1:99BE..C1:9A38
    ; Promoted master ownership of the old group-2 `01` body. Seeds one entry from `5E15[current]`. Captures inline parameters into `AEE4/AEE5`. U

; C1:9A39..C1:9B45 [strong] pass 68
ct_global_opcode_42_seed_from_b16e_validate_commit:
    ; TODO: lift real code/data for C1:9A39..C1:9B45
    ; Table-entry wrapper lands in `9A3D`. Seeds one entry from `B16E[current]`. Optionally resolves inline selectors through `AC14`. Validates th

; C1:9DCE..C1:9E61 [strong] pass 68
ct_global_opcode_4D_bitmask_state_control:
    ; TODO: lift real code/data for C1:9DCE..C1:9E61
    ; Promoted master ownership of the old group-2 `0D` state-control body. Operand bits drive a mix of per-slot and global control writes.

; C1:9E63..C1:9E77 [strong] pass 68
ct_global_opcode_4F_optional_cd0033_then_set_continuation_2:
    ; TODO: lift real code/data for C1:9E63..C1:9E77
    ; If operand 1 is nonzero, calls `JSL $CD0033`. Then writes `B3B8 = 2` and returns.

; C1:9E78 [unspecified] pass 56
ct_g2_cmd10_materialize_tail_slots_from_canonical_map:
    ; TODO: lift real code/data for C1:9E78
    ; Earlier passes already proved the scan gates: `AF0D[x] != FF` `AF02[x] == FF` `AF15.bit7` clear Pass 56 upgrades the noun: this command mate

; C1:9E78..C1:9F59 [strong] pass 68
ct_global_opcode_50_materialize_tail_slots_from_canonical_map_finalize:
    ; TODO: lift real code/data for C1:9E78..C1:9F59
    ; Promoted master ownership of the old group-2 `10` body. Scans canonical/live/deferred tail state through `AF0D/AF02/AF15`. Builds selected e

; C1:9F5A..C1:9FD1 [strong] pass 68
ct_global_opcode_51_group_base_write4_pairs:
    ; TODO: lift real code/data for C1:9F5A..C1:9FD1
    ; Promoted master ownership of the old group-2 `11` writer body.

; C1:9FD2..C1:A14D [strong] pass 68
ct_global_opcode_52_group_base_write5_pairs_validate:
    ; TODO: lift real code/data for C1:9FD2..C1:A14D
    ; Promoted master ownership of the old group-2 `12` writer-plus-validation body.

; C1:A14E..C1:A187 [strong] pass 68
ct_global_opcode_53_sat_signed_delta_to_current_b158:
    ; TODO: lift real code/data for C1:A14E..C1:A187
    ; Promoted master ownership of the old group-2 `13` saturating signed-delta body.

; C1:A396..C1:A3D0 [strong] pass 68
ct_global_opcode_56_wrapper_fused_fd_a990:
    ; TODO: lift real code/data for C1:A396..C1:A3D0
    ; Promoted master ownership of the old group-2 `16` thin wrapper around `FD:A990`.

; C1:A3F6 [strong] pass 69
ct_global_opcode_57_rts_noop_alias:
    ; TODO: lift real code/data for C1:A3F6
    ; Exact single-byte RTS alias. First entry in the promoted selector-control master slice.

; C1:A3F7..C1:A410 [strong] pass 69
ct_global_opcode_58_select_visible_head_occupied_live_slots:
    ; TODO: lift real code/data for C1:A3F7..C1:A410
    ; Scans `AEFF[0..2]`. Appends occupied visible-head live slot indices into `AECC`. Stores the resulting count in `AECB`.

; C1:A411..C1:A42D [strong] pass 69
ct_global_opcode_59_select_all_occupied_live_slots:
    ; TODO: lift real code/data for C1:A411..C1:A42D
    ; Calls the `57/58`-band visible selector first. Then appends occupied live slots `3..10` from `AEFF`. Stores the final count in `AECB`.

; C1:A42E..C1:A43C [strong] pass 69
ct_global_opcode_5A_select_current_tail_local_live_slot:
    ; TODO: lift real code/data for C1:A42E..C1:A43C
    ; Writes `B252 + 3` into `AECC[0]`. Forces `AECB = 1`.

; C1:A43D..C1:A451 [strong] pass 69
ct_global_opcode_5B_select_current_quad_record_low_nibble_entry:
    ; TODO: lift real code/data for C1:A43D..C1:A451
    ; Reads `B19E + 4*B252`. Masks to the low nibble. Stores that value into `AECC[0]`. Forces `AECB = 1`.

; C1:A452..C1:A4AE [provisional] pass 69
ct_global_opcode_5C_select_random_visible_head_live_slot_after_optional_refresh:
    ; TODO: lift real code/data for C1:A452..C1:A4AE
    ; If DP scratch `$24` is zero, runs `B279` across visible entries `0..2` before the selection attempt. Then randomly chooses one occupied visi

; C1:A4AF..C1:A4DF [strong] pass 69
ct_global_opcode_5D_select_target_relation_mode_00:
    ; TODO: lift real code/data for C1:A4AF..C1:A4DF
    ; Promoted master/global ownership of the pass-30 relation-query target selector for mode `00`.

; C1:A4E0..C1:A507 [strong] pass 69
ct_global_opcode_5E_select_target_relation_mode_01:
    ; TODO: lift real code/data for C1:A4E0..C1:A507
    ; Promoted master/global ownership of the pass-30 relation-query target selector for mode `01`.

; C1:A508..C1:A540 [strong] pass 69
ct_global_opcode_5F_select_one_visible_entry_0_1_2_by_min_current_hp:
    ; TODO: lift real code/data for C1:A508..C1:A540
    ; Compares visible-head lane values at `5E30`, `5EB0`, and `5F30`. Selects exactly one visible entry index `0..2` with the minimum current-HP 

; C1:A541..C1:A54A [strong] pass 70
ct_global_opcode_60_select_visible_entries_by_positive_fd_record_byte_1D:
    ; TODO: lift real code/data for C1:A541..C1:A54A
    ; Sets selector offset `0x1D`. Uses the shared visible FD-offset family at `AD68`. Practical contract: positive `record[+1D]`, then reduce.

; C1:A54B..C1:A554 [strong] pass 70
ct_global_opcode_61_select_visible_entries_by_nonzero_fd_record_byte_1E:
    ; TODO: lift real code/data for C1:A54B..C1:A554
    ; Sets selector offset `0x1E`. Uses the shared visible FD-offset family at `AD68`. Also inherits the shared nonnegative `record[+1D]` gate.

; C1:A555..C1:A55E [strong] pass 70
ct_global_opcode_62_select_visible_entries_by_nonzero_fd_record_byte_1F:
    ; TODO: lift real code/data for C1:A555..C1:A55E
    ; Sets selector offset `0x1F`. Uses the shared visible FD-offset family at `AD68`. Also inherits the shared nonnegative `record[+1D]` gate.

; C1:A55F..C1:A568 [strong] pass 70
ct_global_opcode_63_select_visible_entries_by_nonzero_fd_record_byte_20:
    ; TODO: lift real code/data for C1:A55F..C1:A568
    ; Sets selector offset `0x20`. Uses the shared visible FD-offset family at `AD68`. Also inherits the shared nonnegative `record[+1D]` gate.

; C1:A569..C1:A572 [strong] pass 70
ct_global_opcode_64_select_visible_entries_by_nonzero_fd_record_byte_21:
    ; TODO: lift real code/data for C1:A569..C1:A572
    ; Sets selector offset `0x21`. Uses the shared visible FD-offset family at `AD68`. Also inherits the shared nonnegative `record[+1D]` gate.

; C1:A573..C1:A5A2 [strong] pass 70
ct_global_opcode_65_select_visible_entries_by_fd_record_byte_1E_mask_02:
    ; TODO: lift real code/data for C1:A573..C1:A5A2
    ; Uses the shared visible FD-offset/mask pipeline. Tests `record[+1E] & 0x02`. Also inherits the shared nonnegative `record[+1D]` gate.

; C1:A5A3..C1:A5D2 [strong] pass 70
ct_global_opcode_66_select_visible_entries_by_fd_record_byte_1E_mask_80:
    ; TODO: lift real code/data for C1:A5A3..C1:A5D2
    ; Uses the shared visible FD-offset/mask pipeline. Tests `record[+1E] & 0x80`. Also inherits the shared nonnegative `record[+1D]` gate.

; C1:A5D3..C1:A602 [strong] pass 70
ct_global_opcode_67_select_visible_entries_by_fd_record_byte_1E_mask_04:
    ; TODO: lift real code/data for C1:A5D3..C1:A602
    ; Uses the shared visible FD-offset/mask pipeline. Tests `record[+1E] & 0x04`. Also inherits the shared nonnegative `record[+1D]` gate.

; C1:A603..C1:A632 [strong] pass 70
ct_global_opcode_68_select_visible_entries_by_fd_record_byte_21_mask_04:
    ; TODO: lift real code/data for C1:A603..C1:A632
    ; Uses the shared visible FD-offset/mask pipeline. Tests `record[+21] & 0x04`. Also inherits the shared nonnegative `record[+1D]` gate.

; C1:A633..C1:A662 [strong] pass 70
ct_global_opcode_69_select_visible_entries_by_fd_record_byte_21_mask_40:
    ; TODO: lift real code/data for C1:A633..C1:A662
    ; Uses the shared visible FD-offset/mask pipeline. Tests `record[+21] & 0x40`. Also inherits the shared nonnegative `record[+1D]` gate.

; C1:A663..C1:A692 [strong] pass 70
ct_global_opcode_6A_select_visible_entries_by_fd_record_byte_20_mask_10:
    ; TODO: lift real code/data for C1:A663..C1:A692
    ; Uses the shared visible FD-offset/mask pipeline. Tests `record[+20] & 0x10`. Also inherits the shared nonnegative `record[+1D]` gate.

; C1:A693..C1:A6C2 [strong] pass 70
ct_global_opcode_6B_select_visible_entries_by_fd_record_byte_01_mask_08:
    ; TODO: lift real code/data for C1:A693..C1:A6C2
    ; Uses the shared visible FD-offset/mask pipeline. Tests `record[+01] & 0x08`. Also inherits the shared nonnegative `record[+1D]` gate.

; C1:A6C3..C1:A6EC [strong] pass 70
ct_global_opcode_6C_select_occupied_live_tail_slots_except_current:
    ; TODO: lift real code/data for C1:A6C3..C1:A6EC
    ; Computes the current tail-local live slot as `B252 + 3`. Scans live slots `3..10`. Appends every occupied slot except that current one into 

; C1:A6ED..C1:A708 [strong] pass 69
ct_global_opcode_6D_select_nonhead_occupied_live_slots:
    ; TODO: lift real code/data for C1:A6ED..C1:A708
    ; Scans `AEFF[3..10]`. Appends occupied non-head live slot indices into `AECC`. Stores the resulting count in `AECB`.

; C1:A709..C1:A736 [strong] pass 69
ct_global_opcode_6E_select_target_relation_mode_02:
    ; TODO: lift real code/data for C1:A709..C1:A736
    ; Promoted master/global ownership of the pass-30 relation-query target selector for mode `02`.

; C1:A737..C1:A764 [strong] pass 69
ct_global_opcode_6F_select_target_relation_mode_03:
    ; TODO: lift real code/data for C1:A737..C1:A764
    ; Promoted master/global ownership of the pass-30 relation-query target selector for mode `03`.

; C1:A765..C1:A7A8 [strong] pass 71
ct_global_opcode_70_select_one_nonhead_occupied_live_slot_by_min_nonzero_fd_record_word_03:
    ; TODO: lift real code/data for C1:A765..C1:A7A8
    ; Scans occupied live slots `3..10`. Resolves each slot through `FD:A80B + slot*2`. Compares the 16-bit word at `record + 3`. Keeps the smalle

; C1:A7A9..C1:A7E4 [strong] pass 71
ct_global_opcode_71_select_nonhead_occupied_live_slots_excluding_primary_seed_by_positive_fd_record_byte_1D:
    ; TODO: lift real code/data for C1:A7A9..C1:A7E4
    ; Nonhead counterpart of the pass-70 visible FD-byte selector family. Scans live slots `3..10`. Skips the primary-seed slot indexed by `B18B`.

; C1:A7E5..C1:A818 [strong] pass 71
ct_global_opcode_72_select_nonhead_occupied_live_slots_by_positive_fd_record_byte_1D:
    ; TODO: lift real code/data for C1:A7E5..C1:A818
    ; Nonhead counterpart of global `60`. Scans occupied live slots `3..10` through `AE70 -> ADA1`. No `B18B` exclusion.

; C1:A819..C1:A854 [strong] pass 71
ct_global_opcode_73_select_nonhead_occupied_live_slots_excluding_primary_seed_by_nonzero_fd_record_byte_1E:
    ; TODO: lift real code/data for C1:A819..C1:A854
    ; Tests `record[+1E]` through the shared `AE70 -> ADA1` reducer path. Also inherits the shared nonnegative `record[+1D]` gate. Skips the prima

; C1:A855..C1:A888 [strong] pass 71
ct_global_opcode_74_select_nonhead_occupied_live_slots_by_nonzero_fd_record_byte_1E:
    ; TODO: lift real code/data for C1:A855..C1:A888
    ; Nonhead counterpart of global `61`. Uses the shared `AE70 -> ADA1` reducer path. No `B18B` exclusion.

; C1:A889..C1:A8C4 [strong] pass 71
ct_global_opcode_75_select_nonhead_occupied_live_slots_excluding_primary_seed_by_nonzero_fd_record_byte_1F:
    ; TODO: lift real code/data for C1:A889..C1:A8C4
    ; Tests `record[+1F]` through the shared `AE70 -> ADA1` reducer path. Skips the primary-seed slot indexed by `B18B`.

; C1:A8C5..C1:A8F8 [strong] pass 71
ct_global_opcode_76_select_nonhead_occupied_live_slots_by_nonzero_fd_record_byte_1F:
    ; TODO: lift real code/data for C1:A8C5..C1:A8F8
    ; Structurally matches the no-exclusion sibling of global `75`. Intended to test `record[+1F]` through the shared `AE70 -> ADA1` reducer path.

; C1:A8F9..C1:A934 [strong] pass 71
ct_global_opcode_77_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1E_mask_02:
    ; TODO: lift real code/data for C1:A8F9..C1:A934
    ; Uses the shared nonhead FD-offset/mask pipeline. Tests `record[+1E] & 0x02`. Skips the primary-seed slot indexed by `B18B`.

; C1:A935..C1:A970 [strong] pass 71
ct_global_opcode_78_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1E_mask_80:
    ; TODO: lift real code/data for C1:A935..C1:A970
    ; Uses the shared nonhead FD-offset/mask pipeline. Tests `record[+1E] & 0x80`. Skips the primary-seed slot indexed by `B18B`.

; C1:A971..C1:A9AC [strong] pass 71
ct_global_opcode_79_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1E_mask_04:
    ; TODO: lift real code/data for C1:A971..C1:A9AC
    ; Uses the shared nonhead FD-offset/mask pipeline. Tests `record[+1E] & 0x04`. Skips the primary-seed slot indexed by `B18B`.

; C1:A9AD..C1:A9E8 [strong] pass 71
ct_global_opcode_7A_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_21_mask_40:
    ; TODO: lift real code/data for C1:A9AD..C1:A9E8
    ; Uses the shared nonhead FD-offset/mask pipeline. Tests `record[+21] & 0x40`. Skips the primary-seed slot indexed by `B18B`.

; C1:A9E9..C1:AA24 [strong] pass 71
ct_global_opcode_7B_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1D_mask_02:
    ; TODO: lift real code/data for C1:A9E9..C1:AA24
    ; Uses the shared nonhead FD-offset/mask pipeline. Tests `record[+1D] & 0x02`. Skips the primary-seed slot indexed by `B18B`.

; C1:AA25..C1:AA60 [strong] pass 71
ct_global_opcode_7C_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_19_mask_01:
    ; TODO: lift real code/data for C1:AA25..C1:AA60
    ; Uses the shared nonhead FD-offset/mask pipeline. Tests `record[+19] & 0x01`. Skips the primary-seed slot indexed by `B18B`.

; C1:AA61..C1:AAAA [strong] pass 71
ct_global_opcode_7D_select_one_nonhead_occupied_live_slot_excluding_primary_seed_by_min_nonzero_fd_record_word_03:
    ; TODO: lift real code/data for C1:AA61..C1:AAAA
    ; Same minimum-word selector family as global `70`. Scans occupied live slots `3..10`. Skips the primary-seed slot indexed by `B18B`. Chooses 

; C1:AAAB..C1:AAF8 [strong] pass 58
ct_fixed_single_entry_selector_wrappers_3_through_10:
    ; TODO: lift real code/data for C1:AAAB..C1:AAF8
    ; Family of tiny wrappers: `AECC = literal` `AECB = 1` `RTS` Covered literal values: `3..10`.

; C1:AB03..C1:AB49 [strong] pass 57
ct_build_withheld_tail_candidate_list_and_random_reduce_to_one:
    ; TODO: lift real code/data for C1:AB03..C1:AB49
    ; Scans all 8 tail entries. Collects slot indices with `AF15.bit7` set into `AECC`. Stores the candidate count in `AECB`. If `AECB >= 2`, uses

; C1:AB03..C1:AB49 [strong] pass 69
ct_global_opcode_86_build_withheld_tail_candidate_list_and_random_reduce_to_one:
    ; TODO: lift real code/data for C1:AB03..C1:AB49
    ; Promoted master/global ownership of the pass-57 withheld-tail selector body.

; C1:AB4E..C1:AB90 [strong] pass 58
ct_fixed_single_entry_selector_wrappers_0_through_6:
    ; TODO: lift real code/data for C1:AB4E..C1:AB90
    ; Family of tiny wrappers: `AECC = literal` `AECB = 1` `RTS` Covered literal values: `0..6`.

; C1:AB9B..C1:ABC8 [strong] pass 58
ct_select_one_visible_entry_0_1_2_by_min_lane_value:
    ; TODO: lift real code/data for C1:AB9B..C1:ABC8
    ; Compares three lane-local values: `5E30` `5EB0` `5F30` Selects exactly one visible entry index: `0`, `1`, or `2` Stores that selected entry 

; C1:AB9B..C1:ABC8 [strong] pass 69
ct_global_opcode_8E_select_one_visible_entry_0_1_2_by_min_lane_value:
    ; TODO: lift real code/data for C1:AB9B..C1:ABC8
    ; Promoted master/global ownership of the pass-58 visible min selector.

; C1:ABC9..C1:AC13 [strong] pass 58
ct_build_live_tail_slot_candidate_list_and_random_reduce_to_one:
    ; TODO: lift real code/data for C1:ABC9..C1:AC13
    ; Scans the unified live occupant map starting at slot index `3`. Uses `B252 + 3` as the upper live-tail bound. Appends non-`FF` live slot ind

; C1:ABC9..C1:AC13 [strong] pass 69
ct_global_opcode_8F_build_live_tail_slot_candidate_list_and_random_reduce_to_one:
    ; TODO: lift real code/data for C1:ABC9..C1:AC13
    ; Promoted master/global ownership of the pass-58 live-tail selector body.

; C1:AC14..C1:AC45 [strong] pass 59
ct_resolve_inline_selector_control_byte_into_selection_result:
    ; TODO: lift real code/data for C1:AC14..C1:AC45
    ; Reads the next selector-control byte from the CC stream. If negative, uses the preset path through `AED8`. Otherwise dispatches through `ct_

; C1:AC57..C1:AC5D [strong] pass 74
ct_c1_run_common_followup_tail_then_apply_pending_stat_deltas:
    ; TODO: lift real code/data for C1:AC57..C1:AC5D
    ; Calls `BFA4` first. Then calls `AC85`. Structural role: bridge the shared follow-up-context tail into pending stat-delta packet apply.

; C1:AC57..C1:AC5D [strong] pass 75
ct_c1_run_service_04_hook_then_apply_pending_stat_deltas:
    ; TODO: lift real code/data for C1:AC57..C1:AC5D
    ; Exact body: `JSR BFA4 ; JSR AC85 ; RTS`. Because `BFA4` is now exact, this tail is no longer just a vague bridge. Strongest safe reading: ru

; C1:AC85..C1:AC88 [strong] pass 74
ct_c1_apply_pending_stat_delta_channels_wrapper:
    ; TODO: lift real code/data for C1:AC85..C1:AC88
    ; Exact wrapper: `JSR EC7F ; RTS`.

; C1:AD68..C1:ADA0 [strong] pass 70
ct_build_visible_fd_offset_nonzero_candidates_and_reduce:
    ; TODO: lift real code/data for C1:AD68..C1:ADA0
    ; Clears `AECB`, `AF20`, and `AF21`. Forces `AF1F = FF`. Runs `AE70` across visible entries `0`, `1`, and `2`. Then runs `ADA1` to reduce the 

; C1:ADA1..C1:AE20 [strong] pass 70
ct_reduce_visible_fd_candidates_by_b23a_priority_and_optional_relation_redirect:
    ; TODO: lift real code/data for C1:ADA1..C1:AE20
    ; Consumes candidate bytes already staged in `AECC/AECB`. Uses `B23A` as the ordered reduction stream. Prefers `0x80`-marked candidates when a

; C1:AE21..C1:AE6F [strong] pass 64
ct_reduce_marked_selected_entries_to_single_choice_or_fail:
    ; TODO: lift real code/data for C1:AE21..C1:AE6F
    ; Empty input selection increments `AF24` and returns. Requires a bit-7-marked chosen entry to succeed. On success: strips bit 7 writes the ch

; C1:AE70..C1:AECF [strong] pass 70
ct_scan_one_visible_entry_for_fd_offset_mask_candidate:
    ; TODO: lift real code/data for C1:AE70..C1:AECF
    ; Scans one visible entry indexed by `AF1E`. Uses the FD record root table at `FD:A80B`. Tests `(record[offset_from_$0A] & AF1F) != 0`. Also r

; C1:AED3..C1:AEFB [strong] pass 57
ct_materialize_deferred_tail_entry_by_canonical_occupant_id:
    ; TODO: lift real code/data for C1:AED3..C1:AEFB
    ; Scans tail slots `0..7`. Matches target occupant ID in `$0E` against the canonical tail map `AF0D[x]`. Requires that the live tail map `AF02

; C1:AFB6..C1:AFC0 [strong] pass 72
ct_global_opcode_9D_late_pack_helper_internal_alias_seed_dp28_from_fd_ba61:
    ; TODO: lift real code/data for C1:AFB6..C1:AFC0
    ; Internal helper/lead-in alias before the late-pack executor blob. Seeds scratch through `FD:BA61`, `DP28/29`, `C92A`, and a `PLX` return tai

; C1:AFC1..C1:AFCB [strong] pass 72
ct_global_opcode_9E_late_pack_helper_internal_alias_call_c92a_and_plx_return:
    ; TODO: lift real code/data for C1:AFC1..C1:AFCB
    ; Internal alias into the same helper tail used by `9D`. Falls through to `PLX ; STX $2C ; RTS`. Not a clean standalone top-level command body

; C1:AFCC..C1:AFD4 [strong] pass 72
ct_global_opcode_9F_late_pack_helper_internal_alias_plx_return:
    ; TODO: lift real code/data for C1:AFCC..C1:AFD4
    ; Internal alias that lands directly in the `PLX` return tail ahead of the late-pack blob. Not a clean standalone top-level command body.

; C1:AFD7..C1:B08E [strong] pass 60
ct_execute_late_selector_pack_and_capture_tail_result:
    ; TODO: lift real code/data for C1:AFD7..C1:B08E
    ; Top-level late-family executor proved in this pass. Loads a pointer from `ct_late_selector_control_pointer_records`. Uses `B4AA` to select/a

; C1:AFD7..C1:B08E [strong] pass 69
ct_global_opcode_A0_execute_late_selector_pack_and_capture_tail_result:
    ; TODO: lift real code/data for C1:AFD7..C1:B08E
    ; Promoted master/global ownership of the pass-60 late selector-pack executor.

; C1:AFD7..C1:AFE1 [strong] pass 72
ct_global_opcode_A0_late_pack_executor_internal_alias_after_cc_record_load:
    ; TODO: lift real code/data for C1:AFD7..C1:AFE1
    ; The master pointer lands two bytes inside the real `CC:8B08` pointer-load sequence. Keep as an internal late-pack executor alias, not as the

; C1:AFE2..C1:AFEC [strong] pass 72
ct_global_opcode_A1_late_pack_executor_internal_alias_clear_af24_and_probe_second_subop:
    ; TODO: lift real code/data for C1:AFE2..C1:AFEC
    ; Internal alias in the common late-pack executor path. Clears `AF24`, probes byte `+4` for the `FE` chained-subop case, and falls into the sh

; C1:AFED..C1:AFF7 [strong] pass 72
ct_global_opcode_A2_late_pack_executor_internal_alias_arm_second_subop_flag:
    ; TODO: lift real code/data for C1:AFED..C1:AFF7
    ; Internal alias in the same common path. Lives inside the `CMP #$FE` / `B1CF` second-subop arming logic.

; C1:AFF8..C1:B002 [strong] pass 72
ct_global_opcode_A3_late_pack_executor_internal_alias_after_segment_select:
    ; TODO: lift real code/data for C1:AFF8..C1:B002
    ; Internal alias after `B4AA` segment selection. Fetches the current opcode byte into `B239` and falls into the shared dispatch path.

; C1:B003..C1:B00D [strong] pass 72
ct_global_opcode_A4_late_pack_executor_internal_alias_dispatch_current_b239_opcode:
    ; TODO: lift real code/data for C1:B003..C1:B00D
    ; Internal alias that dispatches the current `B239` opcode through the master table.

; C1:B00E..C1:B018 [strong] pass 72
ct_global_opcode_A5_late_pack_executor_internal_alias_advance_to_second_subop:
    ; TODO: lift real code/data for C1:B00E..C1:B018
    ; Internal alias for the chained second-subop advance path. Advances `B1D2` by `+4`, reloads `B239`, and falls back into the shared dispatch.

; C1:B019..C1:B023 [strong] pass 72
ct_global_opcode_A6_late_pack_executor_internal_alias_dispatch_second_subop:
    ; TODO: lift real code/data for C1:B019..C1:B023
    ; Internal alias after the chained second-subop reload. Dispatches the second `B239` opcode and falls into result capture.

; C1:B024..C1:B02E [strong] pass 72
ct_global_opcode_A7_late_pack_executor_internal_alias_capture_af24_result:
    ; TODO: lift real code/data for C1:B024..C1:B02E
    ; Internal alias at the result-capture start. Mirrors `AF24` into `B24A[tail]` and enters the special-case / nonzero-result logic.

; C1:B02F..C1:B039 [strong] pass 72
ct_global_opcode_A8_late_pack_executor_internal_alias_special_case_af24_eq_02:
    ; TODO: lift real code/data for C1:B02F..C1:B039
    ; Internal alias inside the result-capture tail. Special-cases `AF24 == 2` before the broader nonzero-result path.

; C1:B03A..C1:B08E [strong] pass 72
ct_global_opcode_A9_late_pack_executor_internal_alias_nonzero_af24_path:
    ; TODO: lift real code/data for C1:B03A..C1:B08E
    ; Internal alias into the nonzero-result handling and FE/FF continuation logic. Includes the path that marks `B242`, advances FE-delimited seg

; C1:B094..C1:B0B3 [provisional] pass 49
ct_c1_update_lane_low_hp_threshold_flag:
    ; TODO: lift real code/data for C1:B094..C1:B0B3
    ; Previously part of a vague flag-maintenance band. Pass 49 proves this exact routine clears and re-establishes `5E2F.bit0` from the `maxHP/8`

; C1:B279..C1:B2C0 [provisional] pass 55
ct_c1_restore_or_clear_live_battle_slot_occupant_from_default_map:
    ; TODO: lift real code/data for C1:B279..C1:B2C0
    ; Strong structure: restores `AEFF[Y]` from `AF0A[Y]` when a remembered occupant exists later clears `AEFF[Y] = FF` on failure/removal path Ke

; C1:B390 [strong] pass 51
ct_c1_seed_lane_gauge_exports_from_b158:
    ; TODO: lift real code/data for C1:B390
    ; Directly mirrors `B158,Y` into: `AFAB,Y` `99DD,Y` `9F22,Y` Strongest safe reading: direct seed/export mirror from the upstream readiness see

; C1:B4AA..C1:B4E6 [strong] pass 60
ct_select_tail_local_segment_within_late_selector_pack:
    ; TODO: lift real code/data for C1:B4AA..C1:B4E6
    ; Previously just an opaque helper reached from the late family. Pass 60 proves it is the segment-selection / pointer-adjust helper that sits 

; C1:B575 [strong] pass 42
ct_c1_service7_reconcile_canonical_record_lane_pairs:
    ; TODO: lift real code/data for C1:B575
    ; Initializes `B3EB..B3F3` to `FF`, seeds root lane IDs `0/1/2`, This is the concrete front-end of the downstream `93F3` family.

; C1:B725 [strong] pass 50
ct_c1_init_lane_active_time_gauge_exports:
    ; TODO: lift real code/data for C1:B725
    ; Clears the visible lane-progress exports `99DD..99DF`. Seeds the visible lane-threshold/cap exports `9F22..9F24` to `0x30`. Also resets the 

; C1:B80D..C1:B95F [strong] pass 61
ct_c1_master_opcode_dispatch_table:
    ; TODO: lift real code/data for C1:B80D..C1:B95F
    ; Root indexed `JSR` table used by the late-pack executor. Interior slices line up exactly with the previously solved local tables. Current pr

; C1:B85F..C1:B88C [strong] pass 61
ct_c1_group1_opcode_dispatch_slice:
    ; TODO: lift real code/data for C1:B85F..C1:B88C
    ; Keep the useful local group-1 numbering from earlier passes. But this is now proved to be a slice entrypoint inside `ct_c1_master_opcode_dis

; C1:B88D..C1:B8BA [strong] pass 61
ct_c1_group2_opcode_dispatch_slice:
    ; TODO: lift real code/data for C1:B88D..C1:B8BA
    ; Same correction as the group-1 table. Useful local numbering remains valid. Root ownership now belongs to `ct_c1_master_opcode_dispatch_tabl

; C1:B8BB..C1:B95F [strong] pass 59
ct_inline_selector_control_dispatch_table:
    ; TODO: lift real code/data for C1:B8BB..C1:B95F
    ; Directly dispatched by `C1:AC2E  JSR ($B8BB,X)`. `X` is formed from the non-negative inline selector-control byte read by `AC14`. Proven tab

; C1:B8BB..C1:B95F [strong] pass 61
ct_c1_inline_selector_control_dispatch_slice:
    ; TODO: lift real code/data for C1:B8BB..C1:B95F
    ; Same correction again for the selector-control table. `AC14` still dispatches here by local selector-control byte. But this slice is inside 

; C1:B8F3..C1:B92B [provisional] pass 58
ct_selector_wrapper_table_candidate:
    ; TODO: lift real code/data for C1:B8F3..C1:B92B
    ; Coherent pointer run of 29 entries: dynamic selector wrappers fixed single-entry wrappers `AB03` `AB9B` `ABC9` Strongly looks like a real lo

; C1:B961 [strong] pass 42
ct_c1_local_service2_wrapper:
    ; TODO: lift real code/data for C1:B961
    ; Exact wrapper: `LDA #$02` `JSR $0003` `RTL` Invokes local service 2 through the bank-C1 dispatcher.

; C1:BD6F [strong] pass 50
ct_c1_apply_status_modifiers_to_lane_time_increment:
    ; TODO: lift real code/data for C1:BD6F
    ; Starts from `AFAB[x]`. Halves it when the `5E4D|5E52` status family has bit `0x80` set. Doubles it with saturation when `5E4B` bit `0x20` is

; C1:BDE0..C1:BF25 [unspecified] pass 50
ct_c1_advance_lane_active_time_gauge_and_ready_transition_family:
    ; TODO: lift real code/data for C1:BDE0..C1:BF25
    ; Three sibling update families that: seed `AFAB` from `B158` apply `BD6F` advance one or both lane-bar exports with saturation set/update lan

; C1:BF7F..C1:BFA0 [strong] pass 75
ct_c1_copy_17_byte_followup_descriptor_profile_from_cc213f_by_b18c:
    ; TODO: lift real code/data for C1:BF7F..C1:BFA0
    ; Computes `0x11 * B18C`. Copies `0x11` bytes from `CC:213F + 0x11*B18C` into `AEE6..AEF6`. Strongest safe reading: load the current follow-up

; C1:BFA4..C1:BFA9 [strong] pass 75
ct_c1_invoke_local_service_04_wrapper:
    ; TODO: lift real code/data for C1:BFA4..C1:BFA9
    ; Exact bytes: `LDA #$04 ; JSR $0003 ; RTS`. This is no longer a fuzzy helper blob. Structural role: tiny wrapper into the local service/dispa

; C1:BFAA..C1:C029 [strong] pass 75
ct_c1_initialize_current_tail_followup_context_load_current_descriptor_and_run_common_tail:
    ; TODO: lift real code/data for C1:BFAA..C1:C029
    ; Sets `B1FC.bit1` on entry and clears it on exit. Clears `AE93/AE94/AE95/AE96/AE99/AE9A/AE9B`, sets `AE97=AE98=0xFF`, seeds `AE90=0`, `AE91=B

; C1:C90B [strong] pass 52
ct_c1_mul_u16_dp28_dp2a_to_dp2c_lowword:
    ; TODO: lift real code/data for C1:C90B
    ; Shift/add multiply helper. Consumes 16-bit inputs in `$28` and `$2A`. Writes the low word of the product to `$2C`. This is the real arithmet

; C1:CC74..C1:CCC5 [provisional] pass 49
ct_c1_lane_selected_resource_spend_on_5e34_family:
    ; TODO: lift real code/data for C1:CC74..C1:CCC5
    ; Subtracts a computed quantity from exactly one of: `5E34` `5EB4` `5F34` Strongly looks like a lane-selected spend/update path for the field 

; C1:E89F..C1:E8BE [strong] pass 73
ct_c1_compute_ad9c_packet_offset_from_ad9b_and_b1fd:
    ; TODO: lift real code/data for C1:E89F..C1:E8BE
    ; Computes `DP0E = 0x2C * AD9B + 4 * B1FD`. Uses the already-locked `C90B` 16-bit multiply helper. This is the exact packet-slot offset calcul

; C1:E8C0..C1:E8E0 [strong] pass 73
ct_c1_compute_ad9c_packet_offset_from_ad9b_and_b18b:
    ; TODO: lift real code/data for C1:E8C0..C1:E8E0
    ; Computes `DP10 = 0x2C * AD9B + 4 * B18B`. Companion packet-slot offset calculator using `B18B` instead of `B1FD`.

; C1:EBF8..C1:EC38 [strong] pass 73
ct_c1_queue_signed_pending_stat_delta_packet_into_b328_family:
    ; TODO: lift real code/data for C1:EBF8..C1:EC38
    ; Mirrors `B202 -> B203` and negates `AD89` when `B202.bit7` is set. Computes a 4-byte packet slot offset from `B2C7` and the `0x2C` record st

; C1:EC39..C1:EC7E [strong] pass 73
ct_c1_clear_nonpersistent_pending_stat_delta_channels:
    ; TODO: lift real code/data for C1:EC39..C1:EC7E
    ; Scans the three parallel packet families rooted at `B328`, `B354`, and `B380`. If none of the corresponding flag bytes carry bit `0x20`, cle

; C1:EC7F..C1:ED87 [strong] pass 73
ct_c1_apply_pending_stat_delta_channels_and_clamp_lane_currents:
    ; TODO: lift real code/data for C1:EC7F..C1:ED87
    ; Calls the non-persistent channel clearer first. Applies queued signed packet amounts into `5E30/5E32` for the primary current/cap pair. Appl

; C1:FB06..C1:FB2C [provisional] pass 55
ct_c1_rebuild_head_battle_slot_occupant_maps_with_extra_guard:
    ; TODO: lift real code/data for C1:FB06..C1:FB2C
    ; Same structural model as `FD:B24D..B27E`. Extra exclusion via `A09B[X]` is proven. Final caller-facing subsystem name still wants one more p

; C1:FDBF [strong] pass 52
ct_c1_jsl_mul_u16_dp28_dp2a_to_dp2c_lowword:
    ; TODO: lift real code/data for C1:FDBF
    ; Thin long-call wrapper: `JSR $C90B` `RTL` Useful because the seed families call it twice with different inputs.

