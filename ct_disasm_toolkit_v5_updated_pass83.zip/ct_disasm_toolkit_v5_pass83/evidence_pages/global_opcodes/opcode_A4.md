# Global Opcode A4

- Status: **strong structural**
- Dispatch address: **C1:B003**
- Evidence pass: **72**
- Notes: Internal alias that dispatches the current B239 opcode through the master table.

## Matching label evidence
- pass 72: `C1:B003..C1:B00D` **ct_global_opcode_A4_late_pack_executor_internal_alias_dispatch_current_b239_opcode** (strong)
  - Internal alias that dispatches the current `B239` opcode through the master table.
