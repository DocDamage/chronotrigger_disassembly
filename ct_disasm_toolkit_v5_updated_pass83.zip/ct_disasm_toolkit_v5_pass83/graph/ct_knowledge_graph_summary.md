# Knowledge Graph Summary

- Nodes: **938**
- Edges: **1286**

## Bank coverage from label graph
- `C1` -> **221** label-linked nodes
- `7E` -> **214** label-linked nodes
- `CD` -> **58** label-linked nodes
- `FD` -> **23** label-linked nodes
- `D1` -> **22** label-linked nodes
- `CC` -> **13** label-linked nodes
- `C0` -> **3** label-linked nodes
- `C3` -> **2** label-linked nodes
- `CF` -> **1** label-linked nodes
- `D0` -> **1** label-linked nodes

## Runtime-confirmed addresses
- none yet

## Strong current graph take
- The graph is now good enough to tie pass evidence, bank ownership, master opcode coverage, and imported runtime proof together in one place.

