; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_C1
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; C1:011B  top-status=strong  labels=1
; =============================================================================
; [strong] pass 49 :: ct_c1_lsr3_entry
; qualifier: strong
; notes: Mid-routine entry into the `LSR` helper band. Executes exactly three `LSR A` operations before `RTS`. Corrects pass 48’s earlier loose `>> 8` interpretation.
; source: chrono_trigger_labels_pass49.md
C1_011B_ct_c1_lsr3_entry:
    ; TODO: reconstruct body / data for C1:011B

; =============================================================================
; C1:011F  top-status=strong  labels=1
; =============================================================================
; [strong] pass 48 :: ct_c1_format_u16_as_three_decimal_tile_bytes_949d_949f
; qualifier: strong
; notes: Uses `9499` as the numeric working input. Repeatedly subtracts `0x64` and `0x0A` to derive hundreds/tens/ones. Maps those digits through `CC:F903`. Emits tile bytes to `949D`, `949E`, `949F` and sets `949C = 0xFF`.
; source: chrono_trigger_labels_pass48.md
C1_011F_ct_c1_format_u16_as_three_decimal_tile_bytes_949d_949f:
    ; TODO: reconstruct body / data for C1:011F

; =============================================================================
; C1:0174  top-status=strong  labels=1
; =============================================================================
; [strong] pass 48 :: ct_c1_format_u16_as_two_decimal_tile_bytes_949e_949f
; qualifier: strong
; notes: Repeatedly subtracts `0x0A` to derive tens and ones. Maps through `CC:F903`. Emits tile bytes to `949E`, `949F` and blanks `949C`, `949D` with `0xFF`.
; source: chrono_trigger_labels_pass48.md
C1_0174_ct_c1_format_u16_as_two_decimal_tile_bytes_949e_949f:
    ; TODO: reconstruct body / data for C1:0174

; =============================================================================
; C1:0299  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 49 :: ct_c1_rebuild_full_companion_strip_0cc0
; qualifier: strengthened
; notes: Pass 47 proved this was the full strip rebuild entry. Pass 48 proved it contained rendered numeric fields. Pass 49 tightens the three dynamic fields inside it to: current HP max HP current MP (still slightly more conservative than the HP pair) The routine is now best understood as a per-lane status-field strip rebuild path, not a generic glyph mixer.
; source: chrono_trigger_labels_pass49.md
C1_0299_ct_c1_rebuild_full_companion_strip_0cc0:
    ; TODO: reconstruct body / data for C1:0299

; =============================================================================
; C1:06F0  top-status=strong  labels=3
; =============================================================================
; [strong] pass 47 :: ct_c1_render_scaled_lane_bar_into_0cc0
; qualifier: strong
; notes: Uses `FA35[lane] + 0x1A` as the bar anchor. Scales per-lane state through the hardware divide helper at `C1:00D7`. Emits repeated `67` / `6F` glyphs and a partial tail tile into `0CC0`. Strongest safe reading: render a segmented bar/meter into the lane strip.
; source: chrono_trigger_labels_pass47.md
C1_06F0_ct_c1_render_scaled_lane_bar_into_0cc0:
    ; TODO: reconstruct body / data for C1:06F0

; [unspecified] pass 51 :: ct_c1_render_lane_active_time_gauge_into_0cc0
; qualifier: strengthened
; notes: Pass 50 already tied it to the readiness gauge. Pass 51 tightens the exact consumed pair to: current fill = `99DD` goal/cap = `9F22` The human-facing readiness-gauge name holds and the math-side split is now much cleaner.
; source: chrono_trigger_labels_pass51.md
C1_06F0_ct_c1_render_lane_active_time_gauge_into_0cc0:
    ; TODO: reconstruct body / data for C1:06F0

; [unspecified] pass 50 :: old wording “render scaled lane bar into 0CC0”             [replaced]
; notes: Too generic after pass 50. The ROM now supports a materially harder gameplay-facing reading: active-time/readiness gauge renderer.
; source: chrono_trigger_labels_pass50.md
C1_06F0_old_wording_render_scaled_lane_bar_into_0CC0_replaced:
    ; TODO: reconstruct body / data for C1:06F0

; =============================================================================
; C1:07BD  top-status=strong  labels=1
; =============================================================================
; [strong] pass 46 :: ct_c1_blit_companion_strip_template_a_into_0cc0_pair29
; qualifier: strong
; notes: Outer loop = 6 rows. Inner loop = 7 source bytes per row. Reads from `CC:FA41`. Writes source byte to `0CC0+Y`, then constant `0x29` to `0CC1+Y`. Row stride = `0x40` bytes.
; source: chrono_trigger_labels_pass46.md
C1_07BD_ct_c1_blit_companion_strip_template_a_into_0cc0_pair29:
    ; TODO: reconstruct body / data for C1:07BD

; =============================================================================
; C1:07EE  top-status=strong  labels=1
; =============================================================================
; [strong] pass 46 :: ct_c1_blit_companion_strip_template_b_into_0cc0_pair29
; qualifier: strong
; notes: Same loop shape as `C1:07BD`. Reads from `CC:FA6B` instead of `CC:FA41`. Writes the same paired-byte pattern into the `0CC0` family.
; source: chrono_trigger_labels_pass46.md
C1_07EE_ct_c1_blit_companion_strip_template_b_into_0cc0_pair29:
    ; TODO: reconstruct body / data for C1:07EE

; =============================================================================
; C1:07FD  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 46 :: ct_c1_compose_three_slot_panel_strip_into_0b40
; qualifier: withdrawn as exact entry
; notes: Pass 45 used `07FD` as a broad anchor for the panel-strip composer. Pass 46 tightens the true entry to `C1:081F`. The earlier structural reading of the composer remains valid; the entry boundary was just too broad.
; source: chrono_trigger_labels_pass46.md
C1_07FD_ct_c1_compose_three_slot_panel_strip_into_0b40:
    ; TODO: reconstruct body / data for C1:07FD

; =============================================================================
; C1:081F  top-status=strong  labels=1
; =============================================================================
; [strong] pass 46 :: ct_c1_compose_three_slot_panel_strip_into_0b40
; qualifier: strong
; notes: Corrected entry boundary for the pass-45 panel-strip composer. Begins with `STZ $84`, checks `A6D9/A6DA/A6DB`, selects destination offsets in `$82`, This is the actual `0B40` three-slot strip composer entry.
; source: chrono_trigger_labels_pass46.md
C1_081F_ct_c1_compose_three_slot_panel_strip_into_0b40:
    ; TODO: reconstruct body / data for C1:081F

; =============================================================================
; C1:086D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 46 :: ct_c1_clear_current_companion_strip_slice_0cc0
; qualifier: strong
; notes: Uses `95D5` to select a local slice. Clears two adjacent columns across six rows inside the `0CC0` companion strip family. Strongest safe reading: clear the current slice in the paired-byte companion strip.
; source: chrono_trigger_labels_pass46.md
C1_086D_ct_c1_clear_current_companion_strip_slice_0cc0:
    ; TODO: reconstruct body / data for C1:086D

; =============================================================================
; C1:08E8  top-status=strong  labels=2
; =============================================================================
; [strong] pass 46 :: ct_c1_update_current_companion_strip_slice
; qualifier: strong
; notes: Writes back into the same `0CC0 / 0D00` companion-strip family after slice clear. Uses selector tables rooted at `CC:FA23`, `CC:FA29`, and `CC:FADD`. Exact human-facing meaning still open, but the slice-local update role is strong.
; source: chrono_trigger_labels_pass46.md
C1_08E8_ct_c1_update_current_companion_strip_slice:
    ; TODO: reconstruct body / data for C1:08E8

; [unspecified] pass 47 :: ct_c1_fill_current_companion_strip_slice_from_anchor_table
; qualifier: strengthened
; notes: Pass 46 proved this was a slice-local `0CC0` update helper. Pass 47 tightens that role: it selects an anchor from `FA23` or `FA29` then fills five positions with `0x29` This is more specific than the earlier generic “update current slice” wording.
; source: chrono_trigger_labels_pass47.md
C1_08E8_ct_c1_fill_current_companion_strip_slice_from_anchor_table:
    ; TODO: reconstruct body / data for C1:08E8

; =============================================================================
; C1:0929  top-status=strong  labels=1
; =============================================================================
; [strong] pass 45 :: ct_c1_blit_6row_panel_segment_into_0b40_merge_left_border
; qualifier: strong
; notes: Dynamic `0B40` patcher using source data from `D1:59FC`. Writes 6 rows with a destination stride of `0x40` bytes per row. Copies either: 7 words per row (full segment), or 6 words per row after skipping the first source word (merge mode) Strongest safe reading: blits a 6-row panel segment into `0B40`, optionally omitting
; source: chrono_trigger_labels_pass45.md
C1_0929_ct_c1_blit_6row_panel_segment_into_0b40_merge_left_border:
    ; TODO: reconstruct body / data for C1:0929

; =============================================================================
; C1:0958  top-status=strong  labels=1
; =============================================================================
; [strong] pass 46 :: ct_c1_rebuild_companion_record_buffer_0e80
; qualifier: strong
; notes: Clears exactly `0x0180` bytes at `0E80+Y`. Then enters a 3-iteration build loop calling `C1:09B0`. Strongest safe reading: rebuild a full-size companion record buffer.
; source: chrono_trigger_labels_pass46.md
C1_0958_ct_c1_rebuild_companion_record_buffer_0e80:
    ; TODO: reconstruct body / data for C1:0958

; =============================================================================
; C1:09B0  top-status=strong  labels=1
; =============================================================================
; [strong] pass 46 :: ct_c1_emit_fixed_format_companion_record
; qualifier: strong
; notes: Checks the `C1:1580` per-entry control table. Copies 11 bytes from `CC:94A0` to `0B5E + 11*index` using `MVN`. Emits additional paired bytes into `0E86/0EC6` style regions with companion byte `0x2D`. Strongest safe reading: emit a fixed-format companion record.
; source: chrono_trigger_labels_pass46.md
C1_09B0_ct_c1_emit_fixed_format_companion_record:
    ; TODO: reconstruct body / data for C1:09B0

; =============================================================================
; C1:104E  top-status=strong  labels=1
; =============================================================================
; [strong] pass 48 :: ct_c1_blank_leading_zero_decimal_tiles_949d_949e
; qualifier: strong
; notes: Converts tile `0x73` at `949D` to `0xFF`. Converts tile `0x73` at `949E` to `0xFF` only when `949D` is already blank. This is a leading-zero suppression helper over the decimal tile buffer.
; source: chrono_trigger_labels_pass48.md
C1_104E_ct_c1_blank_leading_zero_decimal_tiles_949d_949e:
    ; TODO: reconstruct body / data for C1:104E

; =============================================================================
; C1:1918  top-status=strong  labels=1
; =============================================================================
; [strong] pass 47 :: ct_c1_refresh_current_0e80_lane_marker_glyphs
; qualifier: strong
; notes: Clears the old marker block selected by `991F`. Stamps the current marker block selected by `95E5`. Writes `60/61/62/63` plus companion `29` bytes into `0E80/0EC0`. Strongest safe reading: refresh the current lane marker glyphs inside the `0E80` companion-record region.
; source: chrono_trigger_labels_pass47.md
C1_1918_ct_c1_refresh_current_0e80_lane_marker_glyphs:
    ; TODO: reconstruct body / data for C1:1918

; =============================================================================
; C1:1B19  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_service1_enqueue_lane_and_mark_record_active
; qualifier: strong
; notes: Local service-1 entry for the 3-lane controller. If the current lane is not already active in `A6D9[x]`, maps it through `CC:FAF0`,
; source: chrono_trigger_labels_pass43.md
C1_1B19_ct_c1_service1_enqueue_lane_and_mark_record_active:
    ; TODO: reconstruct body / data for C1:1B19

; =============================================================================
; C1:1B69  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_promote_pending_lane_into_active_roster
; qualifier: strong
; notes: Pulls the head of the pending lane queue at `95D6` into the active roster. Clears `9F38[lane]`, seeds small per-lane state bytes, stores the lane into
; source: chrono_trigger_labels_pass43.md
C1_1B69_ct_c1_promote_pending_lane_into_active_roster:
    ; TODO: reconstruct body / data for C1:1B69

; =============================================================================
; C1:1BAA  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_service2_remove_lane_and_reseat_active_controller
; qualifier: strong
; notes: Local service-2 entry for the same 3-lane controller. Deletes the input lane from either: the pending-admission queue (`95D6..95D8`), or the active roster (`A6D9` / `A6DE`) If the removed lane was the current active lane (`A6DD`), also clears/reseats
; source: chrono_trigger_labels_pass43.md
C1_1BAA_ct_c1_service2_remove_lane_and_reseat_active_controller:
    ; TODO: reconstruct body / data for C1:1BAA

; =============================================================================
; C1:1C3A  top-status=strong  labels=2
; =============================================================================
; [strong] pass 44 :: ct_c1_service2_restore_default_tilemap_template_0b40
; qualifier: strong
; notes: Strengthened from pass 43. No longer just “restore workspace template.” Specifically restores the default `0x180`-byte tilemap/upload template from `D1:5800`
; source: chrono_trigger_labels_pass44.md
C1_1C3A_ct_c1_service2_restore_default_tilemap_template_0b40:
    ; TODO: reconstruct body / data for C1:1C3A

; [strong] pass 43 :: ct_c1_service2_restore_workspace_template_0b40
; qualifier: strong
; notes: Common tail reached from service 2. Copies `0x180` bytes from `D1:5800` into WRAM rooted at `0B40`. Exact high-level meaning of the workspace is still open, but the template-restore
; source: chrono_trigger_labels_pass43.md
C1_1C3A_ct_c1_service2_restore_workspace_template_0b40:
    ; TODO: reconstruct body / data for C1:1C3A

; =============================================================================
; C1:2BBC  top-status=strong  labels=1
; =============================================================================
; [strong] pass 65 :: relation-query mode `05`
; qualifier: strong structural support
; notes: Absolute Y-delta test over `1D23`. Leaves `9872 = 00` when `abs(subject_y - arg_y) < 0x20`. Leaves `9872 = FF` otherwise.
; source: chrono_trigger_labels_pass65.md
C1_2BBC_relation_query_mode_05:
    ; TODO: reconstruct body / data for C1:2BBC

; =============================================================================
; C1:2BDA  top-status=strong  labels=1
; =============================================================================
; [strong] pass 65 :: relation-query mode `06`
; qualifier: strong structural support
; notes: Vertical ordering test over `1D23`. Leaves `9872 = 00` when `subject_y < arg_y`. Leaves `9872 = FF` otherwise.
; source: chrono_trigger_labels_pass65.md
C1_2BDA_relation_query_mode_06:
    ; TODO: reconstruct body / data for C1:2BDA

; =============================================================================
; C1:2CA7  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 65 :: / C1:2CBA / C1:2CCD / C1:2CE0   relation-query modes `09..0C`   [strong structural support]
; notes: These are coarse row/column band predicates over the current subject slot. `09/0A` use `1D23 >> 4`. `0B/0C` use `1D0C >> 4`.  Do not keep describing opcode `0E` as a fixed mode-`06` wrapper. It is parameterized by operand `+2`. Do not keep extending the relation-query family through opcode `12`. That overstates the shared structure. `11/12` are direct record gates. Opcode `10` is now stronger than “mode picker” wording; it is a real current-subject row/column band gate.
; source: chrono_trigger_labels_pass65.md
C1_2CA7_C1_2CBA_C1_2CCD_C1_2CE0_relation_query_modes_09_0C_strong_structural_support:
    ; TODO: reconstruct body / data for C1:2CA7

; =============================================================================
; C1:2CF3  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 66 :: relation-query mode `0E` body
; qualifier: strengthened context
; notes: This mode is no longer best imagined as a trivial boolean compare. The body pulls projected position pairs from `1D0C/1D23`, computes two subject-relative squared-distance-like values, differences them, normalizes the result through `0116`, and returns a value through `9873`. That is why opcode `1F` should stay “mode-0E wrapper” rather than a fake-final gameplay noun.
; source: chrono_trigger_labels_pass66.md
C1_2CF3_relation_query_mode_0E_body:
    ; TODO: reconstruct body / data for C1:2CF3
    ; known span hint: C1:2CF3..C1:2D80

; =============================================================================
; C1:431D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 76 :: ct_c1_service04_mode_dispatcher_by_ae92
; qualifier: strong
; notes: Loads `AE92`, clamps any value `>= 4` to mode `0`, then dispatches through the jump table at `C1:7A63`. Proven table entries: mode `0` -> `475A` mode `1` -> `432C` mode `2` -> `45A0` mode `3` -> `475B` This is the real local mode dispatcher behind service `04`.
; source: chrono_trigger_labels_pass76.md
C1_431D_ct_c1_service04_mode_dispatcher_by_ae92:
    ; TODO: reconstruct body / data for C1:431D
    ; known span hint: C1:431D..C1:432A

; =============================================================================
; C1:432C  top-status=strong  labels=1
; =============================================================================
; [strong] pass 76 :: ct_c1_service04_mode1_load_current_context_profiles_by_source_slot_and_run_common_emit_tail
; qualifier: strong structural
; notes: Mode-1 front end reached when `AE92 = 1`. Splits immediately on `AE91 < 3` vs `AE91 >= 3`. Head-slot branch uses transformed slot state plus parallel bank-`CD` table families around `4000/4007/400E` and `4015/401A/401F`. Tail-slot branch reduces `AE91 - 3`, uses `9853[tail_local]`, and loads tail-family profiles from `CD:4926...` or `CD:4F26...` depending on `AE93`. Both branches populate the `9877 / 987A / 987B / 987E / 9881 / 9884` working neighborhood and converge into `4833`. Strongest safe reading: service-04 mode-1 current-context profile loader/emitter front end.
; source: chrono_trigger_labels_pass76.md
C1_432C_ct_c1_service04_mode1_load_current_context_profiles_by_source_slot_and_run_common_emit_t:
    ; TODO: reconstruct body / data for C1:432C
    ; known span hint: C1:432C..C1:459F

; =============================================================================
; C1:45A0  top-status=strong  labels=1
; =============================================================================
; [strong] pass 76 :: ct_c1_service04_mode2_load_fixed_followup_profiles_by_source_slot_and_run_common_emit_tail
; qualifier: strong structural
; notes: Mode-2 front end reached when `AE92 = 2`. This is the exact service-04 mode used by `895B`, and therefore by the fixed-`7F` follow-up path already proved in passes 74–75. Head-slot branch loads a 7-byte record from `CD:45A6 + 7*AE93` into the `9877..9884` working bytes plus `987C`. Tail-slot branch loads the matching 7-byte record family from `CD:5526 + 7*AE93`. Both branches converge into `4833` after the shared bank-`D1/CD/CE` derivation chain. Strongest safe reading: service-04 mode-2 fixed-follow-up profile loader/emitter front end.
; source: chrono_trigger_labels_pass76.md
C1_45A0_ct_c1_service04_mode2_load_fixed_followup_profiles_by_source_slot_and_run_common_emit_ta:
    ; TODO: reconstruct body / data for C1:45A0
    ; known span hint: C1:45A0..C1:4758

; =============================================================================
; C1:475A  top-status=strong  labels=1
; =============================================================================
; [strong] pass 77 :: ct_c1_service04_mode0_noop_rts
; qualifier: strong
; notes: Exact body is only `RTS`. This is the true mode-`0` target behind the `431D` service-04 dispatcher. Any `AE92 >= 4` fallback therefore collapses to no-op service-04 behavior.
; source: chrono_trigger_labels_pass77.md
C1_475A_ct_c1_service04_mode0_noop_rts:
    ; TODO: reconstruct body / data for C1:475A

; =============================================================================
; C1:475B  top-status=strong  labels=1
; =============================================================================
; [strong] pass 77 :: ct_c1_service04_mode3_load_high_range_fixed_followup_profiles_and_run_common_emit_tail
; qualifier: strong structural
; notes: Computes `X = 7 * (AE93 - 0xBC)`. Loads a 7-byte profile record from `CD:5C26 + 7*(AE93 - 0xBC)` into the same working-byte family used by mode `2`: `9877 / 987A / 987B / 987E / 9881 / 9884 / 987C`. Runs the same shared derivation chain and falls into the common `4833` runner. Strongest safe reading: service-04 mode-3 high-range fixed-follow-up profile-loader front end.
; source: chrono_trigger_labels_pass77.md
C1_475B_ct_c1_service04_mode3_load_high_range_fixed_followup_profiles_and_run_common_emit_tail:
    ; TODO: reconstruct body / data for C1:475B
    ; known span hint: C1:475B..C1:4832

; =============================================================================
; C1:4833  top-status=strong  labels=1
; =============================================================================
; [strong] pass 77 :: ct_c1_service04_common_output_materialization_and_emit_finalize_runner
; qualifier: strong correction
; notes: Pass 76 already pinned this as the shared convergence tail for active service-04 modes. Pass 77 corrects one important detail: the `5D00..` output family is indexed by `JSR 0112`, and `0112 = ASL; ASL; ASL; RTS`, so the loop seeds **16 output slots at 8-byte stride**, not 6-byte records. The loop clears bytes `+0/+1`, seeds bytes `+2/+3` from the `D1:50A2 / D1:50A3` family, and marks `A07B[slot] = 1`.
; source: chrono_trigger_labels_pass77.md
C1_4833_ct_c1_service04_common_output_materialization_and_emit_finalize_runner:
    ; TODO: reconstruct body / data for C1:4833
    ; known span hint: C1:4833..C1:48E7

; =============================================================================
; C1:48EC  top-status=strong  labels=2
; =============================================================================
; [strong] pass 77 :: ct_c1_service04_parse_segmented_ce_fragment_group_stream_into_a280_starts_and_a2a0_counts
; qualifier: strong structural
; notes: Seeds `A280[0] = 9885`, clears local counters, then parses control classes from the top bits of the `CE:0000,X` stream. `0x00..0x1F` high-bit class ends the stream. Negative/high-bit tokens open new groups and seed their first counted 4-byte unit. `0x20`-class tokens commit a zero count to `A2A0[current_group]`. `0x40/0x60`-class tokens commit the accumulated 4-byte-unit count to `A2A0[current_group]`. Builds up to `0x10` group start pointers in `A280` and per-group counts in `A2A0`. Strongest safe reading: segmented CE fragment-group stream parser.
; source: chrono_trigger_labels_pass77.md
C1_48EC_ct_c1_service04_parse_segmented_ce_fragment_group_stream_into_a280_starts_and_a2a0_count:
    ; TODO: reconstruct body / data for C1:48EC
    ; known span hint: C1:48EC..C1:493F

; [provisional] pass 76 :: ct_c1_service04_parse_ce_profile_stream_into_a280_a2a0_work_vectors
; qualifier: provisional strengthened
; notes: Consumes `9885` as the source index. Walks a bank-`CE` byte stream and partitions entries into the `A280..` and `A2A0..` work-vector families. This is clearly a service-04-local stream/parser helper for the shared output tail, not unrelated scratch logic.
; source: chrono_trigger_labels_pass76.md
C1_48EC_ct_c1_service04_parse_ce_profile_stream_into_a280_a2a0_work_vectors:
    ; TODO: reconstruct body / data for C1:48EC
    ; known span hint: C1:48EC..C1:493F

; =============================================================================
; C1:4943  top-status=strong  labels=2
; =============================================================================
; [strong] pass 77 :: ct_c1_service04_decode_one_packed_fragment_batch_into_a2d3_and_a450_quad_workspace
; qualifier: strong structural
; notes: Uses `A650` to choose the current output-row base through `CC:F7C0`. Uses `A652` as the current cursor into the packed `2D00..` stream. Splits the initial control byte into high/low nibble controls, copies the low-nibble-count compact bytes into `A2D3..`, then conditionally emits 4-byte records into the `4500..` workspace when shifted `A2D3` bytes carry out. Uses `CC:F820` lookup bytes while building those 4-byte records. Increments `A05B[current_row]` for each emitted record. Runs four internal subpasses per call before returning. Strongest safe reading: packed fragment/quad batch decoder into the service-04 working output workspace.
; source: chrono_trigger_labels_pass77.md
C1_4943_ct_c1_service04_decode_one_packed_fragment_batch_into_a2d3_and_a450_quad_workspace:
    ; TODO: reconstruct body / data for C1:4943
    ; known span hint: C1:4943..C1:49FD

; [provisional] pass 76 :: ct_c1_service04_build_one_output_record_batch_into_a2d3_and_a45x_workspace
; qualifier: provisional strengthened
; notes: Consumed exactly eight times from the shared `4833` runner. Builds one intermediate output batch into the `A2D3..` / `4500..` workspace neighborhood before final emission into `5D00..`. Final emitted-object noun still needs one more pass, so the label stays structural.
; source: chrono_trigger_labels_pass76.md
C1_4943_ct_c1_service04_build_one_output_record_batch_into_a2d3_and_a45x_workspace:
    ; TODO: reconstruct body / data for C1:4943
    ; known span hint: C1:4943..C1:49FD

; =============================================================================
; C1:8461  top-status=strong  labels=3
; =============================================================================
; [strong] pass 73 :: ct_global_opcode_9C_service7_tail_lane_admission_reseat_and_readiness_refresh_controller
; qualifier: strong structural
; notes: Walks the tail-lane band through `B315/B252/B18B` and the `B179/B163` mapping. Services eligible occupied tail lanes, invoking `8CF9` to run the tail selector-control/materialization stream. On the follow-up path mirrors `B158 -> AFAB`, applies `BD6F` readiness modifiers, and sets `B03A = 1`. Then runs canonical/head-visible reconciliation and readiness-gauge export refresh through helpers such as `B575` and `B725`. Strongest safe reading: service-7 tail-lane admission/reseat plus readiness-refresh controller.
; source: chrono_trigger_labels_pass73.md
C1_8461_ct_global_opcode_9C_service7_tail_lane_admission_reseat_and_readiness_refresh_controller:
    ; TODO: reconstruct body / data for C1:8461
    ; known span hint: C1:8461..C1:883B

; [strong] pass 73 :: ct_service7_tail_lane_admission_reseat_and_readiness_refresh_controller
; qualifier: strong structural
; notes: Local selector-control ownership of global `9C`. Carries the same upgraded reading: outer controller for eligible tail-lane admission/reseat, readiness-shadow refresh, and downstream canonical/head-visible reconciliation.  the fourth byte in each 4-byte packet record remains unresolved here the final gameplay-facing noun of the `5E34/5E36` pair is still slightly below fully frozen `8CF9` is now structurally strong, but some continuation/result fields like `B242` and `AE55` still want a tighter pass
; source: chrono_trigger_labels_pass73.md
C1_8461_ct_service7_tail_lane_admission_reseat_and_readiness_refresh_controller:
    ; TODO: reconstruct body / data for C1:8461
    ; known span hint: C1:8461..C1:883B

; [strong] pass 72 :: ct_global_opcode_9C_service7_lane_controller_and_active_time_update
; qualifier: provisional structural
; notes: Large lane/service controller, not a tiny wrapper. Clears controller scratch, iterates lane-related state through the `B179/B163` mapping, checks occupancy/readiness bytes and lane-block state, and calls already-known service/readiness helpers like `BD6F`, `B575`, and `B725`. Writes readiness/active-time style state such as `B03A`. Final gameplay-facing noun intentionally left open until the helper chain around `8CF9 / B923 / BCE1 / B223` is decoded more tightly.
; source: chrono_trigger_labels_pass72.md
C1_8461_ct_global_opcode_9C_service7_lane_controller_and_active_time_update:
    ; TODO: reconstruct body / data for C1:8461
    ; known span hint: C1:8461..C1:8625

; =============================================================================
; C1:8876  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_90_update_lane_afb6_b045_and_release_5E4B_bit7_on_expiry
; qualifier: strong structural
; notes: Uses `B179[0]` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `AFB6[lane] = 1` and copies `B0D4[lane] -> AF27[lane]`. Decrements `B045[lane]` and reloads it to `0x0A` on expiry. Clears `5E4B + lane*0x80` bit `0x80` and clears `AFB6[lane]` when the countdown expires.
; source: chrono_trigger_labels_pass72.md
C1_8876_ct_global_opcode_90_update_lane_afb6_b045_and_release_5E4B_bit7_on_expiry:
    ; TODO: reconstruct body / data for C1:8876
    ; known span hint: C1:8876..C1:88C4

; =============================================================================
; C1:88C5  top-status=strong  labels=2
; =============================================================================
; [strong] pass 74 :: ct_global_opcode_91_compute_scaled_lane_delta_queue_live_packet_and_run_followup_7f_tail
; qualifier: strong structural
; notes: Uses `B179[1]` or `AEC7` through the `B163` lane mapping. Requires `5E4A.bit7` set and `5E4B.bit6` clear for the packet path. Sets `AFC1[lane] = 1` and `AF32[lane] = B0DF[lane] + 5E64[lane_block]`. Computes a scaled amount through `5E32/33`, a `5E64`-derived scale, and `C92A`. Mirrors that amount into transient packet workspace at `AD9C[offset]` with mode `3` in `AD9E[offset]`. Clears `B202`, queues the live packet through `EBF8`, then runs `A=0x7F ; JSR 895B ; JSL FD:ACEE`. Strongest safe reading: scaled lane-derived dual-path packet caller with shared `7F` follow-up/apply tail.
; source: chrono_trigger_labels_pass74.md
C1_88C5_ct_global_opcode_91_compute_scaled_lane_delta_queue_live_packet_and_run_followup_7f_tail:
    ; TODO: reconstruct body / data for C1:88C5
    ; known span hint: C1:88C5..C1:8974

; [strong] pass 72 :: ct_global_opcode_91_conditionally_seed_afc1_af32_and_ad9c_from_lane_geometry
; qualifier: strong structural
; notes: Uses `B179[1]` or fallback `AEC7`, then maps through `B163` to a lane ID. Requires `5E4A.bit7` set and `5E4B.bit6` clear for the helper path. Sets `AFC1[lane] = 1`, computes `AF32[lane] = B0DF[lane] + 5E64[lane_block]`. Seeds `AD9C/AD9E` and runs the `EBF8` helper chain. Clears `B186` with `AND #$17FF` before return.
; source: chrono_trigger_labels_pass72.md
C1_88C5_ct_global_opcode_91_conditionally_seed_afc1_af32_and_ad9c_from_lane_geometry:
    ; TODO: reconstruct body / data for C1:88C5
    ; known span hint: C1:88C5..C1:8974

; =============================================================================
; C1:895B  top-status=strong  labels=1
; =============================================================================
; [strong] pass 74 :: ct_c1_seed_fixed_followup_context_from_a_and_run_ac57_tail
; qualifier: strong structural
; notes: Copies incoming `A` into `AE93`. Seeds fixed context bytes: `AE91 = 0`, `AE92 = 2`, `AE94 = 0`, `AE95 = 0`, `AE96 = 0x80`. Runs `JSR AC57` and returns. Used by both globals `91` and `99` with `A = 0x7F`.
; source: chrono_trigger_labels_pass74.md
C1_895B_ct_c1_seed_fixed_followup_context_from_a_and_run_ac57_tail:
    ; TODO: reconstruct body / data for C1:895B
    ; known span hint: C1:895B..C1:8974

; =============================================================================
; C1:8975  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_92_update_lane_afcc_b05b_and_clear_afcc_on_expiry
; qualifier: strong structural
; notes: Uses `B17B` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `AFCC[lane] = 1` and copies `B0EA[lane] -> AF3D[lane]`. Decrements `B05B[lane]` and reloads it to `0x0A` on expiry. Clears `AFCC[lane]` when the countdown expires.
; source: chrono_trigger_labels_pass72.md
C1_8975_ct_global_opcode_92_update_lane_afcc_b05b_and_clear_afcc_on_expiry:
    ; TODO: reconstruct body / data for C1:8975
    ; known span hint: C1:8975..C1:89B8

; =============================================================================
; C1:89B9  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_93_update_lane_afd7_b066_and_release_5E4D_bit7_on_expiry
; qualifier: strong structural
; notes: Uses `B17C` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `AFD7[lane] = 1` and copies `B0F5[lane] -> AF48[lane]`. Decrements `B066[lane]` and reloads it to `0x0A` on expiry. Clears `5E4D + lane*0x80` bit `0x80` and clears `AFD7[lane]` on expiry.
; source: chrono_trigger_labels_pass72.md
C1_89B9_ct_global_opcode_93_update_lane_afd7_b066_and_release_5E4D_bit7_on_expiry:
    ; TODO: reconstruct body / data for C1:89B9
    ; known span hint: C1:89B9..C1:8A04

; =============================================================================
; C1:8A05  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_94_update_lane_afe2_b071_and_release_5E4D_bit6_on_expiry
; qualifier: strong structural
; notes: Uses `B17D` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `AFE2[lane] = 1` and copies `B100[lane] -> AF53[lane]`. Decrements `B071[lane]` and reloads it to `0x0A` on expiry. Clears `5E4D + lane*0x80` bit `0x40` and clears `AFE2[lane]` on expiry.
; source: chrono_trigger_labels_pass72.md
C1_8A05_ct_global_opcode_94_update_lane_afe2_b071_and_release_5E4D_bit6_on_expiry:
    ; TODO: reconstruct body / data for C1:8A05
    ; known span hint: C1:8A05..C1:8A50

; =============================================================================
; C1:8A51  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_95_update_lane_afed_b07c_and_release_5E4E_bit6_on_expiry
; qualifier: strong structural
; notes: Uses `B17E` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `AFED[lane] = 1` and copies `B10B[lane] -> AF5E[lane]`. Decrements `B07C[lane]` and reloads it to `0x0A` on expiry. Clears `5E4E + lane*0x80` bit `0x40` and clears `AFED[lane]` on expiry.
; source: chrono_trigger_labels_pass72.md
C1_8A51_ct_global_opcode_95_update_lane_afed_b07c_and_release_5E4E_bit6_on_expiry:
    ; TODO: reconstruct body / data for C1:8A51
    ; known span hint: C1:8A51..C1:8A9C

; =============================================================================
; C1:8A9D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_96_rts_alias
; qualifier: strong
; notes: Exact `RTS` entry.
; source: chrono_trigger_labels_pass72.md
C1_8A9D_ct_global_opcode_96_rts_alias:
    ; TODO: reconstruct body / data for C1:8A9D

; =============================================================================
; C1:8A9E  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_97_rts_alias
; qualifier: strong
; notes: Exact `RTS` entry.
; source: chrono_trigger_labels_pass72.md
C1_8A9E_ct_global_opcode_97_rts_alias:
    ; TODO: reconstruct body / data for C1:8A9E

; =============================================================================
; C1:8A9F  top-status=strong  labels=2
; =============================================================================
; [strong] pass 74 :: ct_global_opcode_98_capture_lane_b12c_variant_into_af7f_and_optionally_apply_one_point_primary_delta
; qualifier: strong structural
; notes: Uses `B179[8]` or `AEC7` through the `B163` lane mapping. Captures `B12C[lane] -> AF7F[lane]` with status-based halve/double transforms. When `5E4B.bit4` is set, seeds `AD89 = 1`, `B1FD = lane`, `B202 = 0`, then runs `EBF8 -> EC7F` directly. Because the packet is primary-route and unsigned, this is the direct one-point primary-stat decrement fast path.
; source: chrono_trigger_labels_pass74.md
C1_8A9F_ct_global_opcode_98_capture_lane_b12c_variant_into_af7f_and_optionally_apply_one_point_p:
    ; TODO: reconstruct body / data for C1:8A9F
    ; known span hint: C1:8A9F..C1:8B0F

; [strong] pass 72 :: ct_global_opcode_98_capture_lane_b12c_variant_into_af7f_and_optionally_run_ec7f
; qualifier: strong structural
; notes: Uses `B179[8]` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `B00E[lane] = 1` and copies `B12C[lane] -> AF7F[lane]`. Applies status-based halve/double transforms from lane-block flags. Clears `B186` with `AND #$1FEF`. Optionally runs the `EBF8 -> EC7F` helper chain when `5E4B.bit4` is set.
; source: chrono_trigger_labels_pass72.md
C1_8A9F_ct_global_opcode_98_capture_lane_b12c_variant_into_af7f_and_optionally_run_ec7f:
    ; TODO: reconstruct body / data for C1:8A9F
    ; known span hint: C1:8A9F..C1:8B0F

; =============================================================================
; C1:8B10  top-status=strong  labels=2
; =============================================================================
; [strong] pass 74 :: ct_global_opcode_99_update_lane_b019_b0a8_and_on_expiry_queue_secondary_plus5_packet_with_followup_7f_tail
; qualifier: strong structural
; notes: Uses `B179[9]` or `AEC7` through the `B163` lane mapping. Updates `B019/AF8A/B0A8` on the mapped lane with the already-proved timer front end. On expiry and lane/block gate success, seeds `AD89 = 5`, `B1FD = lane`, mirrors the amount into transient packet workspace mode `2`, sets `B202 = 0xC0`, then runs `EBF8`. The `0xC0` flag byte gives the queued live packet signed-negate + secondary-route behavior. Finishes through `A=0x7F ; JSR 895B ; JSL FD:ACEE`. Strongest safe reading: timed secondary-route packet caller with the same shared `7F` follow-up/apply tail used by global `91`.
; source: chrono_trigger_labels_pass74.md
C1_8B10_ct_global_opcode_99_update_lane_b019_b0a8_and_on_expiry_queue_secondary_plus5_packet_wit:
    ; TODO: reconstruct body / data for C1:8B10
    ; known span hint: C1:8B10..C1:8BB8

; [strong] pass 72 :: ct_global_opcode_99_update_lane_b019_b0a8_and_on_expiry_conditionally_seed_ad9c
; qualifier: strong structural
; notes: Uses `B179[9]` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `B019[lane] = 1` and copies `B137[lane] -> AF8A[lane]`. Applies status-based halve/double transforms from lane-block flags. Decrements `B0A8[lane]`. On expiry, conditionally seeds `AD9C/AD9E` through the helper chain when the lane-block gates allow it.
; source: chrono_trigger_labels_pass72.md
C1_8B10_ct_global_opcode_99_update_lane_b019_b0a8_and_on_expiry_conditionally_seed_ad9c:
    ; TODO: reconstruct body / data for C1:8B10
    ; known span hint: C1:8B10..C1:8BB8

; =============================================================================
; C1:8BB9  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_9A_update_lane_b024_b0b3_and_release_5E4E_bit2_on_expiry
; qualifier: strong structural
; notes: Uses `B179[0x0A]` or fallback `AEC7`, then maps through `B163` to a lane ID. Sets `B024[lane] = 1` and copies `B142[lane] -> AF95[lane]`. Decrements `B0B3[lane]` and reloads it to `0x0A` on expiry. Clears `5E4E + lane*0x80` bit `0x04` and clears `B024[lane]` on expiry.
; source: chrono_trigger_labels_pass72.md
C1_8BB9_ct_global_opcode_9A_update_lane_b024_b0b3_and_release_5E4E_bit2_on_expiry:
    ; TODO: reconstruct body / data for C1:8BB9
    ; known span hint: C1:8BB9..C1:8C07

; =============================================================================
; C1:8C08  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_9B_rts_alias
; qualifier: strong
; notes: Exact `RTS` entry.
; source: chrono_trigger_labels_pass72.md
C1_8C08_ct_global_opcode_9B_rts_alias:
    ; TODO: reconstruct body / data for C1:8C08

; =============================================================================
; C1:8C0A  top-status=strong  labels=2
; =============================================================================
; [strong] pass 61 :: ct_replay_tail_pack_segments_and_record_per_tail_state
; qualifier: strong structural
; notes: Front-end clears/rebuilds per-tail replay state for the live, unwithheld tail map. Records executed global opcode bytes into `ct_tail_last_executed_global_opcode_bytes`. Records result/status bytes into `B24A[x]`. Records whether additional FE-delimited work remains into `B263[x]`. Advances/resumes execution from later CC bytes after segment completion. Proven to resume through the group-1 dispatch slice when the next resumed byte is non-negative.
; source: chrono_trigger_labels_pass61.md
C1_8C0A_ct_replay_tail_pack_segments_and_record_per_tail_state:
    ; TODO: reconstruct body / data for C1:8C0A
    ; known span hint: C1:8C0A..C1:8CF7

; [strong] pass 57 :: ct_iterate_live_unwithheld_tail_entries_for_dispatch
; qualifier: strong
; notes: Consumes tail entries only when: `AF15.bit7` is clear `AF02[x] != FF` `B2B6[x] == 0` Passes the live occupant ID in `AF02[x]` to `AFD2`. Confirms withheld entries are excluded from normal live-tail dispatch.
; source: chrono_trigger_labels_pass57.md
C1_8C0A_ct_iterate_live_unwithheld_tail_entries_for_dispatch:
    ; TODO: reconstruct body / data for C1:8C0A
    ; known span hint: C1:8C0A..C1:8C37

; =============================================================================
; C1:8CF9  top-status=strong  labels=1
; =============================================================================
; [strong] pass 73 :: ct_c1_run_tail_lane_selector_control_stream_and_materialize_head_state
; qualifier: strong structural
; notes: Initializes current-tail context from `AEC8`, `B252`, and `B18B` and clears selection/result scratch. Chooses the command-stream pointer from the saved per-tail pointer pair `B1D4/B1E4` or the continuation pointer in `B273`. Fetches the current `CC` byte into `AEE3` and dispatches through the selector-control table at `B88D`. Uses `AD8E/AECC/AECB/AE91` and visible-head vacancy scans to materialize or update head-slot assignment/state. Maintains saved continuation state such as `B1D4`, `B2C0`, and `AE55`.
; source: chrono_trigger_labels_pass73.md
C1_8CF9_ct_c1_run_tail_lane_selector_control_stream_and_materialize_head_state:
    ; TODO: reconstruct body / data for C1:8CF9
    ; known span hint: C1:8CF9..C1:8EA6

; =============================================================================
; C1:8EA7  top-status=strong  labels=1
; =============================================================================
; [strong] pass 62 :: ct_global_opcode_00_unconditional_tail_replay_step
; qualifier: strong
; notes: Direct body is only: `JSR $8C3E ; RTS`. Global opcode `00` is therefore an unconditional handoff into the tail replay/controller layer. This is a master-table opcode mapping, not a standalone subsystem root.
; source: chrono_trigger_labels_pass62.md
C1_8EA7_ct_global_opcode_00_unconditional_tail_replay_step:
    ; TODO: reconstruct body / data for C1:8EA7
    ; known span hint: C1:8EA7..C1:8EAA

; =============================================================================
; C1:8EAB  top-status=strong  labels=1
; =============================================================================
; [strong] pass 63 :: ct_global_opcode_01_filter_selected_entries_by_fd_record_threshold
; qualifier: strong structural
; notes: Calls `AC14`, so operand `+1` is an inline selector-control byte. Uses the resulting `AECC/AECB` selected list as input. For each selected entry: resolves a structured-record base via `FD:A80B` requires record byte `+1D` to be non-negative accepts only when record byte `+3` is less than or equal to `(record byte +5) >> 1` Accepted entries are incremented in-place in `AECC`. Writes accepted-count back to `AECB`. Runs `AE21`, then if `AF24 == 0` runs `AEFD` and `8C3E`. Empty input selection does **not** force `AF24 = 1`. Best carried as a selector-driven filtered-list transform, not a pure boolean gate.
; source: chrono_trigger_labels_pass63.md
C1_8EAB_ct_global_opcode_01_filter_selected_entries_by_fd_record_threshold:
    ; TODO: reconstruct body / data for C1:8EAB
    ; known span hint: C1:8EAB..C1:8F10

; =============================================================================
; C1:8F11  top-status=strong  labels=1
; =============================================================================
; [strong] pass 63 :: ct_global_opcode_02_filter_head_or_nonhead_selected_entries_by_lane_flag_mask
; qualifier: strong structural
; notes: Operand `+1` chooses which fixed selector-control byte is dispatched through `AC2C`: operand1 `== 0` -> selector-control `0x01` -> visible/head occupied entries (`A3F7`) operand1 `!= 0` -> selector-control `0x16` -> non-head occupied entries (`A6ED`) Operands `+2/+3` are used as: byte offset inside the lane block required bitmask For each selected entry: reads `5E4A + selected_entry*0x80 + operand2` accepts only when `(byte & operand3) == operand3` Accepted entries are incremented in-place in `AECC`. Zero survivors -> `AF24 = 1`. Successful survivors finalize through `AE21`, `AEFD`, and `8C3E`.
; source: chrono_trigger_labels_pass63.md
C1_8F11_ct_global_opcode_02_filter_head_or_nonhead_selected_entries_by_lane_flag_mask:
    ; TODO: reconstruct body / data for C1:8F11
    ; known span hint: C1:8F11..C1:8F81

; =============================================================================
; C1:8F87  top-status=strong  labels=1
; =============================================================================
; [strong] pass 63 :: ct_global_opcode_03_filter_selected_entries_by_occupant_index_equals_immediate
; qualifier: strong structural
; notes: Calls `AC14`, so operand `+1` is an arbitrary inline selector-control byte. Requires a non-empty selected list from `AECC/AECB`. Consumes the next immediate byte and accepts only selected entries where: `AEFF[selected_entry] == immediate` Accepted entries are incremented in-place in `AECC`. Zero survivors -> `AF24 = 1`. Successful survivors finalize through `AE21`, `AEFD`, and `8C3E`. Strong structural sibling to opcode `02`, but using arbitrary `AC14` selection plus occupant-equality filtering.
; source: chrono_trigger_labels_pass63.md
C1_8F87_ct_global_opcode_03_filter_selected_entries_by_occupant_index_equals_immediate:
    ; TODO: reconstruct body / data for C1:8F87
    ; known span hint: C1:8F87..C1:8FD9

; =============================================================================
; C1:8FDA  top-status=strong  labels=1
; =============================================================================
; [strong] pass 63 :: ct_global_opcode_04_gate_tail_replay_on_live_tail_occupant_presence_mode
; qualifier: strong
; notes: Scans live tail occupant map `AF02[0..AEC6-1]` for operand1. Operand2 selects the sense: operand2 `== 0` -> success only when operand1 is present operand2 `!= 0` -> success only when operand1 is absent Success -> `JSR $8C3E` Failure -> `AF24 = 1` This is the corrected master-table meaning of global opcode `04`.
; source: chrono_trigger_labels_pass63.md
C1_8FDA_ct_global_opcode_04_gate_tail_replay_on_live_tail_occupant_presence_mode:
    ; TODO: reconstruct body / data for C1:8FDA
    ; known span hint: C1:8FDA..C1:9012

; =============================================================================
; C1:9012  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 57 :: ct_gate_tail_dispatch_by_live_unwithheld_count
; qualifier: provisional
; notes: Counts tail entries where: `AF02[x] != FF` `AF15[x] == 0` Compares that count against a descriptor byte from `CC:[B1D2 + 1]`. Dispatches to `8C3E` on one compare outcome; otherwise sets `AF24 = 1`. The exact human-facing noun for the descriptor byte remains open, so this should stay provisional.
; source: chrono_trigger_labels_pass57.md
C1_9012_ct_gate_tail_dispatch_by_live_unwithheld_count:
    ; TODO: reconstruct body / data for C1:9012
    ; known span hint: C1:9012..C1:9043

; =============================================================================
; C1:9013  top-status=strong  labels=1
; =============================================================================
; [strong] pass 62 :: ct_global_opcode_05_gate_tail_replay_by_live_unwithheld_tail_count_max
; qualifier: strong
; notes: Reads one immediate operand byte from `CC:[B1D2 + 1]`. Counts tail entries where: `AF02[x] != FF` and `AF15[x] == 0` Success path is taken when the resulting count is **less than or equal to** the immediate operand. Success -> `JSR $8C3E` Failure -> `AF24 = 1` This strengthens the old pass-57 count gate by pinning the compare direction.
; source: chrono_trigger_labels_pass62.md
C1_9013_ct_global_opcode_05_gate_tail_replay_by_live_unwithheld_tail_count_max:
    ; TODO: reconstruct body / data for C1:9013
    ; known span hint: C1:9013..C1:9043

; =============================================================================
; C1:9045  top-status=strong  labels=1
; =============================================================================
; [strong] pass 62 :: ct_global_opcode_06_gate_tail_replay_when_96f1_96f3_triplet_gte_immediate
; qualifier: strong structural
; notes: Reads a 3-byte immediate operand from `CC:[B1D2 + 1..3]`. Compares that operand lexicographically against current WRAM bytes: `96F1` `96F2` `96F3` Success when current triplet >= immediate triplet. Success -> `JSR $8C3E` Failure -> `AF24 = 1` Gameplay-facing noun for `96F1..96F3` remains intentionally open.
; source: chrono_trigger_labels_pass62.md
C1_9045_ct_global_opcode_06_gate_tail_replay_when_96f1_96f3_triplet_gte_immediate:
    ; TODO: reconstruct body / data for C1:9045
    ; known span hint: C1:9045..C1:9081

; =============================================================================
; C1:9082  top-status=strong  labels=1
; =============================================================================
; [strong] pass 62 :: ct_global_opcode_07_gate_tail_replay_on_current_b320_compare_mode
; qualifier: strong structural
; notes: Reads compare byte from `CC:[B1D2 + 1]` and mode byte from `CC:[B1D2 + 2]`. Uses current slot index `B252` to read `B320[B252]`. Proven compare modes: mode `!= 1` -> success when `B320[current] >= operand1` mode `== 1` -> success when `B320[current] <= operand1` Success -> `JSR $8C3E` Failure -> `AF24 = 1` Final gameplay-facing noun for `B320[x]` still wants more caller proof.
; source: chrono_trigger_labels_pass62.md
C1_9082_ct_global_opcode_07_gate_tail_replay_on_current_b320_compare_mode:
    ; TODO: reconstruct body / data for C1:9082
    ; known span hint: C1:9082..C1:90BD

; =============================================================================
; C1:90BE  top-status=strong  labels=1
; =============================================================================
; [strong] pass 64 :: ct_global_opcode_08_mark_selected_entries_by_fd_record_word3_le_immediate_then_reduce
; qualifier: strong structural
; notes: Calls `AC14`. Empty selection -> failure. Reads a 16-bit immediate threshold. For each selected entry: resolves the `FD:A80B` record base reads the 16-bit field at record offset `+3` marks the entry in `AECC` with bit 7 when `record_word_+3 <= immediate_word` Stores the number of marked entries in `AECB`. Then calls `AE21`, `AEFD`, and `8C3E` on success.
; source: chrono_trigger_labels_pass64.md
C1_90BE_ct_global_opcode_08_mark_selected_entries_by_fd_record_word3_le_immediate_then_reduce:
    ; TODO: reconstruct body / data for C1:90BE
    ; known span hint: C1:90BE..C1:912F

; =============================================================================
; C1:9130  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 64 :: ct_global_opcode_09_scan_selected_entries_for_fd_record_byte_offset_gte_immediate_then_reduce
; qualifier: provisional structural
; notes: Calls `AC14`. Empty selection -> failure. Operand `+1` is a byte offset inside the `FD:A80B` record. Operand `+2` is the compare byte. Scans the selected entries and breaks to `AE21` on the first entry where: `record_byte >= immediate` Fails if the scan completes with no hit. This body does **not** mark `AECC` entries itself before calling `AE21`, so the precise final selected-entry effect should remain open.
; source: chrono_trigger_labels_pass64.md
C1_9130_ct_global_opcode_09_scan_selected_entries_for_fd_record_byte_offset_gte_immediate_then_r:
    ; TODO: reconstruct body / data for C1:9130
    ; known span hint: C1:9130..C1:918D

; =============================================================================
; C1:918E  top-status=strong  labels=1
; =============================================================================
; [strong] pass 64 :: ct_global_opcode_0A_gate_tail_replay_on_priority_selected_entry_record_mask_clear
; qualifier: strong structural
; notes: Calls `AC14`. Empty selection -> failure. If only one entry is selected, uses it directly. If multiple entries are selected, reduces them to one chosen entry using WRAM vector `B23A[0..7]`. Operand `+1` is a record-byte offset. Operand `+2` is an immediate mask. Succeeds only when the chosen entry's `FD:A80B` record byte at that offset has no overlapping bits with the mask. Success goes directly to `8C3E`. Failure sets `AF24 = 1`.
; source: chrono_trigger_labels_pass64.md
C1_918E_ct_global_opcode_0A_gate_tail_replay_on_priority_selected_entry_record_mask_clear:
    ; TODO: reconstruct body / data for C1:918E
    ; known span hint: C1:918E..C1:91F8

; =============================================================================
; C1:91F9  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 64 :: ct_global_opcode_0B_scan_selected_entries_for_fd_record_byte_offset_lte_immediate_then_reduce
; qualifier: provisional structural
; notes: Calls `AC14`. Empty selection -> failure. Operand `+1` is a byte offset inside the `FD:A80B` record. Operand `+2` is the compare byte. Scans the selected entries and breaks to `AE21` on the first entry where: `record_byte <= immediate` Fails if the scan completes with no hit. Like opcode `09`, this body does not mark `AECC` entries itself before `AE21`.
; source: chrono_trigger_labels_pass64.md
C1_91F9_ct_global_opcode_0B_scan_selected_entries_for_fd_record_byte_offset_lte_immediate_then_r:
    ; TODO: reconstruct body / data for C1:91F9
    ; known span hint: C1:91F9..C1:925C

; =============================================================================
; C1:925D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 65 :: ct_global_opcode_0C_gate_tail_replay_on_relation_mode04_current_subject_vs_selection_head
; qualifier: strong structural
; notes: Calls `AC14`. Empty selection -> `AF24 = 1`. Seeds relation-query mode `04` with: `986F = B252 + 3` `9870 = AECC[0]` Calls service `5` through `JSR $0003`. Operand `+1` selects the final zero/nonzero polarity of `9872`. Success writes `AECB = 1` and continues through `8C3E`.
; source: chrono_trigger_labels_pass65.md
C1_925D_ct_global_opcode_0C_gate_tail_replay_on_relation_mode04_current_subject_vs_selection_hea:
    ; TODO: reconstruct body / data for C1:925D
    ; known span hint: C1:925D..C1:92A2

; =============================================================================
; C1:92A3  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 65 :: ct_global_opcode_0D_mark_non_subject_selected_entries_by_relation_mode05_zero_then_reduce
; qualifier: provisional structural
; notes: Calls `AC14`. Sets current subject slot `986F = B252 + 3`. Uses relation-query mode `05`. Skips the subject slot if it appears in the selected list. Marks selected entries whose mode-`05` result leaves `9872 == 0`. Mode `05` is now known strongly enough to be the close-Y / `abs(subject_y - arg_y) < 0x20` predicate. Marked candidates are reduced through `AE21`. Final replay gate still depends on residual `9872` plus operand `+1`, so the top-level human-facing contract should stay provisional.
; source: chrono_trigger_labels_pass65.md
C1_92A3_ct_global_opcode_0D_mark_non_subject_selected_entries_by_relation_mode05_zero_then_reduc:
    ; TODO: reconstruct body / data for C1:92A3
    ; known span hint: C1:92A3..C1:9313

; =============================================================================
; C1:9314  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 65 :: ct_global_opcode_0E_mark_non_subject_selected_entries_by_parameterized_relation_mode_zero_then_reduce
; qualifier: provisional structural
; notes: Same structural family as `0D`. Seeds relation mode with `986E = operand2 + 0x06`. Skips the current subject slot. Marks selected entries whose query leaves `9872 == 0`. Reduces them through `AE21`. Final replay gate still depends on residual `9872` plus operand `+1`.
; source: chrono_trigger_labels_pass65.md
C1_9314_ct_global_opcode_0E_mark_non_subject_selected_entries_by_parameterized_relation_mode_zer:
    ; TODO: reconstruct body / data for C1:9314
    ; known span hint: C1:9314..C1:938C

; =============================================================================
; C1:938D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 65 :: ct_global_opcode_0F_gate_tail_replay_on_relation_mode08_current_subject_vs_selection_head
; qualifier: strong structural
; notes: Calls `AC14`. Empty selection -> `AF24 = 1`. Seeds relation-query mode `08` with: `986F = B252 + 3` `9870 = AECC[0]` `9871 = (operand2 << 2) | 1` Operand `+1` selects the final zero/nonzero polarity of `9872`. Success continues through `8C3E`. Pre-write `9872 = 05` is dead for normal service-5 flow because `2986` clears `9872` before dispatch.
; source: chrono_trigger_labels_pass65.md
C1_938D_ct_global_opcode_0F_gate_tail_replay_on_relation_mode08_current_subject_vs_selection_hea:
    ; TODO: reconstruct body / data for C1:938D
    ; known span hint: C1:938D..C1:93E5

; =============================================================================
; C1:93E6  top-status=strong  labels=1
; =============================================================================
; [strong] pass 65 :: ct_global_opcode_10_gate_tail_replay_on_current_subject_row_column_band_query
; qualifier: strong structural
; notes: Does not call `AC14`. Selects relation mode `09/0A/0B/0C` from operands `+2/+3`. Uses current subject slot `986F = B252 + 3`. Succeeds only when the chosen mode leaves `9872 == 0`. Effective success regions are: mode `09`: `Y>>4 >= 0x08` mode `0A`: `Y>>4 < 0x08` mode `0B`: `X>>4 >= 0x0B` mode `0C`: `X>>4 < 0x05`
; source: chrono_trigger_labels_pass65.md
C1_93E6_ct_global_opcode_10_gate_tail_replay_on_current_subject_row_column_band_query:
    ; TODO: reconstruct body / data for C1:93E6
    ; known span hint: C1:93E6..C1:9429

; =============================================================================
; C1:942A  top-status=strong  labels=1
; =============================================================================
; [strong] pass 65 :: ct_global_opcode_11_gate_tail_replay_on_current_b19e_upper_nibble_class
; qualifier: strong structural
; notes: Direct current-slot gate, not a relation-query wrapper. Computes `X = B252 * 4`. Reads `B19E[X] & 0xF0`. Operand `+1` selects target class `0x40` vs `0x50`. Operand `+3` selects equality vs inequality. Success continues through `8C3E`; failure sets `AF24 = 1`.
; source: chrono_trigger_labels_pass65.md
C1_942A_ct_global_opcode_11_gate_tail_replay_on_current_b19e_upper_nibble_class:
    ; TODO: reconstruct body / data for C1:942A
    ; known span hint: C1:942A..C1:9473

; =============================================================================
; C1:9474  top-status=strong  labels=1
; =============================================================================
; [strong] pass 65 :: ct_global_opcode_12_gate_tail_replay_on_current_b19e_b19f_pair_mode
; qualifier: strong structural
; notes: Direct current-slot gate, not a relation-query wrapper. Computes `X = B252 * 4`. Reads: `B19E[X] & 0xF0` `B19F[X]` Operand `+1` selects target high nibble `0x40` vs `0x50`. Operand `+2` selects exact second-byte compare value. Operand `+3 == 0` -> both comparisons must match. Operand `+3 != 0` -> both comparisons must differ.
; source: chrono_trigger_labels_pass65.md
C1_9474_ct_global_opcode_12_gate_tail_replay_on_current_b19e_b19f_pair_mode:
    ; TODO: reconstruct body / data for C1:9474
    ; known span hint: C1:9474..C1:94D1

; =============================================================================
; C1:94D2  top-status=strong  labels=1
; =============================================================================
; [strong] pass 66 :: ct_global_opcode_13_gate_tail_replay_on_current_b19e_bit4_match_mode
; qualifier: strong structural
; notes: Computes `X = B252 * 4`. Reads `B19E[X] & 0x10`. Operand `+1` bit `0` selects the target bit state (`0x00` vs `0x10`). Operand `+3` selects equality vs inequality. Success continues through `8C3E`; failure sets `AF24 = 1`.
; source: chrono_trigger_labels_pass66.md
C1_94D2_ct_global_opcode_13_gate_tail_replay_on_current_b19e_bit4_match_mode:
    ; TODO: reconstruct body / data for C1:94D2
    ; known span hint: C1:94D2..C1:9513

; =============================================================================
; C1:9514  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 66 :: ct_global_opcode_14_gate_tail_replay_on_current_b19e_bit4_clear_selector_mode
; qualifier: provisional structural
; notes: Two-form handler. In the primary form (`operand+2 == 0`): requires current `B19E[X]` bit 4 clear uses `B19E[X] & 0x0F` to index `AF0A[...]` compares that byte against operand `+1` operand `+3` selects equality vs inequality In the alternate form (`operand+2 != 0`): still requires current `B19E[X]` bit 4 clear then effectively collapses to: operand `+3 == 0` -> fail operand `+3 != 0` -> success The apparent `01/02/05` compare chain in the alternate branch should not be overclaimed as real content logic.
; source: chrono_trigger_labels_pass66.md
C1_9514_ct_global_opcode_14_gate_tail_replay_on_current_b19e_bit4_clear_selector_mode:
    ; TODO: reconstruct body / data for C1:9514
    ; known span hint: C1:9514..C1:9599

; =============================================================================
; C1:959A  top-status=strong  labels=1
; =============================================================================
; [strong] pass 66 :: ct_global_opcode_15_gate_tail_replay_on_current_b1a0_mask_match_mode
; qualifier: strong structural
; notes: Computes `X = B252 * 4`. Reads `B1A0[X]`. Operand `+1` is a required mask. Operand `+3 == 0` -> require full-mask containment. Operand `+3 != 0` -> require non-match.
; source: chrono_trigger_labels_pass66.md
C1_959A_ct_global_opcode_15_gate_tail_replay_on_current_b1a0_mask_match_mode:
    ; TODO: reconstruct body / data for C1:959A
    ; known span hint: C1:959A..C1:95D5

; =============================================================================
; C1:95D6  top-status=strong  labels=1
; =============================================================================
; [strong] pass 66 :: ct_global_opcode_16_unconditional_tail_replay_step_alias
; qualifier: strong
; notes: Exact alias of the unconditional `8C3E ; RTS` replay step.
; source: chrono_trigger_labels_pass66.md
C1_95D6_ct_global_opcode_16_unconditional_tail_replay_step_alias:
    ; TODO: reconstruct body / data for C1:95D6
    ; known span hint: C1:95D6..C1:95D9

; =============================================================================
; C1:95DA  top-status=strong  labels=1
; =============================================================================
; [strong] pass 66 :: ct_global_opcode_17_gate_tail_replay_on_rng_percent_below_immediate
; qualifier: strong structural
; notes: Calls the known RNG helper at `AF22` with `A = 0x64`. Succeeds only when the returned value is below operand `+1`.
; source: chrono_trigger_labels_pass66.md
C1_95DA_ct_global_opcode_17_gate_tail_replay_on_rng_percent_below_immediate:
    ; TODO: reconstruct body / data for C1:95DA
    ; known span hint: C1:95DA..C1:95F9

; =============================================================================
; C1:95FA  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 66 :: ct_global_opcode_18_reduce_selected_entries_by_indirect_table_byte_equals_immediate
; qualifier: provisional structural
; notes: Calls `AC14`. Scans selected entries in `AECC`. Resolves an `FD:A80B` record-rooted value and uses it as the `Y` component of `LDA ($0A),Y`. On equality with operand `+1`, reduces through `AE21`, then `AEFD`, then `8C3E`. Keep provisional because the base-pointer setup through `$0A/$0B` still wants harder confirmation. Important context: master opcodes `23..28` all alias back to this same body.
; source: chrono_trigger_labels_pass66.md
C1_95FA_ct_global_opcode_18_reduce_selected_entries_by_indirect_table_byte_equals_immediate:
    ; TODO: reconstruct body / data for C1:95FA
    ; known span hint: C1:95FA..C1:9651

; =============================================================================
; C1:9652  top-status=strong  labels=1
; =============================================================================
; [strong] pass 66 :: ct_global_opcode_19_unconditional_tail_replay_step_alias
; qualifier: strong
; notes: Exact alias of the unconditional `8C3E ; RTS` replay step.
; source: chrono_trigger_labels_pass66.md
C1_9652_ct_global_opcode_19_unconditional_tail_replay_step_alias:
    ; TODO: reconstruct body / data for C1:9652
    ; known span hint: C1:9652..C1:9655

; =============================================================================
; C1:9656  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 66 :: ct_global_opcode_1A_gate_tail_replay_on_live_tail_occupant_search_mode
; qualifier: strengthened structural
; notes: Scans the live-tail occupant submap `AF02[0..AEC6-1]` for operand `+1`. Dead leading `LDA $B252` should be ignored; the real scan starts from `X = 0`. Operand `+2` enables a mode that skips current-slot hits and requires another matching live-tail entry. Operand `+3` controls the final success gate once a usable match is found.
; source: chrono_trigger_labels_pass66.md
C1_9656_ct_global_opcode_1A_gate_tail_replay_on_live_tail_occupant_search_mode:
    ; TODO: reconstruct body / data for C1:9656
    ; known span hint: C1:9656..C1:96A4

; =============================================================================
; C1:96A5  top-status=strong  labels=1
; =============================================================================
; [strong] pass 66 :: ct_global_opcode_1B_gate_tail_replay_on_visible_head_live_count_at_or_below_immediate
; qualifier: strong structural
; notes: Counts non-`FF` entries in `AEFF[0..2]`. Uses `operand+1 + 1` internally, so the effective success predicate is: visible-head live count `<= operand+1`
; source: chrono_trigger_labels_pass66.md
C1_96A5_ct_global_opcode_1B_gate_tail_replay_on_visible_head_live_count_at_or_below_immediate:
    ; TODO: reconstruct body / data for C1:96A5
    ; known span hint: C1:96A5..C1:96D3

; =============================================================================
; C1:96D4  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 66 :: ct_global_opcode_1C_optionally_replay_on_selected_head_canonical_membership_then_abort
; qualifier: provisional structural
; notes: Calls `AC14`. Searches `AF0A[0..2]` for a byte equal to `AECC[0]`. Uses operand `+2` plus optional `AEFF[x] != FF` live-head confirmation to decide whether to call `8C3E`. Always exits with `AF24 = 1`, even after replay.
; source: chrono_trigger_labels_pass66.md
C1_96D4_ct_global_opcode_1C_optionally_replay_on_selected_head_canonical_membership_then_abort:
    ; TODO: reconstruct body / data for C1:96D4
    ; known span hint: C1:96D4..C1:9727

; =============================================================================
; C1:9728  top-status=strong  labels=1
; =============================================================================
; [strong] pass 66 :: ct_global_opcode_1D_gate_tail_replay_on_selected_tail_live_presence_mode
; qualifier: strong structural
; notes: Calls `AC14`. Uses `AECC[0]` as the selected entry index. Reads `AF02[selected]`. Operand `+2` selects presence vs absence polarity.
; source: chrono_trigger_labels_pass66.md
C1_9728_ct_global_opcode_1D_gate_tail_replay_on_selected_tail_live_presence_mode:
    ; TODO: reconstruct body / data for C1:9728
    ; known span hint: C1:9728..C1:975B

; =============================================================================
; C1:975C  top-status=strong  labels=1
; =============================================================================
; [strong] pass 66 :: ct_global_opcode_1E_unconditional_tail_replay_then_abort
; qualifier: strong structural
; notes: Always runs `8C3E`. Then always writes `AF24 = 1`.
; source: chrono_trigger_labels_pass66.md
C1_975C_ct_global_opcode_1E_unconditional_tail_replay_then_abort:
    ; TODO: reconstruct body / data for C1:975C
    ; known span hint: C1:975C..C1:9764

; =============================================================================
; C1:9765  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 66 :: ct_global_opcode_1F_gate_tail_replay_on_relation_mode0E_current_subject_vs_selection_head
; qualifier: strengthened structural
; notes: Calls `AC14`. Seeds relation-query mode `0E` with: `986F = B252 + 3` `9870 = AECC[0]` Operand `+1` selects the final zero/nonzero gate on `9872`. Success forces `AECB = 1` and continues through `8C3E`. Keep the wrapper label strong-structural, but do not pretend mode `0E`'s underlying noun is already frozen.
; source: chrono_trigger_labels_pass66.md
C1_9765_ct_global_opcode_1F_gate_tail_replay_on_relation_mode0E_current_subject_vs_selection_hea:
    ; TODO: reconstruct body / data for C1:9765
    ; known span hint: C1:9765..C1:97AA

; =============================================================================
; C1:97AB  top-status=strong  labels=1
; =============================================================================
; [strong] pass 62 :: ct_global_opcode_20_gate_tail_replay_on_current_aeb3_nonzero
; qualifier: strong structural
; notes: Uses current index `B252`. Reads `AEB3[B252]`. Success only when that byte is nonzero. Success -> `JSR $8C3E` Failure -> `AF24 = 1` Final gameplay-facing noun for `AEB3[x]` is still intentionally open.
; source: chrono_trigger_labels_pass62.md
C1_97AB_ct_global_opcode_20_gate_tail_replay_on_current_aeb3_nonzero:
    ; TODO: reconstruct body / data for C1:97AB
    ; known span hint: C1:97AB..C1:97BF

; =============================================================================
; C1:97C0  top-status=strong  labels=1
; =============================================================================
; [strong] pass 62 :: ct_global_opcode_21_gate_tail_replay_on_current_af15_zero
; qualifier: strong structural
; notes: Immediate adjacent sibling of opcode `20`. Uses current index `B252`. Success only when `AF15[B252] == 0`. Success -> `JSR $8C3E` Failure -> `AF24 = 1` Useful carry-forward proof that opcode `20` is part of a real replay-gate family.
; source: chrono_trigger_labels_pass62.md
C1_97C0_ct_global_opcode_21_gate_tail_replay_on_current_af15_zero:
    ; TODO: reconstruct body / data for C1:97C0
    ; known span hint: C1:97C0..C1:97D4

; =============================================================================
; C1:97D5  top-status=strong  labels=1
; =============================================================================
; [strong] pass 66 :: ct_global_opcode_22_gate_tail_replay_on_selected_b158_threshold_mode
; qualifier: strong structural
; notes: Calls `AC14`. Uses `AECC[0]` as the selected entry index. Reads `B158[selected]`. Operand `+1` is the threshold. Operand `+2 == 0` -> success on `< threshold` Operand `+2 != 0` -> success on `>= threshold`
; source: chrono_trigger_labels_pass66.md
C1_97D5_ct_global_opcode_22_gate_tail_replay_on_selected_b158_threshold_mode:
    ; TODO: reconstruct body / data for C1:97D5
    ; known span hint: C1:97D5..C1:980F

; =============================================================================
; C1:9810  top-status=strong  labels=1
; =============================================================================
; [strong] pass 67 :: ct_global_opcode_29_persist_selected_head_and_inline_param_to_current_5e15_5e0d
; qualifier: strong structural
; notes: Advances the stream, calls `AC14`, reads one inline byte, and stores: `AEE5 -> 5E0D[current]` `AECC[0] -> 5E15[current]` Strong bridge to later seeded group-2 opcode `01`.
; source: chrono_trigger_labels_pass67.md
C1_9810_ct_global_opcode_29_persist_selected_head_and_inline_param_to_current_5e15_5e0d:
    ; TODO: reconstruct body / data for C1:9810
    ; known span hint: C1:9810..C1:9839

; =============================================================================
; C1:983A  top-status=strong  labels=1
; =============================================================================
; [strong] pass 67 :: ct_global_opcode_2A_2B_ordered_first_choice_persist_shared_body
; qualifier: strong structural
; notes: Calls `AC14`. If multiple selected entries exist, collapses them to the first entry matching the external priority list in `B23A[0..7]`. Copies the chosen entry into `AECC[0]`. Then splits on `AEE3`: non-`2` path persists into `5E0D[current] / 5E15[current]` `2` path persists into `B16E[current]` Failure writes `B242[current] = FF` and `AF24 = 2`.
; source: chrono_trigger_labels_pass67.md
C1_983A_ct_global_opcode_2A_2B_ordered_first_choice_persist_shared_body:
    ; TODO: reconstruct body / data for C1:983A
    ; known span hint: C1:983A..C1:98C3

; =============================================================================
; C1:98C4  top-status=strong  labels=1
; =============================================================================
; [strong] pass 67 :: ct_global_opcode_2C_rts_noop_alias
; qualifier: strong
; notes: Exact single-byte `RTS`.
; source: chrono_trigger_labels_pass67.md
C1_98C4_ct_global_opcode_2C_rts_noop_alias:
    ; TODO: reconstruct body / data for C1:98C4

; =============================================================================
; C1:98C5  top-status=strong  labels=1
; =============================================================================
; [strong] pass 67 :: ct_global_opcode_2D_random_4way_stream_advance
; qualifier: strong
; notes: Promoted global-master ownership of the already-solved group-1 random 4-way stream-control body. Uses RNG split ranges and `FD:BA4A`-driven stream advance.
; source: chrono_trigger_labels_pass67.md
C1_98C5_ct_global_opcode_2D_random_4way_stream_advance:
    ; TODO: reconstruct body / data for C1:98C5
    ; known span hint: C1:98C5..C1:995F

; =============================================================================
; C1:9960  top-status=strong  labels=1
; =============================================================================
; [strong] pass 67 :: ct_global_opcode_2E_rts_noop_alias
; qualifier: strong
; notes: Exact single-byte `RTS`.
; source: chrono_trigger_labels_pass67.md
C1_9960_ct_global_opcode_2E_rts_noop_alias:
    ; TODO: reconstruct body / data for C1:9960

; =============================================================================
; C1:9961  top-status=strong  labels=1
; =============================================================================
; [strong] pass 67 :: ct_global_opcode_2F_rts_noop_alias
; qualifier: strong
; notes: Exact single-byte `RTS`.
; source: chrono_trigger_labels_pass67.md
C1_9961_ct_global_opcode_2F_rts_noop_alias:
    ; TODO: reconstruct body / data for C1:9961

; =============================================================================
; C1:9967  top-status=strong  labels=1
; =============================================================================
; [strong] pass 68 :: ct_global_opcode_32_capture_inline_param1_to_aee4
; qualifier: strong structural
; notes: Reads the current stream byte at `CC:[B1D2 + 1]`. Stores it into `AEE4`. Does not locally advance `B1D2`. Best current reading: tiny inline-parameter capture body for later follow-up state.
; source: chrono_trigger_labels_pass68.md
C1_9967_ct_global_opcode_32_capture_inline_param1_to_aee4:
    ; TODO: reconstruct body / data for C1:9967
    ; known span hint: C1:9967..C1:9977

; =============================================================================
; C1:9981  top-status=strong  labels=1
; =============================================================================
; [strong] pass 68 :: ct_global_opcode_39_3F_gate_on_materializable_canonical_tail_slot_exists
; qualifier: strong structural
; notes: Scans 8 tail slots. Accepts only when: `AF0D[x] != FF` `AF02[x] == FF` `AF15.bit7` clear Success clears `AF24`; zero accepted entries force `AF24 = 2`. Exact alias body for global opcodes `39` and `3F`.
; source: chrono_trigger_labels_pass68.md
C1_9981_ct_global_opcode_39_3F_gate_on_materializable_canonical_tail_slot_exists:
    ; TODO: reconstruct body / data for C1:9981
    ; known span hint: C1:9981..C1:99B3

; =============================================================================
; C1:99B8  top-status=strong  labels=1
; =============================================================================
; [strong] pass 68 :: ct_global_opcode_40_set_group2_continuation_2
; qualifier: strong
; notes: Writes `B3B8 = 2` and returns.
; source: chrono_trigger_labels_pass68.md
C1_99B8_ct_global_opcode_40_set_group2_continuation_2:
    ; TODO: reconstruct body / data for C1:99B8
    ; known span hint: C1:99B8..C1:99BD

; =============================================================================
; C1:99BE  top-status=strong  labels=1
; =============================================================================
; [strong] pass 68 :: ct_global_opcode_41_seed_single_from_5e15_finalize
; qualifier: strong structural
; notes: Promoted master ownership of the old group-2 `01` body. Seeds one entry from `5E15[current]`. Captures inline parameters into `AEE4/AEE5`. Uses unique long helper `FD:AB01`. Finalizes through `AC89/ACCE` with `B3B8 = 0`.
; source: chrono_trigger_labels_pass68.md
C1_99BE_ct_global_opcode_41_seed_single_from_5e15_finalize:
    ; TODO: reconstruct body / data for C1:99BE
    ; known span hint: C1:99BE..C1:9A38

; =============================================================================
; C1:9A39  top-status=strong  labels=1
; =============================================================================
; [strong] pass 68 :: ct_global_opcode_42_seed_from_b16e_validate_commit
; qualifier: strong structural
; notes: Table-entry wrapper lands in `9A3D`. Seeds one entry from `B16E[current]`. Optionally resolves inline selectors through `AC14`. Validates through `C1DD` and commits through `AD09/AD35/FDAAD2/AC89/ACCE`.
; source: chrono_trigger_labels_pass68.md
C1_9A39_ct_global_opcode_42_seed_from_b16e_validate_commit:
    ; TODO: reconstruct body / data for C1:9A39
    ; known span hint: C1:9A39..C1:9B45

; =============================================================================
; C1:9DCE  top-status=strong  labels=1
; =============================================================================
; [strong] pass 68 :: ct_global_opcode_4D_bitmask_state_control
; qualifier: strong
; notes: Promoted master ownership of the old group-2 `0D` state-control body. Operand bits drive a mix of per-slot and global control writes.
; source: chrono_trigger_labels_pass68.md
C1_9DCE_ct_global_opcode_4D_bitmask_state_control:
    ; TODO: reconstruct body / data for C1:9DCE
    ; known span hint: C1:9DCE..C1:9E61

; =============================================================================
; C1:9E63  top-status=strong  labels=1
; =============================================================================
; [strong] pass 68 :: ct_global_opcode_4F_optional_cd0033_then_set_continuation_2
; qualifier: strong
; notes: If operand 1 is nonzero, calls `JSL $CD0033`. Then writes `B3B8 = 2` and returns.
; source: chrono_trigger_labels_pass68.md
C1_9E63_ct_global_opcode_4F_optional_cd0033_then_set_continuation_2:
    ; TODO: reconstruct body / data for C1:9E63
    ; known span hint: C1:9E63..C1:9E77

; =============================================================================
; C1:9E78  top-status=strong  labels=2
; =============================================================================
; [strong] pass 68 :: ct_global_opcode_50_materialize_tail_slots_from_canonical_map_finalize
; qualifier: strong
; notes: Promoted master ownership of the old group-2 `10` body. Scans canonical/live/deferred tail state through `AF0D/AF02/AF15`. Builds selected entries and follow-up masks. Best current noun: materialize eligible tail slots from canonical map, then finalize.
; source: chrono_trigger_labels_pass68.md
C1_9E78_ct_global_opcode_50_materialize_tail_slots_from_canonical_map_finalize:
    ; TODO: reconstruct body / data for C1:9E78
    ; known span hint: C1:9E78..C1:9F59

; [unspecified] pass 56 :: ct_g2_cmd10_materialize_tail_slots_from_canonical_map
; qualifier: strengthened
; notes: Earlier passes already proved the scan gates: `AF0D[x] != FF` `AF02[x] == FF` `AF15.bit7` clear Pass 56 upgrades the noun: this command materializes live tail slots from the canonical tail map,
; source: chrono_trigger_labels_pass56.md
C1_9E78_ct_g2_cmd10_materialize_tail_slots_from_canonical_map:
    ; TODO: reconstruct body / data for C1:9E78

; =============================================================================
; C1:9F5A  top-status=strong  labels=1
; =============================================================================
; [strong] pass 68 :: ct_global_opcode_51_group_base_write4_pairs
; qualifier: strong
; notes: Promoted master ownership of the old group-2 `11` writer body.
; source: chrono_trigger_labels_pass68.md
C1_9F5A_ct_global_opcode_51_group_base_write4_pairs:
    ; TODO: reconstruct body / data for C1:9F5A
    ; known span hint: C1:9F5A..C1:9FD1

; =============================================================================
; C1:9FD2  top-status=strong  labels=1
; =============================================================================
; [strong] pass 68 :: ct_global_opcode_52_group_base_write5_pairs_validate
; qualifier: strong
; notes: Promoted master ownership of the old group-2 `12` writer-plus-validation body.
; source: chrono_trigger_labels_pass68.md
C1_9FD2_ct_global_opcode_52_group_base_write5_pairs_validate:
    ; TODO: reconstruct body / data for C1:9FD2
    ; known span hint: C1:9FD2..C1:A14D

; =============================================================================
; C1:A14E  top-status=strong  labels=1
; =============================================================================
; [strong] pass 68 :: ct_global_opcode_53_sat_signed_delta_to_current_b158
; qualifier: strong
; notes: Promoted master ownership of the old group-2 `13` saturating signed-delta body.
; source: chrono_trigger_labels_pass68.md
C1_A14E_ct_global_opcode_53_sat_signed_delta_to_current_b158:
    ; TODO: reconstruct body / data for C1:A14E
    ; known span hint: C1:A14E..C1:A187

; =============================================================================
; C1:A396  top-status=strong  labels=1
; =============================================================================
; [strong] pass 68 :: ct_global_opcode_56_wrapper_fused_fd_a990
; qualifier: strong
; notes: Promoted master ownership of the old group-2 `16` thin wrapper around `FD:A990`.
; source: chrono_trigger_labels_pass68.md
C1_A396_ct_global_opcode_56_wrapper_fused_fd_a990:
    ; TODO: reconstruct body / data for C1:A396
    ; known span hint: C1:A396..C1:A3D0

; =============================================================================
; C1:A3F6  top-status=strong  labels=1
; =============================================================================
; [strong] pass 69 :: ct_global_opcode_57_rts_noop_alias
; qualifier: strong
; notes: Exact single-byte RTS alias. First entry in the promoted selector-control master slice.
; source: chrono_trigger_labels_pass69.md
C1_A3F6_ct_global_opcode_57_rts_noop_alias:
    ; TODO: reconstruct body / data for C1:A3F6

; =============================================================================
; C1:A3F7  top-status=strong  labels=1
; =============================================================================
; [strong] pass 69 :: ct_global_opcode_58_select_visible_head_occupied_live_slots
; qualifier: strong structural
; notes: Scans `AEFF[0..2]`. Appends occupied visible-head live slot indices into `AECC`. Stores the resulting count in `AECB`.
; source: chrono_trigger_labels_pass69.md
C1_A3F7_ct_global_opcode_58_select_visible_head_occupied_live_slots:
    ; TODO: reconstruct body / data for C1:A3F7
    ; known span hint: C1:A3F7..C1:A410

; =============================================================================
; C1:A411  top-status=strong  labels=1
; =============================================================================
; [strong] pass 69 :: ct_global_opcode_59_select_all_occupied_live_slots
; qualifier: strong structural
; notes: Calls the `57/58`-band visible selector first. Then appends occupied live slots `3..10` from `AEFF`. Stores the final count in `AECB`.
; source: chrono_trigger_labels_pass69.md
C1_A411_ct_global_opcode_59_select_all_occupied_live_slots:
    ; TODO: reconstruct body / data for C1:A411
    ; known span hint: C1:A411..C1:A42D

; =============================================================================
; C1:A42E  top-status=strong  labels=1
; =============================================================================
; [strong] pass 69 :: ct_global_opcode_5A_select_current_tail_local_live_slot
; qualifier: strong structural
; notes: Writes `B252 + 3` into `AECC[0]`. Forces `AECB = 1`.
; source: chrono_trigger_labels_pass69.md
C1_A42E_ct_global_opcode_5A_select_current_tail_local_live_slot:
    ; TODO: reconstruct body / data for C1:A42E
    ; known span hint: C1:A42E..C1:A43C

; =============================================================================
; C1:A43D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 69 :: ct_global_opcode_5B_select_current_quad_record_low_nibble_entry
; qualifier: strong structural
; notes: Reads `B19E + 4*B252`. Masks to the low nibble. Stores that value into `AECC[0]`. Forces `AECB = 1`.
; source: chrono_trigger_labels_pass69.md
C1_A43D_ct_global_opcode_5B_select_current_quad_record_low_nibble_entry:
    ; TODO: reconstruct body / data for C1:A43D
    ; known span hint: C1:A43D..C1:A451

; =============================================================================
; C1:A452  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 69 :: ct_global_opcode_5C_select_random_visible_head_live_slot_after_optional_refresh
; qualifier: provisional structural
; notes: If DP scratch `$24` is zero, runs `B279` across visible entries `0..2` before the selection attempt. Then randomly chooses one occupied visible-head live slot. Exposes the chosen visible slot in `AECC[0]`. Leaves `AECB = 0` on failure. The exact higher-level noun of the `$24` gate still wants one more caller-context pass.
; source: chrono_trigger_labels_pass69.md
C1_A452_ct_global_opcode_5C_select_random_visible_head_live_slot_after_optional_refresh:
    ; TODO: reconstruct body / data for C1:A452
    ; known span hint: C1:A452..C1:A4AE

; =============================================================================
; C1:A4AF  top-status=strong  labels=1
; =============================================================================
; [strong] pass 69 :: ct_global_opcode_5D_select_target_relation_mode_00
; qualifier: strong structural
; notes: Promoted master/global ownership of the pass-30 relation-query target selector for mode `00`.
; source: chrono_trigger_labels_pass69.md
C1_A4AF_ct_global_opcode_5D_select_target_relation_mode_00:
    ; TODO: reconstruct body / data for C1:A4AF
    ; known span hint: C1:A4AF..C1:A4DF

; =============================================================================
; C1:A4E0  top-status=strong  labels=1
; =============================================================================
; [strong] pass 69 :: ct_global_opcode_5E_select_target_relation_mode_01
; qualifier: strong structural
; notes: Promoted master/global ownership of the pass-30 relation-query target selector for mode `01`.
; source: chrono_trigger_labels_pass69.md
C1_A4E0_ct_global_opcode_5E_select_target_relation_mode_01:
    ; TODO: reconstruct body / data for C1:A4E0
    ; known span hint: C1:A4E0..C1:A507

; =============================================================================
; C1:A508  top-status=strong  labels=1
; =============================================================================
; [strong] pass 69 :: ct_global_opcode_5F_select_one_visible_entry_0_1_2_by_min_current_hp
; qualifier: strong structural
; notes: Compares visible-head lane values at `5E30`, `5EB0`, and `5F30`. Selects exactly one visible entry index `0..2` with the minimum current-HP value. Stores that result into `AECC[0]`. Forces `AECB = 1`.
; source: chrono_trigger_labels_pass69.md
C1_A508_ct_global_opcode_5F_select_one_visible_entry_0_1_2_by_min_current_hp:
    ; TODO: reconstruct body / data for C1:A508
    ; known span hint: C1:A508..C1:A540

; =============================================================================
; C1:A541  top-status=strong  labels=1
; =============================================================================
; [strong] pass 70 :: ct_global_opcode_60_select_visible_entries_by_positive_fd_record_byte_1D
; qualifier: strong structural
; notes: Sets selector offset `0x1D`. Uses the shared visible FD-offset family at `AD68`. Practical contract: positive `record[+1D]`, then reduce.
; source: chrono_trigger_labels_pass70.md
C1_A541_ct_global_opcode_60_select_visible_entries_by_positive_fd_record_byte_1D:
    ; TODO: reconstruct body / data for C1:A541
    ; known span hint: C1:A541..C1:A54A

; =============================================================================
; C1:A54B  top-status=strong  labels=1
; =============================================================================
; [strong] pass 70 :: ct_global_opcode_61_select_visible_entries_by_nonzero_fd_record_byte_1E
; qualifier: strong structural
; notes: Sets selector offset `0x1E`. Uses the shared visible FD-offset family at `AD68`. Also inherits the shared nonnegative `record[+1D]` gate.
; source: chrono_trigger_labels_pass70.md
C1_A54B_ct_global_opcode_61_select_visible_entries_by_nonzero_fd_record_byte_1E:
    ; TODO: reconstruct body / data for C1:A54B
    ; known span hint: C1:A54B..C1:A554

; =============================================================================
; C1:A555  top-status=strong  labels=1
; =============================================================================
; [strong] pass 70 :: ct_global_opcode_62_select_visible_entries_by_nonzero_fd_record_byte_1F
; qualifier: strong structural
; notes: Sets selector offset `0x1F`. Uses the shared visible FD-offset family at `AD68`. Also inherits the shared nonnegative `record[+1D]` gate.
; source: chrono_trigger_labels_pass70.md
C1_A555_ct_global_opcode_62_select_visible_entries_by_nonzero_fd_record_byte_1F:
    ; TODO: reconstruct body / data for C1:A555
    ; known span hint: C1:A555..C1:A55E

; =============================================================================
; C1:A55F  top-status=strong  labels=1
; =============================================================================
; [strong] pass 70 :: ct_global_opcode_63_select_visible_entries_by_nonzero_fd_record_byte_20
; qualifier: strong structural
; notes: Sets selector offset `0x20`. Uses the shared visible FD-offset family at `AD68`. Also inherits the shared nonnegative `record[+1D]` gate.
; source: chrono_trigger_labels_pass70.md
C1_A55F_ct_global_opcode_63_select_visible_entries_by_nonzero_fd_record_byte_20:
    ; TODO: reconstruct body / data for C1:A55F
    ; known span hint: C1:A55F..C1:A568

; =============================================================================
; C1:A569  top-status=strong  labels=1
; =============================================================================
; [strong] pass 70 :: ct_global_opcode_64_select_visible_entries_by_nonzero_fd_record_byte_21
; qualifier: strong structural
; notes: Sets selector offset `0x21`. Uses the shared visible FD-offset family at `AD68`. Also inherits the shared nonnegative `record[+1D]` gate.
; source: chrono_trigger_labels_pass70.md
C1_A569_ct_global_opcode_64_select_visible_entries_by_nonzero_fd_record_byte_21:
    ; TODO: reconstruct body / data for C1:A569
    ; known span hint: C1:A569..C1:A572

; =============================================================================
; C1:A573  top-status=strong  labels=1
; =============================================================================
; [strong] pass 70 :: ct_global_opcode_65_select_visible_entries_by_fd_record_byte_1E_mask_02
; qualifier: strong structural
; notes: Uses the shared visible FD-offset/mask pipeline. Tests `record[+1E] & 0x02`. Also inherits the shared nonnegative `record[+1D]` gate.
; source: chrono_trigger_labels_pass70.md
C1_A573_ct_global_opcode_65_select_visible_entries_by_fd_record_byte_1E_mask_02:
    ; TODO: reconstruct body / data for C1:A573
    ; known span hint: C1:A573..C1:A5A2

; =============================================================================
; C1:A5A3  top-status=strong  labels=1
; =============================================================================
; [strong] pass 70 :: ct_global_opcode_66_select_visible_entries_by_fd_record_byte_1E_mask_80
; qualifier: strong structural
; notes: Uses the shared visible FD-offset/mask pipeline. Tests `record[+1E] & 0x80`. Also inherits the shared nonnegative `record[+1D]` gate.
; source: chrono_trigger_labels_pass70.md
C1_A5A3_ct_global_opcode_66_select_visible_entries_by_fd_record_byte_1E_mask_80:
    ; TODO: reconstruct body / data for C1:A5A3
    ; known span hint: C1:A5A3..C1:A5D2

; =============================================================================
; C1:A5D3  top-status=strong  labels=1
; =============================================================================
; [strong] pass 70 :: ct_global_opcode_67_select_visible_entries_by_fd_record_byte_1E_mask_04
; qualifier: strong structural
; notes: Uses the shared visible FD-offset/mask pipeline. Tests `record[+1E] & 0x04`. Also inherits the shared nonnegative `record[+1D]` gate.
; source: chrono_trigger_labels_pass70.md
C1_A5D3_ct_global_opcode_67_select_visible_entries_by_fd_record_byte_1E_mask_04:
    ; TODO: reconstruct body / data for C1:A5D3
    ; known span hint: C1:A5D3..C1:A602

; =============================================================================
; C1:A603  top-status=strong  labels=1
; =============================================================================
; [strong] pass 70 :: ct_global_opcode_68_select_visible_entries_by_fd_record_byte_21_mask_04
; qualifier: strong structural
; notes: Uses the shared visible FD-offset/mask pipeline. Tests `record[+21] & 0x04`. Also inherits the shared nonnegative `record[+1D]` gate.
; source: chrono_trigger_labels_pass70.md
C1_A603_ct_global_opcode_68_select_visible_entries_by_fd_record_byte_21_mask_04:
    ; TODO: reconstruct body / data for C1:A603
    ; known span hint: C1:A603..C1:A632

; =============================================================================
; C1:A633  top-status=strong  labels=1
; =============================================================================
; [strong] pass 70 :: ct_global_opcode_69_select_visible_entries_by_fd_record_byte_21_mask_40
; qualifier: strong structural
; notes: Uses the shared visible FD-offset/mask pipeline. Tests `record[+21] & 0x40`. Also inherits the shared nonnegative `record[+1D]` gate.
; source: chrono_trigger_labels_pass70.md
C1_A633_ct_global_opcode_69_select_visible_entries_by_fd_record_byte_21_mask_40:
    ; TODO: reconstruct body / data for C1:A633
    ; known span hint: C1:A633..C1:A662

; =============================================================================
; C1:A663  top-status=strong  labels=1
; =============================================================================
; [strong] pass 70 :: ct_global_opcode_6A_select_visible_entries_by_fd_record_byte_20_mask_10
; qualifier: strong structural
; notes: Uses the shared visible FD-offset/mask pipeline. Tests `record[+20] & 0x10`. Also inherits the shared nonnegative `record[+1D]` gate.
; source: chrono_trigger_labels_pass70.md
C1_A663_ct_global_opcode_6A_select_visible_entries_by_fd_record_byte_20_mask_10:
    ; TODO: reconstruct body / data for C1:A663
    ; known span hint: C1:A663..C1:A692

; =============================================================================
; C1:A693  top-status=strong  labels=1
; =============================================================================
; [strong] pass 70 :: ct_global_opcode_6B_select_visible_entries_by_fd_record_byte_01_mask_08
; qualifier: strong structural
; notes: Uses the shared visible FD-offset/mask pipeline. Tests `record[+01] & 0x08`. Also inherits the shared nonnegative `record[+1D]` gate.
; source: chrono_trigger_labels_pass70.md
C1_A693_ct_global_opcode_6B_select_visible_entries_by_fd_record_byte_01_mask_08:
    ; TODO: reconstruct body / data for C1:A693
    ; known span hint: C1:A693..C1:A6C2

; =============================================================================
; C1:A6C3  top-status=strong  labels=1
; =============================================================================
; [strong] pass 70 :: ct_global_opcode_6C_select_occupied_live_tail_slots_except_current
; qualifier: strong structural
; notes: Computes the current tail-local live slot as `B252 + 3`. Scans live slots `3..10`. Appends every occupied slot except that current one into `AECC`. Stores the resulting count in `AECB`.
; source: chrono_trigger_labels_pass70.md
C1_A6C3_ct_global_opcode_6C_select_occupied_live_tail_slots_except_current:
    ; TODO: reconstruct body / data for C1:A6C3
    ; known span hint: C1:A6C3..C1:A6EC

; =============================================================================
; C1:A6ED  top-status=strong  labels=1
; =============================================================================
; [strong] pass 69 :: ct_global_opcode_6D_select_nonhead_occupied_live_slots
; qualifier: strong structural
; notes: Scans `AEFF[3..10]`. Appends occupied non-head live slot indices into `AECC`. Stores the resulting count in `AECB`.
; source: chrono_trigger_labels_pass69.md
C1_A6ED_ct_global_opcode_6D_select_nonhead_occupied_live_slots:
    ; TODO: reconstruct body / data for C1:A6ED
    ; known span hint: C1:A6ED..C1:A708

; =============================================================================
; C1:A709  top-status=strong  labels=1
; =============================================================================
; [strong] pass 69 :: ct_global_opcode_6E_select_target_relation_mode_02
; qualifier: strong structural
; notes: Promoted master/global ownership of the pass-30 relation-query target selector for mode `02`.
; source: chrono_trigger_labels_pass69.md
C1_A709_ct_global_opcode_6E_select_target_relation_mode_02:
    ; TODO: reconstruct body / data for C1:A709
    ; known span hint: C1:A709..C1:A736

; =============================================================================
; C1:A737  top-status=strong  labels=1
; =============================================================================
; [strong] pass 69 :: ct_global_opcode_6F_select_target_relation_mode_03
; qualifier: strong structural
; notes: Promoted master/global ownership of the pass-30 relation-query target selector for mode `03`.
; source: chrono_trigger_labels_pass69.md
C1_A737_ct_global_opcode_6F_select_target_relation_mode_03:
    ; TODO: reconstruct body / data for C1:A737
    ; known span hint: C1:A737..C1:A764

; =============================================================================
; C1:A765  top-status=strong  labels=1
; =============================================================================
; [strong] pass 71 :: ct_global_opcode_70_select_one_nonhead_occupied_live_slot_by_min_nonzero_fd_record_word_03
; qualifier: strong structural
; notes: Scans occupied live slots `3..10`. Resolves each slot through `FD:A80B + slot*2`. Compares the 16-bit word at `record + 3`. Keeps the smallest nonzero value and stores the corresponding slot into `AECC[0]`. Forces `AECB = 1`.
; source: chrono_trigger_labels_pass71.md
C1_A765_ct_global_opcode_70_select_one_nonhead_occupied_live_slot_by_min_nonzero_fd_record_word_:
    ; TODO: reconstruct body / data for C1:A765
    ; known span hint: C1:A765..C1:A7A8

; =============================================================================
; C1:A7A9  top-status=strong  labels=1
; =============================================================================
; [strong] pass 71 :: ct_global_opcode_71_select_nonhead_occupied_live_slots_excluding_primary_seed_by_positive_fd_record_byte_1D
; qualifier: strong structural
; notes: Nonhead counterpart of the pass-70 visible FD-byte selector family. Scans live slots `3..10`. Skips the primary-seed slot indexed by `B18B`. Uses `AE70 -> ADA1` to select/reduce candidates.
; source: chrono_trigger_labels_pass71.md
C1_A7A9_ct_global_opcode_71_select_nonhead_occupied_live_slots_excluding_primary_seed_by_positiv:
    ; TODO: reconstruct body / data for C1:A7A9
    ; known span hint: C1:A7A9..C1:A7E4

; =============================================================================
; C1:A7E5  top-status=strong  labels=1
; =============================================================================
; [strong] pass 71 :: ct_global_opcode_72_select_nonhead_occupied_live_slots_by_positive_fd_record_byte_1D
; qualifier: strong structural
; notes: Nonhead counterpart of global `60`. Scans occupied live slots `3..10` through `AE70 -> ADA1`. No `B18B` exclusion.
; source: chrono_trigger_labels_pass71.md
C1_A7E5_ct_global_opcode_72_select_nonhead_occupied_live_slots_by_positive_fd_record_byte_1D:
    ; TODO: reconstruct body / data for C1:A7E5
    ; known span hint: C1:A7E5..C1:A818

; =============================================================================
; C1:A819  top-status=strong  labels=1
; =============================================================================
; [strong] pass 71 :: ct_global_opcode_73_select_nonhead_occupied_live_slots_excluding_primary_seed_by_nonzero_fd_record_byte_1E
; qualifier: strong structural
; notes: Tests `record[+1E]` through the shared `AE70 -> ADA1` reducer path. Also inherits the shared nonnegative `record[+1D]` gate. Skips the primary-seed slot indexed by `B18B`.
; source: chrono_trigger_labels_pass71.md
C1_A819_ct_global_opcode_73_select_nonhead_occupied_live_slots_excluding_primary_seed_by_nonzero:
    ; TODO: reconstruct body / data for C1:A819
    ; known span hint: C1:A819..C1:A854

; =============================================================================
; C1:A855  top-status=strong  labels=1
; =============================================================================
; [strong] pass 71 :: ct_global_opcode_74_select_nonhead_occupied_live_slots_by_nonzero_fd_record_byte_1E
; qualifier: strong structural
; notes: Nonhead counterpart of global `61`. Uses the shared `AE70 -> ADA1` reducer path. No `B18B` exclusion.
; source: chrono_trigger_labels_pass71.md
C1_A855_ct_global_opcode_74_select_nonhead_occupied_live_slots_by_nonzero_fd_record_byte_1E:
    ; TODO: reconstruct body / data for C1:A855
    ; known span hint: C1:A855..C1:A888

; =============================================================================
; C1:A889  top-status=strong  labels=1
; =============================================================================
; [strong] pass 71 :: ct_global_opcode_75_select_nonhead_occupied_live_slots_excluding_primary_seed_by_nonzero_fd_record_byte_1F
; qualifier: strong structural
; notes: Tests `record[+1F]` through the shared `AE70 -> ADA1` reducer path. Skips the primary-seed slot indexed by `B18B`.
; source: chrono_trigger_labels_pass71.md
C1_A889_ct_global_opcode_75_select_nonhead_occupied_live_slots_excluding_primary_seed_by_nonzero:
    ; TODO: reconstruct body / data for C1:A889
    ; known span hint: C1:A889..C1:A8C4

; =============================================================================
; C1:A8C5  top-status=strong  labels=1
; =============================================================================
; [strong] pass 71 :: ct_global_opcode_76_select_nonhead_occupied_live_slots_by_nonzero_fd_record_byte_1F
; qualifier: provisional structural
; notes: Structurally matches the no-exclusion sibling of global `75`. Intended to test `record[+1F]` through the shared `AE70 -> ADA1` reducer path. But the loop update stores back into `$0E` with `STA $0E` at `C1:A8E9` instead of the expected `STX $0E`. Keep the family interpretation, but preserve explicit caution until runtime confirms the practical behavior.
; source: chrono_trigger_labels_pass71.md
C1_A8C5_ct_global_opcode_76_select_nonhead_occupied_live_slots_by_nonzero_fd_record_byte_1F:
    ; TODO: reconstruct body / data for C1:A8C5
    ; known span hint: C1:A8C5..C1:A8F8

; =============================================================================
; C1:A8F9  top-status=strong  labels=1
; =============================================================================
; [strong] pass 71 :: ct_global_opcode_77_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1E_mask_02
; qualifier: strong structural
; notes: Uses the shared nonhead FD-offset/mask pipeline. Tests `record[+1E] & 0x02`. Skips the primary-seed slot indexed by `B18B`.
; source: chrono_trigger_labels_pass71.md
C1_A8F9_ct_global_opcode_77_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_reco:
    ; TODO: reconstruct body / data for C1:A8F9
    ; known span hint: C1:A8F9..C1:A934

; =============================================================================
; C1:A935  top-status=strong  labels=1
; =============================================================================
; [strong] pass 71 :: ct_global_opcode_78_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1E_mask_80
; qualifier: strong structural
; notes: Uses the shared nonhead FD-offset/mask pipeline. Tests `record[+1E] & 0x80`. Skips the primary-seed slot indexed by `B18B`.
; source: chrono_trigger_labels_pass71.md
C1_A935_ct_global_opcode_78_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_reco:
    ; TODO: reconstruct body / data for C1:A935
    ; known span hint: C1:A935..C1:A970

; =============================================================================
; C1:A971  top-status=strong  labels=1
; =============================================================================
; [strong] pass 71 :: ct_global_opcode_79_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1E_mask_04
; qualifier: strong structural
; notes: Uses the shared nonhead FD-offset/mask pipeline. Tests `record[+1E] & 0x04`. Skips the primary-seed slot indexed by `B18B`.
; source: chrono_trigger_labels_pass71.md
C1_A971_ct_global_opcode_79_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_reco:
    ; TODO: reconstruct body / data for C1:A971
    ; known span hint: C1:A971..C1:A9AC

; =============================================================================
; C1:A9AD  top-status=strong  labels=1
; =============================================================================
; [strong] pass 71 :: ct_global_opcode_7A_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_21_mask_40
; qualifier: strong structural
; notes: Uses the shared nonhead FD-offset/mask pipeline. Tests `record[+21] & 0x40`. Skips the primary-seed slot indexed by `B18B`.
; source: chrono_trigger_labels_pass71.md
C1_A9AD_ct_global_opcode_7A_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_reco:
    ; TODO: reconstruct body / data for C1:A9AD
    ; known span hint: C1:A9AD..C1:A9E8

; =============================================================================
; C1:A9E9  top-status=strong  labels=1
; =============================================================================
; [strong] pass 71 :: ct_global_opcode_7B_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1D_mask_02
; qualifier: strong structural
; notes: Uses the shared nonhead FD-offset/mask pipeline. Tests `record[+1D] & 0x02`. Skips the primary-seed slot indexed by `B18B`.
; source: chrono_trigger_labels_pass71.md
C1_A9E9_ct_global_opcode_7B_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_reco:
    ; TODO: reconstruct body / data for C1:A9E9
    ; known span hint: C1:A9E9..C1:AA24

; =============================================================================
; C1:AA25  top-status=strong  labels=1
; =============================================================================
; [strong] pass 71 :: ct_global_opcode_7C_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_19_mask_01
; qualifier: strong structural
; notes: Uses the shared nonhead FD-offset/mask pipeline. Tests `record[+19] & 0x01`. Skips the primary-seed slot indexed by `B18B`.
; source: chrono_trigger_labels_pass71.md
C1_AA25_ct_global_opcode_7C_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_reco:
    ; TODO: reconstruct body / data for C1:AA25
    ; known span hint: C1:AA25..C1:AA60

; =============================================================================
; C1:AA61  top-status=strong  labels=1
; =============================================================================
; [strong] pass 71 :: ct_global_opcode_7D_select_one_nonhead_occupied_live_slot_excluding_primary_seed_by_min_nonzero_fd_record_word_03
; qualifier: strong structural
; notes: Same minimum-word selector family as global `70`. Scans occupied live slots `3..10`. Skips the primary-seed slot indexed by `B18B`. Chooses the smallest nonzero `record_word(+3)` candidate and stores its slot into `AECC[0]`.
; source: chrono_trigger_labels_pass71.md
C1_AA61_ct_global_opcode_7D_select_one_nonhead_occupied_live_slot_excluding_primary_seed_by_min_:
    ; TODO: reconstruct body / data for C1:AA61
    ; known span hint: C1:AA61..C1:AAAA

; =============================================================================
; C1:AAAB  top-status=strong  labels=1
; =============================================================================
; [strong] pass 58 :: ct_fixed_single_entry_selector_wrappers_3_through_10
; qualifier: strong
; notes: Family of tiny wrappers: `AECC = literal` `AECB = 1` `RTS` Covered literal values: `3..10`.
; source: chrono_trigger_labels_pass58.md
C1_AAAB_ct_fixed_single_entry_selector_wrappers_3_through_10:
    ; TODO: reconstruct body / data for C1:AAAB
    ; known span hint: C1:AAAB..C1:AAF8

; =============================================================================
; C1:AB03  top-status=strong  labels=2
; =============================================================================
; [strong] pass 69 :: ct_global_opcode_86_build_withheld_tail_candidate_list_and_random_reduce_to_one
; qualifier: strong
; notes: Promoted master/global ownership of the pass-57 withheld-tail selector body.
; source: chrono_trigger_labels_pass69.md
C1_AB03_ct_global_opcode_86_build_withheld_tail_candidate_list_and_random_reduce_to_one:
    ; TODO: reconstruct body / data for C1:AB03
    ; known span hint: C1:AB03..C1:AB49

; [caution] pass 58 :: ct_build_withheld_tail_candidate_list_and_random_reduce_to_one
; qualifier: context strengthened
; notes: Keep the pass-57 label. Pass 58 now places it inside the same selector-wrapper family as: fixed single-entry wrappers the visible-slot min selector the live-tail selector at `ABC9`
; source: chrono_trigger_labels_pass58.md
C1_AB03_ct_build_withheld_tail_candidate_list_and_random_reduce_to_one:
    ; TODO: reconstruct body / data for C1:AB03
    ; known span hint: C1:AB03..C1:AB49

; =============================================================================
; C1:AB4E  top-status=strong  labels=1
; =============================================================================
; [strong] pass 58 :: ct_fixed_single_entry_selector_wrappers_0_through_6
; qualifier: strong
; notes: Family of tiny wrappers: `AECC = literal` `AECB = 1` `RTS` Covered literal values: `0..6`.
; source: chrono_trigger_labels_pass58.md
C1_AB4E_ct_fixed_single_entry_selector_wrappers_0_through_6:
    ; TODO: reconstruct body / data for C1:AB4E
    ; known span hint: C1:AB4E..C1:AB90

; =============================================================================
; C1:AB9B  top-status=strong  labels=2
; =============================================================================
; [strong] pass 69 :: ct_global_opcode_8E_select_one_visible_entry_0_1_2_by_min_lane_value
; qualifier: strong structural
; notes: Promoted master/global ownership of the pass-58 visible min selector.
; source: chrono_trigger_labels_pass69.md
C1_AB9B_ct_global_opcode_8E_select_one_visible_entry_0_1_2_by_min_lane_value:
    ; TODO: reconstruct body / data for C1:AB9B
    ; known span hint: C1:AB9B..C1:ABC8

; [strong] pass 58 :: ct_select_one_visible_entry_0_1_2_by_min_lane_value
; qualifier: strong structural
; notes: Compares three lane-local values: `5E30` `5EB0` `5F30` Selects exactly one visible entry index: `0`, `1`, or `2` Stores that selected entry into `AECC` Forces `AECB = 1` Exact branch polarity / final gameplay noun should still stay cautious, but the structural selector role is now strong.
; source: chrono_trigger_labels_pass58.md
C1_AB9B_ct_select_one_visible_entry_0_1_2_by_min_lane_value:
    ; TODO: reconstruct body / data for C1:AB9B
    ; known span hint: C1:AB9B..C1:ABC8

; =============================================================================
; C1:ABC9  top-status=strong  labels=2
; =============================================================================
; [strong] pass 69 :: ct_global_opcode_8F_build_live_tail_slot_candidate_list_and_random_reduce_to_one
; qualifier: strong
; notes: Promoted master/global ownership of the pass-58 live-tail selector body.
; source: chrono_trigger_labels_pass69.md
C1_ABC9_ct_global_opcode_8F_build_live_tail_slot_candidate_list_and_random_reduce_to_one:
    ; TODO: reconstruct body / data for C1:ABC9
    ; known span hint: C1:ABC9..C1:AC13

; [strong] pass 58 :: ct_build_live_tail_slot_candidate_list_and_random_reduce_to_one
; qualifier: strong
; notes: Scans the unified live occupant map starting at slot index `3`. Uses `B252 + 3` as the upper live-tail bound. Appends non-`FF` live slot indices into `AECC`. If multiple candidates exist, uses `AF22` to choose one and exposes the chosen slot at `AECC[0]`. Forces `AECB = 1`. Strong structural sibling to pass 57's `AB03`, but over the live-tail side.
; source: chrono_trigger_labels_pass58.md
C1_ABC9_ct_build_live_tail_slot_candidate_list_and_random_reduce_to_one:
    ; TODO: reconstruct body / data for C1:ABC9
    ; known span hint: C1:ABC9..C1:AC13

; =============================================================================
; C1:AC14  top-status=strong  labels=1
; =============================================================================
; [strong] pass 59 :: ct_resolve_inline_selector_control_byte_into_selection_result
; qualifier: strengthened
; notes: Reads the next selector-control byte from the CC stream. If negative, uses the preset path through `AED8`. Otherwise dispatches through `ct_inline_selector_control_dispatch_table`. Mirrors the resulting selection scratch from `AECC` into `AD8E` and records `B2AE = AECC`.
; source: chrono_trigger_labels_pass59.md
C1_AC14_ct_resolve_inline_selector_control_byte_into_selection_result:
    ; TODO: reconstruct body / data for C1:AC14
    ; known span hint: C1:AC14..C1:AC45

; =============================================================================
; C1:AC57  top-status=strong  labels=2
; =============================================================================
; [strong] pass 75 :: ct_c1_run_service_04_hook_then_apply_pending_stat_deltas
; qualifier: strong correction
; notes: Exact body: `JSR BFA4 ; JSR AC85 ; RTS`. Because `BFA4` is now exact, this tail is no longer just a vague bridge. Strongest safe reading: run the service-`04` follow-up hook, then apply pending stat-delta channels.
; source: chrono_trigger_labels_pass75.md
C1_AC57_ct_c1_run_service_04_hook_then_apply_pending_stat_deltas:
    ; TODO: reconstruct body / data for C1:AC57
    ; known span hint: C1:AC57..C1:AC5D

; [strong] pass 74 :: ct_c1_run_common_followup_tail_then_apply_pending_stat_deltas
; qualifier: strong structural
; notes: Calls `BFA4` first. Then calls `AC85`. Structural role: bridge the shared follow-up-context tail into pending stat-delta packet apply.
; source: chrono_trigger_labels_pass74.md
C1_AC57_ct_c1_run_common_followup_tail_then_apply_pending_stat_deltas:
    ; TODO: reconstruct body / data for C1:AC57
    ; known span hint: C1:AC57..C1:AC5D

; =============================================================================
; C1:AC85  top-status=strong  labels=1
; =============================================================================
; [strong] pass 74 :: ct_c1_apply_pending_stat_delta_channels_wrapper
; qualifier: strong
; notes: Exact wrapper: `JSR EC7F ; RTS`.
; source: chrono_trigger_labels_pass74.md
C1_AC85_ct_c1_apply_pending_stat_delta_channels_wrapper:
    ; TODO: reconstruct body / data for C1:AC85
    ; known span hint: C1:AC85..C1:AC88

; =============================================================================
; C1:AD68  top-status=strong  labels=1
; =============================================================================
; [strong] pass 70 :: ct_build_visible_fd_offset_nonzero_candidates_and_reduce
; qualifier: strong structural
; notes: Clears `AECB`, `AF20`, and `AF21`. Forces `AF1F = FF`. Runs `AE70` across visible entries `0`, `1`, and `2`. Then runs `ADA1` to reduce the resulting candidate list.
; source: chrono_trigger_labels_pass70.md
C1_AD68_ct_build_visible_fd_offset_nonzero_candidates_and_reduce:
    ; TODO: reconstruct body / data for C1:AD68
    ; known span hint: C1:AD68..C1:ADA0

; =============================================================================
; C1:ADA1  top-status=strong  labels=1
; =============================================================================
; [strong] pass 70 :: ct_reduce_visible_fd_candidates_by_b23a_priority_and_optional_relation_redirect
; qualifier: strong structural
; notes: Consumes candidate bytes already staged in `AECC/AECB`. Uses `B23A` as the ordered reduction stream. Prefers `0x80`-marked candidates when any are present. Falls back to the first ordinary `B23A` priority match otherwise. If the chosen candidate carries `0x40`, redirects through `A4E0`. Otherwise collapses to a single low-nibble entry in `AECC[0]` with `AECB = 1`.
; source: chrono_trigger_labels_pass70.md
C1_ADA1_ct_reduce_visible_fd_candidates_by_b23a_priority_and_optional_relation_redirect:
    ; TODO: reconstruct body / data for C1:ADA1
    ; known span hint: C1:ADA1..C1:AE20

; =============================================================================
; C1:AE21  top-status=strong  labels=1
; =============================================================================
; [strong] pass 64 :: ct_reduce_marked_selected_entries_to_single_choice_or_fail
; qualifier: strong structural
; notes: Empty input selection increments `AF24` and returns. Requires a bit-7-marked chosen entry to succeed. On success: strips bit 7 writes the chosen entry into `AECC[0]` writes `AECB = 1` On failure increments `AF24`. Multi-entry path uses a low-nibble comparison against the `C1:B163` byte stream before accepting a marked entry. Exact higher-level ranking noun is still open, but the reducer contract itself is now strong.
; source: chrono_trigger_labels_pass64.md
C1_AE21_ct_reduce_marked_selected_entries_to_single_choice_or_fail:
    ; TODO: reconstruct body / data for C1:AE21
    ; known span hint: C1:AE21..C1:AE6F

; =============================================================================
; C1:AE70  top-status=strong  labels=1
; =============================================================================
; [strong] pass 70 :: ct_scan_one_visible_entry_for_fd_offset_mask_candidate
; qualifier: strong structural
; notes: Scans one visible entry indexed by `AF1E`. Uses the FD record root table at `FD:A80B`. Tests `(record[offset_from_$0A] & AF1F) != 0`. Also requires `record[+1D]` to be nonnegative. Appends accepted visible entry indices into `AECC` and increments `AECB`. Annotates the stored candidate with `0x40` / `0x80` marks from `record[+20]` and tracks those counts in `AF20` / `AF21`.
; source: chrono_trigger_labels_pass70.md
C1_AE70_ct_scan_one_visible_entry_for_fd_offset_mask_candidate:
    ; TODO: reconstruct body / data for C1:AE70
    ; known span hint: C1:AE70..C1:AECF

; =============================================================================
; C1:AED3  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 58 :: ct_materialize_deferred_tail_entry_by_canonical_occupant_id
; qualifier: strengthened context
; notes: Keep the pass-57 label. Pass 58 strengthens the context: this helper is **not** the only tail materialization path it is best treated as the **occupant-ID keyed deferred reinsertion helper** slot-indexed materializers exist elsewhere (`9E78`, `86BC` style copy path)
; source: chrono_trigger_labels_pass58.md
C1_AED3_ct_materialize_deferred_tail_entry_by_canonical_occupant_id:
    ; TODO: reconstruct body / data for C1:AED3
    ; known span hint: C1:AED3..C1:AEFB

; =============================================================================
; C1:AFB6  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_9D_late_pack_helper_internal_alias_seed_dp28_from_fd_ba61
; qualifier: strong structural
; notes: Internal helper/lead-in alias before the late-pack executor blob. Seeds scratch through `FD:BA61`, `DP28/29`, `C92A`, and a `PLX` return tail. Not a clean standalone top-level command body.
; source: chrono_trigger_labels_pass72.md
C1_AFB6_ct_global_opcode_9D_late_pack_helper_internal_alias_seed_dp28_from_fd_ba61:
    ; TODO: reconstruct body / data for C1:AFB6
    ; known span hint: C1:AFB6..C1:AFC0

; =============================================================================
; C1:AFC1  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_9E_late_pack_helper_internal_alias_call_c92a_and_plx_return
; qualifier: strong structural
; notes: Internal alias into the same helper tail used by `9D`. Falls through to `PLX ; STX $2C ; RTS`. Not a clean standalone top-level command body.
; source: chrono_trigger_labels_pass72.md
C1_AFC1_ct_global_opcode_9E_late_pack_helper_internal_alias_call_c92a_and_plx_return:
    ; TODO: reconstruct body / data for C1:AFC1
    ; known span hint: C1:AFC1..C1:AFCB

; =============================================================================
; C1:AFCC  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_9F_late_pack_helper_internal_alias_plx_return
; qualifier: strong structural
; notes: Internal alias that lands directly in the `PLX` return tail ahead of the late-pack blob. Not a clean standalone top-level command body.
; source: chrono_trigger_labels_pass72.md
C1_AFCC_ct_global_opcode_9F_late_pack_helper_internal_alias_plx_return:
    ; TODO: reconstruct body / data for C1:AFCC
    ; known span hint: C1:AFCC..C1:AFD4

; =============================================================================
; C1:AFD7  top-status=strong  labels=3
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_A0_late_pack_executor_internal_alias_after_cc_record_load
; qualifier: strong correction
; notes: The master pointer lands two bytes inside the real `CC:8B08` pointer-load sequence. Keep as an internal late-pack executor alias, not as the clean top-level initializer.
; source: chrono_trigger_labels_pass72.md
C1_AFD7_ct_global_opcode_A0_late_pack_executor_internal_alias_after_cc_record_load:
    ; TODO: reconstruct body / data for C1:AFD7
    ; known span hint: C1:AFD7..C1:AFE1

; [strong] pass 69 :: ct_global_opcode_A0_execute_late_selector_pack_and_capture_tail_result
; qualifier: strong structural
; notes: Promoted master/global ownership of the pass-60 late selector-pack executor.
; source: chrono_trigger_labels_pass69.md
C1_AFD7_ct_global_opcode_A0_execute_late_selector_pack_and_capture_tail_result:
    ; TODO: reconstruct body / data for C1:AFD7
    ; known span hint: C1:AFD7..C1:B08E

; [strong] pass 60 :: ct_execute_late_selector_pack_and_capture_tail_result
; qualifier: strong structural
; notes: Top-level late-family executor proved in this pass. Loads a pointer from `ct_late_selector_control_pointer_records`. Uses `B4AA` to select/adjust the current FE/FF-delimited segment. Reads the current sub-op byte into `B239`. Dispatches the sub-op through `B80D`. Optionally dispatches a second chained sub-op at `+4` when `B1CF != 0`. Captures the resulting `AF24` status into tail-local scratch/status arrays. May chain to another FE-delimited segment.
; source: chrono_trigger_labels_pass60.md
C1_AFD7_ct_execute_late_selector_pack_and_capture_tail_result:
    ; TODO: reconstruct body / data for C1:AFD7
    ; known span hint: C1:AFD7..C1:B08E

; =============================================================================
; C1:AFE2  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_A1_late_pack_executor_internal_alias_clear_af24_and_probe_second_subop
; qualifier: strong structural
; notes: Internal alias in the common late-pack executor path. Clears `AF24`, probes byte `+4` for the `FE` chained-subop case, and falls into the shared segment selector path.
; source: chrono_trigger_labels_pass72.md
C1_AFE2_ct_global_opcode_A1_late_pack_executor_internal_alias_clear_af24_and_probe_second_subop:
    ; TODO: reconstruct body / data for C1:AFE2
    ; known span hint: C1:AFE2..C1:AFEC

; =============================================================================
; C1:AFED  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_A2_late_pack_executor_internal_alias_arm_second_subop_flag
; qualifier: strong structural
; notes: Internal alias in the same common path. Lives inside the `CMP #$FE` / `B1CF` second-subop arming logic.
; source: chrono_trigger_labels_pass72.md
C1_AFED_ct_global_opcode_A2_late_pack_executor_internal_alias_arm_second_subop_flag:
    ; TODO: reconstruct body / data for C1:AFED
    ; known span hint: C1:AFED..C1:AFF7

; =============================================================================
; C1:AFF8  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_A3_late_pack_executor_internal_alias_after_segment_select
; qualifier: strong structural
; notes: Internal alias after `B4AA` segment selection. Fetches the current opcode byte into `B239` and falls into the shared dispatch path.
; source: chrono_trigger_labels_pass72.md
C1_AFF8_ct_global_opcode_A3_late_pack_executor_internal_alias_after_segment_select:
    ; TODO: reconstruct body / data for C1:AFF8
    ; known span hint: C1:AFF8..C1:B002

; =============================================================================
; C1:B003  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_A4_late_pack_executor_internal_alias_dispatch_current_b239_opcode
; qualifier: strong structural
; notes: Internal alias that dispatches the current `B239` opcode through the master table.
; source: chrono_trigger_labels_pass72.md
C1_B003_ct_global_opcode_A4_late_pack_executor_internal_alias_dispatch_current_b239_opcode:
    ; TODO: reconstruct body / data for C1:B003
    ; known span hint: C1:B003..C1:B00D

; =============================================================================
; C1:B00E  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_A5_late_pack_executor_internal_alias_advance_to_second_subop
; qualifier: strong structural
; notes: Internal alias for the chained second-subop advance path. Advances `B1D2` by `+4`, reloads `B239`, and falls back into the shared dispatch.
; source: chrono_trigger_labels_pass72.md
C1_B00E_ct_global_opcode_A5_late_pack_executor_internal_alias_advance_to_second_subop:
    ; TODO: reconstruct body / data for C1:B00E
    ; known span hint: C1:B00E..C1:B018

; =============================================================================
; C1:B019  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_A6_late_pack_executor_internal_alias_dispatch_second_subop
; qualifier: strong structural
; notes: Internal alias after the chained second-subop reload. Dispatches the second `B239` opcode and falls into result capture.
; source: chrono_trigger_labels_pass72.md
C1_B019_ct_global_opcode_A6_late_pack_executor_internal_alias_dispatch_second_subop:
    ; TODO: reconstruct body / data for C1:B019
    ; known span hint: C1:B019..C1:B023

; =============================================================================
; C1:B024  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_A7_late_pack_executor_internal_alias_capture_af24_result
; qualifier: strong structural
; notes: Internal alias at the result-capture start. Mirrors `AF24` into `B24A[tail]` and enters the special-case / nonzero-result logic.
; source: chrono_trigger_labels_pass72.md
C1_B024_ct_global_opcode_A7_late_pack_executor_internal_alias_capture_af24_result:
    ; TODO: reconstruct body / data for C1:B024
    ; known span hint: C1:B024..C1:B02E

; =============================================================================
; C1:B02F  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_A8_late_pack_executor_internal_alias_special_case_af24_eq_02
; qualifier: strong structural
; notes: Internal alias inside the result-capture tail. Special-cases `AF24 == 2` before the broader nonzero-result path.
; source: chrono_trigger_labels_pass72.md
C1_B02F_ct_global_opcode_A8_late_pack_executor_internal_alias_special_case_af24_eq_02:
    ; TODO: reconstruct body / data for C1:B02F
    ; known span hint: C1:B02F..C1:B039

; =============================================================================
; C1:B03A  top-status=strong  labels=1
; =============================================================================
; [strong] pass 72 :: ct_global_opcode_A9_late_pack_executor_internal_alias_nonzero_af24_path
; qualifier: strong structural
; notes: Internal alias into the nonzero-result handling and FE/FF continuation logic. Includes the path that marks `B242`, advances FE-delimited segments, and increments or clears `B263`.
; source: chrono_trigger_labels_pass72.md
C1_B03A_ct_global_opcode_A9_late_pack_executor_internal_alias_nonzero_af24_path:
    ; TODO: reconstruct body / data for C1:B03A
    ; known span hint: C1:B03A..C1:B08E

; =============================================================================
; C1:B094  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 49 :: ct_c1_update_lane_low_hp_threshold_flag
; qualifier: strengthened
; notes: Previously part of a vague flag-maintenance band. Pass 49 proves this exact routine clears and re-establishes `5E2F.bit0` from the `maxHP/8` versus current HP test.
; source: chrono_trigger_labels_pass49.md
C1_B094_ct_c1_update_lane_low_hp_threshold_flag:
    ; TODO: reconstruct body / data for C1:B094
    ; known span hint: C1:B094..C1:B0B3

; =============================================================================
; C1:B279  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 55 :: ct_c1_restore_or_clear_live_battle_slot_occupant_from_default_map
; qualifier: provisional
; notes: Strong structure: restores `AEFF[Y]` from `AF0A[Y]` when a remembered occupant exists later clears `AEFF[Y] = FF` on failure/removal path Kept provisional because the exact higher-level gameplay trigger for this restore/remove operation still wants one more caller-context pass.
; source: chrono_trigger_labels_pass55.md
C1_B279_ct_c1_restore_or_clear_live_battle_slot_occupant_from_default_map:
    ; TODO: reconstruct body / data for C1:B279
    ; known span hint: C1:B279..C1:B2C0

; =============================================================================
; C1:B390  top-status=strong  labels=1
; =============================================================================
; [strong] pass 51 :: ct_c1_seed_lane_gauge_exports_from_b158
; qualifier: strong
; notes: Directly mirrors `B158,Y` into: `AFAB,Y` `99DD,Y` `9F22,Y` Strongest safe reading: direct seed/export mirror from the upstream readiness seed value.
; source: chrono_trigger_labels_pass51.md
C1_B390_ct_c1_seed_lane_gauge_exports_from_b158:
    ; TODO: reconstruct body / data for C1:B390

; =============================================================================
; C1:B4AA  top-status=strong  labels=1
; =============================================================================
; [strong] pass 60 :: ct_select_tail_local_segment_within_late_selector_pack
; qualifier: strengthened structural
; notes: Previously just an opaque helper reached from the late family. Pass 60 proves it is the segment-selection / pointer-adjust helper that sits between: the pointer-record seed at `AFD7` and the `B80D` sub-op dispatch. Exact gameplay-facing noun remains open, but “late selector pack segment selector” is now justified.
; source: chrono_trigger_labels_pass60.md
C1_B4AA_ct_select_tail_local_segment_within_late_selector_pack:
    ; TODO: reconstruct body / data for C1:B4AA
    ; known span hint: C1:B4AA..C1:B4E6

; =============================================================================
; C1:B575  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_c1_service7_reconcile_canonical_record_lane_pairs
; qualifier: strong
; notes: Initializes `B3EB..B3F3` to `FF`, seeds root lane IDs `0/1/2`, This is the concrete front-end of the downstream `93F3` family.
; source: chrono_trigger_labels_pass42.md
C1_B575_ct_c1_service7_reconcile_canonical_record_lane_pairs:
    ; TODO: reconstruct body / data for C1:B575

; =============================================================================
; C1:B725  top-status=strong  labels=1
; =============================================================================
; [strong] pass 50 :: ct_c1_init_lane_active_time_gauge_exports
; qualifier: strong
; notes: Clears the visible lane-progress exports `99DD..99DF`. Seeds the visible lane-threshold/cap exports `9F22..9F24` to `0x30`. Also resets the nearby pending-lane/FIFO state. Strongest safe reading: initialization of the visible active-time/readiness gauge export family.
; source: chrono_trigger_labels_pass50.md
C1_B725_ct_c1_init_lane_active_time_gauge_exports:
    ; TODO: reconstruct body / data for C1:B725

; =============================================================================
; C1:B80D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 61 :: ct_c1_master_opcode_dispatch_table
; qualifier: strong architectural
; notes: Root indexed `JSR` table used by the late-pack executor. Interior slices line up exactly with the previously solved local tables. Current proven slice offsets: global `0x29..0x3F` -> `B85F..B88C` global `0x40..0x52` -> `B88D..B8BA` global `0x57..0xA9` -> `B8BB..B95F`
; source: chrono_trigger_labels_pass61.md
C1_B80D_ct_c1_master_opcode_dispatch_table:
    ; TODO: reconstruct body / data for C1:B80D
    ; known span hint: C1:B80D..C1:B95F

; =============================================================================
; C1:B85F  top-status=strong  labels=1
; =============================================================================
; [strong] pass 61 :: ct_c1_group1_opcode_dispatch_slice
; qualifier: strong correction
; notes: Keep the useful local group-1 numbering from earlier passes. But this is now proved to be a slice entrypoint inside `ct_c1_master_opcode_dispatch_table`, not an independent root table.
; source: chrono_trigger_labels_pass61.md
C1_B85F_ct_c1_group1_opcode_dispatch_slice:
    ; TODO: reconstruct body / data for C1:B85F
    ; known span hint: C1:B85F..C1:B88C

; =============================================================================
; C1:B88D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 61 :: ct_c1_group2_opcode_dispatch_slice
; qualifier: strong correction
; notes: Same correction as the group-1 table. Useful local numbering remains valid. Root ownership now belongs to `ct_c1_master_opcode_dispatch_table`.
; source: chrono_trigger_labels_pass61.md
C1_B88D_ct_c1_group2_opcode_dispatch_slice:
    ; TODO: reconstruct body / data for C1:B88D
    ; known span hint: C1:B88D..C1:B8BA

; =============================================================================
; C1:B8BB  top-status=strong  labels=2
; =============================================================================
; [strong] pass 61 :: ct_c1_inline_selector_control_dispatch_slice
; qualifier: strong correction
; notes: Same correction again for the selector-control table. `AC14` still dispatches here by local selector-control byte. But this slice is inside the same master dispatch table rooted at `B80D`.
; source: chrono_trigger_labels_pass61.md
C1_B8BB_ct_c1_inline_selector_control_dispatch_slice:
    ; TODO: reconstruct body / data for C1:B8BB
    ; known span hint: C1:B8BB..C1:B95F

; [strong] pass 59 :: ct_inline_selector_control_dispatch_table
; qualifier: strong
; notes: Directly dispatched by `C1:AC2E  JSR ($B8BB,X)`. `X` is formed from the non-negative inline selector-control byte read by `AC14`. Proven table span in this pass runs from selector-control byte `0x00` through `0x52`. Includes the previously isolated pass-58 selector-wrapper family as the `0x27..0x38` subrange.
; source: chrono_trigger_labels_pass59.md
C1_B8BB_ct_inline_selector_control_dispatch_table:
    ; TODO: reconstruct body / data for C1:B8BB
    ; known span hint: C1:B8BB..C1:B95F

; =============================================================================
; C1:B8F3  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 58 :: ct_selector_wrapper_table_candidate
; qualifier: provisional
; notes: Coherent pointer run of 29 entries: dynamic selector wrappers fixed single-entry wrappers `AB03` `AB9B` `ABC9` Strongly looks like a real local selector-wrapper table. The dispatch site into this table is still not pinned, so keep this provisional.
; source: chrono_trigger_labels_pass58.md
C1_B8F3_ct_selector_wrapper_table_candidate:
    ; TODO: reconstruct body / data for C1:B8F3
    ; known span hint: C1:B8F3..C1:B92B

; =============================================================================
; C1:B961  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_local_service2_wrapper
; qualifier: strong
; notes: Strengthened by pass 43. Exact wrapper into the lane-roster removal/reseat service.
; source: chrono_trigger_labels_pass43.md
C1_B961_ct_c1_local_service2_wrapper:
    ; TODO: reconstruct body / data for C1:B961

; =============================================================================
; C1:BD6F  top-status=strong  labels=1
; =============================================================================
; [strong] pass 50 :: ct_c1_apply_status_modifiers_to_lane_time_increment
; qualifier: strong
; notes: Starts from `AFAB[x]`. Halves it when the `5E4D|5E52` status family has bit `0x80` set. Doubles it with saturation when `5E4B` bit `0x20` is set. Forces a minimum of `1`. Mirrors the adjusted value to `99DD/9F22` for visible party lanes. Strongest safe reading: shared status-modifier helper for the lane active-time/readiness increment.
; source: chrono_trigger_labels_pass50.md
C1_BD6F_ct_c1_apply_status_modifiers_to_lane_time_increment:
    ; TODO: reconstruct body / data for C1:BD6F

; =============================================================================
; C1:BDE0  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 50 :: ct_c1_advance_lane_active_time_gauge_and_ready_transition_family
; qualifier: strengthened
; notes: Three sibling update families that: seed `AFAB` from `B158` apply `BD6F` advance one or both lane-bar exports with saturation set/update lane-ready side effects (`B03A`, `B188`, `93EE`) Best reading now: readiness-gauge advance and ready-transition family.
; source: chrono_trigger_labels_pass50.md
C1_BDE0_ct_c1_advance_lane_active_time_gauge_and_ready_transition_family:
    ; TODO: reconstruct body / data for C1:BDE0
    ; known span hint: C1:BDE0..C1:BF25

; =============================================================================
; C1:BF7F  top-status=strong  labels=1
; =============================================================================
; [strong] pass 75 :: ct_c1_copy_17_byte_followup_descriptor_profile_from_cc213f_by_b18c
; qualifier: strong structural
; notes: Computes `0x11 * B18C`. Copies `0x11` bytes from `CC:213F + 0x11*B18C` into `AEE6..AEF6`. Strongest safe reading: load the current follow-up/descriptor profile record selected by `B18C`.
; source: chrono_trigger_labels_pass75.md
C1_BF7F_ct_c1_copy_17_byte_followup_descriptor_profile_from_cc213f_by_b18c:
    ; TODO: reconstruct body / data for C1:BF7F
    ; known span hint: C1:BF7F..C1:BFA0

; =============================================================================
; C1:BFA4  top-status=strong  labels=1
; =============================================================================
; [strong] pass 75 :: ct_c1_invoke_local_service_04_wrapper
; qualifier: strong
; notes: Exact bytes: `LDA #$04 ; JSR $0003 ; RTS`. This is no longer a fuzzy helper blob. Structural role: tiny wrapper into the local service/dispatcher family with service id `04`.
; source: chrono_trigger_labels_pass75.md
C1_BFA4_ct_c1_invoke_local_service_04_wrapper:
    ; TODO: reconstruct body / data for C1:BFA4
    ; known span hint: C1:BFA4..C1:BFA9

; =============================================================================
; C1:BFAA  top-status=strong  labels=1
; =============================================================================
; [strong] pass 75 :: ct_c1_initialize_current_tail_followup_context_load_current_descriptor_and_run_common_tail
; qualifier: strong structural
; notes: Sets `B1FC.bit1` on entry and clears it on exit. Clears `AE93/AE94/AE95/AE96/AE99/AE9A/AE9B`, sets `AE97=AE98=0xFF`, seeds `AE90=0`, `AE91=B18B`, `AE92=1`. Seeds single-entry selection state through `AECC=AD8E`, `AECB=1`, and `AE94=AD09()`. If `AEFF[B18B] != 0xFF`, resolves `CC:2583[occupant] -> B18C`, loads the 17-byte descriptor/profile through `BF7F`, and checks `AF23`. On success runs `AC57`, optionally arms `B2C0` when `AECC>=3`, clears transient packet workspace through `FD:ACEE`, clears `B1FC.bit1`, and returns.
; source: chrono_trigger_labels_pass75.md
C1_BFAA_ct_c1_initialize_current_tail_followup_context_load_current_descriptor_and_run_common_ta:
    ; TODO: reconstruct body / data for C1:BFAA
    ; known span hint: C1:BFAA..C1:C029

; =============================================================================
; C1:C90B  top-status=strong  labels=1
; =============================================================================
; [strong] pass 52 :: ct_c1_mul_u16_dp28_dp2a_to_dp2c_lowword
; qualifier: strong
; notes: Shift/add multiply helper. Consumes 16-bit inputs in `$28` and `$2A`. Writes the low word of the product to `$2C`. This is the real arithmetic core behind the `C1:FDBF` wrapper used in the readiness seed families.
; source: chrono_trigger_labels_pass52.md
C1_C90B_ct_c1_mul_u16_dp28_dp2a_to_dp2c_lowword:
    ; TODO: reconstruct body / data for C1:C90B

; =============================================================================
; C1:CC74  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 49 :: ct_c1_lane_selected_resource_spend_on_5e34_family
; qualifier: provisional
; notes: Subtracts a computed quantity from exactly one of: `5E34` `5EB4` `5F34` Strongly looks like a lane-selected spend/update path for the field now best read as current MP. Still kept provisional until the caller-side action family is nailed harder.
; source: chrono_trigger_labels_pass49.md
C1_CC74_ct_c1_lane_selected_resource_spend_on_5e34_family:
    ; TODO: reconstruct body / data for C1:CC74
    ; known span hint: C1:CC74..C1:CCC5

; =============================================================================
; C1:E89F  top-status=strong  labels=1
; =============================================================================
; [strong] pass 73 :: ct_c1_compute_ad9c_packet_offset_from_ad9b_and_b1fd
; qualifier: strong
; notes: Computes `DP0E = 0x2C * AD9B + 4 * B1FD`. Uses the already-locked `C90B` 16-bit multiply helper. This is the exact packet-slot offset calculator for one 4-byte entry inside a `0x2C`-byte record family.
; source: chrono_trigger_labels_pass73.md
C1_E89F_ct_c1_compute_ad9c_packet_offset_from_ad9b_and_b1fd:
    ; TODO: reconstruct body / data for C1:E89F
    ; known span hint: C1:E89F..C1:E8BE

; =============================================================================
; C1:E8C0  top-status=strong  labels=1
; =============================================================================
; [strong] pass 73 :: ct_c1_compute_ad9c_packet_offset_from_ad9b_and_b18b
; qualifier: strong
; notes: Computes `DP10 = 0x2C * AD9B + 4 * B18B`. Companion packet-slot offset calculator using `B18B` instead of `B1FD`.
; source: chrono_trigger_labels_pass73.md
C1_E8C0_ct_c1_compute_ad9c_packet_offset_from_ad9b_and_b18b:
    ; TODO: reconstruct body / data for C1:E8C0
    ; known span hint: C1:E8C0..C1:E8E0

; =============================================================================
; C1:EBF8  top-status=strong  labels=1
; =============================================================================
; [strong] pass 73 :: ct_c1_queue_signed_pending_stat_delta_packet_into_b328_family
; qualifier: strong structural
; notes: Mirrors `B202 -> B203` and negates `AD89` when `B202.bit7` is set. Computes a 4-byte packet slot offset from `B2C7` and the `0x2C` record stride. Writes the signed 16-bit amount into `B328[offset]` and the packet flag byte into `B32B[offset]`. Strongest safe reading: queue one signed pending HP/secondary-stat delta packet.
; source: chrono_trigger_labels_pass73.md
C1_EBF8_ct_c1_queue_signed_pending_stat_delta_packet_into_b328_family:
    ; TODO: reconstruct body / data for C1:EBF8
    ; known span hint: C1:EBF8..C1:EC38

; =============================================================================
; C1:EC39  top-status=strong  labels=1
; =============================================================================
; [strong] pass 73 :: ct_c1_clear_nonpersistent_pending_stat_delta_channels
; qualifier: strong structural
; notes: Scans the three parallel packet families rooted at `B328`, `B354`, and `B380`. If none of the corresponding flag bytes carry bit `0x20`, clears the channel data. Also clears associated scratch/export bytes such as `AEB2`, `AEB0`, and `AE82` on the loop tail.
; source: chrono_trigger_labels_pass73.md
C1_EC39_ct_c1_clear_nonpersistent_pending_stat_delta_channels:
    ; TODO: reconstruct body / data for C1:EC39
    ; known span hint: C1:EC39..C1:EC7E

; =============================================================================
; C1:EC7F  top-status=strong  labels=1
; =============================================================================
; [strong] pass 73 :: ct_c1_apply_pending_stat_delta_channels_and_clamp_lane_currents
; qualifier: strong structural
; notes: Calls the non-persistent channel clearer first. Applies queued signed packet amounts into `5E30/5E32` for the primary current/cap pair. Applies queued signed packet amounts into the parallel `5E34/5E36` pair for packets on the secondary-stat route. Clamps the resulting current values and performs lane refresh side effects such as `5E4A.bit7` handling and `FD:ABA2` calls when needed.
; source: chrono_trigger_labels_pass73.md
C1_EC7F_ct_c1_apply_pending_stat_delta_channels_and_clamp_lane_currents:
    ; TODO: reconstruct body / data for C1:EC7F
    ; known span hint: C1:EC7F..C1:ED87

; =============================================================================
; C1:FB06  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 55 :: ct_c1_rebuild_head_battle_slot_occupant_maps_with_extra_guard
; qualifier: provisional
; notes: Same structural model as `FD:B24D..B27E`. Extra exclusion via `A09B[X]` is proven. Final caller-facing subsystem name still wants one more pass.
; source: chrono_trigger_labels_pass55.md
C1_FB06_ct_c1_rebuild_head_battle_slot_occupant_maps_with_extra_guard:
    ; TODO: reconstruct body / data for C1:FB06
    ; known span hint: C1:FB06..C1:FB2C

; =============================================================================
; C1:FDBF  top-status=strong  labels=1
; =============================================================================
; [strong] pass 52 :: ct_c1_jsl_mul_u16_dp28_dp2a_to_dp2c_lowword
; qualifier: strong
; notes: Thin long-call wrapper: `JSR $C90B` `RTL` Useful because the seed families call it twice with different inputs.
; source: chrono_trigger_labels_pass52.md
C1_FDBF_ct_c1_jsl_mul_u16_dp28_dp2a_to_dp2c_lowword:
    ; TODO: reconstruct body / data for C1:FDBF

