; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_CD
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; CD:0015  top-status=strong  labels=1
; =============================================================================
; [strong] pass 78 :: ct_cd_build_first_four_packed_fragment_row_sections_into_2d00_veneer
; qualifier: strong
; notes: Exact body is `JMP $1323`. Called unconditionally from `C1:4833` with `A = 987A`.
; source: chrono_trigger_labels_pass78.md
CD_0015_ct_cd_build_first_four_packed_fragment_row_sections_into_2d00_veneer:
    ; TODO: reconstruct body / data for CD:0015
    ; known span hint: CD:0015..CD:0017

; =============================================================================
; CD:0018  top-status=strong  labels=1
; =============================================================================
; [strong] pass 78 :: ct_cd_optional_selector_driven_auxiliary_fragment_stage_veneer
; qualifier: strong
; notes: Exact body is `JMP $0D28`. Called conditionally from `C1:4833` only when `AE94 == 0`, `987C != FF`, and `AE93 != 37`.
; source: chrono_trigger_labels_pass78.md
CD_0018_ct_cd_optional_selector_driven_auxiliary_fragment_stage_veneer:
    ; TODO: reconstruct body / data for CD:0018
    ; known span hint: CD:0018..CD:001A

; =============================================================================
; CD:002A  top-status=strong  labels=1
; =============================================================================
; [strong] pass 78 :: ct_cd_build_last_two_packed_fragment_row_sections_into_2d00_veneer
; qualifier: strong
; notes: Exact body is `JMP $1314`. Called unconditionally from `C1:4833` with `A = 987B`.
; source: chrono_trigger_labels_pass78.md
CD_002A_ct_cd_build_last_two_packed_fragment_row_sections_into_2d00_veneer:
    ; TODO: reconstruct body / data for CD:002A
    ; known span hint: CD:002A..CD:002C

; =============================================================================
; CD:0D28  top-status=strong  labels=1
; =============================================================================
; [strong] pass 78 :: ct_cd_optional_selector_driven_auxiliary_fragment_stage
; qualifier: strong structural
; notes: Clears `5D9B`, treats input `A` as the selector, runs `0EBD`, then runs `0D33`. This is the top-level coordinator for the optional pre-decode auxiliary stage.
; source: chrono_trigger_labels_pass78.md
CD_0D28_ct_cd_optional_selector_driven_auxiliary_fragment_stage:
    ; TODO: reconstruct body / data for CD:0D28
    ; known span hint: CD:0D28..CD:0D32

; =============================================================================
; CD:0D33  top-status=strong  labels=1
; =============================================================================
; [strong] pass 78 :: ct_cd_clear_auxiliary_fragment_work_tables_and_expand_ca93_descriptor_list
; qualifier: strong structural
; notes: Clears the `CA32 / CA52 / CA72` work families over the local loop. Then walks `CA93[...]` until `FF`, calling `15D5` for each live descriptor. Strongest safe reading: descriptor-list expander into auxiliary fragment work tables.
; source: chrono_trigger_labels_pass78.md
CD_0D33_ct_cd_clear_auxiliary_fragment_work_tables_and_expand_ca93_descriptor_list:
    ; TODO: reconstruct body / data for CD:0D33
    ; known span hint: CD:0D33..CD:0D5F

; =============================================================================
; CD:0EBD  top-status=strong  labels=1
; =============================================================================
; [strong] pass 78 :: ct_cd_init_auxiliary_fragment_stage_by_selector_and_battle_layout
; qualifier: strong structural
; notes: Consumes the selector passed through `X` and checks live battle-layout / side-state bytes (`A017/A018`, `2A21`, `2C66/67`, etc.). Seeds the `CC91 / CC93 / CC95 / CCA2` family and related local state before the later `0D33` expansion stage. Strongest safe reading: selector/battle-layout initializer for the optional auxiliary fragment stage.
; source: chrono_trigger_labels_pass78.md
CD_0EBD_ct_cd_init_auxiliary_fragment_stage_by_selector_and_battle_layout:
    ; TODO: reconstruct body / data for CD:0EBD
    ; known span hint: CD:0EBD..CD:0F9F

; =============================================================================
; CD:1308  top-status=strong  labels=1
; =============================================================================
; [strong] pass 78 :: ct_cd_packed_fragment_row_section_base_offsets_000c_000e_0010_0012_0014_0016
; qualifier: strong
; notes: Proven six-word table used by the shared `CD:1314/1323` builder loop. Supplies the six fixed base offsets for the `2D00..` row-section workspace.
; source: chrono_trigger_labels_pass78.md
CD_1308_ct_cd_packed_fragment_row_section_base_offsets_000c_000e_0010_0012_0014_0016:
    ; TODO: reconstruct body / data for CD:1308
    ; known span hint: CD:1308..CD:1313

; =============================================================================
; CD:1314  top-status=strong  labels=1
; =============================================================================
; [strong] pass 78 :: ct_cd_build_last_two_packed_fragment_row_sections_into_2d00
; qualifier: strong structural
; notes: Seeds `CACE = A`, `CACF = 4`, `CAD0 = 6`, then falls into the shared row-section builder. Therefore covers section ids `4..5`. Uses the `CD:1308` base-offset table to target `2D00 + 0014 / 0016`.
; source: chrono_trigger_labels_pass78.md
CD_1314_ct_cd_build_last_two_packed_fragment_row_sections_into_2d00:
    ; TODO: reconstruct body / data for CD:1314
    ; known span hint: CD:1314..CD:1322

; =============================================================================
; CD:1323  top-status=strong  labels=1
; =============================================================================
; [strong] pass 78 :: ct_cd_build_first_four_packed_fragment_row_sections_into_2d00
; qualifier: strong structural
; notes: Seeds `CACE = A`, `CACF = 0`, `CAD0 = 4`. Therefore covers section ids `0..3`. Uses the same shared builder machinery as `1314`, targeting `2D00 + 000C / 000E / 0010 / 0012`.
; source: chrono_trigger_labels_pass78.md
CD_1323_ct_cd_build_first_four_packed_fragment_row_sections_into_2d00:
    ; TODO: reconstruct body / data for CD:1323
    ; known span hint: CD:1323..CD:13C8

; =============================================================================
; CD:13E6  top-status=strong  labels=1
; =============================================================================
; [strong] pass 79 :: ct_cd_tile_orientation_mode_ptr_table_direct_hflip_vflip_hvflip
; qualifier: strong
; notes: Exact four-entry local jump table used by the shared `1323/1314` row builder. Entry order is now pinned as: `1509` = direct `1445` = horizontal flip `13F6` = vertical flip `13EE` = horizontal + vertical flip
; source: chrono_trigger_labels_pass79.md
CD_13E6_ct_cd_tile_orientation_mode_ptr_table_direct_hflip_vflip_hvflip:
    ; TODO: reconstruct body / data for CD:13E6
    ; known span hint: CD:13E6..CD:13ED

; =============================================================================
; CD:13EE  top-status=strong  labels=1
; =============================================================================
; [strong] pass 79 :: ct_cd_materialize_tile_then_apply_hv_flip_composite_path
; qualifier: strong structural
; notes: Exact body is `PHY ; JSR 13F6 ; PLY ; JMP 144A`. So it composes the vertical-flip path with the bit-reverse horizontal-flip body. Strongest safe reading: horizontal + vertical flip tile materializer.
; source: chrono_trigger_labels_pass79.md
CD_13EE_ct_cd_materialize_tile_then_apply_hv_flip_composite_path:
    ; TODO: reconstruct body / data for CD:13EE
    ; known span hint: CD:13EE..CD:13F5

; =============================================================================
; CD:13F6  top-status=strong  labels=1
; =============================================================================
; [strong] pass 79 :: ct_cd_materialize_tile_then_apply_vertical_flip_to_both_plane_halves
; qualifier: strong structural
; notes: Calls the direct tile materializer, then uses the internal `13FE` helper twice. The helper swaps word pairs `00<->0E`, `02<->0C`, `04<->0A`, `06<->08` and advances `Y` by `0x10`. Therefore reverses row order in both 16-byte plane halves of one 32-byte tile block. Strongest safe reading: vertical-flip tile materializer.
; source: chrono_trigger_labels_pass79.md
CD_13F6_ct_cd_materialize_tile_then_apply_vertical_flip_to_both_plane_halves:
    ; TODO: reconstruct body / data for CD:13F6
    ; known span hint: CD:13F6..CD:1444

; =============================================================================
; CD:1445  top-status=strong  labels=1
; =============================================================================
; [strong] pass 79 :: ct_cd_materialize_tile_then_apply_horizontal_flip_via_c0_fd00_bit_reverse
; qualifier: strong structural
; notes: Calls the direct tile materializer, then rewrites the resulting bytes through `C0:FD00`. `C0:FD00` is a plain bit-reverse map, so this is the tile horizontal-flip path.
; source: chrono_trigger_labels_pass79.md
CD_1445_ct_cd_materialize_tile_then_apply_horizontal_flip_via_c0_fd00_bit_reverse:
    ; TODO: reconstruct body / data for CD:1445
    ; known span hint: CD:1445..CD:1484

; =============================================================================
; CD:1488  top-status=strong  labels=1
; =============================================================================
; [strong] pass 79 :: ct_cd_materialize_base_tile_planes_and_masked_upper_half_from_d0_source_block
; qualifier: strong structural
; notes: Shared helper used by `1509`. Builds the first `0x10` bytes directly from `D0`, then derives the paired `+0x10` upper half under selector mask `$5F`. Strongest safe reading: base 32-byte tile-block materializer helper.
; source: chrono_trigger_labels_pass79.md
CD_1488_ct_cd_materialize_base_tile_planes_and_masked_upper_half_from_d0_source_block:
    ; TODO: reconstruct body / data for CD:1488
    ; known span hint: CD:1488..CD:1508

; =============================================================================
; CD:1509  top-status=strong  labels=1
; =============================================================================
; [strong] pass 79 :: ct_cd_materialize_one_32byte_4bpp_tile_block_from_d0_source_with_optional_second_block_merge
; qualifier: strong structural
; notes: Uses the low 13 bits of the active source word as the `D0` source index, multiplied by 8. Always materializes one 32-byte tile-shaped block into the active `2D00..` row section. Bit `0x2000` controls whether a second `D0` source block is merged into the upper half. Safest reading: direct tile materializer over one or two `D0` source blocks.
; source: chrono_trigger_labels_pass79.md
CD_1509_ct_cd_materialize_one_32byte_4bpp_tile_block_from_d0_source_with_optional_second_block_m:
    ; TODO: reconstruct body / data for CD:1509
    ; known span hint: CD:1509..CD:15D4

; =============================================================================
; CD:15D5  top-status=strong  labels=1
; =============================================================================
; [strong] pass 79 :: ct_cd_expand_one_auxiliary_descriptor_id_into_one_active_runtime_slot
; qualifier: strong structural
; notes: Looks up a descriptor pointer from `D1:646C`. Seeds the active slot's stream pointer and cadence bytes. Increments the slot active flag. Strongest safe reading: expand one descriptor id into one active runtime stream slot.
; source: chrono_trigger_labels_pass79.md
CD_15D5_ct_cd_expand_one_auxiliary_descriptor_id_into_one_active_runtime_slot:
    ; TODO: reconstruct body / data for CD:15D5
    ; known span hint: CD:15D5..CD:1608

; =============================================================================
; CD:1609  top-status=strong  labels=1
; =============================================================================
; [strong] pass 79 :: ct_cd_tick_two_auxiliary_descriptor_runtime_slots_and_interpret_ready_tokens
; qualifier: strong structural
; notes: Runs only while the optional auxiliary stage is active. Walks the two active `CA32` runtime slots. Decrements each slot countdown and calls `1654` whenever the countdown expires. `1654` treats `<80` bytes as data tokens, `7F` as a dedicated advance token, `FF` as end-of-slot, and `>=80` as command tokens dispatched through the large local jump table. Strongest safe reading: two-slot auxiliary descriptor stream scheduler/interpreter.
; source: chrono_trigger_labels_pass79.md
CD_1609_ct_cd_tick_two_auxiliary_descriptor_runtime_slots_and_interpret_ready_tokens:
    ; TODO: reconstruct body / data for CD:1609
    ; known span hint: CD:1609..CD:16A5

; =============================================================================
; CD:1654  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_interpret_one_auxiliary_stream_token_and_derive_d0_tile_block_request_or_dispatch_command
; qualifier: strong structural
; notes: Pulls one byte from the current active auxiliary runtime-slot stream. `0x7F` increments the stream pointer only. `< 0x7F` biases the token by `CA3A,X`, derives a `D0`-rooted tile-block source pointer into `CA18`, and increments `CA17`. `>= 0x80` dispatches through the command-token table at `16B5`. Strongest safe reading: one-token interpreter for the auxiliary stream VM.
; source: chrono_trigger_labels_pass80.md
CD_1654_ct_cd_interpret_one_auxiliary_stream_token_and_derive_d0_tile_block_request_or_dispatch_:
    ; TODO: reconstruct body / data for CD:1654
    ; known span hint: CD:1654..CD:169F

; =============================================================================
; CD:16A6  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_dispatch_one_auxiliary_command_token_80_ff_by_low7_id
; qualifier: strong
; notes: Saves the active slot base in `$43`. Advances the stream pointer by one byte. Dispatches command tokens `0x80..0xFF` through `16B5` using the token's low 7 bits.
; source: chrono_trigger_labels_pass80.md
CD_16A6_ct_cd_dispatch_one_auxiliary_command_token_80_ff_by_low7_id:
    ; TODO: reconstruct body / data for CD:16A6
    ; known span hint: CD:16A6..CD:16B4

; =============================================================================
; CD:16B5  top-status=strong  labels=2
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_command_token_ptr_table_80_ff
; qualifier: strong correction
; notes: This is not just a generic dispatch table anymore. It is now pinned as the main 128-command token pointer table for the auxiliary stream VM.
; source: chrono_trigger_labels_pass80.md
CD_16B5_ct_cd_auxiliary_command_token_ptr_table_80_ff:
    ; TODO: reconstruct body / data for CD:16B5
    ; known span hint: CD:16B5..CD:17A6

; [strong] pass 79 :: ct_cd_auxiliary_descriptor_token_dispatch_table
; qualifier: strong structural
; notes: Large local dispatch table reached from `16A6` for command bytes `>= 0x80`. Exact handler nouns remain open, but the dispatch-table role is now settled.
; source: chrono_trigger_labels_pass79.md
CD_16B5_ct_cd_auxiliary_descriptor_token_dispatch_table:
    ; TODO: reconstruct body / data for CD:16B5
    ; known span hint: CD:16B5..CD:17A6

; =============================================================================
; CD:17A9  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_f9_write_immediate_byte_to_absolute_target
; qualifier: strong
; notes: Reads one immediate byte and the following absolute 16-bit destination address. Writes the byte directly to that destination.
; source: chrono_trigger_labels_pass80.md
CD_17A9_ct_cd_auxiliary_token_f9_write_immediate_byte_to_absolute_target:
    ; TODO: reconstruct body / data for CD:17A9
    ; known span hint: CD:17A9..CD:17BD

; =============================================================================
; CD:17BE  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_f8_copy_one_indexed_2word_pair_between_2000_2200_tables
; qualifier: strong structural
; notes: Reads a source index and destination index from the stream. Copies one 2-word record from the `$2000/$2200` table families at the source index to the destination index.
; source: chrono_trigger_labels_pass80.md
CD_17BE_ct_cd_auxiliary_token_f8_copy_one_indexed_2word_pair_between_2000_2200_tables:
    ; TODO: reconstruct body / data for CD:17BE
    ; known span hint: CD:17BE..CD:17DE

; =============================================================================
; CD:17DF  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_f7_store_immediate_to_ce0e
; qualifier: strong
; notes: Exact tiny handler: store next stream byte to `CE0E`.
; source: chrono_trigger_labels_pass80.md
CD_17DF_ct_cd_auxiliary_token_f7_store_immediate_to_ce0e:
    ; TODO: reconstruct body / data for CD:17DF
    ; known span hint: CD:17DF..CD:17E4

; =============================================================================
; CD:17E5  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_f6_conditional_stream_rewind_by_immediate_when_ce10_allows
; qualifier: strong structural
; notes: Uses `CE10` as a one-shot latch/gate. If the gate condition passes, subtracts the immediate byte from the stream pointer and then clears `CE10`.
; source: chrono_trigger_labels_pass80.md
CD_17E5_ct_cd_auxiliary_token_f6_conditional_stream_rewind_by_immediate_when_ce10_allows:
    ; TODO: reconstruct body / data for CD:17E5
    ; known span hint: CD:17E5..CD:17FE

; =============================================================================
; CD:17FF  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_f5_store_immediate_to_cd46
; qualifier: strong
; notes: Exact tiny handler: store next stream byte to `CD46`.
; source: chrono_trigger_labels_pass80.md
CD_17FF_ct_cd_auxiliary_token_f5_store_immediate_to_cd46:
    ; TODO: reconstruct body / data for CD:17FF
    ; known span hint: CD:17FF..CD:1804

; =============================================================================
; CD:1805  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_f4_call_d1_ebff
; qualifier: strong
; notes: Exact wrapper token: `JSL D1:EBFF ; RTS`.
; source: chrono_trigger_labels_pass80.md
CD_1805_ct_cd_auxiliary_token_f4_call_d1_ebff:
    ; TODO: reconstruct body / data for CD:1805
    ; known span hint: CD:1805..CD:1809

; =============================================================================
; CD:180A  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_f3_store_immediate_to_cd45_and_increment_cd44
; qualifier: strong
; notes: Stores the immediate byte to `CD45`. Increments `CD44`. Strongest safe reading: seed the one-shot rewind/gate state later consumed by token `0xF2`.
; source: chrono_trigger_labels_pass80.md
CD_180A_ct_cd_auxiliary_token_f3_store_immediate_to_cd45_and_increment_cd44:
    ; TODO: reconstruct body / data for CD:180A
    ; known span hint: CD:180A..CD:1812

; =============================================================================
; CD:1813  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_f2_conditional_stream_rewind_by_immediate_when_cd44_allows
; qualifier: strong structural
; notes: Structural sibling of token `0xF6`. Uses `CD44` as the latch/gate and subtracts the immediate byte from the stream pointer when active.
; source: chrono_trigger_labels_pass80.md
CD_1813_ct_cd_auxiliary_token_f2_conditional_stream_rewind_by_immediate_when_cd44_allows:
    ; TODO: reconstruct body / data for CD:1813
    ; known span hint: CD:1813..CD:1829

; =============================================================================
; CD:182A  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_f1_copy_5d8f_into_indexed_caa4_slot
; qualifier: strong
; notes: Reads one immediate slot index byte. Copies stage/global byte `5D8F` into `CAA4 + index`.
; source: chrono_trigger_labels_pass80.md
CD_182A_ct_cd_auxiliary_token_f1_copy_5d8f_into_indexed_caa4_slot:
    ; TODO: reconstruct body / data for CD:182A
    ; known span hint: CD:182A..CD:1830

; =============================================================================
; CD:184B  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_f0_call_d1_efd0
; qualifier: strong
; notes: Exact wrapper token: `JSL D1:EFD0 ; RTS`.
; source: chrono_trigger_labels_pass80.md
CD_184B_ct_cd_auxiliary_token_f0_call_d1_efd0:
    ; TODO: reconstruct body / data for CD:184B
    ; known span hint: CD:184B..CD:184F

; =============================================================================
; CD:2A4A  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_80_extended_subopcode_dispatcher_32way
; qualifier: strong structural
; notes: Token `0x80` reads the following stream byte, doubles it, and dispatches through the local table at `2A51`. Strongest safe reading: extended/meta command family with 32 secondary sub-opcodes.
; source: chrono_trigger_labels_pass80.md
CD_2A4A_ct_cd_auxiliary_token_80_extended_subopcode_dispatcher_32way:
    ; TODO: reconstruct body / data for CD:2A4A
    ; known span hint: CD:2A4A..CD:2A8E

; =============================================================================
; CD:2A51  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_80_extended_subopcode_ptr_table_29_live_entries
; qualifier: strong correction
; notes: The table reached from token `0x80` does **not** expose a clean 32-entry live namespace. Straight ROM parsing gives live sub-op targets for `0x00..0x1C` only. After that, the bytes are ordinary code, not more valid pointer entries. Strongest safe reading: 29-entry live extended sub-op family.
; source: chrono_trigger_labels_pass81.md
CD_2A51_ct_cd_auxiliary_token_80_extended_subopcode_ptr_table_29_live_entries:
    ; TODO: reconstruct body / data for CD:2A51
    ; known span hint: CD:2A51..CD:2A89

; =============================================================================
; CD:2A8B  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_80_subop_1b_increment_8byte_strip_at_9ffa
; qualifier: strong structural
; notes: Starts with zeroed X and increments `9FFA,X` across eight consecutive byte positions. Final noun of the `9FFA..A001` strip is still open.
; source: chrono_trigger_labels_pass81.md
CD_2A8B_ct_cd_auxiliary_token_80_subop_1b_increment_8byte_strip_at_9ffa:
    ; TODO: reconstruct body / data for CD:2A8B
    ; known span hint: CD:2A8B..CD:2A96

; =============================================================================
; CD:2A97  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_80_subop_1c_call_d1_e8c1
; qualifier: strong
; notes: Exact wrapper: `JSL D1:E8C1 ; RTS`.
; source: chrono_trigger_labels_pass81.md
CD_2A97_ct_cd_auxiliary_token_80_subop_1c_call_d1_e8c1:
    ; TODO: reconstruct body / data for CD:2A97
    ; known span hint: CD:2A97..CD:2A9B

; =============================================================================
; CD:2A9C  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_80_subop_1a_call_d1_e899
; qualifier: strong
; notes: Exact wrapper: `JSL D1:E899 ; RTS`.
; source: chrono_trigger_labels_pass81.md
CD_2A9C_ct_cd_auxiliary_token_80_subop_1a_call_d1_e899:
    ; TODO: reconstruct body / data for CD:2A9C
    ; known span hint: CD:2A9C..CD:2AA0

; =============================================================================
; CD:2AA1  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_80_subop_19_increment_ce10_rewind_gate
; qualifier: strong
; notes: Exact one-byte latch setter. Increments `CE10` and returns. Strongest safe reading: arm/set path for the rewind gate later consumed by token `0xF6`.
; source: chrono_trigger_labels_pass81.md
CD_2AA1_ct_cd_auxiliary_token_80_subop_19_increment_ce10_rewind_gate:
    ; TODO: reconstruct body / data for CD:2AA1
    ; known span hint: CD:2AA1..CD:2AA4

; =============================================================================
; CD:2AA5  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_80_subop_18_call_d1_e91a
; qualifier: strong
; notes: Exact wrapper: `JSL D1:E91A ; RTS`.
; source: chrono_trigger_labels_pass81.md
CD_2AA5_ct_cd_auxiliary_token_80_subop_18_call_d1_e91a:
    ; TODO: reconstruct body / data for CD:2AA5
    ; known span hint: CD:2AA5..CD:2AA9

; =============================================================================
; CD:2AAA  top-status=strong  labels=2
; =============================================================================
; [strong] pass 82 :: ct_cd_auxiliary_token_80_subop_17_exact_wrapper_call_d1_e984
; qualifier: strong correction
; notes: Exact body: `JSL D1:E984 ; RTS`. The local code at `CD:2AAF..` belongs to the shared helper used by sub-op `0x16`, not to sub-op `0x17`.
; source: chrono_trigger_labels_pass82.md
CD_2AAA_ct_cd_auxiliary_token_80_subop_17_exact_wrapper_call_d1_e984:
    ; TODO: reconstruct body / data for CD:2AAA
    ; known span hint: CD:2AAA..CD:2AAE

; [provisional] pass 81 :: ct_cd_auxiliary_token_80_subop_17_d1_e984_anchored_local_setup_entry
; qualifier: provisional strengthened
; notes: Anchored by the exact wrapper call to `D1:E984`. Also advances `CD3B` and falls into a local lookup/copy follow-up. Strongest safe reading so far: local setup entry belonging to the same `E500/E850`-side family as sub-ops `0x15/0x16`.
; source: chrono_trigger_labels_pass81.md
CD_2AAA_ct_cd_auxiliary_token_80_subop_17_d1_e984_anchored_local_setup_entry:
    ; TODO: reconstruct body / data for CD:2AAA
    ; known span hint: CD:2AAA..CD:2AC5

; =============================================================================
; CD:2AC6  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_80_subop_16_run_tripled_setup_then_decrement_active_e500_by_10_where_e850_live
; qualifier: strong structural
; notes: Calls the shared local setup helper three times. Walks the same strided family and subtracts `0x0010` from `E500,X` when `E850,X` is nonzero. Final gameplay-facing noun of the `E500/E850` families remains open.
; source: chrono_trigger_labels_pass81.md
CD_2AC6_ct_cd_auxiliary_token_80_subop_16_run_tripled_setup_then_decrement_active_e500_by_10_whe:
    ; TODO: reconstruct body / data for CD:2AC6
    ; known span hint: CD:2AC6..CD:2AEE

; =============================================================================
; CD:2AEF  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_80_subop_15_clear_strided_e500_e502_pair_table
; qualifier: strong structural
; notes: Walks in 4-byte steps and clears `E500,X` and `E502,X` until `X == 0x06A0`. Strongest safe reading: clear pass over a strided pair-table family.
; source: chrono_trigger_labels_pass81.md
CD_2AEF_ct_cd_auxiliary_token_80_subop_15_clear_strided_e500_e502_pair_table:
    ; TODO: reconstruct body / data for CD:2AEF
    ; known span hint: CD:2AEF..CD:2B04

; =============================================================================
; CD:2B05  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_80_subop_14_seed_cd3a_0060_and_007c_0040
; qualifier: strong
; notes: Exact constant seeds: `CD3A = 0x0060` `$007C = 0x0040`
; source: chrono_trigger_labels_pass81.md
CD_2B05_ct_cd_auxiliary_token_80_subop_14_seed_cd3a_0060_and_007c_0040:
    ; TODO: reconstruct body / data for CD:2B05
    ; known span hint: CD:2B05..CD:2B11

; =============================================================================
; CD:2B12  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_80_subop_12_clamp_5da1_to_31_d4
; qualifier: strong
; notes: Exact clamp of `5DA1` into `[0x31, 0xD4]`.
; source: chrono_trigger_labels_pass81.md
CD_2B12_ct_cd_auxiliary_token_80_subop_12_clamp_5da1_to_31_d4:
    ; TODO: reconstruct body / data for CD:2B12
    ; known span hint: CD:2B12..CD:2B26

; =============================================================================
; CD:2B27  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_80_subop_11_seed_mirrored_pair_around_80_and_arm_99d2_bit7
; qualifier: strong structural
; notes: Sets `99D2.bit7`. Copies `99D3` into `05A5` and `0599`. Copies `0x80 - 99D3` into `05A6` and `059A`. Strongest safe reading: mirrored/complement pair seed around midpoint `0x80`.
; source: chrono_trigger_labels_pass81.md
CD_2B27_ct_cd_auxiliary_token_80_subop_11_seed_mirrored_pair_around_80_and_arm_99d2_bit7:
    ; TODO: reconstruct body / data for CD:2B27
    ; known span hint: CD:2B27..CD:2B44

; =============================================================================
; CD:2B45  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_80_subop_10_seed_e0_into_parallel_bb_bc_highbyte_tables
; qualifier: strong structural
; notes: Writes `0xE0` into `BB07,Y`, `BB87,Y`, and `BC07,Y` in a repeated stride pattern. Strongest safe reading: preset builder for three parallel high-byte tables.
; source: chrono_trigger_labels_pass81.md
CD_2B45_ct_cd_auxiliary_token_80_subop_10_seed_e0_into_parallel_bb_bc_highbyte_tables:
    ; TODO: reconstruct body / data for CD:2B45
    ; known span hint: CD:2B45..CD:2B5B

; =============================================================================
; CD:2B5C  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_80_subop_0f_clear_99b5_at_index_from_cd00
; qualifier: strong
; notes: Loads `CD00` into X and clears `99B5,X`.
; source: chrono_trigger_labels_pass81.md
CD_2B5C_ct_cd_auxiliary_token_80_subop_0f_clear_99b5_at_index_from_cd00:
    ; TODO: reconstruct body / data for CD:2B5C
    ; known span hint: CD:2B5C..CD:2B63

; =============================================================================
; CD:2D39  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_80_subop_13_seed_5d9a_then_build_parallel_bb_bc_tables
; qualifier: strong structural
; notes: Writes `5D9A = 1`. Seeds `A = 0x14`. Falls into the shared `2D53` parallel-table builder tail.
; source: chrono_trigger_labels_pass81.md
CD_2D39_ct_cd_auxiliary_token_80_subop_13_seed_5d9a_then_build_parallel_bb_bc_tables:
    ; TODO: reconstruct body / data for CD:2D39
    ; known span hint: CD:2D39..CD:2DC9

; =============================================================================
; CD:2D44  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_80_subop_0e_build_parallel_bb_bc_tables_fixed_a04
; qualifier: strong structural
; notes: Seeds `A = 0x04` and falls into the shared `2D53` builder tail.
; source: chrono_trigger_labels_pass81.md
CD_2D44_ct_cd_auxiliary_token_80_subop_0e_build_parallel_bb_bc_tables_fixed_a04:
    ; TODO: reconstruct body / data for CD:2D44
    ; known span hint: CD:2D44..CD:2DC9

; =============================================================================
; CD:2D4A  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_80_subop_00_countdown_variant_of_parallel_bb_bc_table_builder
; qualifier: strong structural
; notes: Clears/uses `CD04` and then enters the shared `2D53` builder tail. Strongest safe reading: countdown/variation member of the same table-builder family as `0x0E` and `0x13`.
; source: chrono_trigger_labels_pass81.md
CD_2D4A_ct_cd_auxiliary_token_80_subop_00_countdown_variant_of_parallel_bb_bc_table_builder:
    ; TODO: reconstruct body / data for CD:2D4A
    ; known span hint: CD:2D4A..CD:2DC9

; =============================================================================
; CD:2D53  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_80_shared_parallel_bb06_bb86_bc06_and_bb07_bb87_bc07_builder_tail
; qualifier: strong structural
; notes: Shared convergence tail used by sub-ops `0x00`, `0x0E`, and `0x13`. Writes repeated-stride values into: `BB06/BB07` `BB86/BB87` `BC06/BC07` Final gameplay-facing noun of these three parallel arrays remains one notch below frozen.
; source: chrono_trigger_labels_pass81.md
CD_2D53_ct_cd_auxiliary_token_80_shared_parallel_bb06_bb86_bc06_and_bb07_bb87_bc07_builder_tail:
    ; TODO: reconstruct body / data for CD:2D53
    ; known span hint: CD:2D53..CD:2DC9

; =============================================================================
; CD:2DCB  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_81_seed_slot_reload_and_current_countdown
; qualifier: strong
; notes: Writes the same immediate byte to `CA38,X` and `CA39,X`. Exact role: seed reload + current countdown for the active auxiliary runtime slot.
; source: chrono_trigger_labels_pass80.md
CD_2DCB_ct_cd_auxiliary_token_81_seed_slot_reload_and_current_countdown:
    ; TODO: reconstruct body / data for CD:2DCB
    ; known span hint: CD:2DCB..CD:2DD5

; =============================================================================
; CD:2DD6  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_82_apply_one_of_eight_paired_16bit_delta_ops_to_ca5e_ca60
; qualifier: strong structural
; notes: Low 5 bits + 1 of the immediate byte become the magnitude. High 3 bits select one of eight local sub-ops through `2DEA`. Those sub-ops apply all sign-combination variants over the paired 16-bit fields at `CA5E,X` and `CA60,X`. Strongest safe reading: paired-delta operator token for the auxiliary VM.
; source: chrono_trigger_labels_pass80.md
CD_2DD6_ct_cd_auxiliary_token_82_apply_one_of_eight_paired_16bit_delta_ops_to_ca5e_ca60:
    ; TODO: reconstruct body / data for CD:2DD6
    ; known span hint: CD:2DD6..CD:2E9F

; =============================================================================
; CD:2DEA  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_82_paired_delta_subop_ptr_table_8
; qualifier: strong
; notes: Exact eight-entry local pointer table used by token `0x82`. Dispatches the paired add/subtract variants over `CA5E/CA60`.
; source: chrono_trigger_labels_pass80.md
CD_2DEA_ct_cd_auxiliary_token_82_paired_delta_subop_ptr_table_8:
    ; TODO: reconstruct body / data for CD:2DEA
    ; known span hint: CD:2DEA..CD:2DF9

; =============================================================================
; CD:2EA2  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_83_seed_repeat_resume_pointer_and_repeat_count
; qualifier: strong
; notes: Stores the current stream pointer to `CA72,X`. Stores `immediate + 1` to `CA74,X`. Exact role: repeat-loop seed token.
; source: chrono_trigger_labels_pass80.md
CD_2EA2_ct_cd_auxiliary_token_83_seed_repeat_resume_pointer_and_repeat_count:
    ; TODO: reconstruct body / data for CD:2EA2
    ; known span hint: CD:2EA2..CD:2EB4

; =============================================================================
; CD:2EB5  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_84_repeat_until_countdown_exhausted_then_consume_trailing_byte
; qualifier: strong structural
; notes: Decrements `CA74,X`. While nonzero, rewinds the stream pointer back to `CA72,X`. When exhausted, consumes one trailing byte and falls through.
; source: chrono_trigger_labels_pass80.md
CD_2EB5_ct_cd_auxiliary_token_84_repeat_until_countdown_exhausted_then_consume_trailing_byte:
    ; TODO: reconstruct body / data for CD:2EB5
    ; known span hint: CD:2EB5..CD:2EC7

; =============================================================================
; CD:2EC8  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_85_seed_repeat_resume_pointer_and_clear_ca3a
; qualifier: strong structural
; notes: Same repeat-loop seed pattern as token `0x83`. Also clears `CA3A,X`.
; source: chrono_trigger_labels_pass80.md
CD_2EC8_ct_cd_auxiliary_token_85_seed_repeat_resume_pointer_and_clear_ca3a:
    ; TODO: reconstruct body / data for CD:2EC8
    ; known span hint: CD:2EC8..CD:2EDD

; =============================================================================
; CD:2EDE  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_token_86_repeat_with_iteration_counter_in_ca3a
; qualifier: strong structural
; notes: Same repeat-loop behavior as token `0x84`. Increments `CA3A,X` each loop iteration. Clears `CA3A,X` when the loop terminates.
; source: chrono_trigger_labels_pass80.md
CD_2EDE_ct_cd_auxiliary_token_86_repeat_with_iteration_counter_in_ca3a:
    ; TODO: reconstruct body / data for CD:2EDE
    ; known span hint: CD:2EDE..CD:2EF6

