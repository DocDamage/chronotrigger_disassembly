# Source State Index

Generated from the persistent label DB.

## 7E
- File: `source/banks/wram_7E.asm`
- Address groups: **123**
- Rows: **196**

## C0
- File: `source/banks/bank_C0.asm`
- Address groups: **3**
- Rows: **3**

## C1
- File: `source/banks/bank_C1.asm`
- Address groups: **193**
- Rows: **213**

## C3
- File: `source/banks/bank_C3.asm`
- Address groups: **2**
- Rows: **2**

## CC
- File: `source/banks/bank_CC.asm`
- Address groups: **10**
- Rows: **13**

## CD
- File: `source/banks/bank_CD.asm`
- Address groups: **56**
- Rows: **58**

## CF
- File: `source/banks/bank_CF.asm`
- Address groups: **1**
- Rows: **1**

## D0
- File: `source/banks/bank_D0.asm`
- Address groups: **1**
- Rows: **1**

## D1
- File: `source/banks/bank_D1.asm`
- Address groups: **14**
- Rows: **22**

## FD
- File: `source/banks/bank_FD.asm`
- Address groups: **18**
- Rows: **21**

