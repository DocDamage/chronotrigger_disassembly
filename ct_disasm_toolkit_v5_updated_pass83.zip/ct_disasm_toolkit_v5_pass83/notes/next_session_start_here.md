# Next Session Start Here

1. Read `notes/community_research_first.md`
2. Open these in order:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `dossiers/D1_dossier.md`
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - `chrono_trigger_disasm_pass82.md`
   - `chrono_trigger_labels_pass82.md`
   - `chrono_trigger_disasm_pass83.md`
   - `chrono_trigger_labels_pass83.md`
3. Active top-of-stack seam after pass 83:
   - find the mapped runtime writer that drives `CFFF` nonzero for the `D1:F431 / F457` suspend-vs-restore gate
   - tighten `CDC8` and `CE0F` now that `CE12` is locally much clearer
   - explain why the suspend path clears only positive `0x1x` palette-animation headers while sparing the signed `0x8x` family
   - freeze the exact role of the tail descriptor slots at `0568..057F`
   - then return to the remaining auxiliary command families at `0x88..0x9F`
4. Specific cleanup targets:
   - decide whether the `2040/20A0/2120/21A0/2240/22A0/2320/23A0` families are best frozen as palette pages, palette lanes, or another tighter noun
   - decide whether `CD2F..CD36` should be described as a descriptor-header mirror, shadow bank, or another stricter noun
   - tighten the exact `+1` and `+4` field nouns inside the `0520` / `0544` slabs as used by `E91A / E984`
   - decide whether `D0:FD00..FD5F` should be frozen as a default seed page, boot page, or another stricter palette-band noun
   - tighten the exact roles of `A101`, `2A21.bit1`, and the `0575.bit6` toggle in `D1:E70A`
5. Runtime confirmation shortlist:
   - `D1:F431` one-shot shadow-and-suspend behavior when `CE12` is zero vs nonzero
   - `D1:F457` restore behavior and `CE12` clear path
   - mapped runtime writer(s) for `CFFF`
   - `D1:E70A` pre-toggle over `A101 / 2A21 / 0575`
   - exact live effect of the `2120/21A0` and `2320/23A0` exchange on battle/UI presentation
