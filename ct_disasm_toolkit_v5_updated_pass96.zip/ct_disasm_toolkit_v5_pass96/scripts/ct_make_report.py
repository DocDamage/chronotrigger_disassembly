#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import re
import sqlite3
from pathlib import Path


PASS_RE = re.compile(r'Latest completed pass:\s*\*\*(\d+)\*\*', re.IGNORECASE)
SEAM_RE = re.compile(r'## Best next seam\s*(.*?)(?:\n## |\Z)', re.IGNORECASE | re.DOTALL)


def read_csv_rows(path: Path):
    if not path.exists():
        return []
    with path.open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def read_next_session(root: Path) -> tuple[int | None, str]:
    note = root / 'notes' / 'next_session_start_here.md'
    if not note.exists():
        return None, ''
    text = note.read_text(encoding='utf-8')
    pass_match = PASS_RE.search(text)
    seam_match = SEAM_RE.search(text)
    seam = ''
    if seam_match:
        seam = ' '.join(line.strip('- ').strip() for line in seam_match.group(1).strip().splitlines() if line.strip())
        seam = seam.replace('**', '').replace('`', '')
    return (int(pass_match.group(1)) if pass_match else None), seam


def main() -> None:
    ap = argparse.ArgumentParser(description='Generate a workspace state report from the current toolkit data.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--output', default='reports/ct_workspace_report.md')
    ap.add_argument('--state-json', default='state/current_state.json')
    args = ap.parse_args()
    root = Path(args.root)
    con = sqlite3.connect(root / args.db)
    cur = con.cursor()
    row_count = cur.execute('SELECT COUNT(*) FROM labels').fetchone()[0]
    latest_pass_db = cur.execute('SELECT MAX(pass_num) FROM labels').fetchone()[0] or 0
    strong = cur.execute("SELECT COUNT(*) FROM labels WHERE status_bucket='strong'").fetchone()[0]
    provisional = cur.execute("SELECT COUNT(*) FROM labels WHERE status_bucket='provisional'").fetchone()[0]
    alias = cur.execute("SELECT COUNT(*) FROM labels WHERE status_bucket='alias'").fetchone()[0]
    caution = cur.execute("SELECT COUNT(*) FROM labels WHERE status_bucket='caution'").fetchone()[0]
    runtime_tables = {r[0] for r in cur.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    runtime_rows = cur.execute('SELECT COUNT(*) FROM runtime_evidence').fetchone()[0] if 'runtime_evidence' in runtime_tables else 0
    con.close()

    note_pass, seam_from_note = read_next_session(root)
    latest_pass = max(latest_pass_db, note_pass or 0)

    master_rows = read_csv_rows(root / 'data' / 'ct_c1_master_opcode_coverage_full.csv')
    selector_rows = read_csv_rows(root / 'data' / 'ct_c1_selector_control_coverage_full.csv')
    service7_rows = read_csv_rows(root / 'data' / 'ct_service7_wrapper_coverage_full.csv')
    xref_path = root / 'data' / 'ct_hot_xref_cache.json'
    xref_targets = 0
    if xref_path.exists():
        xref_targets = len(json.loads(xref_path.read_text(encoding='utf-8')).get('targets', {}))
    completion_path = root / 'reports' / 'completion' / 'ct_completion_score.json'
    completion = {'overall_completion_percent': 38}
    if completion_path.exists():
        completion = json.loads(completion_path.read_text(encoding='utf-8'))

    live_seam = seam_from_note or 'See notes/next_session_start_here.md for the current seam.'

    state = {
        'latest_pass': latest_pass,
        'current_live_seam': live_seam,
        'completion_estimate_percent': completion.get('overall_completion_percent', 38),
        'label_rows': row_count,
        'strong_labels': strong,
        'provisional_labels': provisional,
        'alias_labels': alias,
        'caution_labels': caution,
        'runtime_evidence_rows': runtime_rows,
        'xref_cache_targets': xref_targets,
        'rom_expected_crc32': '2D206BF7',
        'rom_expected_md5': 'a2bc447961e52fd2227baed164f729dc',
    }
    state_path = root / args.state_json
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(json.dumps(state, indent=2), encoding='utf-8')

    lines = [
        '# Chrono Trigger Workspace Report', '',
        '## Current top-of-stack',
        f"- Latest pass: **{latest_pass}**",
        f"- Current live seam: **{state['current_live_seam']}**",
        f"- Completion estimate: **~{state['completion_estimate_percent']}%**", '',
        '## Label database',
        f"- Total label rows: **{row_count}**",
        f"- Strong: **{strong}**",
        f"- Provisional: **{provisional}**",
        f"- Alias: **{alias}**",
        f"- Caution: **{caution}**",
        f"- Runtime evidence rows: **{runtime_rows}**", '',
        '## Coverage worksheets',
        f"- Master C1 global opcode worksheet rows: **{len(master_rows)}**",
        f"- Selector-control worksheet rows: **{len(selector_rows)}**",
        f"- Service-7 wrapper worksheet rows: **{len(service7_rows)}**", '',
        '## Xref cache', f"- Hot targets cached: **{xref_targets}**", '',
        '## Generated artifacts',
        '- `reports/ct_completion_score.md`',
        '- `reports/ct_conflict_report.md`',
        '- `reports/code_data_score.md`',
        '- `graph/ct_knowledge_graph_summary.md`',
        '- `reports/ct_unresolved_dashboard.md`',
        '- `reports/ct_dispatch_family_report.md`',
        '- `reports/ct_apu_packet_summary.md`',
        '- `reports/ct_source_state.md`',
        '- `reports/ct_rebuild_diff_report.md`',
        '- `asm_skeleton/banks/`', '',
        '## Immediate next work',
        '1. Read `notes/next_session_start_here.md` and stay on that seam before going broad.',
        '2. Use `reports/ct_dispatch_family_report.md` when you are dealing with veneers, opcode families, or packet dispatchers.',
        '3. Use `reports/ct_apu_packet_summary.md` when the work touches the C7 sound/APU packet side.',
        '4. Import runtime evidence when static ownership proof stalls.', '',
        '## Still required for full disassembly',
        '- Complete bank-by-bank code/data separation across the untouched ROM banks',
        '- Finish decompressor grammar / format work',
        '- Freeze subsystem ownership boundaries across banks',
        '- Build a rebuildable source tree and validate against ROM fingerprints',
        ''
    ]
    out = root / args.output
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text('\n'.join(lines), encoding='utf-8')
    print(out)
    print(state_path)


if __name__ == '__main__':
    main()
