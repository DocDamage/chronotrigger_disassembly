# Next Session Start Here

1. Read `notes/community_research_first.md`
2. Open these in order:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `dossiers/D1_dossier.md`
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - `chrono_trigger_disasm_pass86.md`
   - `chrono_trigger_labels_pass86.md`
   - `chrono_trigger_disasm_pass87.md`
   - `chrono_trigger_labels_pass87.md`
3. Active top-of-stack seam after pass 87:
   - identify the exact downstream consumer(s) of the four WRAM target strips rooted by `CD:38AA..38B1`
   - decide whether the rasterized `CD0D..CD1B` four-point bundle is best described finally as a quad, mask polygon, panel/wipe primitive, or another nearby presentation noun
   - find the first exact producer/consumer pair that explains the meaning of `7E:C161 / C163 / C4E1 / C4E3`
   - then return to the first exact external reader(s) of `CE0F`
4. Specific cleanup targets:
   - determine whether the `CC64.bit0 + 7C.bit0` four-way selector is selecting planes, pages, double-buffer lanes, or another tighter noun
   - find whether `D1:FB68 / FB72` advance the same column-raster target family that `F9E7` writes into
   - tighten the final noun of the `CD47..CDC6` strip once a real producer/consumer pair is found
   - keep being strict about low-half code/data separation: trust low-half hits only when real callers or coherent helper bodies prove them
5. Runtime confirmation shortlist:
   - downstream consumer(s) of the WRAM target strips seeded by `CD:38B2`
   - exact meaning of the four bases `C161 / C163 / C4E1 / C4E3`
   - first exact external reader(s) of `CE0F`
   - confirmation that the `EC28 -> F9AF` path is a presentation/mask/polygon raster path rather than another nearby primitive family
