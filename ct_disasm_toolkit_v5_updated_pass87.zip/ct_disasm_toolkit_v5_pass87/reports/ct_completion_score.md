# Completion Score

- Latest pass: **87**
- Overall completion estimate: **~61.2%**

## Weighted components
- Label semantics: **76.0%**
- Opcode coverage: **92.5%**
- Bank separation: **24.0%**
- Rebuild readiness: **8.1%**

## Coverage counts
- Master C1 opcodes: **170/170**
- Selector-control bytes: **83/83**
- Service-7 wrappers: **5/8**

## Interpretation
- This is a structured estimate, not a fake “almost done” claim.
- This pass materially tightened **semantic coverage** by freezing the `F8EB / F91C / F972 / F9AF / F9E7` cluster as a real column-raster family.
- The expensive endgame still remains code/data separation, decompressor work, and assembler-valid source lift.
