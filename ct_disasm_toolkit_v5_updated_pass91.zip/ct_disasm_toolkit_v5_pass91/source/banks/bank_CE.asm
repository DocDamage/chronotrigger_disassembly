; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_CE
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; CE:E000  top-status=strong  labels=1
; =============================================================================
; [strong] pass 88 :: ct_ce_mirror_selected_0x6c_band_between_primary_and_shadow_eight_table_raster_target_bundles
; qualifier: strong structural
; notes: Reads one byte from `[$40]`, doubles it, computes stop offset `start + 0x006C`, then mirrors that selected band across eight exact root tables. Exact primary roots: `C161 / C1CD / C239 / C2A5 / C311 / C37D / C3E9 / C455`. Exact shadow roots: `C4E1 / C54D / C5B9 / C625 / C691 / C6FD / C769 / C7D5`. When `7C.bit0 != 0`, direction is primary -> shadow; otherwise shadow -> primary. Strongest safe reading: selected-band mirror helper for one `0x6C` raster-target bundle family.
; source: chrono_trigger_labels_pass88.md
CE_E000_ct_ce_mirror_selected_0x6c_band_between_primary_and_shadow_eight_table_raster_target_bun:
    ; TODO: reconstruct body / data for CE:E000
    ; known span hint: CE:E000..CE:E08D

; =============================================================================
; CE:E18E  top-status=strong  labels=1
; =============================================================================
; [strong] pass 86 :: ct_ce_clear_cd47_cdc6_work_strip_only_when_cdc8_nonzero
; qualifier: strong structural
; notes: Exact body: `LDA $CDC8 ; BEQ return ; TDC ; TAX ; REP #$20 ; STZ $CD47,X ; INX ; INX ; CPX #$0080 ; BNE loop ; TDC ; SEP #$20 ; RTL`. Exact behavior: if `CDC8 == 0`, return immediately. If `CDC8 != 0`, clear the exact `0x80`-byte strip `CD47..CDC6`. Strongest safe reading: first exact external `CDC8` reader; nonzero-gated clear helper for one D1-adjacent work strip.
; source: chrono_trigger_labels_pass86.md
CE_E18E_ct_ce_clear_cd47_cdc6_work_strip_only_when_cdc8_nonzero:
    ; TODO: reconstruct body / data for CE:E18E
    ; known span hint: CE:E18E..CE:E1A4

; =============================================================================
; CE:EE6E  top-status=strong  labels=1
; =============================================================================
; [strong] pass 91 :: ct_ce_seed_nine_stride_2d_template_records_into_c867_c9ec_from_selector_offset_table_and_2a21_side_bit
; qualifier: strong structural
; notes: Entry `A` is doubled with `ASL A` and used to index the exact 16-bit offset table at `CE:F24E`. The fetched word becomes an exact byte offset into the flat source-record family rooted at `CE:F58E`. The routine loads 9 exact source offsets from one 10-word source record. The seventh copied block is selected from one of two exact record words depending on `2A21.bit0`. Uses 9 exact `MVN` copies from bank `CE` to bank `7E`, each with `A = 0x001D`, so each copy is exactly `0x1E` bytes long. Exact destination roots are: `C867`, `C894`, `C8C1`, `C8EE`, `C91B`, `C948`, `C975`, `C9A2`, `C9CF`. Those roots are spaced by an exact stride of `0x2D` bytes. Strongest safe reading: selector/side-driven template-record seeder for the nine-record `C867..C9EC` workspace.
; source: chrono_trigger_labels_pass91.md
CE_EE6E_ct_ce_seed_nine_stride_2d_template_records_into_c867_c9ec_from_selector_offset_table_and:
    ; TODO: reconstruct body / data for CE:EE6E
    ; known span hint: CE:EE6E..CE:EF0D

