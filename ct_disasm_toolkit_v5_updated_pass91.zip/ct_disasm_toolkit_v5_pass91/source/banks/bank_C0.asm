; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_C0
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; C0:0008  top-status=strong  labels=1
; =============================================================================
; [strong] pass 91 :: ct_c0_branch_long_to_1bab_conditional_c70004_packet_submitter_veneer
; qualifier: strong
; notes: Exact body: `BRL $1BA0`. Lands at exact target `C0:1BAB`. Strongest safe reading: veneer for the conditional packet-submit helper behind the pass-90 follow-up tail.
; source: chrono_trigger_labels_pass91.md
C0_0008_ct_c0_branch_long_to_1bab_conditional_c70004_packet_submitter_veneer:
    ; TODO: reconstruct body / data for C0:0008
    ; known span hint: C0:0008..C0:000A

; =============================================================================
; C0:1BAB  top-status=strong  labels=1
; =============================================================================
; [strong] pass 91 :: ct_c0_submit_one_of_two_c70004_command_packets_by_2a1f_bit6
; qualifier: strong structural
; notes: Saves `B` and `D`, sets `D = 0x0100`, and sets `DB = 0x00`. Reads `7E:2A1F` and branches on exact mask `0x40`. If `2A1F.bit6 == 0`: writes `1E10 = 0xFF` writes `1E01` from exact direct-page byte `$FA` after `D = 0x0100` writes `1E00 = 0x14` then calls `JSL C7:0004` If `2A1F.bit6 != 0`: writes `1E01 = 0x01` writes `1E00 = 0x70` then calls `JSL C7:0004` Restores `D` and `B`, then returns with `RTL`. Strongest safe reading: conditional one-packet `C7:0004` submit helper behind `C0:0008`.
; source: chrono_trigger_labels_pass91.md
C0_1BAB_ct_c0_submit_one_of_two_c70004_command_packets_by_2a1f_bit6:
    ; TODO: reconstruct body / data for C0:1BAB
    ; known span hint: C0:1BAB..C0:1BE5

; =============================================================================
; C0:A270  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 48 :: ct_c0_parallel_source_plane_consumer_band
; qualifier: strengthened
; notes: Not promoted to a final high-level subsystem name. But this band now has stronger proven structure: reads `7F:0C00/X`, `7F:0C80/X`, `7F:0E00/X`, `7F:0E80/X` consumes those families as parallel source planes in a downstream copy path This materially strengthens the producer/consumer relationship from the strip/record side.
; source: chrono_trigger_labels_pass48.md
C0_A270_ct_c0_parallel_source_plane_consumer_band:
    ; TODO: reconstruct body / data for C0:A270
    ; known span hint: C0:A270..C0:A335

; =============================================================================
; C0:A2B0  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 47 :: consumer path                                           [unlabeled as final routine]
; notes: Pass 47 found direct `0E00/0E80` read-side proof there. Exact routine entry and full higher-level purpose are still open. The consumer relationship is real; the final routine label is not ready yet.
; source: chrono_trigger_labels_pass47.md
C0_A2B0_consumer_path_unlabeled_as_final_routine:
    ; TODO: reconstruct body / data for C0:A2B0
    ; known span hint: C0:A2B0..C0:A335

; =============================================================================
; C0:FD00  top-status=strong  labels=1
; =============================================================================
; [strong] pass 79 :: ct_c0_bit_reverse_lookup_256
; qualifier: strong
; notes: Exact 256-byte bit-reversal table. Example mappings: `01->80`, `02->40`, `03->C0`. Used directly by the `1445` horizontal-flip tile path.
; source: chrono_trigger_labels_pass79.md
C0_FD00_ct_c0_bit_reverse_lookup_256:
    ; TODO: reconstruct body / data for C0:FD00
    ; known span hint: C0:FD00..C0:FDFF

