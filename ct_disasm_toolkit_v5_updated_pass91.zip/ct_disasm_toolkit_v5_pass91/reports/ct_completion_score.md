# Completion Score

- Latest pass: **91**
- Overall completion estimate: **~61.2%**

## Weighted components
- Label semantics: **76.2%**
- Opcode coverage: **92.5%**
- Bank separation: **24.0%**
- Rebuild readiness: **8.0%**

## Coverage counts
- Master C1 opcodes: **170/170**
- Selector-control bytes: **83/83**
- Service-7 wrappers: **5/8**

## Interpretation
- This is a structured estimate, not a fake “almost done” claim.
- Semantic coverage is materially ahead of rebuild readiness.
- The expensive endgame remains code/data separation, decompressor work, and assembler-valid source lift.
