# Next Session Start Here

1. Read `notes/community_research_first.md`
2. Run `python3 scripts/ct_resume_workspace.py --workdir .`
3. Open these in order:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `dossiers/C1_dossier.md`
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - latest pass + labels
4. Active top-of-stack seam:
   - early global opcode band inside `C1:B80D..C1:B95F`
5. Runtime confirmation targets live in:
   - `targets/trace_packs/`
   - `notes/bsnes_trace_targets.md`
