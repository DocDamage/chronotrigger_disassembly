# ROM / WRAM Coverage View

Lower-bound coverage only. Point labels count as a single byte unless a wider range is explicitly known.

## 7E
- Covered bytes: **841** / 65536 (**1.283%**)
- Labels: **122**  strong=39 provisional=45 caution=0 alias=0

## C0
- Covered bytes: **198** / 65536 (**0.302%**)
- Labels: **2**  strong=0 provisional=1 caution=0 alias=0

## C1
- Covered bytes: **1879** / 65536 (**2.867%**)
- Labels: **55**  strong=40 provisional=7 caution=1 alias=0

## CC
- Covered bytes: **369** / 65536 (**0.563%**)
- Labels: **13**  strong=10 provisional=2 caution=0 alias=0

## CF
- Covered bytes: **1** / 65536 (**0.002%**)
- Labels: **1**  strong=1 provisional=0 caution=0 alias=0

## D1
- Covered bytes: **4** / 65536 (**0.006%**)
- Labels: **12**  strong=4 provisional=6 caution=0 alias=0

## FD
- Covered bytes: **471** / 65536 (**0.719%**)
- Labels: **18**  strong=10 provisional=6 caution=0 alias=0

