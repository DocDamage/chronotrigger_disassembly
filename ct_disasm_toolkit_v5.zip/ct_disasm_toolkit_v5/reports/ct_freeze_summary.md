# Range Freeze Summary

This file is the V5 range lock / freeze map.

- Total frozen/stable ranges: **104**

## 7E
- Entries: **39**
- `7E:0B40` :: **confirmed** :: / 00:0B40  ct_c1_tilemap_staging_buffer_vram7a00_0180        [strong]
- `7E:0B40` :: **confirmed** :: / 00:0B40  ct_c1_tilemap_strip_buffer_32x6_words_vram7a00     [strong]
- `7E:5E2F.bit0` :: **confirmed** :: ct_c1_lane_low_hp_critical_flag                      [strong]
- `7E:5E30` :: **confirmed** :: ct_c1_lane_current_hp
- `7E:5E32` :: **confirmed** :: ct_c1_lane_max_hp
- `7E:93EE` :: **confirmed** :: ct_c1_service7_record_status_flags
- `7E:93EF` :: **confirmed** :: ct_c1_service7_record_aux_flags
- `7E:93F3` :: **confirmed** :: ct_c1_service7_record_lane_pair
- `7E:9499` :: **confirmed** :: ct_c1_decimal_tile_format_input_u16
- `7E:949C..7E:949F` :: **confirmed** :: ct_c1_decimal_tile_format_output_4bytes
- `7E:95D6` :: **confirmed** :: ct_c1_pending_lane_admission_queue
- `7E:95DA` :: **confirmed** :: ct_c1_pending_lane_admission_count
- `7E:99E2` :: **confirmed** :: ct_c1_tilemap_upload_pending_counter
- `7E:A10F` :: **confirmed** :: ct_c1_lane_hp_threshold_numeric_attr_selector
- `7E:A6D9` :: **confirmed** :: ct_c1_active_lane_roster_marker_per_lane
- `7E:A6DD` :: **confirmed** :: ct_c1_current_active_lane
- `7E:A6DE` :: **confirmed** :: ct_c1_active_lane_count
- `7E:AEC5` :: **confirmed** :: ct_visible_head_occupied_slot_count
- `7E:AEC6` :: **confirmed** :: ct_canonical_tail_slot_count
- `7E:AEFF..AF09` :: **confirmed** :: ct_battle_slot_live_occupant_map
- ... 19 more

## C1
- Entries: **40**
- `C1:011B` :: **confirmed** :: ct_c1_lsr3_entry
- `C1:011F` :: **confirmed** :: ct_c1_format_u16_as_three_decimal_tile_bytes_949d_949f
- `C1:0174` :: **confirmed** :: ct_c1_format_u16_as_two_decimal_tile_bytes_949e_949f
- `C1:06F0` :: **confirmed** :: ct_c1_render_scaled_lane_bar_into_0cc0
- `C1:07BD` :: **confirmed** :: ct_c1_blit_companion_strip_template_a_into_0cc0_pair29
- `C1:07EE` :: **confirmed** :: ct_c1_blit_companion_strip_template_b_into_0cc0_pair29
- `C1:081F` :: **confirmed** :: ct_c1_compose_three_slot_panel_strip_into_0b40
- `C1:086D` :: **confirmed** :: ct_c1_clear_current_companion_strip_slice_0cc0
- `C1:08E8` :: **confirmed** :: ct_c1_update_current_companion_strip_slice
- `C1:0929` :: **confirmed** :: ct_c1_blit_6row_panel_segment_into_0b40_merge_left_border
- `C1:0958` :: **confirmed** :: ct_c1_rebuild_companion_record_buffer_0e80
- `C1:09B0` :: **confirmed** :: ct_c1_emit_fixed_format_companion_record
- `C1:104E` :: **confirmed** :: ct_c1_blank_leading_zero_decimal_tiles_949d_949e
- `C1:1918` :: **confirmed** :: ct_c1_refresh_current_0e80_lane_marker_glyphs
- `C1:1B19` :: **confirmed** :: ct_c1_service1_enqueue_lane_and_mark_record_active
- `C1:1B69` :: **confirmed** :: ct_c1_promote_pending_lane_into_active_roster
- `C1:1BAA` :: **confirmed** :: ct_c1_service2_remove_lane_and_reseat_active_controller
- `C1:1C3A` :: **confirmed** :: ct_c1_service2_restore_default_tilemap_template_0b40
- `C1:1C3A` :: **confirmed** :: ct_c1_service2_restore_workspace_template_0b40
- `C1:8C0A..C1:8C37` :: **confirmed** :: ct_iterate_live_unwithheld_tail_entries_for_dispatch
- ... 20 more

## CC
- Entries: **10**
- `CC:2E31` :: **confirmed** :: ct_cc_battle_speed_page_speed_to_readiness_seed_adjust_table
- `CC:2E31` :: **confirmed** :: ct_cc_speed_like_stat_to_readiness_bonus_table
- `CC:8B08..CC:8C53` :: **confirmed** :: ct_late_selector_control_pointer_records
- `CC:94A0` :: **confirmed** :: ct_cc_companion_record_template_table
- `CC:F903` :: **confirmed** :: ct_cc_decimal_digit_tile_table_73_to_7c
- `CC:FA23..CC:FA3F` :: **confirmed** :: ct_cc_companion_strip_lane_anchor_offset_family
- `CC:FA41` :: **confirmed** :: ct_cc_companion_strip_template_a_6x7_bytes
- `CC:FA6B` :: **confirmed** :: ct_cc_companion_strip_template_b_6x7_bytes
- `CC:FADD` :: **confirmed** :: ct_cc_companion_strip_lane_block_offsets_0000_0080_0100
- `CC:FAE9` :: **confirmed** :: ct_cc_companion_record_lane_marker_offsets_0002_0082_0102

## CF
- Entries: **1**
- `CF:E380` :: **confirmed** :: ct_cf_upload_pending_tilemap_0b40_to_vram_7a00

## D1
- Entries: **4**
- `D1:5800` :: **confirmed** :: ct_d1_tilemap_template_default_0b40_0180
- `D1:59FC` :: **confirmed** :: ct_d1_panel_segment_template_6x7_words
- `D1:5A50` :: **confirmed** :: ct_d1_tilemap_template_alt_a_0b40_0180
- `D1:5BD0` :: **confirmed** :: ct_d1_tilemap_template_alt_b_0b40_0180

## FD
- Entries: **10**
- `FD:A8A5` :: **confirmed** :: ct_fd_service7_lane_block_is_eligible
- `FD:A8CE` :: **confirmed** :: ct_fd_service7_clear_canonical_record_lane
- `FD:A8FE` :: **confirmed** :: ct_fd_service7_clear_occupied_lane_and_refresh_service2
- `FD:A93C` :: **confirmed** :: ct_fd_service7_dispatch_enabled_lane_clear_phase
- `FD:A95F` :: **confirmed** :: ct_fd_service7_dispatch_enabled_lane_refresh_phase
- `FD:B2A3..B2DD` :: **confirmed** :: ct_build_tail_live_and_canonical_occupant_maps
- `FD:B800..FD:B94F` :: **confirmed** :: ct_fd_seed_battle_slot_readiness_head_and_tail_partitions
- `FD:B820..FD:B850` :: **confirmed** :: ct_fd_seed_primary_visible_lane_readiness_from_config_and_speed
- `FD:B820..FD:B850` :: **confirmed** :: ct_fd_seed_visible_lane_readiness_from_speed_like_stat
- `FD:B8F7..FD:B93A` :: **confirmed** :: ct_fd_normalize_active_battle_slot_readiness_to_minimum_one_before_head_export

