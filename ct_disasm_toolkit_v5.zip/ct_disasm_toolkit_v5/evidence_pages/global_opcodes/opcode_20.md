# Global Opcode 20

- Status: **observed**
- Dispatch address: **unresolved**
- Evidence pass: **61**
- Notes: Observed in late-pack fed opcode set from pass 61

## Matching label evidence
- no direct label rows matched yet
