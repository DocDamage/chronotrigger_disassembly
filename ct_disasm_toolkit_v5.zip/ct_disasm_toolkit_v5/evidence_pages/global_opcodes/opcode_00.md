# Global Opcode 00

- Status: **observed**
- Dispatch address: **C1:B80D**
- Evidence pass: **61**
- Notes: Observed in late-pack fed opcode set from pass 61

## Matching label evidence
- pass 61: `C1:B80D..C1:B95F` **ct_c1_master_opcode_dispatch_table** (strong)
  - Root indexed `JSR` table used by the late-pack executor. Interior slices line up exactly with the previously solved local tables. Current proven slice offsets: global `0x29..0x3F` -> `B85F..B88C` global `0x40..0x52` -> `B88D..B8BA` global `0x57..0xA9` -> `B8BB..B95F`
