# Global Opcode 0F

- Status: **unknown**
- Dispatch address: **unresolved**
- Evidence pass: **n/a**
- Notes: n/a

## Matching label evidence
- no direct label rows matched yet
