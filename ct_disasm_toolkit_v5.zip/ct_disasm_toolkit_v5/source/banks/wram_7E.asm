; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: wram_7E
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; 7E:0B40  top-status=strong  labels=4
; =============================================================================
; [strong] pass 45 :: / 00:0B40  ct_c1_tilemap_strip_buffer_32x6_words_vram7a00     [strong]
; notes: Corrected from pass 44’s provisional geometry. The proven row stride from `C1:0929` is `0x40` bytes, yielding a 32-word by 6-row layout
; source: chrono_trigger_labels_pass45.md
L_7E_0B40_00_0B40_ct_c1_tilemap_strip_buffer_32x6_words_vram7a00_strong:
    ; TODO: reconstruct body / data for 7E:0B40

; [strong] pass 44 :: / 00:0B40  ct_c1_tilemap_staging_buffer_vram7a00_0180        [strong]
; notes: `0x180`-byte WRAM staging buffer. Written from ROM templates at `D1:5800`, `D1:5A50`, and `D1:5BD0`. Uploaded by DMA from the low-bank WRAM mirror `00:0B40` to VRAM address `7A00`
; source: chrono_trigger_labels_pass44.md
L_7E_0B40_00_0B40_ct_c1_tilemap_staging_buffer_vram7a00_0180_strong:
    ; TODO: reconstruct body / data for 7E:0B40

; [provisional] pass 45 :: ct_c1_lane_roster_strip_tilemap_buffer
; qualifier: provisional
; notes: Supported by the strong link from `C1:07FD` to the active-roster state. Kept provisional because the final gameplay-facing subsystem name is still open.
; source: chrono_trigger_labels_pass45.md
L_7E_0B40_ct_c1_lane_roster_strip_tilemap_buffer:
    ; TODO: reconstruct body / data for 7E:0B40

; [provisional] pass 45 :: ct_c1_panel_or_screen_tilemap_buffer
; qualifier: provisional -> corrected context
; notes: Still not given a final human-facing UI name. But now known much more concretely as a 32x6 strip buffer with dynamic three-slot panel composition.
; source: chrono_trigger_labels_pass45.md
L_7E_0B40_ct_c1_panel_or_screen_tilemap_buffer:
    ; TODO: reconstruct body / data for 7E:0B40

; =============================================================================
; 7E:0CC0  top-status=provisional  labels=3
; =============================================================================
; [provisional] pass 50 :: ct_c1_companion_paired_byte_strip_buffer
; qualifier: strengthened
; notes: Earlier passes had already established HP/max HP/MP numeric content and the segmented bar. Pass 50 tightens the bar specifically to the lane active-time/readiness gauge. The strip now reads more coherently as a battle-status lane display.
; source: chrono_trigger_labels_pass50.md
L_7E_0CC0_ct_c1_companion_paired_byte_strip_buffer:
    ; TODO: reconstruct body / data for 7E:0CC0
    ; known span hint: 7E:0CC0..7E:0E08

; [provisional] pass 47 :: ct_c1_three_lane_status_or_command_strip
; qualifier: provisional
; notes: Pass 47 makes the three-lane, layout-driven presentation role much stronger. Still not safe to commit to the final gameplay-facing subsystem name.
; source: chrono_trigger_labels_pass47.md
L_7E_0CC0_ct_c1_three_lane_status_or_command_strip:
    ; TODO: reconstruct body / data for 7E:0CC0
    ; known span hint: 7E:0CC0..7E:0E08

; [provisional] pass 46 :: ct_c1_roster_presentation_companion_strip
; qualifier: provisional
; notes: Strongly linked to the same roster/strip refresh band as `0B40`. Kept provisional because the final gameplay-facing subsystem name is still unresolved.
; source: chrono_trigger_labels_pass46.md
L_7E_0CC0_ct_c1_roster_presentation_companion_strip:
    ; TODO: reconstruct body / data for 7E:0CC0
    ; known span hint: 7E:0CC0..7E:0E08

; =============================================================================
; 7E:0E80  top-status=provisional  labels=3
; =============================================================================
; [provisional] pass 47 :: ct_c1_companion_record_buffer_0x180
; qualifier: strengthened
; notes: Pass 46 proved the writer-side rebuild path. Pass 47 adds: lane-marker anchor table `FAE9` current-lane marker refresh at `C1:1918` hard read-side consumer proof in bank `C0` This region is now known to participate in downstream composition, not just local build logic.
; source: chrono_trigger_labels_pass47.md
L_7E_0E80_ct_c1_companion_record_buffer_0x180:
    ; TODO: reconstruct body / data for 7E:0E80
    ; known span hint: 7E:0E80..7E:0FFF

; [provisional] pass 47 :: ct_c1_three_lane_marker_record_presentation_block
; qualifier: provisional
; notes: Strongly tied to lane markers and downstream consumption. Still not safe to collapse into “text”, “command labels”, or any narrower final name.
; source: chrono_trigger_labels_pass47.md
L_7E_0E80_ct_c1_three_lane_marker_record_presentation_block:
    ; TODO: reconstruct body / data for 7E:0E80
    ; known span hint: 7E:0E80..7E:0FFF

; [provisional] pass 46 :: ct_c1_roster_presentation_companion_records
; qualifier: provisional
; notes: Strongly linked to the same refresh band and built in three iterations. Still not safe to call text, icon metadata, or anything more specific yet.
; source: chrono_trigger_labels_pass46.md
L_7E_0E80_ct_c1_roster_presentation_companion_records:
    ; TODO: reconstruct body / data for 7E:0E80
    ; known span hint: 7E:0E80..7E:0FFF

; =============================================================================
; 7E:2990  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 52 :: low 3 bits  ct_cfg_battle_speed_field                                [strengthened]
; notes: This pass proves the low 3 bits are consumed directly as an 8-way page selector in the readiness seed branch. The whole byte is still a broader config byte, but the low field is no longer vague. Strongest safe reading: battle-speed option field.
; source: chrono_trigger_labels_pass52.md
L_7E_2990_low_3_bits_ct_cfg_battle_speed_field_strengthened:
    ; TODO: reconstruct body / data for 7E:2990

; =============================================================================
; 7E:5E2F  top-status=strong  labels=1
; =============================================================================
; [strong] pass 49 :: ct_c1_lane_low_hp_critical_flag                      [strong]
; notes: Cleared, then conditionally set in `C1:B094..B0B3`. Condition is driven by `5E30` versus `5E32 >> 3`. Strongest safe reading: low-HP / critical threshold flag.
; source: chrono_trigger_labels_pass49.md
L_7E_5E2F_ct_c1_lane_low_hp_critical_flag_strong:
    ; TODO: reconstruct body / data for 7E:5E2F

; =============================================================================
; 7E:5E30  top-status=strong  labels=2
; =============================================================================
; [strong] pass 49 :: ct_c1_lane_current_hp
; qualifier: strong
; notes: Rendered as the first 3-digit numeric lane field in `C1:0299`. Compared against `5E32 >> 3` in both UI and non-UI logic. Mutated directly and clamped against `5E32` in `C1:EC90..ECD7`. Strongest safe reading now: current HP.
; source: chrono_trigger_labels_pass49.md
L_7E_5E30_ct_c1_lane_current_hp:
    ; TODO: reconstruct body / data for 7E:5E30

; [provisional] pass 48 :: ct_c1_lane_primary_numeric_field
; qualifier: provisional
; notes: Rendered through `011F` as a 3-digit decimal field in `C1:0299`. Structurally related to the `5E32` field by a pre-render compare. Final gameplay-facing meaning still open.
; source: chrono_trigger_labels_pass48.md
L_7E_5E30_ct_c1_lane_primary_numeric_field:
    ; TODO: reconstruct body / data for 7E:5E30

; =============================================================================
; 7E:5E32  top-status=strong  labels=2
; =============================================================================
; [strong] pass 49 :: ct_c1_lane_max_hp
; qualifier: strong
; notes: Rendered as the second 3-digit numeric lane field in `C1:0299`. Divided by 8 for the low-HP threshold test. Used as the clamp/cap for `5E30` in `C1:EC90..ECD7`. Strongest safe reading now: max HP.
; source: chrono_trigger_labels_pass49.md
L_7E_5E32_ct_c1_lane_max_hp:
    ; TODO: reconstruct body / data for 7E:5E32

; [provisional] pass 48 :: ct_c1_lane_secondary_numeric_field
; qualifier: provisional
; notes: Rendered through `011F` as a second 3-digit decimal field. Its high byte is compared against `5E30` before rendering. Final gameplay-facing meaning still open.
; source: chrono_trigger_labels_pass48.md
L_7E_5E32_ct_c1_lane_secondary_numeric_field:
    ; TODO: reconstruct body / data for 7E:5E32

; =============================================================================
; 7E:5E34  top-status=provisional  labels=2
; =============================================================================
; [provisional] pass 49 :: ct_c1_lane_current_mp
; qualifier: provisional
; notes: Rendered as the third lane numeric field through the 2-digit formatter. Participates in a lane-selected subtract/update path at `C1:CC74..CCC5`. Grouped tightly with the now-strong HP pair in the same per-lane panel record. Strongest safe reading now: current MP. Kept provisional only because pass 49 did not yet pin the cleanest possible direct “tech cost / MP spend” caller chain.
; source: chrono_trigger_labels_pass49.md
L_7E_5E34_ct_c1_lane_current_mp:
    ; TODO: reconstruct body / data for 7E:5E34

; [provisional] pass 48 :: ct_c1_lane_aux_two_digit_numeric_field
; qualifier: provisional
; notes: Rendered through `0174` as a 2-digit decimal field. Final gameplay-facing meaning still open.
; source: chrono_trigger_labels_pass48.md
L_7E_5E34_ct_c1_lane_aux_two_digit_numeric_field:
    ; TODO: reconstruct body / data for 7E:5E34

; =============================================================================
; 7E:5E4B  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 50 :: ct_c1_lane_haste_like_rate_modifier_bit               [provisional]
; source: chrono_trigger_labels_pass50.md
L_7E_5E4B_ct_c1_lane_haste_like_rate_modifier_bit_provisional:
    ; TODO: reconstruct body / data for 7E:5E4B

; =============================================================================
; 7E:5E4D  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 50 :: bit7  ct_c1_lane_slow_like_rate_modifier_bit_family [provisional]
; notes: ROM proof is strong for the functional behavior: one family doubles the increment one family halves it Exact final human-facing status names are still intentionally kept one step conservative.
; source: chrono_trigger_labels_pass50.md
L_7E_5E4D_bit7_ct_c1_lane_slow_like_rate_modifier_bit_family_provisional:
    ; TODO: reconstruct body / data for 7E:5E4D
    ; known span hint: 7E:5E4D..7E:5E52

; =============================================================================
; 7E:93EE  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_c1_service7_record_status_flags
; qualifier: strong
; notes: Strengthened by `FD:A8CE` / `FD:A8FE`, which explicitly clear this field
; source: chrono_trigger_labels_pass42.md
L_7E_93EE_ct_c1_service7_record_status_flags:
    ; TODO: reconstruct body / data for 7E:93EE

; =============================================================================
; 7E:93EF  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_c1_service7_record_aux_flags
; qualifier: strong
; notes: Strengthened by `FD:A8CE` / `FD:A8FE`, which explicitly clear this field
; source: chrono_trigger_labels_pass42.md
L_7E_93EF_ct_c1_service7_record_aux_flags:
    ; TODO: reconstruct body / data for 7E:93EF

; =============================================================================
; 7E:93F3  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_c1_service7_record_lane_pair
; qualifier: strong
; notes: Stronger than pass 41. The packed byte is no longer just “small dispatch categories.” It is now best read as a packed pair of **lane IDs** for the canonical `0` `1` `2` `F` = none / disabled
; source: chrono_trigger_labels_pass42.md
L_7E_93F3_ct_c1_service7_record_lane_pair:
    ; TODO: reconstruct body / data for 7E:93F3

; =============================================================================
; 7E:9499  top-status=strong  labels=1
; =============================================================================
; [strong] pass 48 :: ct_c1_decimal_tile_format_input_u16
; qualifier: strong
; notes: Working numeric input consumed by `011F` and `0174`. Loaded from per-lane record fields during `C1:0299` numeric field emission.
; source: chrono_trigger_labels_pass48.md
L_7E_9499_ct_c1_decimal_tile_format_input_u16:
    ; TODO: reconstruct body / data for 7E:9499

; =============================================================================
; 7E:949C  top-status=strong  labels=1
; =============================================================================
; [strong] pass 48 :: ct_c1_decimal_tile_format_output_4bytes
; qualifier: strong
; notes: Shared 4-byte tile buffer emitted by the decimal formatter helpers. `949C` is used as a blank/fill slot. `949D..949F` hold the generated digit tiles before they are copied into the strip.
; source: chrono_trigger_labels_pass48.md
L_7E_949C_ct_c1_decimal_tile_format_output_4bytes:
    ; TODO: reconstruct body / data for 7E:949C
    ; known span hint: 7E:949C..7E:949F

; =============================================================================
; 7E:95D6  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_pending_lane_admission_queue
; qualifier: strong
; notes: Root of the 3-entry pending-admission queue consumed by `1B69` and compacted by `1BAA`.
; source: chrono_trigger_labels_pass43.md
L_7E_95D6_ct_c1_pending_lane_admission_queue:
    ; TODO: reconstruct body / data for 7E:95D6

; =============================================================================
; 7E:95DA  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_pending_lane_admission_count
; qualifier: strong
; notes: Pending queue count / append index for `95D6..95D8`.
; source: chrono_trigger_labels_pass43.md
L_7E_95DA_ct_c1_pending_lane_admission_count:
    ; TODO: reconstruct body / data for 7E:95DA

; =============================================================================
; 7E:99DD  top-status=provisional  labels=8
; =============================================================================
; [provisional] pass 47 :: ct_c1_lane_display_value_for_scaled_bar
; qualifier: provisional
; notes: Read by `C1:06F0` as one input to the segmented bar renderer. Reset/clear paths still mirror it from broader lane-carried state. Strong structural role, but final gameplay-facing meaning still open.
; source: chrono_trigger_labels_pass47.md
L_7E_99DD_ct_c1_lane_display_value_for_scaled_bar:
    ; TODO: reconstruct body / data for 7E:99DD

; [provisional] pass 43 :: ct_c1_lane_primary_value_export_a
; qualifier: provisional
; notes: Export mirror updated from the same lane-carried value family as `B158/AFAB`.
; source: chrono_trigger_labels_pass43.md
L_7E_99DD_ct_c1_lane_primary_value_export_a:
    ; TODO: reconstruct body / data for 7E:99DD

; [provisional] pass 42 :: ct_c1_service7_lane_shadow_value_1
; qualifier: provisional
; source: chrono_trigger_labels_pass42.md
L_7E_99DD_ct_c1_service7_lane_shadow_value_1:
    ; TODO: reconstruct body / data for 7E:99DD

; [unspecified] pass 54 :: ct_visible_head_lane_readiness_current_export
; qualifier: strengthened
; notes: Pass 51 already pinned this as current/fill export. Pass 54 proves the exported values are specifically the **post-normalized head work values**.
; source: chrono_trigger_labels_pass54.md
L_7E_99DD_ct_visible_head_lane_readiness_current_export:
    ; TODO: reconstruct body / data for 7E:99DD
    ; known span hint: 7E:99DD..7E:99DF

; [unspecified] pass 51 :: ct_c1_lane_active_time_gauge_current_fill_export
; qualifier: strengthened
; notes: `C1:06F0` loads it as the renderer numerator/current-side value. Goal-only update families do **not** necessarily overwrite it. Snap/full commit families explicitly mirror it equal to `9F22`. Replaces the looser “progress export” wording with a harder current-fill role.
; source: chrono_trigger_labels_pass51.md
L_7E_99DD_ct_c1_lane_active_time_gauge_current_fill_export:
    ; TODO: reconstruct body / data for 7E:99DD

; [unspecified] pass 51 :: old wording “lane_active_time_gauge_progress_export”                    [replaced]
; notes: Too generic after the renderer-side numerator proof. Replaced by `ct_c1_lane_active_time_gauge_current_fill_export`.
; source: chrono_trigger_labels_pass51.md
L_7E_99DD_old_wording_lane_active_time_gauge_progress_export_replaced:
    ; TODO: reconstruct body / data for 7E:99DD

; [unspecified] pass 50 :: ct_c1_lane_active_time_gauge_progress_export
; qualifier: strengthened
; notes: Visible lane-bar input used by `C1:06F0`. Initialized to zero by `B725`. Updated in the readiness-gauge advance families. Best reading now: visible active-time/readiness gauge progress export.
; source: chrono_trigger_labels_pass50.md
L_7E_99DD_ct_c1_lane_active_time_gauge_progress_export:
    ; TODO: reconstruct body / data for 7E:99DD

; [unspecified] pass 50 :: old wording “display value for scaled bar”                 [replaced]
; notes: Replaced by `ct_c1_lane_active_time_gauge_progress_export`.
; source: chrono_trigger_labels_pass50.md
L_7E_99DD_old_wording_display_value_for_scaled_bar_replaced:
    ; TODO: reconstruct body / data for 7E:99DD

; =============================================================================
; 7E:99DE  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 50 :: / 7E:99DF  ct_c1_lane_active_time_gauge_progress_export_1_2 [provisional]
; source: chrono_trigger_labels_pass50.md
L_7E_99DE_7E_99DF_ct_c1_lane_active_time_gauge_progress_export_1_2_provisional:
    ; TODO: reconstruct body / data for 7E:99DE

; =============================================================================
; 7E:99E2  top-status=strong  labels=1
; =============================================================================
; [strong] pass 44 :: ct_c1_tilemap_upload_pending_counter
; qualifier: strong
; notes: Dirty/request latch (or small counter) for the `0B40 -> VRAM 7A00` upload. Multiple bank-`C1` paths `INC` it after rewriting `0B40`. `CF:E380` checks it, performs the DMA upload, then clears it.
; source: chrono_trigger_labels_pass44.md
L_7E_99E2_ct_c1_tilemap_upload_pending_counter:
    ; TODO: reconstruct body / data for 7E:99E2

; =============================================================================
; 7E:9F20  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 49 :: ct_c1_companion_strip_layout_mode_3state
; qualifier: strengthened
; notes: Earlier passes proved it selects layout variants. With the HP/maxHP/MP field family now resolved harder, the layout mode is better understood as repositioning a stable status-field bundle rather than arbitrary numeric fragments.
; source: chrono_trigger_labels_pass49.md
L_7E_9F20_ct_c1_companion_strip_layout_mode_3state:
    ; TODO: reconstruct body / data for 7E:9F20

; =============================================================================
; 7E:9F22  top-status=provisional  labels=8
; =============================================================================
; [provisional] pass 54 :: ct_visible_head_lane_readiness_goal_export
; qualifier: strengthened
; notes: Pass 51 already pinned this as goal/cap export in the gauge-facing path. Pass 54 proves this mirror copy at `B93B..B94F` receives the same **post-normalized head work values** in this initializer path.
; source: chrono_trigger_labels_pass54.md
L_7E_9F22_ct_visible_head_lane_readiness_goal_export:
    ; TODO: reconstruct body / data for 7E:9F22
    ; known span hint: 7E:9F22..7E:9F24

; [provisional] pass 47 :: ct_c1_lane_display_divisor_or_capacity
; qualifier: provisional
; notes: Read by `C1:06F0` as the other scaling input to the segmented bar renderer. Exact human-facing meaning still unresolved.
; source: chrono_trigger_labels_pass47.md
L_7E_9F22_ct_c1_lane_display_divisor_or_capacity:
    ; TODO: reconstruct body / data for 7E:9F22

; [provisional] pass 43 :: ct_c1_lane_primary_value_export_b
; qualifier: provisional
; notes: Second export mirror updated from the same lane-carried value family as `B158/AFAB`.
; source: chrono_trigger_labels_pass43.md
L_7E_9F22_ct_c1_lane_primary_value_export_b:
    ; TODO: reconstruct body / data for 7E:9F22

; [provisional] pass 42 :: ct_c1_service7_lane_shadow_value_2
; qualifier: provisional
; notes: Three destinations that receive `B158[lane]` during lane clear/reset. Their exact downstream semantics are still open.
; source: chrono_trigger_labels_pass42.md
L_7E_9F22_ct_c1_service7_lane_shadow_value_2:
    ; TODO: reconstruct body / data for 7E:9F22

; [unspecified] pass 51 :: ct_c1_lane_active_time_gauge_goal_or_cap_export
; qualifier: strengthened
; notes: `C1:06F0` loads it as the denominator/goal-side value for the gauge math. `C1:BE00..BE2A` updates it without also updating `99DD`. Equal-write paths force `99DD == 9F22` to export a full/ready bar. Replaces the narrower pass-50 “cap export” wording with a harder goal/denominator role.
; source: chrono_trigger_labels_pass51.md
L_7E_9F22_ct_c1_lane_active_time_gauge_goal_or_cap_export:
    ; TODO: reconstruct body / data for 7E:9F22

; [unspecified] pass 51 :: old wording “lane_active_time_gauge_cap_export”                         [replaced]
; notes: Too narrow after the goal-only update path at `C1:BE00..BE2A` and the snap/full mirror paths. Replaced by `ct_c1_lane_active_time_gauge_goal_or_cap_export`.
; source: chrono_trigger_labels_pass51.md
L_7E_9F22_old_wording_lane_active_time_gauge_cap_export_replaced:
    ; TODO: reconstruct body / data for 7E:9F22

; [unspecified] pass 50 :: ct_c1_lane_active_time_gauge_cap_export
; qualifier: strengthened
; notes: Second visible lane-bar input used by `C1:06F0`. Initialized to `0x30` by `B725`. Updated by the readiness-gauge advance families. Best reading now: visible active-time/readiness gauge threshold/cap export.
; source: chrono_trigger_labels_pass50.md
L_7E_9F22_ct_c1_lane_active_time_gauge_cap_export:
    ; TODO: reconstruct body / data for 7E:9F22

; [unspecified] pass 50 :: old wording “display divisor or capacity”                  [replaced]
; notes: Replaced by `ct_c1_lane_active_time_gauge_cap_export`.
; source: chrono_trigger_labels_pass50.md
L_7E_9F22_old_wording_display_divisor_or_capacity_replaced:
    ; TODO: reconstruct body / data for 7E:9F22

; =============================================================================
; 7E:9F23  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 50 :: / 7E:9F24  ct_c1_lane_active_time_gauge_cap_export_1_2      [provisional]
; notes: `B725` proves these are sibling exports for the other visible lanes. Their human-facing meaning matches lane 0 strongly. Kept grouped/provisional only because pass 50 focused on the branch semantics more than on per-lane alias cleanup.
; source: chrono_trigger_labels_pass50.md
L_7E_9F23_7E_9F24_ct_c1_lane_active_time_gauge_cap_export_1_2_provisional:
    ; TODO: reconstruct body / data for 7E:9F23

; =============================================================================
; 7E:9F38  top-status=provisional  labels=2
; =============================================================================
; [provisional] pass 47 :: ct_c1_lane_emitted_aux_or_mask
; qualifier: provisional, unchanged
; notes: Pass 47 stayed on the strip/record presentation seam. Positive writer side remains intentionally unresolved.
; source: chrono_trigger_labels_pass47.md
L_7E_9F38_ct_c1_lane_emitted_aux_or_mask:
    ; TODO: reconstruct body / data for 7E:9F38

; [provisional] pass 42 :: ct_c1_service7_slot_aux_flags_for_emitted_records
; qualifier: provisional
; notes: Carried forward from pass 41. Still a valid sink-side label because its low bits feed `93EF` on emit,  Pass 42 materially tightened the downstream `93F3` family: the nibble The main unresolved seam has shifted again:
; source: chrono_trigger_labels_pass42.md
L_7E_9F38_ct_c1_service7_slot_aux_flags_for_emitted_records:
    ; TODO: reconstruct body / data for 7E:9F38

; =============================================================================
; 7E:A10F  top-status=strong  labels=3
; =============================================================================
; [strong] pass 49 :: ct_c1_lane_hp_threshold_numeric_attr_selector
; qualifier: strong
; notes: Reset per lane before numeric field generation in `C1:0299`. Incremented only through the `currentHP` versus `maxHP/8` compare path. Immediately consumed to choose between paired-byte values `0x29` and `0x2D` for the lane’s rendered digits. Strongest safe reading: lane-local HP-threshold presentation selector/count.
; source: chrono_trigger_labels_pass49.md
L_7E_A10F_ct_c1_lane_hp_threshold_numeric_attr_selector:
    ; TODO: reconstruct body / data for 7E:A10F

; [provisional] pass 48 :: ct_c1_numeric_threshold_or_warning_counter
; qualifier: provisional
; notes: Incremented when the pre-render compare between `5E30` and `5E32 >> 8` fails in one direction. Strongly acts like a counter or warning latch related to numeric inconsistency/overflow. Final semantics remain unresolved.
; source: chrono_trigger_labels_pass48.md
L_7E_A10F_ct_c1_numeric_threshold_or_warning_counter:
    ; TODO: reconstruct body / data for 7E:A10F

; [unspecified] pass 49 :: old wording “numeric threshold or warning counter”
; qualifier: replaced
; notes: Too vague after pass 49. The ROM now supports a harder reading: a lane-local HP-threshold presentation selector/count.
; source: chrono_trigger_labels_pass49.md
L_7E_A10F_old_wording_numeric_threshold_or_warning_counter:
    ; TODO: reconstruct body / data for 7E:A10F

; =============================================================================
; 7E:A6D9  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_active_lane_roster_marker_per_lane
; qualifier: strong
; notes: Three-entry per-lane active-roster membership marker. `FF` = absent/inactive. Nonnegative = lane is present in the local active controller.
; source: chrono_trigger_labels_pass43.md
L_7E_A6D9_ct_c1_active_lane_roster_marker_per_lane:
    ; TODO: reconstruct body / data for 7E:A6D9

; =============================================================================
; 7E:A6DD  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_current_active_lane
; qualifier: strong
; notes: Current active lane for the local 3-lane controller. Reseated by service 2 when the current lane is removed.
; source: chrono_trigger_labels_pass43.md
L_7E_A6DD_ct_c1_current_active_lane:
    ; TODO: reconstruct body / data for 7E:A6DD

; =============================================================================
; 7E:A6DE  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_active_lane_count
; qualifier: strong
; notes: Active-lane count for the local 3-lane controller. Incremented when a pending lane is promoted; decremented when an active lane is removed.
; source: chrono_trigger_labels_pass43.md
L_7E_A6DE_ct_c1_active_lane_count:
    ; TODO: reconstruct body / data for 7E:A6DE

; =============================================================================
; 7E:A6DF  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 43 :: ct_c1_lane_roster_change_sentinel
; qualifier: provisional
; notes: Forced to `FEh` in both the pending->active promotion path and the active-lane removal path. Structurally real, but exact downstream meaning still needs more proof.
; source: chrono_trigger_labels_pass43.md
L_7E_A6DF_ct_c1_lane_roster_change_sentinel:
    ; TODO: reconstruct body / data for 7E:A6DF

; =============================================================================
; 7E:AEC5  top-status=strong  labels=2
; =============================================================================
; [strong] pass 55 :: ct_visible_head_occupied_slot_count
; qualifier: strong
; notes: Incremented when canonical head-slot rebuilds admit a valid visible occupant. Reset and rebuilt in both: `FD:B24D..B27E` `C1:FB06..FB2C`
; source: chrono_trigger_labels_pass55.md
L_7E_AEC5_ct_visible_head_occupied_slot_count:
    ; TODO: reconstruct body / data for 7E:AEC5

; [unspecified] pass 55 :: ct_visible_head_active_slot_count
; qualifier: strengthened
; notes: Tightened from generic “active slot count” wording. Specifically counts admitted visible-head occupants during head-map rebuild.
; source: chrono_trigger_labels_pass55.md
L_7E_AEC5_ct_visible_head_active_slot_count:
    ; TODO: reconstruct body / data for 7E:AEC5

; =============================================================================
; 7E:AEC6  top-status=strong  labels=2
; =============================================================================
; [strong] pass 56 :: ct_canonical_tail_slot_count
; qualifier: strong
; notes: Reset by the canonical tail-map builder at `FD:B2A3`. Incremented once per admitted tail source record. Counts populated canonical tail entries, not merely currently live tail occupants.
; source: chrono_trigger_labels_pass56.md
L_7E_AEC6_ct_canonical_tail_slot_count:
    ; TODO: reconstruct body / data for 7E:AEC6

; [provisional] pass 53 :: ct_runtime_tail_slot_count
; qualifier: strengthened
; notes: Used as the bound for the tail seeder loop in `FD:B867..B8EC`. Best current reading: live/populated tail-slot count rather than total capacity.
; source: chrono_trigger_labels_pass53.md
L_7E_AEC6_ct_runtime_tail_slot_count:
    ; TODO: reconstruct body / data for 7E:AEC6

; =============================================================================
; 7E:AECB  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 57 :: / 7E:AECC  global labels should remain cautious
; notes: in `AB03`, `AECC` temporarily holds withheld tail-slot indices in `AB03`, `AECB` temporarily holds the count of those withheld candidates  the compare/gate exists the final noun still wants wrapper proof the mechanical meaning is now strong the exact scenario/use case still wants caller proof this pass proves it suppresses dispatch in `8C0A` the exact state meaning remains open
; source: chrono_trigger_labels_pass57.md
L_7E_AECB_7E_AECC_global_labels_should_remain_cautious:
    ; TODO: reconstruct body / data for 7E:AECB

; =============================================================================
; 7E:AEFF  top-status=strong  labels=4
; =============================================================================
; [strong] pass 56 :: ct_battle_slot_live_occupant_map
; qualifier: strengthened
; notes: Unified 11-slot live occupant map. Slots `0..2` = visible head live occupants. Slots `3..10` = tail live/materialized occupants. `FF` means unoccupied / not live in this map.
; source: chrono_trigger_labels_pass56.md
L_7E_AEFF_ct_battle_slot_live_occupant_map:
    ; TODO: reconstruct body / data for 7E:AEFF
    ; known span hint: 7E:AEFF..7E:AF09

; [strong] pass 55 :: ct_battle_slot_occupant_index_map
; qualifier: strong
; notes: Slot-indexed map. Each non-`FF` entry names the battler/participant currently assigned to that slot. `FF` means the slot is unoccupied. Proven by: direct slot initialization at `FD:B24D..B27E` alternate rebuild at `C1:FB06..FB2C` inverse-map construction into `B1BE` at `FD:B28F..B2A3` battler-structured downstream consumption at `FD:B363...`
; source: chrono_trigger_labels_pass55.md
L_7E_AEFF_ct_battle_slot_occupant_index_map:
    ; TODO: reconstruct body / data for 7E:AEFF
    ; known span hint: 7E:AEFF..7E:AF09

; [unspecified] pass 55 :: ct_battle_slot_active_entry_gate_array
; qualifier: replaced
; notes: Too weak after pass 55. Replaced by: `ct_battle_slot_occupant_index_map` The gating behavior from pass 54 remains true, but it is now clearly a consequence of slot occupancy, not the primary noun.
; source: chrono_trigger_labels_pass55.md
L_7E_AEFF_ct_battle_slot_active_entry_gate_array:
    ; TODO: reconstruct body / data for 7E:AEFF
    ; known span hint: 7E:AEFF..7E:AF09

; [unspecified] pass 55 :: “active-entry gate array”
; qualifier: retired as primary noun
; notes: Still true in pass-54 arithmetic terms. No longer the best primary label after pass 55.
; source: chrono_trigger_labels_pass55.md
L_7E_AEFF_active_entry_gate_array:
    ; TODO: reconstruct body / data for 7E:AEFF
    ; known span hint: 7E:AEFF..7E:AF09

; =============================================================================
; 7E:AF02  top-status=strong  labels=1
; =============================================================================
; [strong] pass 56 :: ct_tail_live_occupant_submap
; qualifier: strong
; notes: Tail subrange of the unified live occupant map. Receives occupant IDs from the `29C4` source family. May be forced to `FF` while the canonical tail map still retains the occupant.
; source: chrono_trigger_labels_pass56.md
L_7E_AF02_ct_tail_live_occupant_submap:
    ; TODO: reconstruct body / data for 7E:AF02
    ; known span hint: 7E:AF02..7E:AF09

; =============================================================================
; 7E:AF0A  top-status=strong  labels=4
; =============================================================================
; [strong] pass 56 :: ct_battle_slot_canonical_occupant_map
; qualifier: strengthened
; notes: Unified 11-slot canonical/remembered occupant map. Head half built from the visible source path. Tail half built from the `29C4` source-record family.
; source: chrono_trigger_labels_pass56.md
L_7E_AF0A_ct_battle_slot_canonical_occupant_map:
    ; TODO: reconstruct body / data for 7E:AF0A
    ; known span hint: 7E:AF0A..7E:AF14

; [strong] pass 55 :: ct_battle_slot_default_occupant_index_map
; qualifier: strong
; notes: Initialized in lockstep with `AEFF`. Used by `C1:B279..B28E` to restore live slot occupancy. Shares the same `FF` empty sentinel semantics.
; source: chrono_trigger_labels_pass55.md
L_7E_AF0A_ct_battle_slot_default_occupant_index_map:
    ; TODO: reconstruct body / data for 7E:AF0A
    ; known span hint: 7E:AF0A..7E:AF14

; [unspecified] pass 55 :: ct_battle_slot_occupant_index_mirror
; qualifier: strengthened
; notes: Pass 55 shows this is not just a mirror. It is the remembered/default occupant map used for restoration.
; source: chrono_trigger_labels_pass55.md
L_7E_AF0A_ct_battle_slot_occupant_index_mirror:
    ; TODO: reconstruct body / data for 7E:AF0A
    ; known span hint: 7E:AF0A..7E:AF14

; [unspecified] pass 55 :: “occupant mirror”
; qualifier: retired as primary noun
; notes: Too weak after restore-path proof. Replace with “default / remembered occupant index map”.   Trace direct producer paths for tail-slot occupants beyond the visible-head rebuilders. Re-check the ready-transition helpers with the now-frozen occupant-map model. Target the downstream logic that distinguishes: occupied-but-zero readiness occupied-and-one-step-away readiness occupied-and-larger-positive readiness
; source: chrono_trigger_labels_pass55.md
L_7E_AF0A_occupant_mirror:
    ; TODO: reconstruct body / data for 7E:AF0A
    ; known span hint: 7E:AF0A..7E:AF14

; =============================================================================
; 7E:AF0D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 56 :: ct_tail_canonical_occupant_submap
; qualifier: strong
; notes: Tail subrange of the unified canonical/remembered occupant map. Always receives the admitted occupant ID when the tail-source gate passes.
; source: chrono_trigger_labels_pass56.md
L_7E_AF0D_ct_tail_canonical_occupant_submap:
    ; TODO: reconstruct body / data for 7E:AF0D
    ; known span hint: 7E:AF0D..7E:AF14

; =============================================================================
; 7E:AF15  top-status=strong  labels=4
; =============================================================================
; [strong] pass 57 :: bit 7  ct_tail_deferred_materialization_flag                              [strengthened]
; notes: Stronger than pass 56's “canonical present but not live” wording. Bit 7 now sits inside a proved selection/materialization flow: collected by `AB03` ignored by ordinary live-tail consumers cleared by `AED3` when the entry is materialized into `AF02` Safest current noun: deferred / withheld-from-live tail materialization flag.
; source: chrono_trigger_labels_pass57.md
L_7E_AF15_bit_7_ct_tail_deferred_materialization_flag_strengthened:
    ; TODO: reconstruct body / data for 7E:AF15

; [provisional] pass 53 :: bit 6  ct_runtime_tail_slot_seed_side_effect_flag                     [provisional]
; notes: Set only by the tail seeder when source record byte `+0x0A` has bit 0 set. Real and structurally isolated, but final gameplay-facing meaning is still unresolved.
; source: chrono_trigger_labels_pass53.md
L_7E_AF15_bit_6_ct_runtime_tail_slot_seed_side_effect_flag_provisional:
    ; TODO: reconstruct body / data for 7E:AF15

; [unspecified] pass 56 :: bit 7  ct_tail_canonical_present_but_not_live_flag               [strengthened]
; notes: Set only when the tail-source builder keeps the canonical occupant (`AF0D`) but forces the live occupant (`AF02`) to `FF`. Strong structural meaning: canonical tail entry exists, but it is withheld from the live/materialized tail map. Exact gameplay-facing noun remains cautious.
; source: chrono_trigger_labels_pass56.md
L_7E_AF15_bit_7_ct_tail_canonical_present_but_not_live_flag_strengthened:
    ; TODO: reconstruct body / data for 7E:AF15

; [unspecified] pass 52 :: bit 6  ct_runtime_slot_sibling_seed_side_effect_flag                  [provisional]
; notes: Set by the sibling seed family when record byte `+0x0A` has bit 0 set. Real side effect, but gameplay-facing meaning still unresolved.
; source: chrono_trigger_labels_pass52.md
L_7E_AF15_bit_6_ct_runtime_slot_sibling_seed_side_effect_flag_provisional:
    ; TODO: reconstruct body / data for 7E:AF15

; =============================================================================
; 7E:AFAB  top-status=provisional  labels=9
; =============================================================================
; [provisional] pass 54 :: value `0`  ct_battle_slot_readiness_zero_special_state                [provisional]
; notes: In this routine, zero values are: excluded from minimum selection excluded from subtractive normalization preserved across the pass Strong structural meaning: not an active positive countdown participant. Final gameplay-facing noun still wants one more downstream confirmation.
; source: chrono_trigger_labels_pass54.md
L_7E_AFAB_value_0_ct_battle_slot_readiness_zero_special_state_provisional:
    ; TODO: reconstruct body / data for 7E:AFAB

; [provisional] pass 51 :: ct_c1_lane_readiness_work_value
; qualifier: strengthened
; notes: Receives the same upstream seed as `B158` in the battle-side writer families. Is also the working value advanced by the later goal/snap export families. Stronger now as the work-value/shadow branch for the lane readiness gauge.
; source: chrono_trigger_labels_pass51.md
L_7E_AFAB_ct_c1_lane_readiness_work_value:
    ; TODO: reconstruct body / data for 7E:AFAB

; [provisional] pass 43 :: ct_c1_lane_primary_carried_value_shadow
; qualifier: provisional
; notes: Per-lane shadow/mirror of `B158`.
; source: chrono_trigger_labels_pass43.md
L_7E_AFAB_ct_c1_lane_primary_carried_value_shadow:
    ; TODO: reconstruct body / data for 7E:AFAB

; [provisional] pass 42 :: ct_c1_service7_lane_shadow_value_0
; qualifier: provisional
; source: chrono_trigger_labels_pass42.md
L_7E_AFAB_ct_c1_service7_lane_shadow_value_0:
    ; TODO: reconstruct body / data for 7E:AFAB

; [unspecified] pass 54 :: ct_battle_slot_readiness_work_array
; qualifier: strengthened
; notes: Pass 53 proved this is one unified 11-entry work array. Pass 54 proves it is also the target of a **minimum-positive subtractive normalization**. Smallest eligible positive value is forced to `1` before head export. Zero entries are preserved. `AEFF == FF` entries are preserved.
; source: chrono_trigger_labels_pass54.md
L_7E_AFAB_ct_battle_slot_readiness_work_array:
    ; TODO: reconstruct body / data for 7E:AFAB
    ; known span hint: 7E:AFAB..7E:AFB5

; [unspecified] pass 54 :: ct_visible_head_lane_readiness_work_array
; qualifier: strengthened
; notes: Still the visible head partition. Pass 54 proves these values are exported **after unified 11-slot normalization**, not as raw seeded values.
; source: chrono_trigger_labels_pass54.md
L_7E_AFAB_ct_visible_head_lane_readiness_work_array:
    ; TODO: reconstruct body / data for 7E:AFAB
    ; known span hint: 7E:AFAB..7E:AFAD

; [unspecified] pass 52 :: ct_c1_primary_lane_readiness_work_value
; qualifier: strengthened
; notes: Receives the same formula result as `B158` in the primary seed family. Still the best working/readiness-shadow label.
; source: chrono_trigger_labels_pass52.md
L_7E_AFAB_ct_c1_primary_lane_readiness_work_value:
    ; TODO: reconstruct body / data for 7E:AFAB

; [unspecified] pass 51 :: old wording “lane_active_time_increment_shadow”                         [soft-replaced]
; notes: Too narrow after the direct seed/export mirror proof and the later working-value advances. Soft-replaced by `ct_c1_lane_readiness_work_value`.
; source: chrono_trigger_labels_pass51.md
L_7E_AFAB_old_wording_lane_active_time_increment_shadow_soft_replaced:
    ; TODO: reconstruct body / data for 7E:AFAB

; [unspecified] pass 50 :: ct_c1_lane_active_time_increment_shadow
; qualifier: strengthened
; notes: Working shadow derived from `B158`. Modified by `BD6F` through slow-like / haste-like status effects. Consumed by the gauge-advance families at `BDE0/BE50/BED0`. Best reading now: status-adjusted active-time/readiness increment shadow.
; source: chrono_trigger_labels_pass50.md
L_7E_AFAB_ct_c1_lane_active_time_increment_shadow:
    ; TODO: reconstruct body / data for 7E:AFAB

; =============================================================================
; 7E:AFAE  top-status=provisional  labels=2
; =============================================================================
; [provisional] pass 52 :: ct_c1_sibling_lane_readiness_work_value
; qualifier: provisional
; notes: Formula-aligned sibling of `AFAB`. Final freeze deferred pending more downstream consumer proof.
; source: chrono_trigger_labels_pass52.md
L_7E_AFAE_ct_c1_sibling_lane_readiness_work_value:
    ; TODO: reconstruct body / data for 7E:AFAE

; [unspecified] pass 54 :: ct_runtime_tail_slot_readiness_work_array
; qualifier: strengthened
; notes: Tail partition still not exported directly here. Pass 54 proves it still participates in the same shared normalization pass as the visible head. This is strong evidence that head and tail are one readiness/countdown space, not parallel unrelated arrays.
; source: chrono_trigger_labels_pass54.md
L_7E_AFAE_ct_runtime_tail_slot_readiness_work_array:
    ; TODO: reconstruct body / data for 7E:AFAE
    ; known span hint: 7E:AFAE..7E:AFB5

; =============================================================================
; 7E:B03A  top-status=strong  labels=6
; =============================================================================
; [strong] pass 53 :: ct_battle_slot_readiness_dirty_array
; qualifier: strong
; notes: Contiguous 11-byte readiness update/valid array. Head seeder writes the first 3 entries through `B03A,X`. Tail seeder writes the later entries through `B03D,X = B03A + 3 + X`.
; source: chrono_trigger_labels_pass53.md
L_7E_B03A_ct_battle_slot_readiness_dirty_array:
    ; TODO: reconstruct body / data for 7E:B03A
    ; known span hint: 7E:B03A..7E:B044

; [provisional] pass 52 :: ct_c1_primary_visible_lane_readiness_seed_valid_flag
; qualifier: strengthened
; notes: This pass confirms it is asserted directly by the primary seed family after the exact formula store.
; source: chrono_trigger_labels_pass52.md
L_7E_B03A_ct_c1_primary_visible_lane_readiness_seed_valid_flag:
    ; TODO: reconstruct body / data for 7E:B03A

; [provisional] pass 51 :: ct_c1_visible_lane_readiness_seed_valid_flag
; qualifier: provisional
; notes: Set to `1` by the primary visible-lane seed family at `FD:B820..B850`. Strongly looks like a “valid/seeded/armed” lane flag. Final freeze deferred until the sibling `B03D` path is fully aligned.
; source: chrono_trigger_labels_pass51.md
L_7E_B03A_ct_c1_visible_lane_readiness_seed_valid_flag:
    ; TODO: reconstruct body / data for 7E:B03A

; [provisional] pass 43 :: ct_c1_lane_secondary_dirty_latch
; qualifier: provisional
; notes: Secondary per-lane latch cleared beside `B188` in the lane-reset families. Structurally part of the same carried-state bundle, but exact semantics remain open.
; source: chrono_trigger_labels_pass43.md
L_7E_B03A_ct_c1_lane_secondary_dirty_latch:
    ; TODO: reconstruct body / data for 7E:B03A

; [provisional] pass 42 :: ct_c1_service7_lane_aux_reset_field
; qualifier: provisional
; notes: Cleared during both lane-reset helpers. Real reset role is proven; human-facing meaning is still open.
; source: chrono_trigger_labels_pass42.md
L_7E_B03A_ct_c1_service7_lane_aux_reset_field:
    ; TODO: reconstruct body / data for 7E:B03A

; [unspecified] pass 53 :: ct_visible_head_lane_readiness_dirty_array
; qualifier: strengthened
; notes: Head partition of the contiguous readiness dirty/update array. Asserted directly by the head seeder.
; source: chrono_trigger_labels_pass53.md
L_7E_B03A_ct_visible_head_lane_readiness_dirty_array:
    ; TODO: reconstruct body / data for 7E:B03A
    ; known span hint: 7E:B03A..7E:B03C

; =============================================================================
; 7E:B03D  top-status=provisional  labels=2
; =============================================================================
; [provisional] pass 52 :: ct_c1_sibling_visible_lane_readiness_seed_valid_flag
; qualifier: provisional
; notes: Sibling of `B03A`, but only set under an extra gate (`AF02 != FF`). Final freeze deferred pending tighter alignment with the lane-selection/state machinery.
; source: chrono_trigger_labels_pass52.md
L_7E_B03D_ct_c1_sibling_visible_lane_readiness_seed_valid_flag:
    ; TODO: reconstruct body / data for 7E:B03D

; [unspecified] pass 53 :: ct_runtime_tail_slot_readiness_dirty_array
; qualifier: strengthened
; notes: Tail partition of the contiguous readiness dirty array rooted at `B03A`. Set by the tail seeder only under the extra `AF02 != FF` gate.
; source: chrono_trigger_labels_pass53.md
L_7E_B03D_ct_runtime_tail_slot_readiness_dirty_array:
    ; TODO: reconstruct body / data for 7E:B03D
    ; known span hint: 7E:B03D..7E:B044

; =============================================================================
; 7E:B158  top-status=strong  labels=9
; =============================================================================
; [strong] pass 53 :: ct_battle_slot_readiness_seed_array
; qualifier: strong
; notes: Contiguous 11-byte readiness/base array. Proven by the 11-entry bulk writer at `FD:B4E0..B54D`. Head partition = `B158..B15A`. Tail partition = `B15B..B162`.
; source: chrono_trigger_labels_pass53.md
L_7E_B158_ct_battle_slot_readiness_seed_array:
    ; TODO: reconstruct body / data for 7E:B158
    ; known span hint: 7E:B158..7E:B162

; [provisional] pass 43 :: ct_c1_lane_primary_carried_value
; qualifier: provisional
; notes: Per-lane carried scalar maintained beside the canonical-record lane system. Mirrored into `AFAB`, and exported to `99DD` / `9F22` in the clear/update families.
; source: chrono_trigger_labels_pass43.md
L_7E_B158_ct_c1_lane_primary_carried_value:
    ; TODO: reconstruct body / data for 7E:B158

; [provisional] pass 42 :: ct_c1_service7_lane_carried_value
; qualifier: provisional
; notes: Copied into `AFAB`, `99DD`, and `9F22` during lane clear/reset. Structural role is real; gameplay-facing meaning is still unresolved.
; source: chrono_trigger_labels_pass42.md
L_7E_B158_ct_c1_service7_lane_carried_value:
    ; TODO: reconstruct body / data for 7E:B158

; [unspecified] pass 53 :: ct_visible_head_lane_readiness_seed_array
; qualifier: strengthened
; notes: Previously treated as a standalone “primary pair”. This pass proves it is the fixed 3-entry head partition of the larger 11-slot seed array. These are the entries directly tied to the visible export path.
; source: chrono_trigger_labels_pass53.md
L_7E_B158_ct_visible_head_lane_readiness_seed_array:
    ; TODO: reconstruct body / data for 7E:B158
    ; known span hint: 7E:B158..7E:B15A

; [unspecified] pass 52 :: ct_c1_primary_lane_readiness_seed_value
; qualifier: strengthened
; notes: Still best kept as a seed value rather than a final gameplay-facing name. This pass proves the exact upstream formula feeding it.
; source: chrono_trigger_labels_pass52.md
L_7E_B158_ct_c1_primary_lane_readiness_seed_value:
    ; TODO: reconstruct body / data for 7E:B158

; [unspecified] pass 51 :: ct_c1_lane_readiness_seed_value
; qualifier: strengthened
; notes: This pass proves `B158` is a direct upstream seed into the visible lane-gauge branch. `C1:B390` mirrors it directly into `AFAB/99DD/9F22`. `FD:B820..B850` seeds it from a speed-like stat and bonus table. This is a stronger and safer description than the older purely generic scalar wording.
; source: chrono_trigger_labels_pass51.md
L_7E_B158_ct_c1_lane_readiness_seed_value:
    ; TODO: reconstruct body / data for 7E:B158

; [unspecified] pass 51 :: old wording “lane_base_active_time_increment”                           [soft-replaced]
; notes: Pass 50's increment wording was useful but too narrow. Pass 51 proves `B158` is at least a direct upstream seed value for the readiness-gauge branch. Soft-replaced by `ct_c1_lane_readiness_seed_value` pending one more pass on exact subroles.
; source: chrono_trigger_labels_pass51.md
L_7E_B158_old_wording_lane_base_active_time_increment_soft_replaced:
    ; TODO: reconstruct body / data for 7E:B158

; [unspecified] pass 50 :: / 7E:AFAB old wording “primary carried scalar/shadow”      [replaced]
; notes: Too abstract after the status-modified gauge-rate proof. Replaced by the active-time/readiness increment wording.
; source: chrono_trigger_labels_pass50.md
L_7E_B158_7E_AFAB_old_wording_primary_carried_scalar_shadow_replaced:
    ; TODO: reconstruct body / data for 7E:B158

; [unspecified] pass 50 :: ct_c1_lane_base_active_time_increment
; qualifier: strengthened
; notes: Repeatedly copied into `AFAB` before `BD6F` is applied. Feeds the visible lane-bar branch through the status-modified increment family. Best reading now: base active-time/readiness increment.
; source: chrono_trigger_labels_pass50.md
L_7E_B158_ct_c1_lane_base_active_time_increment:
    ; TODO: reconstruct body / data for 7E:B158

; =============================================================================
; 7E:B15B  top-status=provisional  labels=2
; =============================================================================
; [provisional] pass 52 :: ct_c1_sibling_lane_readiness_seed_value
; qualifier: provisional
; notes: Formula-aligned sibling of `B158`. Final freeze deferred until the exact caller/consumer split is clearer.
; source: chrono_trigger_labels_pass52.md
L_7E_B15B_ct_c1_sibling_lane_readiness_seed_value:
    ; TODO: reconstruct body / data for 7E:B15B

; [unspecified] pass 53 :: ct_runtime_tail_slot_readiness_seed_array
; qualifier: strengthened
; notes: Previously labeled as a separate “sibling” seed pair. This pass proves it is the tail partition of the same contiguous seed array rooted at `B158`. Seeded by the same config/speed formula as the head partition.
; source: chrono_trigger_labels_pass53.md
L_7E_B15B_ct_runtime_tail_slot_readiness_seed_array:
    ; TODO: reconstruct body / data for 7E:B15B
    ; known span hint: 7E:B15B..7E:B162

; =============================================================================
; 7E:B188  top-status=strong  labels=2
; =============================================================================
; [strong] pass 43 :: ct_c1_lane_occupied_refresh_latch
; qualifier: strong
; notes: Per-lane occupied/refresh-required latch. Directly gates whether the lane-clear path at `FD:A8FE` escalates into local service 2.
; source: chrono_trigger_labels_pass43.md
L_7E_B188_ct_c1_lane_occupied_refresh_latch:
    ; TODO: reconstruct body / data for 7E:B188

; [provisional] pass 42 :: ct_c1_service7_lane_occupied_or_latched_flag
; qualifier: provisional
; notes: Gates the extra refresh path in `FD:A8FE`. Strongly looks like a lane-occupied / lane-latched byte, but still needs
; source: chrono_trigger_labels_pass42.md
L_7E_B188_ct_c1_service7_lane_occupied_or_latched_flag:
    ; TODO: reconstruct body / data for 7E:B188

; =============================================================================
; 7E:B1BE  top-status=strong  labels=2
; =============================================================================
; [strong] pass 55 :: ct_battler_to_visible_head_slot_inverse_map                 [strong]
; notes: Rebuilt from `AEFF[0..2]` at `FD:B28F..B2A3`. Semantics: `B1BE[battler] = visible head slot`. Consumed directly by `C1:BE50..BF24`.
; source: chrono_trigger_labels_pass55.md
L_7E_B1BE_ct_battler_to_visible_head_slot_inverse_map_strong:
    ; TODO: reconstruct body / data for 7E:B1BE

; [unspecified] pass 55 :: ct_visible_lane_inverse_lookup                               [strengthened]
; notes: Pass 55 makes the direction exact: battler index -> visible head slot Used by targeted readiness/gauge helpers after `B2EB/B2EC` selection.
; source: chrono_trigger_labels_pass55.md
L_7E_B1BE_ct_visible_lane_inverse_lookup_strengthened:
    ; TODO: reconstruct body / data for 7E:B1BE

; =============================================================================
; 7E:B1CF  top-status=strong  labels=1
; =============================================================================
; [strong] pass 60 :: ct_late_selector_segment_has_chained_second_subopcode_flag
; qualifier: strong
; notes: Set when `CC:[current_segment + 4] != FE`. Governs whether the late executor dispatches a second 4-byte sub-op from `+4`.
; source: chrono_trigger_labels_pass60.md
L_7E_B1CF_ct_late_selector_segment_has_chained_second_subopcode_flag:
    ; TODO: reconstruct body / data for 7E:B1CF

; =============================================================================
; 7E:B239  top-status=strong  labels=2
; =============================================================================
; [strong] pass 61 :: ct_current_c1_master_opcode_byte
; qualifier: strengthened
; notes: Previously carried as a late-pack subopcode byte. Pass 61 proves the stronger architectural read: it is the current opcode byte fed into the master C1 dispatcher. In the late-pack flow, it is the current pack-sourced global opcode byte.
; source: chrono_trigger_labels_pass61.md
L_7E_B239_ct_current_c1_master_opcode_byte:
    ; TODO: reconstruct body / data for 7E:B239

; [strong] pass 60 :: ct_current_late_selector_pack_subopcode
; qualifier: strong
; notes: Loaded from `CC:[B1D2 + 0]` immediately before the `B80D` dispatch. This is the current sub-op byte executed by the late selector-pack executor.
; source: chrono_trigger_labels_pass60.md
L_7E_B239_ct_current_late_selector_pack_subopcode:
    ; TODO: reconstruct body / data for 7E:B239

; =============================================================================
; 7E:B242  top-status=strong  labels=2
; =============================================================================
; [strong] pass 61 :: ct_tail_last_executed_global_opcode_bytes
; qualifier: strong
; notes: Directly proved by: `LDA B239` `STA B242,X` Holds the per-tail last executed global opcode byte. This corrects the older provisional “nonzero result mark” read.
; source: chrono_trigger_labels_pass61.md
L_7E_B242_ct_tail_last_executed_global_opcode_bytes:
    ; TODO: reconstruct body / data for 7E:B242
    ; known span hint: 7E:B242..7E:B249

; [provisional] pass 60 :: ct_tail_late_selector_nonzero_result_mark_bytes
; qualifier: provisional
; notes: Set to `FF` on the nonzero-`AF24` path inside `ct_execute_late_selector_pack_and_capture_tail_result`. Exact higher-level noun remains unresolved.
; source: chrono_trigger_labels_pass60.md
L_7E_B242_ct_tail_late_selector_nonzero_result_mark_bytes:
    ; TODO: reconstruct body / data for 7E:B242
    ; known span hint: 7E:B242..7E:B249

; =============================================================================
; 7E:B24A  top-status=strong  labels=2
; =============================================================================
; [strong] pass 61 :: ct_tail_last_opcode_result_status_bytes
; qualifier: strengthened
; notes: Pass 60 already proved these bytes capture `AF24` after execution. Pass 61 strengthens the surrounding controller context by pairing them directly with: `ct_tail_last_executed_global_opcode_bytes` `B263[x]` Best safe read now: per-tail last-op result/status bytes.
; source: chrono_trigger_labels_pass61.md
L_7E_B24A_ct_tail_last_opcode_result_status_bytes:
    ; TODO: reconstruct body / data for 7E:B24A
    ; known span hint: 7E:B24A..7E:B251

; [provisional] pass 60 :: ct_tail_late_selector_result_status_bytes
; qualifier: strengthened structural
; notes: `B24A[B252]` captures `AF24` after the current late-pack sub-op execution. The exact meaning of each result code is still open. Structural role as per-tail late-executor status capture is now strong.
; source: chrono_trigger_labels_pass60.md
L_7E_B24A_ct_tail_late_selector_result_status_bytes:
    ; TODO: reconstruct body / data for 7E:B24A
    ; known span hint: 7E:B24A..7E:B251

; =============================================================================
; 7E:B263  top-status=provisional  labels=2
; =============================================================================
; [provisional] pass 60 :: ct_tail_late_selector_has_following_segment_flags
; qualifier: provisional
; notes: Incremented when another FE-delimited segment is found and execution chains forward. Cleared when no following segment remains. Strongest safe reading so far: per-tail “has additional late-pack segment / chained segment present” flag or counter.
; source: chrono_trigger_labels_pass60.md
L_7E_B263_ct_tail_late_selector_has_following_segment_flags:
    ; TODO: reconstruct body / data for 7E:B263
    ; known span hint: 7E:B263..7E:B26A

; [unspecified] pass 61 :: ct_tail_has_additional_pack_segment_flags
; qualifier: strengthened
; notes: Still not fully finalized as a gameplay-facing noun. But pass 61 strengthens the structural role: controller-managed per-tail flag/counter for whether later FE-delimited work remains after the current executed segment.
; source: chrono_trigger_labels_pass61.md
L_7E_B263_ct_tail_has_additional_pack_segment_flags:
    ; TODO: reconstruct body / data for 7E:B263
    ; known span hint: 7E:B263..7E:B26A

; =============================================================================
; 7E:B3E7  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_c1_service7_enabled_lane0_flag
; qualifier: strong
; source: chrono_trigger_labels_pass42.md
L_7E_B3E7_ct_c1_service7_enabled_lane0_flag:
    ; TODO: reconstruct body / data for 7E:B3E7

; =============================================================================
; 7E:B3E8  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_c1_service7_enabled_lane1_flag
; qualifier: strong
; source: chrono_trigger_labels_pass42.md
L_7E_B3E8_ct_c1_service7_enabled_lane1_flag:
    ; TODO: reconstruct body / data for 7E:B3E8

; =============================================================================
; 7E:B3E9  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_c1_service7_enabled_lane2_flag
; qualifier: strong
; notes: Final enabled-lane flags derived from the canonical trio’s lane-ID pairs
; source: chrono_trigger_labels_pass42.md
L_7E_B3E9_ct_c1_service7_enabled_lane2_flag:
    ; TODO: reconstruct body / data for 7E:B3E9

; =============================================================================
; 7E:B3EA  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_fd_service7_lane_eligibility_hit
; qualifier: strong
; notes: Scratch result written by `FD:A8A5`. Nonzero means the currently tested lane family has a qualifying lane block.
; source: chrono_trigger_labels_pass42.md
L_7E_B3EA_ct_fd_service7_lane_eligibility_hit:
    ; TODO: reconstruct body / data for 7E:B3EA

