#!/usr/bin/env python3
from __future__ import annotations

import argparse, csv
from pathlib import Path

def load_overlay(path: Path, key_field: str):
    if not path.exists():
        return {}
    with path.open(encoding='utf-8', newline='') as f:
        rows = list(csv.DictReader(f))
    return {row[key_field].strip().upper(): row for row in rows if row.get(key_field)}

def write_rows(path: Path, key_field: str, count: int, cols: list[str], overlay: dict):
    with path.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for i in range(count):
            key = f'{i:02X}'
            row = {c: '' for c in cols}
            row[key_field] = key
            if 'decimal' in row: row['decimal'] = str(i)
            row['status'] = 'unknown'
            row.update(overlay.get(key, {}))
            w.writerow(row)

def main() -> None:
    ap = argparse.ArgumentParser(description='Expand starter opcode matrices into full-range coverage worksheets.')
    ap.add_argument('--data-dir', default='data')
    args = ap.parse_args()
    data = Path(args.data_dir); data.mkdir(parents=True, exist_ok=True)
    write_rows(data / 'ct_c1_master_opcode_coverage_full.csv', 'global_opcode_hex', 0x40, ['global_opcode_hex','decimal','slice','dispatch_addr','label','status','evidence_pass','notes'], load_overlay(data / 'ct_c1_master_opcode_matrix.csv', 'global_opcode_hex'))
    write_rows(data / 'ct_c1_selector_control_coverage_full.csv', 'selector_byte_hex', 0x53, ['selector_byte_hex','decimal','dispatch_addr','label','status','evidence_pass','notes'], load_overlay(data / 'ct_c1_selector_control_matrix.csv', 'selector_byte_hex'))
    write_rows(data / 'ct_service7_wrapper_coverage_full.csv', 'wrapper_opcode_hex', 0x08, ['wrapper_opcode_hex','decimal','dispatch_addr','label','status','evidence_pass','notes'], load_overlay(data / 'ct_service7_wrapper_matrix.csv', 'wrapper_opcode_hex'))
    print(data / 'ct_c1_master_opcode_coverage_full.csv')
    print(data / 'ct_c1_selector_control_coverage_full.csv')
    print(data / 'ct_service7_wrapper_coverage_full.csv')

if __name__ == '__main__':
    main()
