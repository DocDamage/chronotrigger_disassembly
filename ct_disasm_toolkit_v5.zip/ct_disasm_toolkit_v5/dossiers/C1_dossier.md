# Bank C1 Dossier

- Label rows: **62**
- Latest pass touching bank: **61**

## Status mix
- caution: **1**
- provisional: **7**
- strong: **45**
- unspecified: **9**

## Top labels carried in this bank
- `C1:B575`  **ct_c1_service7_reconcile_canonical_record_lane_pairs**  (strong, pass 42)
- `C1:B961`  **ct_c1_local_service2_wrapper**  (strong, pass 42)
- `C1:1B19`  **ct_c1_service1_enqueue_lane_and_mark_record_active**  (strong, pass 43)
- `C1:1B69`  **ct_c1_promote_pending_lane_into_active_roster**  (strong, pass 43)
- `C1:1BAA`  **ct_c1_service2_remove_lane_and_reseat_active_controller**  (strong, pass 43)
- `C1:1C3A`  **ct_c1_service2_restore_workspace_template_0b40**  (strong, pass 43)
- `C1:B961`  **ct_c1_local_service2_wrapper**  (strong, pass 43)
- `C1:1C3A`  **ct_c1_service2_restore_default_tilemap_template_0b40**  (strong, pass 44)
- `C1:07FD`  **ct_c1_compose_three_slot_panel_strip_into_0b40**  (strong, pass 45)
- `C1:0929`  **ct_c1_blit_6row_panel_segment_into_0b40_merge_left_border**  (strong, pass 45)
- `C1:07BD`  **ct_c1_blit_companion_strip_template_a_into_0cc0_pair29**  (strong, pass 46)
- `C1:07EE`  **ct_c1_blit_companion_strip_template_b_into_0cc0_pair29**  (strong, pass 46)
- `C1:07FD`  **ct_c1_compose_three_slot_panel_strip_into_0b40**  (unspecified, pass 46)
- `C1:081F`  **ct_c1_compose_three_slot_panel_strip_into_0b40**  (strong, pass 46)
- `C1:086D`  **ct_c1_clear_current_companion_strip_slice_0cc0**  (strong, pass 46)
- `C1:08E8`  **ct_c1_update_current_companion_strip_slice**  (strong, pass 46)
- `C1:0958`  **ct_c1_rebuild_companion_record_buffer_0e80**  (strong, pass 46)
- `C1:09B0`  **ct_c1_emit_fixed_format_companion_record**  (strong, pass 46)
- `C1:0299`  **ct_c1_rebuild_full_companion_strip_0cc0**  (strong, pass 47)
- `C1:06F0`  **ct_c1_render_scaled_lane_bar_into_0cc0**  (strong, pass 47)
- `C1:08E8`  **ct_c1_fill_current_companion_strip_slice_from_anchor_table**  (unspecified, pass 47)
- `C1:1918`  **ct_c1_refresh_current_0e80_lane_marker_glyphs**  (strong, pass 47)
- `C1:011F`  **ct_c1_format_u16_as_three_decimal_tile_bytes_949d_949f**  (strong, pass 48)
- `C1:0174`  **ct_c1_format_u16_as_two_decimal_tile_bytes_949e_949f**  (strong, pass 48)
- `C1:0299`  **ct_c1_rebuild_full_companion_strip_0cc0**  (unspecified, pass 48)

## Highest-value open work
- early global opcode band inside `C1:B80D..C1:B95F`
- resume conditions between opcode slices
- unresolved handler semantics above the proved late-pack/master-dispatch seam

## Notes
- Generated from the persistent label DB. Use this as the fast bank-local briefing before reopening pass notes.

