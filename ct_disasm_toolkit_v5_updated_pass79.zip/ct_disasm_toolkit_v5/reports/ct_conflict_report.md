# Conflict Report

- Total conflicts detected: **48**

## Conflict list
- `address_multiple_labels` :: **7E:0B40** :: / 00:0B40  ct_c1_tilemap_staging_buffer_vram7a00_0180        [strong] | / 00:0B40  ct_c1_tilemap_strip_buffer_32x6_words_vram7a00     [strong] | ct_c1_lane_roster_strip_tilemap_buffer | ct_c1_panel_or_screen_tilemap_buffer
- `address_multiple_labels` :: **7E:0CC0..7E:0E08** :: ct_c1_companion_paired_byte_strip_buffer | ct_c1_roster_presentation_companion_strip | ct_c1_three_lane_status_or_command_strip
- `address_multiple_labels` :: **7E:0E80..7E:0FFF** :: ct_c1_companion_record_buffer_0x180 | ct_c1_roster_presentation_companion_records | ct_c1_three_lane_marker_record_presentation_block
- `address_multiple_labels` :: **7E:2D00..7E:2DFF** :: ct_c1_service04_packed_fragment_row_stream_workspace | ct_c1_service04_packed_tile_row_or_tile_batch_workspace
- `address_multiple_labels` :: **7E:5E30** :: ct_c1_lane_current_hp | ct_c1_lane_primary_numeric_field
- `address_multiple_labels` :: **7E:5E32** :: ct_c1_lane_max_hp | ct_c1_lane_secondary_numeric_field
- `address_multiple_labels` :: **7E:5E34** :: ct_c1_lane_aux_two_digit_numeric_field | ct_c1_lane_current_mp
- `address_multiple_labels` :: **7E:99DD** :: ct_c1_lane_active_time_gauge_current_fill_export | ct_c1_lane_active_time_gauge_progress_export | ct_c1_lane_display_value_for_scaled_bar | ct_c1_lane_primary_value_export_a | ct_c1_service7_lane_shadow_value_1 | old wording “display value for scaled bar”                 [replaced] | old wording “lane_active_time_gauge_progress_export”                    [replaced]
- `address_multiple_labels` :: **7E:9F22** :: ct_c1_lane_active_time_gauge_cap_export | ct_c1_lane_active_time_gauge_goal_or_cap_export | ct_c1_lane_display_divisor_or_capacity | ct_c1_lane_primary_value_export_b | ct_c1_service7_lane_shadow_value_2 | old wording “display divisor or capacity”                  [replaced] | old wording “lane_active_time_gauge_cap_export”                         [replaced]
- `address_multiple_labels` :: **7E:9F38** :: ct_c1_lane_emitted_aux_or_mask | ct_c1_service7_slot_aux_flags_for_emitted_records
- `address_multiple_labels` :: **7E:A10F** :: ct_c1_lane_hp_threshold_numeric_attr_selector | ct_c1_numeric_threshold_or_warning_counter | old wording “numeric threshold or warning counter”
- `address_multiple_labels` :: **7E:AEC5** :: ct_visible_head_active_slot_count | ct_visible_head_occupied_slot_count
- `address_multiple_labels` :: **7E:AEC6** :: ct_canonical_tail_slot_count | ct_runtime_tail_slot_count
- `address_multiple_labels` :: **7E:AEFF..7E:AF09** :: ct_battle_slot_active_entry_gate_array | ct_battle_slot_occupant_index_map | “active-entry gate array”
- `address_multiple_labels` :: **7E:AF0A..7E:AF14** :: ct_battle_slot_default_occupant_index_map | ct_battle_slot_occupant_index_mirror | “occupant mirror”
- `address_multiple_labels` :: **7E:AF15** :: bit 6  ct_runtime_slot_sibling_seed_side_effect_flag                  [provisional] | bit 6  ct_runtime_tail_slot_seed_side_effect_flag                     [provisional] | bit 7  ct_tail_canonical_present_but_not_live_flag               [strengthened] | bit 7  ct_tail_deferred_materialization_flag                              [strengthened]
- `address_multiple_labels` :: **7E:AFAB** :: ct_c1_lane_active_time_increment_shadow | ct_c1_lane_primary_carried_value_shadow | ct_c1_lane_readiness_work_value | ct_c1_primary_lane_readiness_work_value | ct_c1_service7_lane_shadow_value_0 | old wording “lane_active_time_increment_shadow”                         [soft-replaced] | value `0`  ct_battle_slot_readiness_zero_special_state                [provisional]
- `address_multiple_labels` :: **7E:B03A** :: ct_c1_lane_secondary_dirty_latch | ct_c1_primary_visible_lane_readiness_seed_valid_flag | ct_c1_service7_lane_aux_reset_field | ct_c1_visible_lane_readiness_seed_valid_flag
- `address_multiple_labels` :: **7E:B158** :: / 7E:AFAB old wording “primary carried scalar/shadow”      [replaced] | ct_c1_lane_base_active_time_increment | ct_c1_lane_primary_carried_value | ct_c1_lane_readiness_seed_value | ct_c1_primary_lane_readiness_seed_value | ct_c1_service7_lane_carried_value | old wording “lane_base_active_time_increment”                           [soft-replaced]
- `address_multiple_labels` :: **7E:B188** :: ct_c1_lane_occupied_refresh_latch | ct_c1_service7_lane_occupied_or_latched_flag
- `address_multiple_labels` :: **7E:B1BE..** :: ct_battler_to_visible_head_slot_inverse_map                 [strong] | ct_visible_lane_inverse_lookup                               [strengthened]
- `address_multiple_labels` :: **7E:B239** :: ct_current_c1_master_opcode_byte | ct_current_late_selector_pack_subopcode
- `address_multiple_labels` :: **7E:B242..7E:B249** :: ct_tail_last_executed_global_opcode_bytes | ct_tail_late_selector_nonzero_result_mark_bytes
- `address_multiple_labels` :: **7E:B24A..7E:B251** :: ct_tail_last_opcode_result_status_bytes | ct_tail_late_selector_result_status_bytes
- `address_multiple_labels` :: **7E:B263..7E:B26A** :: ct_tail_has_additional_pack_segment_flags | ct_tail_late_selector_has_following_segment_flags
- `address_multiple_labels` :: **7E:CA93..7E:CA9F** :: ct_cd_auxiliary_descriptor_id_list_first_two_seed_runtime_slots | ct_cd_auxiliary_fragment_descriptor_list
- `address_multiple_labels` :: **C1:06F0** :: ct_c1_render_lane_active_time_gauge_into_0cc0 | ct_c1_render_scaled_lane_bar_into_0cc0 | old wording “render scaled lane bar into 0CC0”             [replaced]
- `address_multiple_labels` :: **C1:08E8** :: ct_c1_fill_current_companion_strip_slice_from_anchor_table | ct_c1_update_current_companion_strip_slice
- `address_multiple_labels` :: **C1:1C3A** :: ct_c1_service2_restore_default_tilemap_template_0b40 | ct_c1_service2_restore_workspace_template_0b40
- `address_multiple_labels` :: **C1:48EC..C1:493F** :: ct_c1_service04_parse_ce_profile_stream_into_a280_a2a0_work_vectors | ct_c1_service04_parse_segmented_ce_fragment_group_stream_into_a280_starts_and_a2a0_counts
- `address_multiple_labels` :: **C1:4943..C1:49FD** :: ct_c1_service04_build_one_output_record_batch_into_a2d3_and_a45x_workspace | ct_c1_service04_decode_one_packed_fragment_batch_into_a2d3_and_a450_quad_workspace
- `address_multiple_labels` :: **C1:8461..C1:883B** :: ct_global_opcode_9C_service7_tail_lane_admission_reseat_and_readiness_refresh_controller | ct_service7_tail_lane_admission_reseat_and_readiness_refresh_controller
- `address_multiple_labels` :: **C1:88C5..C1:8974** :: ct_global_opcode_91_compute_scaled_lane_delta_queue_live_packet_and_run_followup_7f_tail | ct_global_opcode_91_conditionally_seed_afc1_af32_and_ad9c_from_lane_geometry
- `address_multiple_labels` :: **C1:8A9F..C1:8B0F** :: ct_global_opcode_98_capture_lane_b12c_variant_into_af7f_and_optionally_apply_one_point_primary_delta | ct_global_opcode_98_capture_lane_b12c_variant_into_af7f_and_optionally_run_ec7f
- `address_multiple_labels` :: **C1:8B10..C1:8BB8** :: ct_global_opcode_99_update_lane_b019_b0a8_and_on_expiry_conditionally_seed_ad9c | ct_global_opcode_99_update_lane_b019_b0a8_and_on_expiry_queue_secondary_plus5_packet_with_followup_7f_tail
- `address_multiple_labels` :: **C1:AB03..C1:AB49** :: ct_build_withheld_tail_candidate_list_and_random_reduce_to_one | ct_global_opcode_86_build_withheld_tail_candidate_list_and_random_reduce_to_one
- `address_multiple_labels` :: **C1:AB9B..C1:ABC8** :: ct_global_opcode_8E_select_one_visible_entry_0_1_2_by_min_lane_value | ct_select_one_visible_entry_0_1_2_by_min_lane_value
- `address_multiple_labels` :: **C1:ABC9..C1:AC13** :: ct_build_live_tail_slot_candidate_list_and_random_reduce_to_one | ct_global_opcode_8F_build_live_tail_slot_candidate_list_and_random_reduce_to_one
- `address_multiple_labels` :: **C1:AC57..C1:AC5D** :: ct_c1_run_common_followup_tail_then_apply_pending_stat_deltas | ct_c1_run_service_04_hook_then_apply_pending_stat_deltas
- `address_multiple_labels` :: **C1:AFD7..C1:B08E** :: ct_execute_late_selector_pack_and_capture_tail_result | ct_global_opcode_A0_execute_late_selector_pack_and_capture_tail_result
- `address_multiple_labels` :: **C1:B8BB..C1:B95F** :: ct_c1_inline_selector_control_dispatch_slice | ct_inline_selector_control_dispatch_table
- `address_multiple_labels` :: **CC:2E31** :: ct_cc_battle_speed_page_speed_to_readiness_seed_adjust_table | ct_cc_speed_like_stat_to_readiness_bonus_table | old wording “speed-like stat -> readiness bonus table”               [soft-replaced]
- `address_multiple_labels` :: **D1:5800** :: / D1:5A50 / D1:5BD0  ct_d1_alt_base_strip_layout_family        [provisional] | / D1:5A50 / D1:5BD0  ct_d1_alt_base_strip_layout_family      [strengthened context] | / D1:5A50 / D1:5BD0  ct_d1_base_strip_template_family_32x6     [strong] | / D1:5A50 / D1:5BD0  ct_d1_tilemap_template_family_16x12_words [provisional] | / D1:5A50 / D1:5BD0  ct_d1_tilemap_template_family_16x12_words [withdrawn] | ct_d1_base_strip_template_default | ct_d1_tilemap_template_default_0b40_0180
- `address_multiple_labels` :: **D1:5A50** :: ct_d1_base_strip_template_latched_alt | ct_d1_tilemap_template_alt_a_0b40_0180
- `address_multiple_labels` :: **D1:5BD0** :: ct_d1_base_strip_template_transition_alt | ct_d1_tilemap_template_alt_b_0b40_0180
- `address_multiple_labels` :: **FD:B820..FD:B850** :: ct_fd_seed_primary_visible_lane_readiness_from_config_and_speed | ct_fd_seed_visible_lane_readiness_from_speed_like_stat | old wording “seed ... from speed-like stat”                 [soft-replaced]
- `address_multiple_labels` :: **FD:B8C0..FD:B8E0** :: ct_fd_seed_sibling_visible_lane_readiness_from_config_and_speed | ct_fd_seed_visible_lane_readiness_sibling_family
- `label_multiple_addresses` :: **ct_c1_compose_three_slot_panel_strip_into_0b40** :: C1:07FD | C1:081F

## Notes
- This report is intentionally conservative. It flags likely review items, not guaranteed mistakes.

