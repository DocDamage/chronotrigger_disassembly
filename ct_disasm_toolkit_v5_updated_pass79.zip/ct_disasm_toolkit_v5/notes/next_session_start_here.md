# Next Session Start Here

1. Read `notes/community_research_first.md`
2. Open these in order:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `dossiers/C1_dossier.md`
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - latest pass + labels
3. Active top-of-stack seam after pass 78:
   - decode the four local transform/materialization modes under `CD:13E6`
   - tighten the final noun of the `CA32/52/72` auxiliary fragment work tables seeded by `CD:0018`
   - keep pushing toward the final noun of the `4500.. / 5D00.. / A07B` output family
4. Specific cleanup targets:
   - decide whether the `2D00..` row sections are best modeled as command rows, fragment rows, or a still tighter noun
   - freeze the final roles of `9877..9885`
   - re-open mode-3 callers `BADA / BB15` with the cleaner front-half pipeline in hand
   - decode the four local section-build targets at `CD:13F6 / 1445 / 14EE / 1509`
5. Runtime confirmation shortlist:
   - current-tail path `BFAA -> CD:0015/002A -> optional CD:0018 -> C3:0002 -> 4943`
   - fixed-`7F` path `895B -> CD:0015/002A -> optional CD:0018 -> C3:0002 -> 4943`
   - high-range path `BADA/BB15 -> CD:0015/002A -> optional CD:0018 -> C3:0002 -> 4943`
   - `0306` as returned output-size / destination-advance from `C3:0557`
