; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_C7
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; C7:0004  top-status=strong  labels=1
; =============================================================================
; [strong] pass 93 :: ct_c7_branch_to_0140_low_bank_packet_dispatcher_veneer
; qualifier: strong
; notes: Exact body: `JMP $0140`. Lands at exact target `C7:0140`. Strongest safe reading: veneer for the low-bank packet opcode-family dispatcher behind all the `1E00..` command-packet submit helpers.
; source: chrono_trigger_labels_pass93.md
C7_0004_ct_c7_branch_to_0140_low_bank_packet_dispatcher_veneer:
    ; TODO: reconstruct body / data for C7:0004
    ; known span hint: C7:0004..C7:0006

; =============================================================================
; C7:0140  top-status=strong  labels=2
; =============================================================================
; [strong] pass 94 :: ct_c7_dispatch_1e00_sound_command_opcode_families_into_apu_port_handlers
; qualifier: strong structural
; notes: Pass 93 already froze this range as the exact `1E00` opcode-family dispatcher. Pass 94 upgrades the subsystem noun with downstream proof: opcode `0x70` lands at `08E3`, which performs exact traffic through `2140..2143` opcode `0x71` lands at `0755`, which also performs exact repeated writes through `2141..2143` the `0x10..0x17` gate table at `0AD9` is now exact Strongest safe reading: exact low-bank **sound/APU command** opcode-family dispatcher over the `1E00..` workspace.
; source: chrono_trigger_labels_pass94.md
C7_0140_ct_c7_dispatch_1e00_sound_command_opcode_families_into_apu_port_handlers:
    ; TODO: reconstruct body / data for C7:0140
    ; known span hint: C7:0140..C7:019D

; [strong] pass 93 :: ct_c7_dispatch_1e00_packet_opcode_families_into_low_bank_handlers
; qualifier: strong structural
; notes: Exact prologue saves `B`, `D`, flags, `A`, `X`, and `Y`. Sets exact direct page to `D = 0x1E00`. Forces `DB = 0x00`. Reads exact packet header bytes from the `1E00..` workspace, including `1E00` and `1E05`. If `1E05` is negative, diverts into the special path at `01A1`. If `1E00 == 00`, exits immediately. Exact opcode-family split from `1E00` is now frozen: `0x10..0x17` -> indexed indirect jump through table `0AD9` `0x18..0x2F` -> `JMP $061C` `0x30..0x3F` -> `JMP $071D` `0x70` -> `JMP $08E3` `0x71` -> `JMP $0755` Unsupported / finished paths clear exact byte `1E00` before restoring state and returning with `RTL`. Strongest safe reading: exact low-bank packet opcode-family dispatcher over the `1E00..` command packet workspace.
; source: chrono_trigger_labels_pass93.md
C7_0140_ct_c7_dispatch_1e00_packet_opcode_families_into_low_bank_handlers:
    ; TODO: reconstruct body / data for C7:0140
    ; known span hint: C7:0140..C7:019D

; =============================================================================
; C7:0192  top-status=strong  labels=1
; =============================================================================
; [strong] pass 94 :: ct_c7_common_dispatch_exit_and_register_restore_epilogue
; qualifier: strong
; notes: Exact body: `SEP #$20` `STZ $00` `REP #$20` `REP #$10` restores `Y`, `X`, `A`, flags, direct page, and bank returns with `RTL` Strongest safe reading: exact common dispatcher exit / cleanup epilogue used by the low-bank C7 sound-command side.
; source: chrono_trigger_labels_pass94.md
C7_0192_ct_c7_common_dispatch_exit_and_register_restore_epilogue:
    ; TODO: reconstruct body / data for C7:0192
    ; known span hint: C7:0192..C7:01A0

; =============================================================================
; C7:01A1  top-status=strong  labels=1
; =============================================================================
; [strong] pass 95 :: ct_c7_negative_1e05_special_path_rebuild_candidate_slot_strips_at_1f00_and_1f20_before_reconcile
; qualifier: strong structural
; notes: Validates exact selector byte `1E01` against exact long value at `C7:0AE9`. Calls exact local helpers `0734` and `0A39`. Copies `1E01 -> 1E05`. Clears two exact 0x20-byte strips through the loop over `1EFE..1F1E` and `1F1E..1F3E`. Scans backward through exact live strip `1E20..1E3E` to seed the last-active index in `0C`. Seeds exact staging pointers: `12 = 1F00` `14 = 1F20` Walks the exact long table rooted at `C7:0E11`: writes nonzero entries into `[12]` / `1F00..` writes entries not already present in `1E20..1E3E` into `[14]` / `1F20..` If `1F20 == 0`, jumps directly to `037B`. Strongest safe reading: candidate rebuild / staging gate for the negative-`1E05` special sound-command path.
; source: chrono_trigger_labels_pass95.md
C7_01A1_ct_c7_negative_1e05_special_path_rebuild_candidate_slot_strips_at_1f00_and_1f20_before_r:
    ; TODO: reconstruct body / data for C7:01A1
    ; known span hint: C7:01A1..C7:0216

; =============================================================================
; C7:0217  top-status=strong  labels=1
; =============================================================================
; [strong] pass 95 :: ct_c7_reconcile_unmatched_1f20_candidates_into_live_1e20_1e40_1e60_slot_state_using_apu_command_07
; qualifier: strong structural
; notes: Prunes dead entries from live `1E20..1E3E` if absent from the candidate strip at `1F00..1F1E`. Finds the first open live slot and the last occupied live slot. If those are equal, jumps directly to `0326`. Otherwise sends exact APU command byte `0x07` through `$2141`. Iterates over unmatched/new strip `1F20..1F3E`. Migrates/mirrors exact values into the live strips `1E20..`, `1E40..`, and `1E62..` while writing exact triplets through `$2142/$2143`. Updates exact local byte `84` through repeated calls to `09DA`. On the no-free-slot path, sends exact zero payload through `$2142/$2143` and rebuilds `1EFE..1F7E` from exact table `C7:0E0F`. Strongest safe reading: live-slot reconcile / migration phase of the negative-`1E05` path using APU command `0x07`.
; source: chrono_trigger_labels_pass95.md
C7_0217_ct_c7_reconcile_unmatched_1f20_candidates_into_live_1e20_1e40_1e60_slot_state_using_apu_:
    ; TODO: reconstruct body / data for C7:0217
    ; known span hint: C7:0217..C7:0325

; =============================================================================
; C7:037B  top-status=strong  labels=1
; =============================================================================
; [strong] pass 95 :: ct_c7_emit_staged_special_path_blocks_from_1f80_with_apu_command_02
; qualifier: strong structural
; notes: Seeds exact pointer `12 = 1F80`. Walks candidate strip `1F00..1F1E` and writes paired output words into `1F80..`. Uses exact long table `C7:0BA4` for the paired-output build when entries are already present in live `1E20..`. Sends an exact command-`0x02` block header through APU ports: `$2143 = 0x1E` `$2142 = 0x80` `$2141 = 0x02` Streams the exact staged `1F80..1FBF` block. Sends two more exact command-`0x02` blocks rooted at: `1F40..` using exact table `C7:0C20` `1FC0..` using exact table `C7:0C9C` Repeatedly updates exact local byte `84` through `JSR 09DA` and normalizes it back to `0xE0`. Strongest safe reading: staged command-`0x02` emit phase of the negative-`1E05` special sound-command path.
; source: chrono_trigger_labels_pass95.md
C7_037B_ct_c7_emit_staged_special_path_blocks_from_1f80_with_apu_command_02:
    ; TODO: reconstruct body / data for C7:037B
    ; known span hint: C7:037B..C7:04B0

; =============================================================================
; C7:0755  top-status=strong  labels=1
; =============================================================================
; [strong] pass 94 :: ct_c7_handle_opcode_71_as_table_driven_apu_triplet_burst_sender
; qualifier: strong structural
; notes: Exact opening behavior: checks exact per-slot/state byte `1E20` if that state is active and `1E01 == 0`, exits through `0192` Exact setup behavior: computes `(1E01 - 1) * 3` indexes the exact table rooted at `C7:0AEA` Exact hardware-facing behavior: performs repeated three-byte burst writes through `2141 / 2142 / 2143` issues exact fixed follow-up command writes including `2141 = 0x05` later issues exact `2141 = 0x02` with paired `2142/2143` values Exact tail behavior: caches the current `1E01` value into the per-slot strip at `1E20 + X` exits through the common cleanup path at `0192` Strongest safe reading: exact opcode-`0x71` table-driven APU burst sender / uploader over the `1E00..` sound-command workspace.
; source: chrono_trigger_labels_pass94.md
C7_0755_ct_c7_handle_opcode_71_as_table_driven_apu_triplet_burst_sender:
    ; TODO: reconstruct body / data for C7:0755
    ; known span hint: C7:0755..C7:08E2

; =============================================================================
; C7:08E3  top-status=strong  labels=1
; =============================================================================
; [strong] pass 94 :: ct_c7_handle_opcode_70_as_apu_handshake_and_triplet_packet_sender
; qualifier: strong structural
; notes: Exact opening behavior: reads `1E01` compares against the latched pair at `1E10 / 1E11` Exact hardware-facing behavior: performs handshake traffic through `2140` using `0xFE` later uses exact `2140` handshake/reset traffic with `0xE0` performs repeated command/data triplets through `2141 / 2142 / 2143` selects exact command byte `0x05` when `1E00 == 0x70` otherwise uses exact command byte `0x03` on the shared internal path Exact table-backed send behavior: sources repeated triplet payloads from exact tables rooted at `C7:430B` and `C7:5B0D` clears exact local latch byte `F3` before returning in the table-send paths Strongest safe reading: exact opcode-`0x70` APU handshake / packet-send handler behind the `1E00` sound-command dispatcher.
; source: chrono_trigger_labels_pass94.md
C7_08E3_ct_c7_handle_opcode_70_as_apu_handshake_and_triplet_packet_sender:
    ; TODO: reconstruct body / data for C7:08E3
    ; known span hint: C7:08E3..C7:09D8

; =============================================================================
; C7:0AD9  top-status=strong  labels=1
; =============================================================================
; [strong] pass 94 :: ct_c7_packet_opcode_10_17_gate_table_to_active_handler_or_common_exit
; qualifier: strong
; notes: Exact eight-entry 16-bit table for packet opcodes `0x10..0x17`: `0x10 -> 01A1` `0x11 -> 01A1` `0x12 -> 0192` `0x13 -> 0192` `0x14 -> 01A1` `0x15 -> 01A1` `0x16 -> 0192` `0x17 -> 0192` Strongest safe reading: exact two-target early gate for the `0x10..0x17` family, splitting to either the active handler (`01A1`) or the immediate common exit (`0192`).
; source: chrono_trigger_labels_pass94.md
C7_0AD9_ct_c7_packet_opcode_10_17_gate_table_to_active_handler_or_common_exit:
    ; TODO: reconstruct body / data for C7:0AD9
    ; known span hint: C7:0AD9..C7:0AE8

