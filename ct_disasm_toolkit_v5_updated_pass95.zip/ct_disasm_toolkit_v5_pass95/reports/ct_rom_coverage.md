# ROM / WRAM Coverage View

Lower-bound coverage only. Point labels count as a single byte unless a wider range is explicitly known.

## 00
- Covered bytes: **210** / 65536 (**0.320%**)
- Labels: **3**  strong=0 provisional=3 caution=0 alias=0

## 7E
- Covered bytes: **8621** / 65536 (**13.155%**)
- Labels: **226**  strong=92 provisional=89 caution=1 alias=1

## 7F
- Covered bytes: **1** / 65536 (**0.002%**)
- Labels: **1**  strong=0 provisional=1 caution=0 alias=0

## C0
- Covered bytes: **797** / 65536 (**1.216%**)
- Labels: **7**  strong=5 provisional=1 caution=0 alias=0

## C1
- Covered bytes: **13045** / 65536 (**19.905%**)
- Labels: **215**  strong=186 provisional=18 caution=1 alias=0

## C2
- Covered bytes: **550** / 65536 (**0.839%**)
- Labels: **10**  strong=10 provisional=0 caution=0 alias=0

## C3
- Covered bytes: **853** / 65536 (**1.302%**)
- Labels: **2**  strong=2 provisional=0 caution=0 alias=0

## C7
- Covered bytes: **1459** / 65536 (**2.226%**)
- Labels: **10**  strong=10 provisional=0 caution=0 alias=0

## CC
- Covered bytes: **369** / 65536 (**0.563%**)
- Labels: **13**  strong=10 provisional=2 caution=0 alias=0

## CD
- Covered bytes: **2560** / 65536 (**3.906%**)
- Labels: **72**  strong=71 provisional=1 caution=0 alias=0

## CE
- Covered bytes: **325** / 65536 (**0.496%**)
- Labels: **3**  strong=3 provisional=0 caution=0 alias=0

## CF
- Covered bytes: **1** / 65536 (**0.002%**)
- Labels: **1**  strong=1 provisional=0 caution=0 alias=0

## D0
- Covered bytes: **96** / 65536 (**0.146%**)
- Labels: **1**  strong=1 provisional=0 caution=0 alias=0

## D1
- Covered bytes: **3076** / 65536 (**4.694%**)
- Labels: **43**  strong=35 provisional=6 caution=0 alias=0

## FD
- Covered bytes: **818** / 65536 (**1.248%**)
- Labels: **21**  strong=11 provisional=8 caution=0 alias=0

