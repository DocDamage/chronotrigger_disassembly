# bsnes / bsnes-plus runtime notes for this project

This is not a substitute for ROM proof.
It is the runtime-confirmation layer to use when static analysis stops being enough.

## Best uses for bsnes in this project
- confirm which late selector-control bytes are actually emitted
- trace pack/replay execution around the late-tail executor
- verify when `0B40` / `0CC0` / `0E80` mutations happen relative to UI updates
- observe readiness/head-tail occupancy changes live
- confirm deferred tail materialization triggers and reinsertion timing

## Suggested breakpoint/watch targets from current top-of-stack
- `C1:AC14`
- `C1:AFD7`
- `C1:B80D`
- `C1:8C0A`
- `C1:8CE7`
- `C1:8D88`
- `C1:07BD`
- `C1:081F`
- `C1:0958`
- `C1:0299`
- `FD:B8F7`

## Suggested WRAM watches
- `7E:0B40`
- `7E:0CC0`
- `7E:0E80`
- `7E:99DD..99DF`
- `7E:9F22..9F24`
- `7E:AEFF..AF15`
- `7E:B158..B162`
- `7E:AFAB..AFB5`
- `7E:B03A..B044`

## Practical rule
Use emulator traces to confirm:
- which path fired
- in what order
- with what live values

Then push the naming back into the ROM-side pass notes.
Do not let live emulator state by itself become the label proof.
