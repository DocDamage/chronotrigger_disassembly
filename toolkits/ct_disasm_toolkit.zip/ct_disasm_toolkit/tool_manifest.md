# Tool Manifest

## What this bundle gives you
A reusable helper layer for continuing the Chrono Trigger ROM disassembly without recreating:

- address conversion
- range dumping
- byte-pattern search
- pointer-table inspection
- xref scans
- pass/label scaffolding
- pass/label inventory
- label merging

## What it does **not** give you
- a full disassembler
- a rebuildable source tree
- a final symbol database
- full opcode semantics
- automatic subsystem naming

## Best current use
Use it against the current top-of-stack where `C1:B80D` is the master bank-C1 opcode dispatch table and the next live opcode seam is the early global opcode band.
