# Chrono Trigger ROM Disassembly Toolkit

This is a reusable utility bundle for continuing the Chrono Trigger (USA) ROM disassembly without recreating the helper layer from scratch.

It is built around the current project state where:
- **Pass 61** is the latest pass
- **`C1:B80D`** is the current strongest master bank-C1 opcode dispatch result
- the next live opcode seam is the **early global opcode band** inside that master table

These scripts are not a fake complete disassembler.
They are the practical utility layer used for the kind of work done in this session:
- address conversion
- ROM range dumping
- byte/pattern searching
- pointer-table inspection
- xref scanning
- pass/label scaffolding
- pass/label inventory
- label consolidation

## Folder layout

- `scripts/ct_common.py` — shared ROM/address helpers
- `scripts/ct_addr.py` — SNES/PC address conversion
- `scripts/ct_dump_range.py` — range dump with byte/word/long views
- `scripts/ct_find_bytes.py` — byte-pattern search with `??` wildcards
- `scripts/ct_ptr_table.py` — inspect pointer tables (16-bit local-bank or 24-bit long)
- `scripts/ct_xrefs.py` — search for xrefs/calls/raw address-byte matches
- `scripts/ct_make_pass.py` — scaffold next disassembly pass + labels file
- `scripts/ct_pass_index.py` — inventory passes/labels and show latest pass
- `scripts/ct_merge_labels.py` — consolidate label files into one merged artifact

## ROM assumptions

Default ROM profile:
- headerless
- 4 MiB
- HiROM
- Chrono Trigger (USA)

Default path if omitted:
- `./Chrono Trigger (USA).sfc`

You can override with `--rom`.

## Quick examples

### 1) Convert addresses
```bash
python scripts/ct_addr.py C1:B80D
python scripts/ct_addr.py 0x31B80D --mode pc-to-snes
```

### 2) Dump the master C1 dispatch area
```bash
python scripts/ct_dump_range.py C1:B80D --length 0xC0 --width 16
python scripts/ct_dump_range.py C1:B80D --length 0x60 --words
```

### 3) Inspect a local-bank 16-bit pointer table
```bash
python scripts/ct_ptr_table.py C1:B80D --count 16 --kind local16 --bank C1
python scripts/ct_ptr_table.py CC:8B08 --count 8 --kind long24
```

### 4) Search for an emitted opcode pattern or byte sequence
```bash
python scripts/ct_find_bytes.py "22 ?? ?? C1"
python scripts/ct_find_bytes.py "FE FF"
```

### 5) Search for callers/xrefs to an address
```bash
python scripts/ct_xrefs.py C1:AC14 --mode calls
python scripts/ct_xrefs.py C1:B80D --mode word --bank C1
python scripts/ct_xrefs.py C1:AFD7 --mode raw
```

### 6) Scaffold the next pass
```bash
python scripts/ct_make_pass.py --dir .
```

### 7) See the current pass inventory
```bash
python scripts/ct_pass_index.py --dir .
```

### 8) Merge all labels into one file
```bash
python scripts/ct_merge_labels.py --dir . --output merged_labels.md
```

## Suggested next-session flow

1. Refresh community context first (Chrono Compendium, Data Crystal, Temporal Flux/Kajar Labs vocabulary, bsnes workflow).
2. Read:
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - `chrono_trigger_disasm_pass59.md`
   - `chrono_trigger_disasm_pass60.md`
   - `chrono_trigger_disasm_pass61.md`
3. Use this toolkit to continue on the early global opcode band inside `C1:B80D`.

## Notes

- These tools are intentionally conservative.
- They help with disassembly work, but they do not replace proof.
- Keep strong and provisional labels separated.
- Do not let raw byte matches override actual control-flow evidence.
