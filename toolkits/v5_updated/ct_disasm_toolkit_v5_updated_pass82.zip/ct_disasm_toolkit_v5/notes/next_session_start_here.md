# Next Session Start Here

1. Read `notes/community_research_first.md`
2. Open these in order:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `dossiers/C1_dossier.md`
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - `chrono_trigger_disasm_pass82.md`
   - `chrono_trigger_labels_pass82.md`
3. Active top-of-stack seam after pass 82:
   - finish the `CE12 / CDC8 / CE0F` control half-cycle around the new D1 palette-band helpers
   - re-open `D1:F42B..F46C` as the downstream consumer/gate for the pass-82 seed/promote cluster
   - re-open `D1:E71D..E77A` as the exact swap/exchange path for the `2120/21A0` and `2320/23A0` bands
   - then return to the remaining auxiliary command families at `0x88..0x9F`
4. Specific cleanup targets:
   - decide whether the `2040/20A0/2120/21A0/2240/22A0/2320/23A0` families are best frozen as palette pages, palette lanes, or another tighter noun
   - tighten the exact nouns of `CD2F..CD34`
   - tighten the exact `+1` and `+4` field nouns inside the `0520` and `0544` 3-record slabs as used by `E91A/E984`
   - decide whether `D0:FD00..FD5F` should be frozen as a default seed page, boot page, or another stricter palette-band noun
5. Runtime confirmation shortlist:
   - `D1:E984` seed path from `D0:FD00 -> 2040/2240`
   - `D1:E91A` promote path `2040/2240 -> 20A0/22A0`
   - `D1:F42B..F46C` gated behavior when `CE12` is zero vs nonzero
   - `D1:E71D..E77A` swap path over `2120/21A0` and `2320/23A0`
   - auxiliary VM wrapper chain `0x17 / 0x18 / 0x1A / 0x1C`
