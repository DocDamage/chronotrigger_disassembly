; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_00
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; 00:1E00  top-status=provisional  labels=2
; =============================================================================
; [provisional] pass 94 :: ct_c7_low_bank_sound_apu_command_packet_workspace
; qualifier: provisional strengthened
; notes: Pass 93 already proved this workspace is the live header family consumed by `C7:0140`. Pass 94 upgrades the noun with hardware-facing proof from `0755` and `08E3`. Exact proven fields now include: `1E00` = sound/APU command opcode / opcode-family selector `1E01` = active selector / payload byte consumed by the `0x70` and `0x71` handlers `1E10 / 1E11` = exact latch pair consumed by the `0x70` handshake path Strongest safe reading: low-bank sound/APU command packet workspace consumed by the `C7:0140` dispatcher and its exact downstream handlers.  I have **not** frozen the final gameplay-facing noun of the broader C2 stream language behind `58B2 / 5BF5 / 5C3E / 5C77`. I have **not** frozen the final user-facing meaning of each opcode family in the C7 sound/APU command set. I have **not** returned to the first exact clean-code external reader of `CE0F` yet. I **have** crossed an important noun threshold: the C7 packet side is no longer honestly describable as “generic low-bank packet machinery”.
; source: chrono_trigger_labels_pass94.md
L_00_1E00_ct_c7_low_bank_sound_apu_command_packet_workspace:
    ; TODO: reconstruct body / data for 00:1E00
    ; known span hint: 00:1E00..00:1E10

; [provisional] pass 93 :: ct_c7_low_bank_command_packet_header_workspace
; qualifier: provisional strengthened
; notes: Pass 93 proves `C7:0140..019D` sets `D = 0x1E00` and consumes exact header bytes from this low-bank workspace. Exact proven fields now include: `1E00` = packet opcode / opcode family selector `1E05` = signed control byte that can divert into the special path at `01A1` Strongest safe reading: low-bank command-packet header workspace consumed by the `C7:0004 -> 0140` dispatcher.  I have **not** frozen the final high-level noun of the downstream `58B2 / 5BF5 / 5C3E / 5C77` handler families. I have **not** frozen the final gameplay-facing noun of the broader pass-88/89 lane+raster workspace. I have **not** returned to the first exact clean-code external reader of `CE0F` yet. I do now have enough exact structure to stop calling `C2:0003`, `C2:0009`, and `C7:0004` generic mystery addresses.
; source: chrono_trigger_labels_pass93.md
L_00_1E00_ct_c7_low_bank_command_packet_header_workspace:
    ; TODO: reconstruct body / data for 00:1E00
    ; known span hint: 00:1E00..00:1E05

