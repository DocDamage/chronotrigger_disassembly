; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_C2
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; C2:0003  top-status=strong  labels=1
; =============================================================================
; [strong] pass 93 :: ct_c2_branch_to_57df_stream_state_initializer_veneer
; qualifier: strong
; notes: Exact body: `JMP $57DF`. Lands at exact target `C2:57DF`. Strongest safe reading: veneer for the stream-state initializer behind the `CD:025E` dual-call tail.
; source: chrono_trigger_labels_pass93.md
C2_0003_ct_c2_branch_to_57df_stream_state_initializer_veneer:
    ; TODO: reconstruct body / data for C2:0003
    ; known span hint: C2:0003..C2:0005

; =============================================================================
; C2:0009  top-status=strong  labels=1
; =============================================================================
; [strong] pass 93 :: ct_c2_branch_to_5823_stream_token_dispatch_stage_veneer
; qualifier: strong
; notes: Exact body: `JMP $5823`. Lands at exact target `C2:5823`. Strongest safe reading: veneer for the token/stream dispatch stage immediately following `C2:0003` in the `CD:025E` follow-up chain.
; source: chrono_trigger_labels_pass93.md
C2_0009_ct_c2_branch_to_5823_stream_token_dispatch_stage_veneer:
    ; TODO: reconstruct body / data for C2:0009
    ; known span hint: C2:0009..C2:000B

; =============================================================================
; C2:57DF  top-status=strong  labels=1
; =============================================================================
; [strong] pass 93 :: ct_c2_init_stream_state_from_020c_0214_packet_workspace
; qualifier: strong structural
; notes: Exact prologue saves flags and direct page, then sets `D = 0x0200`. Treats `020C` as an index/selector: masks it to `00FF` doubles it uses it as `Y` Reads a **16-bit entry** through exact long-indirect pointer `[020D],Y` and stores that into `0231`. Copies exact byte `020F -> 0233`. Therefore proves the live `020D..020F` packet family is consumed as a long pointer base for the selected stream/table entry. Seeds exact local state: `0230 = 00` `0234 = 00` or `08` depending on exact comparison of `0214` with `02` if `0214` is negative, forcibly clears `0234` `0215 = 04` `023D = 0200` `023F = 00` `0217 = 00` Returns immediately with `RTL` after the seed. Strongest safe reading: exact stream-state initializer behind the `020C..0214` packet/workspace family used by `CD:025E` before `C2:0009` runs.
; source: chrono_trigger_labels_pass93.md
C2_57DF_ct_c2_init_stream_state_from_020c_0214_packet_workspace:
    ; TODO: reconstruct body / data for C2:57DF
    ; known span hint: C2:57DF..C2:5822

; =============================================================================
; C2:5823  top-status=strong  labels=1
; =============================================================================
; [strong] pass 93 :: ct_c2_dispatch_prepared_stream_state_into_four_handler_families
; qualifier: strong structural
; notes: Exact prologue saves flags and direct page, then sets `D = 0x0200`. Calls exact local helper `JSR $584A`. If that helper returns carry set, exits immediately. Otherwise reads exact local mode/state byte `0230`. Doubles that byte and dispatches through the exact four-entry table at `5842`: `58B2` `5BF5` `5C3E` `5C77` Clears `A` on the common exit path, restores state, then returns with `RTL`. Strongest safe reading: exact token/stream dispatch stage over the state seeded by `57DF`, with four concrete downstream handler families.
; source: chrono_trigger_labels_pass93.md
C2_5823_ct_c2_dispatch_prepared_stream_state_into_four_handler_families:
    ; TODO: reconstruct body / data for C2:5823
    ; known span hint: C2:5823..C2:5841

; =============================================================================
; C2:584A  top-status=strong  labels=1
; =============================================================================
; [strong] pass 94 :: ct_c2_dispatch_0215_substate_through_micro_jump_gate_before_main_token_family_split
; qualifier: strong structural
; notes: Exact opening body: loads `0215` doubles it uses exact indexed indirect jump `JMP ($5851,X)` Therefore this range is a **pure substate jump gate**, not generic arithmetic. The table collapses to a small exact set of entry bodies: `5893` = `SEC ; RTS` `5895` = immediate clear-carry continue path via `BRA` into `CLC ; RTS` `5897` / `589B` = two entry points into the same seed/update body that: seed `0234` with `08` or `14` clear `0217` subtract `08` from `0234` when `(0214 & 0x0F) == 0x02` return with clear carry Strongest safe reading: exact `0215`-driven pre-dispatch micro-gate that either forces early exit by carry or prepares local state and returns “continue”.
; source: chrono_trigger_labels_pass94.md
C2_584A_ct_c2_dispatch_0215_substate_through_micro_jump_gate_before_main_token_family_split:
    ; TODO: reconstruct body / data for C2:584A
    ; known span hint: C2:584A..C2:58B1

; =============================================================================
; C2:58B2  top-status=strong  labels=1
; =============================================================================
; [strong] pass 94 :: ct_c2_consume_next_stream_token_and_dispatch_primary_token_families
; qualifier: strong structural
; notes: Exact opening behavior: reads the next byte through direct-indirect pointer `[0231]` increments the live stream pointer at `0231` then splits on the token value Exact family split now frozen: `token >= 0xA0` stores token into `0235` calls exact local helper `JSR $5DC4` decrements `0213` loops this path while `0213` remains nonzero then sets `0215 = 0x10` and returns `0x21 <= token < 0xA0` stores raw token into `023B` indexes the exact long table rooted at `DE:FA00` seeds `0237/0239/023A` sets `0230 = 0x01` jumps directly into `5BF5` `token < 0x21` dispatches through the exact local jump table rooted at `5903` Strongest safe reading: exact primary stream-token consumer / dispatcher behind the `57DF -> 5823` chain.
; source: chrono_trigger_labels_pass94.md
C2_58B2_ct_c2_consume_next_stream_token_and_dispatch_primary_token_families:
    ; TODO: reconstruct body / data for C2:58B2
    ; known span hint: C2:58B2..C2:5902

