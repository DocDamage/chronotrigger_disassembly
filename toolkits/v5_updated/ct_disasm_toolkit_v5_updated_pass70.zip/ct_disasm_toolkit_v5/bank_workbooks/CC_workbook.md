# Bank CC Workbook

## Bank role
Descriptor / pointer / table bank

## Current state
Heavily used as data substrate. Many table families are known, but not all semantic owners are frozen.

## Anchor addresses
- `CC:2AB0`
- `CC:2E31`
- `CC:8B08`
- `CC:FA23`
- `CC:FA29`
- `CC:FADD`
- `CC:F903`

## Evidence log
- add exact pass references, byte dumps, and caller/callee relationships here

## Strong labels already tied to this bank
- fill from report / label DB during active work

## Provisional or caution labels
- keep the dangerous guesses here until promoted or killed

## Next targets
- Continue exact semantics of late selector pointer-record tables
- Tighten config-page / descriptor / lane-anchor table ownership

## Open questions
- 
