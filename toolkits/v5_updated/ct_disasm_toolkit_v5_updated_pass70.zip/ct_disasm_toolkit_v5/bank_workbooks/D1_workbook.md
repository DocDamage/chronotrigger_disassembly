# Bank D1 Workbook

## Bank role
Template / strip source bank

## Current state
Three strip/tilemap template families are pinned as sources, but variant-selection context is still incomplete.

## Anchor addresses
- `D1:5800`
- `D1:59FC`
- `D1:5A50`
- `D1:5BD0`

## Evidence log
- add exact pass references, byte dumps, and caller/callee relationships here

## Strong labels already tied to this bank
- fill from report / label DB during active work

## Provisional or caution labels
- keep the dangerous guesses here until promoted or killed

## Next targets
- Caller-side selection of 5800 / 5A50 / 5BD0
- Additional template families for companion strips and records

## Open questions
- 
