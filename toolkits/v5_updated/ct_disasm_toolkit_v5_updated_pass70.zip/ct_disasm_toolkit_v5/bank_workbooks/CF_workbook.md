# Bank CF Workbook

## Bank role
DMA / upload support bank

## Current state
Key upload proof exists for 0B40 -> VRAM 7A00, but the whole bank is not mapped.

## Anchor addresses
- `CF:[0B40 upload path]`

## Evidence log
- add exact pass references, byte dumps, and caller/callee relationships here

## Strong labels already tied to this bank
- fill from report / label DB during active work

## Provisional or caution labels
- keep the dangerous guesses here until promoted or killed

## Next targets
- Map additional consumers of 0B40/0CC0/0E80 products
- Separate generic DMA helpers from panel-specific callers

## Open questions
- 
