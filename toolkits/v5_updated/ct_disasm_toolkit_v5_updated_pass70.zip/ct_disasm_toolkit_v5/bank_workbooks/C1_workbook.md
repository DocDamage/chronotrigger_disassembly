# Bank C1 Workbook

## Bank role
Primary control / opcode / selector / service bank

## Current state
Strongest live area. Master global opcode dispatch at B80D..B95F, selector-control dispatch at AC14/AC2E, service-7 wrapper/query stack, tail replay/controller layer, panel/tilemap builders, and many late control helpers.

## Anchor addresses
- `C1:B80D`
- `C1:B85F`
- `C1:B88D`
- `C1:B8BB`
- `C1:AC14`
- `C1:AFD7`
- `C1:8C0A`

## Evidence log
- add exact pass references, byte dumps, and caller/callee relationships here

## Strong labels already tied to this bank
- fill from report / label DB during active work

## Provisional or caution labels
- keep the dangerous guesses here until promoted or killed

## Next targets
- Early global opcode band inside B80D master dispatch
- Observed pack-fed global opcodes from pass 61
- Late pack executor sub-ops and downstream consumers

## Open questions
- 
