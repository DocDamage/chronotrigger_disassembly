# Bank C0 Workbook

## Bank role
Downstream consumer / parallel source plane

## Current state
Consumer-side proof exists for 0E80 and related panel outputs, but the bank is not deeply split.

## Anchor addresses
- `C0:A2B0`
- `C0:A335`

## Evidence log
- add exact pass references, byte dumps, and caller/callee relationships here

## Strong labels already tied to this bank
- fill from report / label DB during active work

## Provisional or caution labels
- keep the dangerous guesses here until promoted or killed

## Next targets
- Consumer paths around A2B0..A335
- Parallel source-plane ownership vs panel-facing presentation

## Open questions
- 
