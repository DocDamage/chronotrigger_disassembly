# Bank FD Workbook

## Bank role
Readiness / normalization / occupancy support bank

## Current state
Strongly advanced. Seed math, normalization, head/tail occupancy maps, and several battle-facing helpers are structurally pinned.

## Anchor addresses
- `FD:B24D`
- `FD:B2A3`
- `FD:B4E0`
- `FD:B820`
- `FD:B8F7`
- `FD:AB01`

## Evidence log
- add exact pass references, byte dumps, and caller/callee relationships here

## Strong labels already tied to this bank
- fill from report / label DB during active work

## Provisional or caution labels
- keep the dangerous guesses here until promoted or killed

## Next targets
- Remaining owner paths around occupant withholding/materialization support
- Cross-check helper families against late executor use

## Open questions
- 
