Drop raw trace exports here before running the resume/bootstrap command.
