# Next Pass Checklist

- previous pass read
- matching labels file read
- current seam named explicitly
- new claims separated into:
  - strong
  - strengthened
  - provisional
  - corrections
- labels file updated with:
  - strong labels
  - provisional labels
  - alias/wrapper/caution labels
- next seam named before ending pass
- if community research changed vocabulary, note it explicitly
