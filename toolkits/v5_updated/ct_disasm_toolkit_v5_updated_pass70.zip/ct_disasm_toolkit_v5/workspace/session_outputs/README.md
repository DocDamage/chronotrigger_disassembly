# Session Outputs

Use this folder for local scratch exports, temporary dumps, and trace logs.
