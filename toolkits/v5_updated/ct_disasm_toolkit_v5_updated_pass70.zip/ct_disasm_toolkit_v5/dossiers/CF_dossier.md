# Bank CF Dossier

- Label rows: **1**
- Latest pass touching bank: **44**

## Status mix
- strong: **1**

## Top labels carried in this bank
- `CF:E380`  **ct_cf_upload_pending_tilemap_0b40_to_vram_7a00**  (strong, pass 44)

## Highest-value open work
- continue separating hard proof from architecture wording; current bank coverage is still partial

## Notes
- Generated from the persistent label DB. Use this as the fast bank-local briefing before reopening pass notes.

