# Bank D1 Dossier

- Label rows: **12**
- Latest pass touching bank: **46**

## Status mix
- provisional: **6**
- strong: **4**
- unspecified: **2**

## Top labels carried in this bank
- `D1:5800`  **/ D1:5A50 / D1:5BD0  ct_d1_tilemap_template_family_16x12_words [provisional]**  (unspecified, pass 44)
- `D1:5800`  **ct_d1_tilemap_template_default_0b40_0180**  (strong, pass 44)
- `D1:5A50`  **ct_d1_tilemap_template_alt_a_0b40_0180**  (strong, pass 44)
- `D1:5BD0`  **ct_d1_tilemap_template_alt_b_0b40_0180**  (strong, pass 44)
- `D1:5800`  **/ D1:5A50 / D1:5BD0  ct_d1_alt_base_strip_layout_family        [provisional]**  (provisional, pass 45)
- `D1:5800`  **/ D1:5A50 / D1:5BD0  ct_d1_base_strip_template_family_32x6     [strong]**  (unspecified, pass 45)
- `D1:5800`  **/ D1:5A50 / D1:5BD0  ct_d1_tilemap_template_family_16x12_words [withdrawn]**  (provisional, pass 45)
- `D1:59FC`  **ct_d1_panel_segment_template_6x7_words**  (strong, pass 45)
- `D1:5800`  **/ D1:5A50 / D1:5BD0  ct_d1_alt_base_strip_layout_family      [strengthened context]**  (provisional, pass 46)
- `D1:5800`  **ct_d1_base_strip_template_default**  (provisional, pass 46)
- `D1:5A50`  **ct_d1_base_strip_template_latched_alt**  (provisional, pass 46)
- `D1:5BD0`  **ct_d1_base_strip_template_transition_alt**  (provisional, pass 46)

## Highest-value open work
- continue separating hard proof from architecture wording; current bank coverage is still partial

## Notes
- Generated from the persistent label DB. Use this as the fast bank-local briefing before reopening pass notes.

