# Bank C0 Dossier

- Label rows: **2**
- Latest pass touching bank: **48**

## Status mix
- provisional: **1**
- unspecified: **1**

## Top labels carried in this bank
- `C0:A2B0..A335`  **consumer path                                           [unlabeled as final routine]**  (unspecified, pass 47)
- `C0:A270..C0:A335`  **ct_c0_parallel_source_plane_consumer_band**  (provisional, pass 48)

## Highest-value open work
- continue separating hard proof from architecture wording; current bank coverage is still partial

## Notes
- Generated from the persistent label DB. Use this as the fast bank-local briefing before reopening pass notes.

