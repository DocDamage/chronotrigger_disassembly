# Bank CC Dossier

- Label rows: **13**
- Latest pass touching bank: **60**

## Status mix
- provisional: **2**
- strong: **10**
- unspecified: **1**

## Top labels carried in this bank
- `CC:94A0`  **ct_cc_companion_record_template_table**  (strong, pass 46)
- `CC:FA23`  **/ CC:FA29 / CC:FADD  ct_cc_companion_strip_selector_tables   [provisional]**  (provisional, pass 46)
- `CC:FA41`  **ct_cc_companion_strip_template_a_6x7_bytes**  (strong, pass 46)
- `CC:FA6B`  **ct_cc_companion_strip_template_b_6x7_bytes**  (strong, pass 46)
- `CC:FA23..CC:FA3F`  **ct_cc_companion_strip_lane_anchor_offset_family**  (strong, pass 47)
- `CC:FADD`  **ct_cc_companion_strip_lane_block_offsets_0000_0080_0100**  (strong, pass 47)
- `CC:FAE9`  **ct_cc_companion_record_lane_marker_offsets_0002_0082_0102**  (strong, pass 47)
- `CC:F8ED`  **ct_cc_live_three_lane_record_block_offsets_0000_0080_0100**  (provisional, pass 48)
- `CC:F903`  **ct_cc_decimal_digit_tile_table_73_to_7c**  (strong, pass 48)
- `CC:2E31`  **ct_cc_speed_like_stat_to_readiness_bonus_table**  (strong, pass 51)
- `CC:2E31`  **ct_cc_battle_speed_page_speed_to_readiness_seed_adjust_table**  (strong, pass 52)
- `CC:2E31`  **old wording “speed-like stat -> readiness bonus table”               [soft-replaced]**  (unspecified, pass 52)
- `CC:8B08..CC:8C53`  **ct_late_selector_control_pointer_records**  (strong, pass 60)

## Highest-value open work
- freeze more table ownership and table family semantics so fewer entries remain generic descriptors

## Notes
- Generated from the persistent label DB. Use this as the fast bank-local briefing before reopening pass notes.

