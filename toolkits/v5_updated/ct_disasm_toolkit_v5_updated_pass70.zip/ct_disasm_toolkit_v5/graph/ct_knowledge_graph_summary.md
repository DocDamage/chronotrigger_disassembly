# Knowledge Graph Summary

- Nodes: **356**
- Edges: **519**

## Bank coverage from label graph
- `7E` -> **139** label-linked nodes
- `C1` -> **68** label-linked nodes
- `FD` -> **20** label-linked nodes
- `CC` -> **13** label-linked nodes
- `D1` -> **12** label-linked nodes
- `C0` -> **2** label-linked nodes
- `CF` -> **1** label-linked nodes

## Runtime-confirmed addresses
- none yet

## Strong current graph take
- The graph is now good enough to tie pass evidence, bank ownership, master opcode coverage, and imported runtime proof together in one place.

