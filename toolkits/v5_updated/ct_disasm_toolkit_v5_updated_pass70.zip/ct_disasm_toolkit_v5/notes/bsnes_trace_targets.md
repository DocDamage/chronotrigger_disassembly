# bsnes Runtime Trace Targets

Use runtime traces as confirmation, not as naming authority.

## Best current targets
- `C1:AC14`
- `C1:B80D`
- `C1:B8BB`
- `C1:AFD7`
- `C1:8C0A`
- `C1:8CE7`
- `C1:8D88`
- `C1:07BD`
- `C1:081F`
- `C1:0958`
- `C1:0299`
- `FD:B8F7`

## Best WRAM watches
- `7E:0B40`
- `7E:0CC0`
- `7E:0E80`
- `7E:99DD..99DF`
- `7E:9F22..9F24`
- `7E:AEFF..AF15`
- `7E:B158..B162`
- `7E:AFAB..AFB5`
- `7E:B03A..B044`
- `7E:B242`
- `7E:B24A`
- `7E:B263`
