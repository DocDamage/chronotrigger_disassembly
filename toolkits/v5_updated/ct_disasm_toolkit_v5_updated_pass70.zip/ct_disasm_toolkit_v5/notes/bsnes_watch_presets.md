# bsnes Watch Presets

## Panel/tilemap build path
- `7E:0B40` length `0x180`
- `7E:0CC0` length `0x180`
- `7E:0E80` length `0x180`
- `7E:99E2`
- break on writes near:
  - `C1:07BD`
  - `C1:081F`
  - `C1:0958`

## Readiness / lane gauges
- `7E:99DD..99DF`
- `7E:9F22..9F24`
- `7E:B158..B162`
- `7E:AFAB..AFB5`
- `7E:B03A..B044`
- `7E:AEFF..AF15`

## Late selector / tail replay
- `7E:B1CF`
- `7E:B1D0`
- `7E:B1D2`
- `7E:B242`
- `7E:B24A`
- `7E:B263`
- break on:
  - `C1:AFD7`
  - `C1:B80D`
  - `C1:8C0A`
