# What v4 adds

## Core jump over v3
V3 preserved state.
V4 operationalizes that state.

## New generated artifacts
- `graph/ct_knowledge_graph.json`
- `graph/ct_knowledge_graph_summary.md`
- `dossiers/*_dossier.md`
- `evidence_pages/global_opcodes/*.md`
- `reports/ct_conflict_report.md`
- `reports/ct_completion_score.md`
- `reports/code_data_score.md`
- `asm_skeleton/banks/*.asm`

## New scripts
- `ct_import_runtime_evidence.py`
- `ct_build_knowledge_graph.py`
- `ct_generate_bank_dossiers.py`
- `ct_generate_evidence_pages.py`
- `ct_score_code_data.py`
- `ct_generate_asm_skeleton.py`
- `ct_detect_conflicts.py`
- `ct_completion_score.py`

## New runtime-evidence hooks
Drop trace exports into `traces/imported/` and re-run the workspace resume script.
Supported source shapes:
- `.txt`
- `.log`
- `.csv`
- `.json`

The import is intentionally permissive and address-driven. It is meant to capture reusable proof,
not pretend it fully understands every emulator export format.
