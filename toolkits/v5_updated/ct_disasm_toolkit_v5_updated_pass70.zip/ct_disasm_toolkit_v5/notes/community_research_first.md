# Community Research First

Before resuming heavy reverse-engineering, refresh context from the established Chrono Trigger hacking/modding community.

## Why this comes first
The public ecosystem has useful context around:
- Temporal Flux / event scripting assumptions
- Data Crystal RAM/data notes
- Chrono Compendium utilities and technical notes
- Kajar Labs / modification forum history
- Chrono Compressor / graphics and compression workflows
- debugger-centered workflows used by long-time hackers

That context helps prevent dumb mistakes:
- collapsing every command interpreter into “the event engine”
- misnaming battle-facing helpers as map/object logic
- reinventing already-known table identities
- mixing editor/tool conventions with ROM-proof semantics

## Minimum refresh set
1. Chrono Compendium utilities / modification documentation
2. Temporal Flux event documentation and related event-command notes
3. Data Crystal main game page + RAM map + enemy AI docs
4. Chrono Compendium / Kajar Labs modification forum threads relevant to battle, event, and compression behavior
5. bsnes / bsnes-plus / Geiger-style debugger notes for runtime validation workflow

## Ground rule
Community material is context, not proof.
Use it to sharpen vocabulary and avoid false assumptions.
Do not let it outrank:
- byte evidence
- caller/callee proof
- table ownership proof
- actual ROM control flow
