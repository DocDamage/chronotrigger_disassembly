# Next Session Start Here

1. Read `notes/community_research_first.md`
2. Open these in order:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `dossiers/C1_dossier.md`
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - latest pass + labels
3. Active top-of-stack seam:
   - promoted master-table globals after pass 70
   - primary target: `70..7D`
4. Specific cleanup targets:
   - decode the next promoted selector-control master band at `70..7D`
   - then revisit the late promoted range `90..A9`
   - keep the visible-selector helper wording explicit around `AD68 / AE70 / ADA1` and the `A4E0` redirect path
5. Runtime confirmation targets live in:
   - `targets/trace_packs/`
   - `notes/bsnes_trace_targets.md`
