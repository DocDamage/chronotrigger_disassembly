# Rebuild Pipeline Notes

V5 creates a **rebuild/diff scaffold**, not a finished assembler integration.

## Intended workflow
1. Generate / refresh `source/` with:
   `python3 scripts/ct_generate_bank_sources.py --root . --db data/ct_label_db.sqlite --output-dir source`
2. Lock confirmed ranges with:
   `python3 scripts/ct_freeze_ranges.py --root . --db data/ct_label_db.sqlite --output-json state/range_freeze.json --summary-md reports/ct_freeze_summary.md --seed-from-db`
3. When you have an assembler setup, emit a rebuilt ROM somewhere like:
   `build/rebuild/chrono_trigger_rebuilt.sfc`
4. Compare it against the original with:
   `python3 scripts/ct_rebuild_diff.py --root . --rom "/path/to/Chrono Trigger (USA).sfc" --rebuilt-rom build/rebuild/chrono_trigger_rebuilt.sfc`

## Why the scaffold exists
The project is not yet at the point where a single assembler dialect can be forced on the source tree
without creating more confusion than value. V5 keeps the source tree **assembler-neutral enough to edit**
while still giving you a stable place to hang labels, comments, provenance, and freeze decisions.
