# What v5 adds

V5 is the point where the toolkit stops being just a research workspace and starts acting like a
**source-maintenance workspace**.

## New parts
- `source/` tree generation from the persistent label DB
- `state/range_freeze.json` seeded from strong labels
- `reports/ct_source_state.md`
- `reports/ct_unresolved_dashboard.md`
- `reports/ct_rom_coverage.md` + `reports/ct_rom_coverage.html`
- `reports/ct_runtime_validation.md`
- `reports/ct_rebuild_diff_report.md`
- pass-to-source merge helper

## What it still does not do
- assemble Chrono Trigger end-to-end on its own
- guarantee byte-perfect rebuilds
- auto-solve code/data separation for unresolved banks

That is deliberate. V5 is meant to move the project toward rebuildability without pretending the
assembler-integration problem is already solved.
