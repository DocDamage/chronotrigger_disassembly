# Source Tree Workflow

## Core idea
Treat `source/` as the human-maintained reconstruction workspace. Treat passes and labels as evidence.

## Suggested loop
1. Read the current handoff and unresolved dashboard.
2. Do a new pass.
3. Save the new pass markdown and label markdown.
4. Run:
   `python3 scripts/ct_apply_pass_to_source.py --root . --pass-num <N>`
5. Review:
   - `reports/ct_source_state.md`
   - `reports/ct_unresolved_dashboard.md`
   - `reports/ct_conflict_report.md`
   - `source/meta/source_index.md`
6. Freeze only ranges you are willing to treat as stable.

## Principle
Do not overwrite evidence with nice-looking source comments. The source tree should stay traceable back to
pass files, labels, and runtime validation.
