# What Changed in v3

## Big jump from v2
V2 gave you helper scripts plus starter CSVs.

V3 adds:
- persisted label state in SQLite
- machine-readable JSON export
- query + diff tooling
- full-range coverage worksheets
- xref cache generation
- bank workbooks
- report generation
- a single bootstrap command that rebuilds the workspace state

## Practical result
Next session should start like this:
1. open folder
2. run bootstrap
3. read report and handoff
4. continue real disassembly
