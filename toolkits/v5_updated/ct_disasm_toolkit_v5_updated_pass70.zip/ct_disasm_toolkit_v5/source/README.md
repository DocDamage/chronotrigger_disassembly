# Generated Source Workspace

This tree is the V5 source-maintenance layer. It is intentionally scaffold-first and assembler-neutral.

- `banks/` contains per-bank source scaffolds
- `includes/all_symbols.inc` contains generated symbol assignments
- `meta/source_manifest.json` contains a machine-readable summary
- `ranges/` contains per-bank CSV indexes
