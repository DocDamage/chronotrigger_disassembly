; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_CC
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; CC:2E31  top-status=strong  labels=3
; =============================================================================
; [strong] pass 52 :: ct_cc_battle_speed_page_speed_to_readiness_seed_adjust_table
; qualifier: strong
; notes: 8 pages of 16 signed-byte entries each. Page selected by `($2990 & 7)`. Entry selected by `(speed - 1)`. Supplies the additive adjustment term in the exact readiness seed formula.
; source: chrono_trigger_labels_pass52.md
CC_2E31_ct_cc_battle_speed_page_speed_to_readiness_seed_adjust_table:
    ; TODO: reconstruct body / data for CC:2E31

; [strong] pass 51 :: ct_cc_speed_like_stat_to_readiness_bonus_table
; qualifier: strong
; notes: 16-byte signed step table: Smooth +4-step ladder from negative to small positive bonus. Consumed directly by the `FD:B820..B850` readiness seed family. Strongest safe reading: speed-like stat -> readiness bonus table.
; source: chrono_trigger_labels_pass51.md
CC_2E31_ct_cc_speed_like_stat_to_readiness_bonus_table:
    ; TODO: reconstruct body / data for CC:2E31

; [unspecified] pass 52 :: old wording “speed-like stat -> readiness bonus table”               [soft-replaced]
; notes: Too narrow after page-selection proof. Replaced by `ct_cc_battle_speed_page_speed_to_readiness_seed_adjust_table`.
; source: chrono_trigger_labels_pass52.md
CC_2E31_old_wording_speed_like_stat_readiness_bonus_table_soft_replaced:
    ; TODO: reconstruct body / data for CC:2E31

; =============================================================================
; CC:8B08  top-status=strong  labels=1
; =============================================================================
; [strong] pass 60 :: ct_late_selector_control_pointer_records
; qualifier: strong structural
; notes: Indexed at 4-byte stride by the late selector-control family. `AFD7` proves the first word of each record is used as a pointer seed. For `0x49..0x52`, the first-word pointers land in `CC:A77B`, `A7E5`, `A8E5`, `A96A`, `AA1F`, `AAE2`, `ABB5`, `ACDD`, `AD5B`, and `ADFF`. The second word of each 4-byte record remains unresolved and should not be named yet.
; source: chrono_trigger_labels_pass60.md
CC_8B08_ct_late_selector_control_pointer_records:
    ; TODO: reconstruct body / data for CC:8B08
    ; known span hint: CC:8B08..CC:8C53

; =============================================================================
; CC:94A0  top-status=strong  labels=1
; =============================================================================
; [strong] pass 46 :: ct_cc_companion_record_template_table
; qualifier: strong
; notes: ROM template source copied by `C1:09B0`. Used as structured record data, not code.
; source: chrono_trigger_labels_pass46.md
CC_94A0_ct_cc_companion_record_template_table:
    ; TODO: reconstruct body / data for CC:94A0

; =============================================================================
; CC:F8ED  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 48 :: ct_cc_live_three_lane_record_block_offsets_0000_0080_0100
; qualifier: provisional
; notes: Proven live subgroup used by the numeric writer path: `0000` `0080` `0100` Acts as the lane-selected record-block offset table for the dynamic numeric fields. Broader table family may contain additional entries beyond the live subgroup.
; source: chrono_trigger_labels_pass48.md
CC_F8ED_ct_cc_live_three_lane_record_block_offsets_0000_0080_0100:
    ; TODO: reconstruct body / data for CC:F8ED

; =============================================================================
; CC:F903  top-status=strong  labels=1
; =============================================================================
; [strong] pass 48 :: ct_cc_decimal_digit_tile_table_73_to_7c
; qualifier: strong
; notes: Live digit tile codes used by `011F` and `0174` are: `73 74 75 76 77 78 79 7A 7B 7C` Strongest safe reading: decimal digit tile codes for `0..9`.
; source: chrono_trigger_labels_pass48.md
CC_F903_ct_cc_decimal_digit_tile_table_73_to_7c:
    ; TODO: reconstruct body / data for CC:F903

; =============================================================================
; CC:FA23  top-status=strong  labels=2
; =============================================================================
; [strong] pass 47 :: ct_cc_companion_strip_lane_anchor_offset_family
; qualifier: strong
; notes: Family of 3-entry 16-bit offset tables. Every table uses `0x80` lane spacing. Proven live subgroups: `FA23` = `0029,00A9,0129` `FA29` = `001B,009B,011B` `FA2F` = `0068,00E8,0168` `FA35` = `005A,00DA,015A` `FA3B` = `0066,00E6,0166` These are lane-anchor tables for distinct `0CC0` strip subfields/layouts.
; source: chrono_trigger_labels_pass47.md
CC_FA23_ct_cc_companion_strip_lane_anchor_offset_family:
    ; TODO: reconstruct body / data for CC:FA23
    ; known span hint: CC:FA23..CC:FA3F

; [provisional] pass 46 :: / CC:FA29 / CC:FADD  ct_cc_companion_strip_selector_tables   [provisional]
; notes: These tables clearly feed `C1:08E8` slice-local updates in the `0CC0` companion strip. Exact semantics of each selector lane remain open.
; source: chrono_trigger_labels_pass46.md
CC_FA23_CC_FA29_CC_FADD_ct_cc_companion_strip_selector_tables_provisional:
    ; TODO: reconstruct body / data for CC:FA23

; =============================================================================
; CC:FA41  top-status=strong  labels=1
; =============================================================================
; [strong] pass 46 :: ct_cc_companion_strip_template_a_6x7_bytes
; qualifier: strong
; notes: Compact ROM byte template consumed only by `C1:07BD` in this pass. Structurally matches the proven `6-row x 7-byte` loop.
; source: chrono_trigger_labels_pass46.md
CC_FA41_ct_cc_companion_strip_template_a_6x7_bytes:
    ; TODO: reconstruct body / data for CC:FA41

; =============================================================================
; CC:FA6B  top-status=strong  labels=1
; =============================================================================
; [strong] pass 46 :: ct_cc_companion_strip_template_b_6x7_bytes
; qualifier: strong
; notes: Compact ROM byte template consumed only by `C1:07EE` in this pass. Structurally matches the proven `6-row x 7-byte` loop.
; source: chrono_trigger_labels_pass46.md
CC_FA6B_ct_cc_companion_strip_template_b_6x7_bytes:
    ; TODO: reconstruct body / data for CC:FA6B

; =============================================================================
; CC:FADD  top-status=strong  labels=1
; =============================================================================
; [strong] pass 47 :: ct_cc_companion_strip_lane_block_offsets_0000_0080_0100
; qualifier: strong
; notes: Proven live words used by `C1:08BF`: `0000` `0080` `0100` Exact role: the three base offsets for the lane blocks inside the `0CC0` strip.
; source: chrono_trigger_labels_pass47.md
CC_FADD_ct_cc_companion_strip_lane_block_offsets_0000_0080_0100:
    ; TODO: reconstruct body / data for CC:FADD

; =============================================================================
; CC:FAE9  top-status=strong  labels=1
; =============================================================================
; [strong] pass 47 :: ct_cc_companion_record_lane_marker_offsets_0002_0082_0102
; qualifier: strong
; notes: Proven live words: `0002` `0082` `0102` Used by `C1:1918..1969` to clear/stamp one of three `0E80` lane marker positions.
; source: chrono_trigger_labels_pass47.md
CC_FAE9_ct_cc_companion_record_lane_marker_offsets_0002_0082_0102:
    ; TODO: reconstruct body / data for CC:FAE9

