; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_C1
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; C1:011B  top-status=strong  labels=1
; =============================================================================
; [strong] pass 49 :: ct_c1_lsr3_entry
; qualifier: strong
; notes: Mid-routine entry into the `LSR` helper band. Executes exactly three `LSR A` operations before `RTS`. Corrects pass 48’s earlier loose `>> 8` interpretation.
; source: chrono_trigger_labels_pass49.md
C1_011B_ct_c1_lsr3_entry:
    ; TODO: reconstruct body / data for C1:011B

; =============================================================================
; C1:011F  top-status=strong  labels=1
; =============================================================================
; [strong] pass 48 :: ct_c1_format_u16_as_three_decimal_tile_bytes_949d_949f
; qualifier: strong
; notes: Uses `9499` as the numeric working input. Repeatedly subtracts `0x64` and `0x0A` to derive hundreds/tens/ones. Maps those digits through `CC:F903`. Emits tile bytes to `949D`, `949E`, `949F` and sets `949C = 0xFF`.
; source: chrono_trigger_labels_pass48.md
C1_011F_ct_c1_format_u16_as_three_decimal_tile_bytes_949d_949f:
    ; TODO: reconstruct body / data for C1:011F

; =============================================================================
; C1:0174  top-status=strong  labels=1
; =============================================================================
; [strong] pass 48 :: ct_c1_format_u16_as_two_decimal_tile_bytes_949e_949f
; qualifier: strong
; notes: Repeatedly subtracts `0x0A` to derive tens and ones. Maps through `CC:F903`. Emits tile bytes to `949E`, `949F` and blanks `949C`, `949D` with `0xFF`.
; source: chrono_trigger_labels_pass48.md
C1_0174_ct_c1_format_u16_as_two_decimal_tile_bytes_949e_949f:
    ; TODO: reconstruct body / data for C1:0174

; =============================================================================
; C1:0299  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 49 :: ct_c1_rebuild_full_companion_strip_0cc0
; qualifier: strengthened
; notes: Pass 47 proved this was the full strip rebuild entry. Pass 48 proved it contained rendered numeric fields. Pass 49 tightens the three dynamic fields inside it to: current HP max HP current MP (still slightly more conservative than the HP pair) The routine is now best understood as a per-lane status-field strip rebuild path, not a generic glyph mixer.
; source: chrono_trigger_labels_pass49.md
C1_0299_ct_c1_rebuild_full_companion_strip_0cc0:
    ; TODO: reconstruct body / data for C1:0299

; =============================================================================
; C1:06F0  top-status=strong  labels=3
; =============================================================================
; [strong] pass 47 :: ct_c1_render_scaled_lane_bar_into_0cc0
; qualifier: strong
; notes: Uses `FA35[lane] + 0x1A` as the bar anchor. Scales per-lane state through the hardware divide helper at `C1:00D7`. Emits repeated `67` / `6F` glyphs and a partial tail tile into `0CC0`. Strongest safe reading: render a segmented bar/meter into the lane strip.
; source: chrono_trigger_labels_pass47.md
C1_06F0_ct_c1_render_scaled_lane_bar_into_0cc0:
    ; TODO: reconstruct body / data for C1:06F0

; [unspecified] pass 51 :: ct_c1_render_lane_active_time_gauge_into_0cc0
; qualifier: strengthened
; notes: Pass 50 already tied it to the readiness gauge. Pass 51 tightens the exact consumed pair to: current fill = `99DD` goal/cap = `9F22` The human-facing readiness-gauge name holds and the math-side split is now much cleaner.
; source: chrono_trigger_labels_pass51.md
C1_06F0_ct_c1_render_lane_active_time_gauge_into_0cc0:
    ; TODO: reconstruct body / data for C1:06F0

; [unspecified] pass 50 :: old wording “render scaled lane bar into 0CC0”             [replaced]
; notes: Too generic after pass 50. The ROM now supports a materially harder gameplay-facing reading: active-time/readiness gauge renderer.
; source: chrono_trigger_labels_pass50.md
C1_06F0_old_wording_render_scaled_lane_bar_into_0CC0_replaced:
    ; TODO: reconstruct body / data for C1:06F0

; =============================================================================
; C1:07BD  top-status=strong  labels=1
; =============================================================================
; [strong] pass 46 :: ct_c1_blit_companion_strip_template_a_into_0cc0_pair29
; qualifier: strong
; notes: Outer loop = 6 rows. Inner loop = 7 source bytes per row. Reads from `CC:FA41`. Writes source byte to `0CC0+Y`, then constant `0x29` to `0CC1+Y`. Row stride = `0x40` bytes.
; source: chrono_trigger_labels_pass46.md
C1_07BD_ct_c1_blit_companion_strip_template_a_into_0cc0_pair29:
    ; TODO: reconstruct body / data for C1:07BD

; =============================================================================
; C1:07EE  top-status=strong  labels=1
; =============================================================================
; [strong] pass 46 :: ct_c1_blit_companion_strip_template_b_into_0cc0_pair29
; qualifier: strong
; notes: Same loop shape as `C1:07BD`. Reads from `CC:FA6B` instead of `CC:FA41`. Writes the same paired-byte pattern into the `0CC0` family.
; source: chrono_trigger_labels_pass46.md
C1_07EE_ct_c1_blit_companion_strip_template_b_into_0cc0_pair29:
    ; TODO: reconstruct body / data for C1:07EE

; =============================================================================
; C1:07FD  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 46 :: ct_c1_compose_three_slot_panel_strip_into_0b40
; qualifier: withdrawn as exact entry
; notes: Pass 45 used `07FD` as a broad anchor for the panel-strip composer. Pass 46 tightens the true entry to `C1:081F`. The earlier structural reading of the composer remains valid; the entry boundary was just too broad.
; source: chrono_trigger_labels_pass46.md
C1_07FD_ct_c1_compose_three_slot_panel_strip_into_0b40:
    ; TODO: reconstruct body / data for C1:07FD

; =============================================================================
; C1:081F  top-status=strong  labels=1
; =============================================================================
; [strong] pass 46 :: ct_c1_compose_three_slot_panel_strip_into_0b40
; qualifier: strong
; notes: Corrected entry boundary for the pass-45 panel-strip composer. Begins with `STZ $84`, checks `A6D9/A6DA/A6DB`, selects destination offsets in `$82`, This is the actual `0B40` three-slot strip composer entry.
; source: chrono_trigger_labels_pass46.md
C1_081F_ct_c1_compose_three_slot_panel_strip_into_0b40:
    ; TODO: reconstruct body / data for C1:081F

; =============================================================================
; C1:086D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 46 :: ct_c1_clear_current_companion_strip_slice_0cc0
; qualifier: strong
; notes: Uses `95D5` to select a local slice. Clears two adjacent columns across six rows inside the `0CC0` companion strip family. Strongest safe reading: clear the current slice in the paired-byte companion strip.
; source: chrono_trigger_labels_pass46.md
C1_086D_ct_c1_clear_current_companion_strip_slice_0cc0:
    ; TODO: reconstruct body / data for C1:086D

; =============================================================================
; C1:08E8  top-status=strong  labels=2
; =============================================================================
; [strong] pass 46 :: ct_c1_update_current_companion_strip_slice
; qualifier: strong
; notes: Writes back into the same `0CC0 / 0D00` companion-strip family after slice clear. Uses selector tables rooted at `CC:FA23`, `CC:FA29`, and `CC:FADD`. Exact human-facing meaning still open, but the slice-local update role is strong.
; source: chrono_trigger_labels_pass46.md
C1_08E8_ct_c1_update_current_companion_strip_slice:
    ; TODO: reconstruct body / data for C1:08E8

; [unspecified] pass 47 :: ct_c1_fill_current_companion_strip_slice_from_anchor_table
; qualifier: strengthened
; notes: Pass 46 proved this was a slice-local `0CC0` update helper. Pass 47 tightens that role: it selects an anchor from `FA23` or `FA29` then fills five positions with `0x29` This is more specific than the earlier generic “update current slice” wording.
; source: chrono_trigger_labels_pass47.md
C1_08E8_ct_c1_fill_current_companion_strip_slice_from_anchor_table:
    ; TODO: reconstruct body / data for C1:08E8

; =============================================================================
; C1:0929  top-status=strong  labels=1
; =============================================================================
; [strong] pass 45 :: ct_c1_blit_6row_panel_segment_into_0b40_merge_left_border
; qualifier: strong
; notes: Dynamic `0B40` patcher using source data from `D1:59FC`. Writes 6 rows with a destination stride of `0x40` bytes per row. Copies either: 7 words per row (full segment), or 6 words per row after skipping the first source word (merge mode) Strongest safe reading: blits a 6-row panel segment into `0B40`, optionally omitting
; source: chrono_trigger_labels_pass45.md
C1_0929_ct_c1_blit_6row_panel_segment_into_0b40_merge_left_border:
    ; TODO: reconstruct body / data for C1:0929

; =============================================================================
; C1:0958  top-status=strong  labels=1
; =============================================================================
; [strong] pass 46 :: ct_c1_rebuild_companion_record_buffer_0e80
; qualifier: strong
; notes: Clears exactly `0x0180` bytes at `0E80+Y`. Then enters a 3-iteration build loop calling `C1:09B0`. Strongest safe reading: rebuild a full-size companion record buffer.
; source: chrono_trigger_labels_pass46.md
C1_0958_ct_c1_rebuild_companion_record_buffer_0e80:
    ; TODO: reconstruct body / data for C1:0958

; =============================================================================
; C1:09B0  top-status=strong  labels=1
; =============================================================================
; [strong] pass 46 :: ct_c1_emit_fixed_format_companion_record
; qualifier: strong
; notes: Checks the `C1:1580` per-entry control table. Copies 11 bytes from `CC:94A0` to `0B5E + 11*index` using `MVN`. Emits additional paired bytes into `0E86/0EC6` style regions with companion byte `0x2D`. Strongest safe reading: emit a fixed-format companion record.
; source: chrono_trigger_labels_pass46.md
C1_09B0_ct_c1_emit_fixed_format_companion_record:
    ; TODO: reconstruct body / data for C1:09B0

; =============================================================================
; C1:104E  top-status=strong  labels=1
; =============================================================================
; [strong] pass 48 :: ct_c1_blank_leading_zero_decimal_tiles_949d_949e
; qualifier: strong
; notes: Converts tile `0x73` at `949D` to `0xFF`. Converts tile `0x73` at `949E` to `0xFF` only when `949D` is already blank. This is a leading-zero suppression helper over the decimal tile buffer.
; source: chrono_trigger_labels_pass48.md
C1_104E_ct_c1_blank_leading_zero_decimal_tiles_949d_949e:
    ; TODO: reconstruct body / data for C1:104E

; =============================================================================
; C1:1918  top-status=strong  labels=1
; =============================================================================
; [strong] pass 47 :: ct_c1_refresh_current_0e80_lane_marker_glyphs
; qualifier: strong
; notes: Clears the old marker block selected by `991F`. Stamps the current marker block selected by `95E5`. Writes `60/61/62/63` plus companion `29` bytes into `0E80/0EC0`. Strongest safe reading: refresh the current lane marker glyphs inside the `0E80` companion-record region.
; source: chrono_trigger_labels_pass47.md
C1_1918_ct_c1_refresh_current_0e80_lane_marker_glyphs:
    ; TODO: reconstruct body / data for C1:1918

; =============================================================================
; C1:1B19  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_service1_enqueue_lane_and_mark_record_active
; qualifier: strong
; notes: Local service-1 entry for the 3-lane controller. If the current lane is not already active in `A6D9[x]`, maps it through `CC:FAF0`,
; source: chrono_trigger_labels_pass43.md
C1_1B19_ct_c1_service1_enqueue_lane_and_mark_record_active:
    ; TODO: reconstruct body / data for C1:1B19

; =============================================================================
; C1:1B69  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_promote_pending_lane_into_active_roster
; qualifier: strong
; notes: Pulls the head of the pending lane queue at `95D6` into the active roster. Clears `9F38[lane]`, seeds small per-lane state bytes, stores the lane into
; source: chrono_trigger_labels_pass43.md
C1_1B69_ct_c1_promote_pending_lane_into_active_roster:
    ; TODO: reconstruct body / data for C1:1B69

; =============================================================================
; C1:1BAA  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_service2_remove_lane_and_reseat_active_controller
; qualifier: strong
; notes: Local service-2 entry for the same 3-lane controller. Deletes the input lane from either: the pending-admission queue (`95D6..95D8`), or the active roster (`A6D9` / `A6DE`) If the removed lane was the current active lane (`A6DD`), also clears/reseats
; source: chrono_trigger_labels_pass43.md
C1_1BAA_ct_c1_service2_remove_lane_and_reseat_active_controller:
    ; TODO: reconstruct body / data for C1:1BAA

; =============================================================================
; C1:1C3A  top-status=strong  labels=2
; =============================================================================
; [strong] pass 44 :: ct_c1_service2_restore_default_tilemap_template_0b40
; qualifier: strong
; notes: Strengthened from pass 43. No longer just “restore workspace template.” Specifically restores the default `0x180`-byte tilemap/upload template from `D1:5800`
; source: chrono_trigger_labels_pass44.md
C1_1C3A_ct_c1_service2_restore_default_tilemap_template_0b40:
    ; TODO: reconstruct body / data for C1:1C3A

; [strong] pass 43 :: ct_c1_service2_restore_workspace_template_0b40
; qualifier: strong
; notes: Common tail reached from service 2. Copies `0x180` bytes from `D1:5800` into WRAM rooted at `0B40`. Exact high-level meaning of the workspace is still open, but the template-restore
; source: chrono_trigger_labels_pass43.md
C1_1C3A_ct_c1_service2_restore_workspace_template_0b40:
    ; TODO: reconstruct body / data for C1:1C3A

; =============================================================================
; C1:8C0A  top-status=strong  labels=2
; =============================================================================
; [strong] pass 61 :: ct_replay_tail_pack_segments_and_record_per_tail_state
; qualifier: strong structural
; notes: Front-end clears/rebuilds per-tail replay state for the live, unwithheld tail map. Records executed global opcode bytes into `ct_tail_last_executed_global_opcode_bytes`. Records result/status bytes into `B24A[x]`. Records whether additional FE-delimited work remains into `B263[x]`. Advances/resumes execution from later CC bytes after segment completion. Proven to resume through the group-1 dispatch slice when the next resumed byte is non-negative.
; source: chrono_trigger_labels_pass61.md
C1_8C0A_ct_replay_tail_pack_segments_and_record_per_tail_state:
    ; TODO: reconstruct body / data for C1:8C0A
    ; known span hint: C1:8C0A..C1:8CF7

; [strong] pass 57 :: ct_iterate_live_unwithheld_tail_entries_for_dispatch
; qualifier: strong
; notes: Consumes tail entries only when: `AF15.bit7` is clear `AF02[x] != FF` `B2B6[x] == 0` Passes the live occupant ID in `AF02[x]` to `AFD2`. Confirms withheld entries are excluded from normal live-tail dispatch.
; source: chrono_trigger_labels_pass57.md
C1_8C0A_ct_iterate_live_unwithheld_tail_entries_for_dispatch:
    ; TODO: reconstruct body / data for C1:8C0A
    ; known span hint: C1:8C0A..C1:8C37

; =============================================================================
; C1:8EA7  top-status=strong  labels=1
; =============================================================================
; [strong] pass 62 :: ct_global_opcode_00_unconditional_tail_replay_step
; qualifier: strong
; notes: Direct body is only: `JSR $8C3E ; RTS`. Global opcode `00` is therefore an unconditional handoff into the tail replay/controller layer. This is a master-table opcode mapping, not a standalone subsystem root.
; source: chrono_trigger_labels_pass62.md
C1_8EA7_ct_global_opcode_00_unconditional_tail_replay_step:
    ; TODO: reconstruct body / data for C1:8EA7
    ; known span hint: C1:8EA7..C1:8EAA

; =============================================================================
; C1:9012  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 57 :: ct_gate_tail_dispatch_by_live_unwithheld_count
; qualifier: provisional
; notes: Counts tail entries where: `AF02[x] != FF` `AF15[x] == 0` Compares that count against a descriptor byte from `CC:[B1D2 + 1]`. Dispatches to `8C3E` on one compare outcome; otherwise sets `AF24 = 1`. The exact human-facing noun for the descriptor byte remains open, so this should stay provisional.
; source: chrono_trigger_labels_pass57.md
C1_9012_ct_gate_tail_dispatch_by_live_unwithheld_count:
    ; TODO: reconstruct body / data for C1:9012
    ; known span hint: C1:9012..C1:9043

; =============================================================================
; C1:9013  top-status=strong  labels=1
; =============================================================================
; [strong] pass 62 :: ct_global_opcode_05_gate_tail_replay_by_live_unwithheld_tail_count_max
; qualifier: strong
; notes: Reads one immediate operand byte from `CC:[B1D2 + 1]`. Counts tail entries where: `AF02[x] != FF` and `AF15[x] == 0` Success path is taken when the resulting count is **less than or equal to** the immediate operand. Success -> `JSR $8C3E` Failure -> `AF24 = 1` This strengthens the old pass-57 count gate by pinning the compare direction.
; source: chrono_trigger_labels_pass62.md
C1_9013_ct_global_opcode_05_gate_tail_replay_by_live_unwithheld_tail_count_max:
    ; TODO: reconstruct body / data for C1:9013
    ; known span hint: C1:9013..C1:9043

; =============================================================================
; C1:9045  top-status=strong  labels=1
; =============================================================================
; [strong] pass 62 :: ct_global_opcode_06_gate_tail_replay_when_96f1_96f3_triplet_gte_immediate
; qualifier: strong structural
; notes: Reads a 3-byte immediate operand from `CC:[B1D2 + 1..3]`. Compares that operand lexicographically against current WRAM bytes: `96F1` `96F2` `96F3` Success when current triplet >= immediate triplet. Success -> `JSR $8C3E` Failure -> `AF24 = 1` Gameplay-facing noun for `96F1..96F3` remains intentionally open.
; source: chrono_trigger_labels_pass62.md
C1_9045_ct_global_opcode_06_gate_tail_replay_when_96f1_96f3_triplet_gte_immediate:
    ; TODO: reconstruct body / data for C1:9045
    ; known span hint: C1:9045..C1:9081

; =============================================================================
; C1:9082  top-status=strong  labels=1
; =============================================================================
; [strong] pass 62 :: ct_global_opcode_07_gate_tail_replay_on_current_b320_compare_mode
; qualifier: strong structural
; notes: Reads compare byte from `CC:[B1D2 + 1]` and mode byte from `CC:[B1D2 + 2]`. Uses current slot index `B252` to read `B320[B252]`. Proven compare modes: mode `!= 1` -> success when `B320[current] >= operand1` mode `== 1` -> success when `B320[current] <= operand1` Success -> `JSR $8C3E` Failure -> `AF24 = 1` Final gameplay-facing noun for `B320[x]` still wants more caller proof.
; source: chrono_trigger_labels_pass62.md
C1_9082_ct_global_opcode_07_gate_tail_replay_on_current_b320_compare_mode:
    ; TODO: reconstruct body / data for C1:9082
    ; known span hint: C1:9082..C1:90BD

; =============================================================================
; C1:97AB  top-status=strong  labels=1
; =============================================================================
; [strong] pass 62 :: ct_global_opcode_20_gate_tail_replay_on_current_aeb3_nonzero
; qualifier: strong structural
; notes: Uses current index `B252`. Reads `AEB3[B252]`. Success only when that byte is nonzero. Success -> `JSR $8C3E` Failure -> `AF24 = 1` Final gameplay-facing noun for `AEB3[x]` is still intentionally open.
; source: chrono_trigger_labels_pass62.md
C1_97AB_ct_global_opcode_20_gate_tail_replay_on_current_aeb3_nonzero:
    ; TODO: reconstruct body / data for C1:97AB
    ; known span hint: C1:97AB..C1:97BF

; =============================================================================
; C1:97C0  top-status=strong  labels=1
; =============================================================================
; [strong] pass 62 :: ct_global_opcode_21_gate_tail_replay_on_current_af15_zero
; qualifier: strong structural
; notes: Immediate adjacent sibling of opcode `20`. Uses current index `B252`. Success only when `AF15[B252] == 0`. Success -> `JSR $8C3E` Failure -> `AF24 = 1` Useful carry-forward proof that opcode `20` is part of a real replay-gate family.
; source: chrono_trigger_labels_pass62.md
C1_97C0_ct_global_opcode_21_gate_tail_replay_on_current_af15_zero:
    ; TODO: reconstruct body / data for C1:97C0
    ; known span hint: C1:97C0..C1:97D4

; =============================================================================
; C1:9E78  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 56 :: ct_g2_cmd10_materialize_tail_slots_from_canonical_map
; qualifier: strengthened
; notes: Earlier passes already proved the scan gates: `AF0D[x] != FF` `AF02[x] == FF` `AF15.bit7` clear Pass 56 upgrades the noun: this command materializes live tail slots from the canonical tail map,
; source: chrono_trigger_labels_pass56.md
C1_9E78_ct_g2_cmd10_materialize_tail_slots_from_canonical_map:
    ; TODO: reconstruct body / data for C1:9E78

; =============================================================================
; C1:AAAB  top-status=strong  labels=1
; =============================================================================
; [strong] pass 58 :: ct_fixed_single_entry_selector_wrappers_3_through_10
; qualifier: strong
; notes: Family of tiny wrappers: `AECC = literal` `AECB = 1` `RTS` Covered literal values: `3..10`.
; source: chrono_trigger_labels_pass58.md
C1_AAAB_ct_fixed_single_entry_selector_wrappers_3_through_10:
    ; TODO: reconstruct body / data for C1:AAAB
    ; known span hint: C1:AAAB..C1:AAF8

; =============================================================================
; C1:AB03  top-status=caution  labels=1
; =============================================================================
; [caution] pass 58 :: ct_build_withheld_tail_candidate_list_and_random_reduce_to_one
; qualifier: context strengthened
; notes: Keep the pass-57 label. Pass 58 now places it inside the same selector-wrapper family as: fixed single-entry wrappers the visible-slot min selector the live-tail selector at `ABC9`
; source: chrono_trigger_labels_pass58.md
C1_AB03_ct_build_withheld_tail_candidate_list_and_random_reduce_to_one:
    ; TODO: reconstruct body / data for C1:AB03
    ; known span hint: C1:AB03..C1:AB49

; =============================================================================
; C1:AB4E  top-status=strong  labels=1
; =============================================================================
; [strong] pass 58 :: ct_fixed_single_entry_selector_wrappers_0_through_6
; qualifier: strong
; notes: Family of tiny wrappers: `AECC = literal` `AECB = 1` `RTS` Covered literal values: `0..6`.
; source: chrono_trigger_labels_pass58.md
C1_AB4E_ct_fixed_single_entry_selector_wrappers_0_through_6:
    ; TODO: reconstruct body / data for C1:AB4E
    ; known span hint: C1:AB4E..C1:AB90

; =============================================================================
; C1:AB9B  top-status=strong  labels=1
; =============================================================================
; [strong] pass 58 :: ct_select_one_visible_entry_0_1_2_by_min_lane_value
; qualifier: strong structural
; notes: Compares three lane-local values: `5E30` `5EB0` `5F30` Selects exactly one visible entry index: `0`, `1`, or `2` Stores that selected entry into `AECC` Forces `AECB = 1` Exact branch polarity / final gameplay noun should still stay cautious, but the structural selector role is now strong.
; source: chrono_trigger_labels_pass58.md
C1_AB9B_ct_select_one_visible_entry_0_1_2_by_min_lane_value:
    ; TODO: reconstruct body / data for C1:AB9B
    ; known span hint: C1:AB9B..C1:ABC8

; =============================================================================
; C1:ABC9  top-status=strong  labels=1
; =============================================================================
; [strong] pass 58 :: ct_build_live_tail_slot_candidate_list_and_random_reduce_to_one
; qualifier: strong
; notes: Scans the unified live occupant map starting at slot index `3`. Uses `B252 + 3` as the upper live-tail bound. Appends non-`FF` live slot indices into `AECC`. If multiple candidates exist, uses `AF22` to choose one and exposes the chosen slot at `AECC[0]`. Forces `AECB = 1`. Strong structural sibling to pass 57's `AB03`, but over the live-tail side.
; source: chrono_trigger_labels_pass58.md
C1_ABC9_ct_build_live_tail_slot_candidate_list_and_random_reduce_to_one:
    ; TODO: reconstruct body / data for C1:ABC9
    ; known span hint: C1:ABC9..C1:AC13

; =============================================================================
; C1:AC14  top-status=strong  labels=1
; =============================================================================
; [strong] pass 59 :: ct_resolve_inline_selector_control_byte_into_selection_result
; qualifier: strengthened
; notes: Reads the next selector-control byte from the CC stream. If negative, uses the preset path through `AED8`. Otherwise dispatches through `ct_inline_selector_control_dispatch_table`. Mirrors the resulting selection scratch from `AECC` into `AD8E` and records `B2AE = AECC`.
; source: chrono_trigger_labels_pass59.md
C1_AC14_ct_resolve_inline_selector_control_byte_into_selection_result:
    ; TODO: reconstruct body / data for C1:AC14
    ; known span hint: C1:AC14..C1:AC45

; =============================================================================
; C1:AED3  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 58 :: ct_materialize_deferred_tail_entry_by_canonical_occupant_id
; qualifier: strengthened context
; notes: Keep the pass-57 label. Pass 58 strengthens the context: this helper is **not** the only tail materialization path it is best treated as the **occupant-ID keyed deferred reinsertion helper** slot-indexed materializers exist elsewhere (`9E78`, `86BC` style copy path)
; source: chrono_trigger_labels_pass58.md
C1_AED3_ct_materialize_deferred_tail_entry_by_canonical_occupant_id:
    ; TODO: reconstruct body / data for C1:AED3
    ; known span hint: C1:AED3..C1:AEFB

; =============================================================================
; C1:AFD7  top-status=strong  labels=1
; =============================================================================
; [strong] pass 60 :: ct_execute_late_selector_pack_and_capture_tail_result
; qualifier: strong structural
; notes: Top-level late-family executor proved in this pass. Loads a pointer from `ct_late_selector_control_pointer_records`. Uses `B4AA` to select/adjust the current FE/FF-delimited segment. Reads the current sub-op byte into `B239`. Dispatches the sub-op through `B80D`. Optionally dispatches a second chained sub-op at `+4` when `B1CF != 0`. Captures the resulting `AF24` status into tail-local scratch/status arrays. May chain to another FE-delimited segment.
; source: chrono_trigger_labels_pass60.md
C1_AFD7_ct_execute_late_selector_pack_and_capture_tail_result:
    ; TODO: reconstruct body / data for C1:AFD7
    ; known span hint: C1:AFD7..C1:B08E

; =============================================================================
; C1:B094  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 49 :: ct_c1_update_lane_low_hp_threshold_flag
; qualifier: strengthened
; notes: Previously part of a vague flag-maintenance band. Pass 49 proves this exact routine clears and re-establishes `5E2F.bit0` from the `maxHP/8` versus current HP test.
; source: chrono_trigger_labels_pass49.md
C1_B094_ct_c1_update_lane_low_hp_threshold_flag:
    ; TODO: reconstruct body / data for C1:B094
    ; known span hint: C1:B094..C1:B0B3

; =============================================================================
; C1:B279  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 55 :: ct_c1_restore_or_clear_live_battle_slot_occupant_from_default_map
; qualifier: provisional
; notes: Strong structure: restores `AEFF[Y]` from `AF0A[Y]` when a remembered occupant exists later clears `AEFF[Y] = FF` on failure/removal path Kept provisional because the exact higher-level gameplay trigger for this restore/remove operation still wants one more caller-context pass.
; source: chrono_trigger_labels_pass55.md
C1_B279_ct_c1_restore_or_clear_live_battle_slot_occupant_from_default_map:
    ; TODO: reconstruct body / data for C1:B279
    ; known span hint: C1:B279..C1:B2C0

; =============================================================================
; C1:B390  top-status=strong  labels=1
; =============================================================================
; [strong] pass 51 :: ct_c1_seed_lane_gauge_exports_from_b158
; qualifier: strong
; notes: Directly mirrors `B158,Y` into: `AFAB,Y` `99DD,Y` `9F22,Y` Strongest safe reading: direct seed/export mirror from the upstream readiness seed value.
; source: chrono_trigger_labels_pass51.md
C1_B390_ct_c1_seed_lane_gauge_exports_from_b158:
    ; TODO: reconstruct body / data for C1:B390

; =============================================================================
; C1:B4AA  top-status=strong  labels=1
; =============================================================================
; [strong] pass 60 :: ct_select_tail_local_segment_within_late_selector_pack
; qualifier: strengthened structural
; notes: Previously just an opaque helper reached from the late family. Pass 60 proves it is the segment-selection / pointer-adjust helper that sits between: the pointer-record seed at `AFD7` and the `B80D` sub-op dispatch. Exact gameplay-facing noun remains open, but “late selector pack segment selector” is now justified.
; source: chrono_trigger_labels_pass60.md
C1_B4AA_ct_select_tail_local_segment_within_late_selector_pack:
    ; TODO: reconstruct body / data for C1:B4AA
    ; known span hint: C1:B4AA..C1:B4E6

; =============================================================================
; C1:B575  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_c1_service7_reconcile_canonical_record_lane_pairs
; qualifier: strong
; notes: Initializes `B3EB..B3F3` to `FF`, seeds root lane IDs `0/1/2`, This is the concrete front-end of the downstream `93F3` family.
; source: chrono_trigger_labels_pass42.md
C1_B575_ct_c1_service7_reconcile_canonical_record_lane_pairs:
    ; TODO: reconstruct body / data for C1:B575

; =============================================================================
; C1:B725  top-status=strong  labels=1
; =============================================================================
; [strong] pass 50 :: ct_c1_init_lane_active_time_gauge_exports
; qualifier: strong
; notes: Clears the visible lane-progress exports `99DD..99DF`. Seeds the visible lane-threshold/cap exports `9F22..9F24` to `0x30`. Also resets the nearby pending-lane/FIFO state. Strongest safe reading: initialization of the visible active-time/readiness gauge export family.
; source: chrono_trigger_labels_pass50.md
C1_B725_ct_c1_init_lane_active_time_gauge_exports:
    ; TODO: reconstruct body / data for C1:B725

; =============================================================================
; C1:B80D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 61 :: ct_c1_master_opcode_dispatch_table
; qualifier: strong architectural
; notes: Root indexed `JSR` table used by the late-pack executor. Interior slices line up exactly with the previously solved local tables. Current proven slice offsets: global `0x29..0x3F` -> `B85F..B88C` global `0x40..0x52` -> `B88D..B8BA` global `0x57..0xA9` -> `B8BB..B95F`
; source: chrono_trigger_labels_pass61.md
C1_B80D_ct_c1_master_opcode_dispatch_table:
    ; TODO: reconstruct body / data for C1:B80D
    ; known span hint: C1:B80D..C1:B95F

; =============================================================================
; C1:B85F  top-status=strong  labels=1
; =============================================================================
; [strong] pass 61 :: ct_c1_group1_opcode_dispatch_slice
; qualifier: strong correction
; notes: Keep the useful local group-1 numbering from earlier passes. But this is now proved to be a slice entrypoint inside `ct_c1_master_opcode_dispatch_table`, not an independent root table.
; source: chrono_trigger_labels_pass61.md
C1_B85F_ct_c1_group1_opcode_dispatch_slice:
    ; TODO: reconstruct body / data for C1:B85F
    ; known span hint: C1:B85F..C1:B88C

; =============================================================================
; C1:B88D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 61 :: ct_c1_group2_opcode_dispatch_slice
; qualifier: strong correction
; notes: Same correction as the group-1 table. Useful local numbering remains valid. Root ownership now belongs to `ct_c1_master_opcode_dispatch_table`.
; source: chrono_trigger_labels_pass61.md
C1_B88D_ct_c1_group2_opcode_dispatch_slice:
    ; TODO: reconstruct body / data for C1:B88D
    ; known span hint: C1:B88D..C1:B8BA

; =============================================================================
; C1:B8BB  top-status=strong  labels=2
; =============================================================================
; [strong] pass 61 :: ct_c1_inline_selector_control_dispatch_slice
; qualifier: strong correction
; notes: Same correction again for the selector-control table. `AC14` still dispatches here by local selector-control byte. But this slice is inside the same master dispatch table rooted at `B80D`.
; source: chrono_trigger_labels_pass61.md
C1_B8BB_ct_c1_inline_selector_control_dispatch_slice:
    ; TODO: reconstruct body / data for C1:B8BB
    ; known span hint: C1:B8BB..C1:B95F

; [strong] pass 59 :: ct_inline_selector_control_dispatch_table
; qualifier: strong
; notes: Directly dispatched by `C1:AC2E  JSR ($B8BB,X)`. `X` is formed from the non-negative inline selector-control byte read by `AC14`. Proven table span in this pass runs from selector-control byte `0x00` through `0x52`. Includes the previously isolated pass-58 selector-wrapper family as the `0x27..0x38` subrange.
; source: chrono_trigger_labels_pass59.md
C1_B8BB_ct_inline_selector_control_dispatch_table:
    ; TODO: reconstruct body / data for C1:B8BB
    ; known span hint: C1:B8BB..C1:B95F

; =============================================================================
; C1:B8F3  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 58 :: ct_selector_wrapper_table_candidate
; qualifier: provisional
; notes: Coherent pointer run of 29 entries: dynamic selector wrappers fixed single-entry wrappers `AB03` `AB9B` `ABC9` Strongly looks like a real local selector-wrapper table. The dispatch site into this table is still not pinned, so keep this provisional.
; source: chrono_trigger_labels_pass58.md
C1_B8F3_ct_selector_wrapper_table_candidate:
    ; TODO: reconstruct body / data for C1:B8F3
    ; known span hint: C1:B8F3..C1:B92B

; =============================================================================
; C1:B961  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_local_service2_wrapper
; qualifier: strong
; notes: Strengthened by pass 43. Exact wrapper into the lane-roster removal/reseat service.
; source: chrono_trigger_labels_pass43.md
C1_B961_ct_c1_local_service2_wrapper:
    ; TODO: reconstruct body / data for C1:B961

; =============================================================================
; C1:BD6F  top-status=strong  labels=1
; =============================================================================
; [strong] pass 50 :: ct_c1_apply_status_modifiers_to_lane_time_increment
; qualifier: strong
; notes: Starts from `AFAB[x]`. Halves it when the `5E4D|5E52` status family has bit `0x80` set. Doubles it with saturation when `5E4B` bit `0x20` is set. Forces a minimum of `1`. Mirrors the adjusted value to `99DD/9F22` for visible party lanes. Strongest safe reading: shared status-modifier helper for the lane active-time/readiness increment.
; source: chrono_trigger_labels_pass50.md
C1_BD6F_ct_c1_apply_status_modifiers_to_lane_time_increment:
    ; TODO: reconstruct body / data for C1:BD6F

; =============================================================================
; C1:BDE0  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 50 :: ct_c1_advance_lane_active_time_gauge_and_ready_transition_family
; qualifier: strengthened
; notes: Three sibling update families that: seed `AFAB` from `B158` apply `BD6F` advance one or both lane-bar exports with saturation set/update lane-ready side effects (`B03A`, `B188`, `93EE`) Best reading now: readiness-gauge advance and ready-transition family.
; source: chrono_trigger_labels_pass50.md
C1_BDE0_ct_c1_advance_lane_active_time_gauge_and_ready_transition_family:
    ; TODO: reconstruct body / data for C1:BDE0
    ; known span hint: C1:BDE0..C1:BF25

; =============================================================================
; C1:C90B  top-status=strong  labels=1
; =============================================================================
; [strong] pass 52 :: ct_c1_mul_u16_dp28_dp2a_to_dp2c_lowword
; qualifier: strong
; notes: Shift/add multiply helper. Consumes 16-bit inputs in `$28` and `$2A`. Writes the low word of the product to `$2C`. This is the real arithmetic core behind the `C1:FDBF` wrapper used in the readiness seed families.
; source: chrono_trigger_labels_pass52.md
C1_C90B_ct_c1_mul_u16_dp28_dp2a_to_dp2c_lowword:
    ; TODO: reconstruct body / data for C1:C90B

; =============================================================================
; C1:CC74  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 49 :: ct_c1_lane_selected_resource_spend_on_5e34_family
; qualifier: provisional
; notes: Subtracts a computed quantity from exactly one of: `5E34` `5EB4` `5F34` Strongly looks like a lane-selected spend/update path for the field now best read as current MP. Still kept provisional until the caller-side action family is nailed harder.
; source: chrono_trigger_labels_pass49.md
C1_CC74_ct_c1_lane_selected_resource_spend_on_5e34_family:
    ; TODO: reconstruct body / data for C1:CC74
    ; known span hint: C1:CC74..C1:CCC5

; =============================================================================
; C1:FB06  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 55 :: ct_c1_rebuild_head_battle_slot_occupant_maps_with_extra_guard
; qualifier: provisional
; notes: Same structural model as `FD:B24D..B27E`. Extra exclusion via `A09B[X]` is proven. Final caller-facing subsystem name still wants one more pass.
; source: chrono_trigger_labels_pass55.md
C1_FB06_ct_c1_rebuild_head_battle_slot_occupant_maps_with_extra_guard:
    ; TODO: reconstruct body / data for C1:FB06
    ; known span hint: C1:FB06..C1:FB2C

; =============================================================================
; C1:FDBF  top-status=strong  labels=1
; =============================================================================
; [strong] pass 52 :: ct_c1_jsl_mul_u16_dp28_dp2a_to_dp2c_lowword
; qualifier: strong
; notes: Thin long-call wrapper: `JSR $C90B` `RTL` Useful because the seed families call it twice with different inputs.
; source: chrono_trigger_labels_pass52.md
C1_FDBF_ct_c1_jsl_mul_u16_dp28_dp2a_to_dp2c_lowword:
    ; TODO: reconstruct body / data for C1:FDBF

