; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_CF
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; CF:E380  top-status=strong  labels=1
; =============================================================================
; [strong] pass 44 :: ct_cf_upload_pending_tilemap_0b40_to_vram_7a00
; qualifier: strong
; notes: Cross-bank sink for the `0B40` render buffer. If `99E2 != 0`, configures DMA to upload `0x0180` bytes from `00:0B40`
; source: chrono_trigger_labels_pass44.md
CF_E380_ct_cf_upload_pending_tilemap_0b40_to_vram_7a00:
    ; TODO: reconstruct body / data for CF:E380

