; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_D1
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; D1:5800  top-status=strong  labels=7
; =============================================================================
; [strong] pass 44 :: ct_d1_tilemap_template_default_0b40_0180
; qualifier: strong
; notes: Default/reset ROM template copied into `0B40` by `C1:1C3A`. Same size as the upload buffer and structurally part of the same tilemap-template family.
; source: chrono_trigger_labels_pass44.md
D1_5800_ct_d1_tilemap_template_default_0b40_0180:
    ; TODO: reconstruct body / data for D1:5800

; [provisional] pass 46 :: / D1:5A50 / D1:5BD0  ct_d1_alt_base_strip_layout_family      [strengthened context]
; notes: Pass 46 strengthens their caller-context roles: `5800` = default/base restore through `C1:1C3A` `5A50` = latched alternate via `A86A` `5BD0` = transition/reset alternate in later state-advance paths
; source: chrono_trigger_labels_pass46.md
D1_5800_D1_5A50_D1_5BD0_ct_d1_alt_base_strip_layout_family_strengthened_context:
    ; TODO: reconstruct body / data for D1:5800

; [provisional] pass 46 :: ct_d1_base_strip_template_default
; qualifier: provisional
; notes: Caller context strongly suggests the default/base restore variant. Final gameplay-facing mode name still open.
; source: chrono_trigger_labels_pass46.md
D1_5800_ct_d1_base_strip_template_default:
    ; TODO: reconstruct body / data for D1:5800

; [provisional] pass 45 :: / D1:5A50 / D1:5BD0  ct_d1_alt_base_strip_layout_family        [provisional]
; notes: The three templates are clearly alternate base layouts within the same 32x6 strip region. Exact gameplay/UI mode names are still unresolved.
; source: chrono_trigger_labels_pass45.md
D1_5800_D1_5A50_D1_5BD0_ct_d1_alt_base_strip_layout_family_provisional:
    ; TODO: reconstruct body / data for D1:5800

; [provisional] pass 45 :: / D1:5A50 / D1:5BD0  ct_d1_tilemap_template_family_16x12_words [withdrawn]
; notes: Pass 45 corrects this earlier provisional geometry. The safer keepable geometry is `32x6`, not `16x12`.
; source: chrono_trigger_labels_pass45.md
D1_5800_D1_5A50_D1_5BD0_ct_d1_tilemap_template_family_16x12_words_withdrawn:
    ; TODO: reconstruct body / data for D1:5800

; [unspecified] pass 45 :: / D1:5A50 / D1:5BD0  ct_d1_base_strip_template_family_32x6     [strong]
; notes: Corrected geometrically in this pass. All three `0x0180`-byte base templates are best modeled as 32-word by 6-row strip layouts. Used as the base tilemap copied into `0B40` before dynamic patching and upload.
; source: chrono_trigger_labels_pass45.md
D1_5800_D1_5A50_D1_5BD0_ct_d1_base_strip_template_family_32x6_strong:
    ; TODO: reconstruct body / data for D1:5800

; [unspecified] pass 44 :: / D1:5A50 / D1:5BD0  ct_d1_tilemap_template_family_16x12_words [provisional]
; notes: The three source blocks are best interpreted as a 192-word (likely 16x12) template family. This matrix interpretation fits both the dense row-structured data and the fixed-size VRAM upload,
; source: chrono_trigger_labels_pass44.md
D1_5800_D1_5A50_D1_5BD0_ct_d1_tilemap_template_family_16x12_words_provisional:
    ; TODO: reconstruct body / data for D1:5800

; =============================================================================
; D1:59FC  top-status=strong  labels=1
; =============================================================================
; [strong] pass 45 :: ct_d1_panel_segment_template_6x7_words
; qualifier: strong
; notes: Unique ROM source table used by `C1:0929`. Resolves cleanly as 6 rows of 7 words. Tile values form a compact border/interior segment template rather than logic data.
; source: chrono_trigger_labels_pass45.md
D1_59FC_ct_d1_panel_segment_template_6x7_words:
    ; TODO: reconstruct body / data for D1:59FC

; =============================================================================
; D1:5A50  top-status=strong  labels=2
; =============================================================================
; [strong] pass 44 :: ct_d1_tilemap_template_alt_a_0b40_0180
; qualifier: strong
; notes: Alternate ROM template variant copied into `0B40` by the `0EA1..0EB1` path. Followed by `INC $99E2`, proving it feeds the same upload path as the default template.
; source: chrono_trigger_labels_pass44.md
D1_5A50_ct_d1_tilemap_template_alt_a_0b40_0180:
    ; TODO: reconstruct body / data for D1:5A50

; [provisional] pass 46 :: ct_d1_base_strip_template_latched_alt
; qualifier: provisional
; notes: Single-shot alternate selected when `A86A` is nonzero, then that latch is cleared. Kept provisional until the higher-level mode name is pinned.
; source: chrono_trigger_labels_pass46.md
D1_5A50_ct_d1_base_strip_template_latched_alt:
    ; TODO: reconstruct body / data for D1:5A50

; =============================================================================
; D1:5BD0  top-status=strong  labels=2
; =============================================================================
; [strong] pass 44 :: ct_d1_tilemap_template_alt_b_0b40_0180
; qualifier: strong
; notes: Alternate ROM template variant copied into `0B40` by the `1301..1315`, Followed by `INC $99E2`, proving it feeds the same upload path as the default template.
; source: chrono_trigger_labels_pass44.md
D1_5BD0_ct_d1_tilemap_template_alt_b_0b40_0180:
    ; TODO: reconstruct body / data for D1:5BD0

; [provisional] pass 46 :: ct_d1_base_strip_template_transition_alt
; qualifier: provisional
; notes: Copied in later state-transition/reset paths with surrounding controller bookkeeping. Strong structural role, but final mode name still unresolved.
; source: chrono_trigger_labels_pass46.md
D1_5BD0_ct_d1_base_strip_template_transition_alt:
    ; TODO: reconstruct body / data for D1:5BD0

