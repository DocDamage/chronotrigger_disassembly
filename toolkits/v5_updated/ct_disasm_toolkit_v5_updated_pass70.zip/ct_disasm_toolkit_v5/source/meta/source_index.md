# Source State Index

Generated from the persistent label DB.

## 7E
- File: `source/banks/wram_7E.asm`
- Address groups: **55**
- Rows: **123**

## C0
- File: `source/banks/bank_C0.asm`
- Address groups: **2**
- Rows: **2**

## C1
- File: `source/banks/bank_C1.asm`
- Address groups: **55**
- Rows: **61**

## CC
- File: `source/banks/bank_CC.asm`
- Address groups: **10**
- Rows: **13**

## CF
- File: `source/banks/bank_CF.asm`
- Address groups: **1**
- Rows: **1**

## D1
- File: `source/banks/bank_D1.asm`
- Address groups: **4**
- Rows: **12**

## FD
- File: `source/banks/bank_FD.asm`
- Address groups: **15**
- Rows: **18**

