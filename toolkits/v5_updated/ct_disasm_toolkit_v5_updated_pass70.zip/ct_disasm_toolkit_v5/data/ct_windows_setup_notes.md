# Windows Setup Notes

## Expected local layout
Put the toolkit folder and your ROM in the same directory:
- `ct_disasm_toolkit_v3/`
- `Chrono Trigger (USA).sfc`

## Recommended commands
- `windows\run_resume_workspace.bat`
- `windows\run_query_label_db.bat --label opcode`
- `windows\run_build_xref_cache.bat`
- `windows\run_make_report.bat`

## Fingerprint check
Working ROM should match:
- CRC32 `2D206BF7`
- MD5 `a2bc447961e52fd2227baed164f729dc`
