#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional

DEFAULT_ROM = "Chrono Trigger (USA).sfc"

_ADDR_RE = re.compile(
    r"^\s*(?:(?P<bank>[0-9A-Fa-f]{2})[:](?P<offs>[0-9A-Fa-f]{4})|0x(?P<hex>[0-9A-Fa-f]+)|(?P<plain>[0-9A-Fa-f]{6}))\s*$"
)

def parse_int(text: str) -> int:
    text = text.strip()
    return int(text, 0)

def parse_snes_addr(text: str) -> int:
    m = _ADDR_RE.match(text)
    if not m:
        raise ValueError(f"Could not parse SNES/hex address: {text!r}")
    if m.group("bank"):
        return (int(m.group("bank"), 16) << 16) | int(m.group("offs"), 16)
    if m.group("hex"):
        return int(m.group("hex"), 16)
    if m.group("plain"):
        return int(m.group("plain"), 16)
    raise ValueError(f"Unhandled address form: {text!r}")

def fmt_snes(addr: int) -> str:
    addr &= 0xFFFFFF
    return f"{(addr >> 16) & 0xFF:02X}:{addr & 0xFFFF:04X}"

def fmt_pc(pc: int) -> str:
    return f"0x{pc:06X}"

def hirom_to_pc(addr: int, rom_size: Optional[int] = None) -> int:
    bank = (addr >> 16) & 0xFF
    offs = addr & 0xFFFF
    if offs < 0x8000:
        raise ValueError(f"{fmt_snes(addr)} is not a valid HiROM mapped CPU ROM address")
    pc = ((bank & 0x3F) << 16) | (offs & 0xFFFF)
    if rom_size is not None and not (0 <= pc < rom_size):
        raise ValueError(f"{fmt_snes(addr)} maps outside ROM size ({pc:#x})")
    return pc

def pc_to_hirom(pc: int) -> int:
    if pc < 0:
        raise ValueError("PC offset must be >= 0")
    bank = 0xC0 + ((pc >> 16) & 0x3F)
    offs = pc & 0xFFFF
    if offs < 0x8000:
        offs |= 0x8000
    return (bank << 16) | offs

@dataclass
class RomImage:
    path: Path
    data: bytes

    @classmethod
    def load(cls, path: str | Path) -> "RomImage":
        p = Path(path)
        data = p.read_bytes()
        return cls(path=p, data=data)

    @property
    def size(self) -> int:
        return len(self.data)

    @property
    def md5(self) -> str:
        return hashlib.md5(self.data).hexdigest()

    @property
    def crc32(self) -> str:
        import zlib
        return f"{zlib.crc32(self.data) & 0xFFFFFFFF:08X}"

    def pc(self, addr: str | int) -> int:
        if isinstance(addr, str):
            addr = parse_snes_addr(addr)
        return hirom_to_pc(addr, len(self.data))

    def snes(self, pc: int) -> int:
        return pc_to_hirom(pc)

    def read(self, start: str | int, length: int) -> bytes:
        pc = self.pc(start) if not isinstance(start, int) or start > self.size else start
        return self.data[pc:pc + length]

    def byte(self, start: str | int) -> int:
        pc = self.pc(start) if not isinstance(start, int) or start > self.size else start
        return self.data[pc]

def default_rom_path(explicit: Optional[str]) -> Path:
    if explicit:
        return Path(explicit)
    cwd = Path.cwd() / DEFAULT_ROM
    if cwd.exists():
        return cwd
    data = Path("/mnt/data") / DEFAULT_ROM
    if data.exists():
        return data
    return cwd

def chunked(seq: bytes, n: int) -> Iterable[bytes]:
    for i in range(0, len(seq), n):
        yield seq[i:i+n]

def hexdump(rom: RomImage, start_snes: int, blob: bytes, width: int = 16) -> str:
    lines: List[str] = []
    start_pc = hirom_to_pc(start_snes, rom.size)
    for i in range(0, len(blob), width):
        row = blob[i:i+width]
        pc = start_pc + i
        snes = pc_to_hirom(pc)
        hex_bytes = " ".join(f"{b:02X}" for b in row)
        ascii_part = "".join(chr(b) if 32 <= b < 127 else "." for b in row)
        lines.append(f"{fmt_snes(snes)}  {fmt_pc(pc)}  {hex_bytes:<{width*3}}  {ascii_part}")
    return "\n".join(lines)

def parse_pattern(pattern: str) -> list[Optional[int]]:
    out: list[Optional[int]] = []
    for part in pattern.strip().split():
        if part in {"??", "?"}:
            out.append(None)
        else:
            out.append(int(part, 16))
    if not out:
        raise ValueError("Pattern must not be empty")
    return out

def find_pattern(blob: bytes, pattern: list[Optional[int]]) -> list[int]:
    hits: list[int] = []
    plen = len(pattern)
    for i in range(0, len(blob) - plen + 1):
        ok = True
        for j, want in enumerate(pattern):
            if want is not None and blob[i+j] != want:
                ok = False
                break
        if ok:
            hits.append(i)
    return hits

def make_argparser(description: str) -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=description)
    p.add_argument("--rom", help="Path to Chrono Trigger ROM")
    return p
