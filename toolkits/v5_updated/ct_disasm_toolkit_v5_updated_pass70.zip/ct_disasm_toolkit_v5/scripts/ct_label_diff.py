#!/usr/bin/env python3
from __future__ import annotations

import argparse, csv, json
from pathlib import Path

def load_dataset(path: Path):
    if path.suffix.lower() == '.json':
        data = json.loads(path.read_text(encoding='utf-8'))
        rows = data.get('latest_by_address_range') or data.get('labels') or []
        return {(r.get('address_range'), r.get('label')): r for r in rows}
    if path.suffix.lower() == '.csv':
        with path.open(encoding='utf-8', newline='') as f:
            rows = list(csv.DictReader(f))
        return {(r.get('address_range'), r.get('label')): r for r in rows}
    raise SystemExit(f'Unsupported file type: {path}')

def main() -> None:
    ap = argparse.ArgumentParser(description='Diff two label datasets (CSV or JSON export).')
    ap.add_argument('old'); ap.add_argument('new'); args = ap.parse_args()
    old = load_dataset(Path(args.old)); new = load_dataset(Path(args.new))
    old_keys, new_keys = set(old), set(new)
    added, removed = sorted(new_keys - old_keys), sorted(old_keys - new_keys)
    changed = [(k, old[k], new[k]) for k in sorted(old_keys & new_keys) if old[k] != new[k]]
    print(f'added={len(added)} removed={len(removed)} changed={len(changed)}')
    if added:
        print('
[added]')
        for k in added[:50]: print(f'{k[0]} | {k[1]}')
    if removed:
        print('
[removed]')
        for k in removed[:50]: print(f'{k[0]} | {k[1]}')
    if changed:
        print('
[changed]')
        for k, old_row, new_row in changed[:20]:
            print(f'{k[0]} | {k[1]}')
            print(f'  old={old_row}')
            print(f'  new={new_row}')

if __name__ == '__main__':
    main()
