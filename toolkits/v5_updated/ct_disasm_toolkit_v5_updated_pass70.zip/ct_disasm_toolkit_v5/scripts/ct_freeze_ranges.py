#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sqlite3
from collections import defaultdict
from pathlib import Path
from ct_common import parse_snes_addr

STATUS_TO_LEVEL = {'strong': 'confirmed', 'alias': 'stable', 'caution': 'review', 'provisional': 'review', 'unspecified': 'review'}


def load_latest_rows(db_path: Path):
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    rows = con.execute(
        'SELECT pass_num, address_range, address_start, address_end, label, status_bucket, notes, source_file FROM labels WHERE address_start IS NOT NULL ORDER BY pass_num, address_start'
    ).fetchall()
    con.close()
    latest = {}
    for r in rows:
        key = (r['address_range'], r['label'])
        if key not in latest or r['pass_num'] >= latest[key]['pass_num']:
            latest[key] = dict(r)
    return list(latest.values())


def build_seed(rows):
    out = []
    for r in rows:
        if r['status_bucket'] != 'strong':
            continue
        out.append({
            'range': r['address_range'],
            'start': r['address_start'],
            'end': normalize_end(r['address_start'], r['address_end']),
            'level': STATUS_TO_LEVEL.get(r['status_bucket'], 'review'),
            'label': r['label'],
            'pass_num': r['pass_num'],
            'source_file': r['source_file'],
            'notes': r['notes'],
        })
    return out


def parse_range(text: str):
    if '..' in text:
        a, b = text.split('..', 1)
        return parse_snes_addr(a), parse_snes_addr(b), text
    v = parse_snes_addr(text)
    return v, v, text



def normalize_end(start: int, end: int | None) -> int:
    if end is None:
        return start
    if end < start and end < 0x10000 and start > 0xFFFF:
        return (start & 0xFF0000) | end
    return end


def main() -> None:
    ap = argparse.ArgumentParser(description='Build or edit the V5 range freeze map.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--output-json', default='state/range_freeze.json')
    ap.add_argument('--summary-md', default='reports/ct_freeze_summary.md')
    ap.add_argument('--seed-from-db', action='store_true')
    ap.add_argument('--set-range', default=None, help='Manual range like C1:B80D..C1:B95F or C1:B80D')
    ap.add_argument('--set-level', default='review')
    ap.add_argument('--set-label', default='MANUAL_RANGE')
    ap.add_argument('--set-note', default='')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    out_json = root / args.output_json
    out_md = root / args.summary_md
    entries = []
    if out_json.exists():
        try:
            data = json.loads(out_json.read_text(encoding='utf-8'))
            entries = list(data.get('entries', []))
        except Exception:
            entries = []
    if args.seed_from_db:
        rows = load_latest_rows(root / args.db)
        entries = build_seed(rows)
    if args.set_range:
        start, end, text = parse_range(args.set_range)
        entries.append({
            'range': text,
            'start': start,
            'end': end,
            'level': args.set_level,
            'label': args.set_label,
            'pass_num': None,
            'source_file': 'manual',
            'notes': args.set_note,
        })
    uniq = {}
    for e in entries:
        key = (e['range'], e['label'], e['level'])
        uniq[key] = e
    entries = sorted(uniq.values(), key=lambda e: (e.get('start') or 0, e.get('label') or ''))
    payload = {'schema_version': 1, 'entries': entries}
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(payload, indent=2), encoding='utf-8')
    by_bank = defaultdict(list)
    for e in entries:
        bank = ((e['start'] or 0) >> 16) & 0xFF
        by_bank[f'{bank:02X}'].append(e)
    lines = ['# Range Freeze Summary', '', 'This file is the V5 range lock / freeze map.', '']
    lines.append(f'- Total frozen/stable ranges: **{len(entries)}**')
    lines.append('')
    for bank in sorted(by_bank):
        lines.append(f'## {bank}')
        lines.append(f'- Entries: **{len(by_bank[bank])}**')
        for e in by_bank[bank][:20]:
            lines.append(f'- `{e["range"]}` :: **{e["level"]}** :: {e["label"]}')
        if len(by_bank[bank]) > 20:
            lines.append(f'- ... {len(by_bank[bank]) - 20} more')
        lines.append('')
    out_md.parent.mkdir(parents=True, exist_ok=True)
    out_md.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(out_json)
    print(out_md)


if __name__ == '__main__':
    main()
