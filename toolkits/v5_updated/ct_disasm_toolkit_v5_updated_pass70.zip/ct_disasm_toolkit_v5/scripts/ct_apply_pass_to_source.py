#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
from pathlib import Path


def run(cmd, cwd: Path):
    print('+', ' '.join(str(x) for x in cmd))
    subprocess.run(cmd, cwd=str(cwd), check=True)


def main() -> None:
    ap = argparse.ArgumentParser(description='Apply a completed pass into the V5 source workspace.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--pass-num', type=int, default=None)
    ap.add_argument('--rom', default=None)
    args = ap.parse_args()
    root = Path(args.root).resolve()
    if args.pass_num is not None:
        needed = [root / f'chrono_trigger_disasm_pass{args.pass_num}.md', root / f'chrono_trigger_labels_pass{args.pass_num}.md']
        missing = [p for p in needed if not p.exists()]
        if missing:
            raise SystemExit('Missing pass artifacts: ' + ', '.join(str(p.name) for p in missing))
    run(['python3', 'scripts/ct_build_label_db.py', '--dir', str(root), '--output', 'data/ct_label_db.sqlite'], root)
    run(['python3', 'scripts/ct_export_label_db_json.py', '--db', 'data/ct_label_db.sqlite', '--output', 'data/ct_label_db.json'], root)
    run(['python3', 'scripts/ct_generate_bank_sources.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-dir', 'source'], root)
    run(['python3', 'scripts/ct_freeze_ranges.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-json', 'state/range_freeze.json', '--summary-md', 'reports/ct_freeze_summary.md', '--seed-from-db'], root)
    run(['python3', 'scripts/ct_source_state_report.py', '--root', str(root), '--manifest', 'source/meta/source_manifest.json', '--freeze-json', 'state/range_freeze.json', '--output-md', 'reports/ct_source_state.md'], root)
    run(['python3', 'scripts/ct_generate_unresolved_dashboard.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-md', 'reports/ct_unresolved_dashboard.md', '--output-json', 'reports/ct_unresolved_dashboard.json'], root)
    run(['python3', 'scripts/ct_generate_rom_coverage.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-md', 'reports/ct_rom_coverage.md', '--output-html', 'reports/ct_rom_coverage.html', '--output-json', 'reports/ct_rom_coverage.json'], root)
    run(['python3', 'scripts/ct_runtime_validate.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-md', 'reports/ct_runtime_validation.md', '--output-json', 'reports/runtime/runtime_validation.json', '--output-csv', 'reports/runtime/runtime_validation.csv'], root)
    cmd = ['python3', 'scripts/ct_rebuild_diff.py', '--root', str(root), '--output-md', 'reports/ct_rebuild_diff_report.md', '--output-json', 'reports/ct_rebuild_diff_report.json']
    if args.rom:
        cmd += ['--rom', args.rom]
    run(cmd, root)
    print('Pass-to-source apply complete.')


if __name__ == '__main__':
    main()
