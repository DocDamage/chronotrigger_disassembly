#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sqlite3
from collections import defaultdict
from pathlib import Path


def merge_intervals(items):
    if not items:
        return []
    items = sorted(items)
    out = [list(items[0])]
    for s, e in items[1:]:
        if s <= out[-1][1] + 1:
            out[-1][1] = max(out[-1][1], e)
        else:
            out.append([s, e])
    return [(a, b) for a, b in out]



def normalize_end(start: int, end: int | None) -> int:
    if end is None:
        return start
    if end < start and end < 0x10000 and start > 0xFFFF:
        return (start & 0xFF0000) | end
    return end


def main() -> None:
    ap = argparse.ArgumentParser(description='Generate ROM/WRAM coverage views from the label DB.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--output-md', default='reports/ct_rom_coverage.md')
    ap.add_argument('--output-html', default='reports/ct_rom_coverage.html')
    ap.add_argument('--output-json', default='reports/ct_rom_coverage.json')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    con = sqlite3.connect(root / args.db)
    con.row_factory = sqlite3.Row
    rows = [dict(r) for r in con.execute('SELECT pass_num, address_range, address_start, address_end, status_bucket, label FROM labels WHERE address_start IS NOT NULL')]
    con.close()
    latest = {}
    for r in rows:
        key = (r['address_range'], r['label'])
        if key not in latest or r['pass_num'] >= latest[key]['pass_num']:
            latest[key] = r
    per_bank_ranges = defaultdict(list)
    per_bank_stats = defaultdict(lambda: {'labels': 0, 'strong': 0, 'provisional': 0, 'caution': 0, 'alias': 0, 'unspecified': 0})
    for r in latest.values():
        start = r['address_start']
        end = normalize_end(start, r['address_end'])
        bank = (start >> 16) & 0xFF
        bank_base = bank << 16
        per_bank_ranges[bank].append((start - bank_base, end - bank_base))
        per_bank_stats[bank]['labels'] += 1
        per_bank_stats[bank][r['status_bucket']] = per_bank_stats[bank].get(r['status_bucket'], 0) + 1
    summary = {'banks': []}
    lines = ['# ROM / WRAM Coverage View', '', 'Lower-bound coverage only. Point labels count as a single byte unless a wider range is explicitly known.', '']
    rows_html = []
    for bank in sorted(per_bank_ranges):
        merged = merge_intervals(per_bank_ranges[bank])
        covered = sum((b - a + 1) for a, b in merged)
        pct = covered / 65536 * 100.0
        item = {'bank': f'{bank:02X}', 'covered_bytes': covered, 'pct_of_64k': round(pct, 3), **per_bank_stats[bank]}
        summary['banks'].append(item)
        lines.append(f'## {bank:02X}')
        lines.append(f'- Covered bytes: **{covered}** / 65536 (**{pct:.3f}%**)')
        lines.append(f'- Labels: **{item["labels"]}**  strong={item.get("strong",0)} provisional={item.get("provisional",0)} caution={item.get("caution",0)} alias={item.get("alias",0)}')
        lines.append('')
        rows_html.append(f"<tr><td>{bank:02X}</td><td>{covered}</td><td>{pct:.3f}%</td><td><div style='background:#ddd;width:320px'><div style='background:#4a6ee0;height:14px;width:{min(pct,100):.3f}%;'></div></div></td></tr>")
    (root / args.output_md).write_text('\n'.join(lines) + '\n', encoding='utf-8')
    html = f'''<!doctype html><html><head><meta charset="utf-8"><title>CT ROM Coverage</title></head><body>
<h1>Chrono Trigger Coverage View</h1>
<p>Lower-bound coverage only. Point labels count as a single byte unless the range is explicitly known.</p>
<table border="1" cellspacing="0" cellpadding="6"><tr><th>Bank</th><th>Covered bytes</th><th>% of 64K</th><th>Bar</th></tr>
{''.join(rows_html)}
</table></body></html>'''
    (root / args.output_html).write_text(html, encoding='utf-8')
    (root / args.output_json).write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(root / args.output_md)
    print(root / args.output_html)
    print(root / args.output_json)


if __name__ == '__main__':
    main()
