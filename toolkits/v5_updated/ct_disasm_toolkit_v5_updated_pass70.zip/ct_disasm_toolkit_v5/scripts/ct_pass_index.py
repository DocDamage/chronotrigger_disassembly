#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
from pathlib import Path

PASS_RE = re.compile(r"chrono_trigger_disasm_pass(\d+)\.md$")
LABEL_RE = re.compile(r"chrono_trigger_labels_pass(\d+)\.md$")

def main() -> None:
    ap = argparse.ArgumentParser(description="Inventory Chrono Trigger pass and label files.")
    ap.add_argument("--dir", default=".", help="Working directory")
    args = ap.parse_args()

    root = Path(args.dir)
    passes = sorted((int(m.group(1)), p.name) for p in root.iterdir() if (m := PASS_RE.match(p.name)))
    labels = sorted((int(m.group(1)), p.name) for p in root.iterdir() if (m := LABEL_RE.match(p.name)))

    pass_nums = {n for n, _ in passes}
    label_nums = {n for n, _ in labels}

    print(f"Pass files:  {len(passes)}")
    print(f"Label files: {len(labels)}")
    if passes:
        print(f"Latest pass: {passes[-1][0]}")
    missing_labels = sorted(pass_nums - label_nums)
    missing_passes = sorted(label_nums - pass_nums)

    if missing_labels:
        print("Passes missing label files:", ", ".join(map(str, missing_labels)))
    if missing_passes:
        print("Label files with no matching pass:", ", ".join(map(str, missing_passes)))

    print("\nPass inventory:")
    for n, name in passes:
        marker = ""
        if n in label_nums:
            marker = " +labels"
        print(f"  {n:03d}  {name}{marker}")

if __name__ == "__main__":
    main()
