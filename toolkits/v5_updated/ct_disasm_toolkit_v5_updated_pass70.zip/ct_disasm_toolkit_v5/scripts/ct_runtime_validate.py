#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import sqlite3
from pathlib import Path


def addr_to_int(text: str) -> int | None:
    text = text.strip().replace('0x', '').replace(':', '')
    try:
        return int(text, 16)
    except ValueError:
        return None


def main() -> None:
    ap = argparse.ArgumentParser(description='Validate imported runtime evidence against the label DB.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--output-md', default='reports/ct_runtime_validation.md')
    ap.add_argument('--output-json', default='reports/runtime/runtime_validation.json')
    ap.add_argument('--output-csv', default='reports/runtime/runtime_validation.csv')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    db = sqlite3.connect(root / args.db)
    db.row_factory = sqlite3.Row
    labels = [dict(r) for r in db.execute('SELECT address_start, address_end, label, status_bucket, pass_num FROM labels WHERE address_start IS NOT NULL ORDER BY address_start')]
    try:
        runtime_rows = [dict(r) for r in db.execute('SELECT source_file, source_kind, address, event_type, count, notes FROM runtime_evidence ORDER BY count DESC, address')]
    except sqlite3.OperationalError:
        runtime_rows = []
    result_rows = []
    matched = 0
    unmatched = 0
    for rr in runtime_rows:
        addr_i = addr_to_int(rr['address'])
        matches = []
        if addr_i is not None:
            for lab in labels:
                start = lab['address_start']
                end = lab['address_end'] if lab['address_end'] is not None else start
                if start <= addr_i <= end:
                    matches.append(lab)
        if matches:
            matched += 1
            top = sorted(matches, key=lambda x: (x['status_bucket'] == 'strong', x['pass_num']), reverse=True)[0]
            result_rows.append({
                'address': rr['address'], 'event_type': rr['event_type'], 'count': rr['count'],
                'status': 'matched', 'top_label': top['label'], 'top_bucket': top['status_bucket'],
                'source_file': rr['source_file'], 'notes': rr['notes'],
            })
        else:
            unmatched += 1
            result_rows.append({
                'address': rr['address'], 'event_type': rr['event_type'], 'count': rr['count'],
                'status': 'unmatched', 'top_label': '', 'top_bucket': '', 'source_file': rr['source_file'], 'notes': rr['notes'],
            })
    out_json = root / args.output_json
    out_json.parent.mkdir(parents=True, exist_ok=True)
    payload = {'runtime_rows': len(runtime_rows), 'matched_rows': matched, 'unmatched_rows': unmatched, 'rows': result_rows[:500]}
    out_json.write_text(json.dumps(payload, indent=2), encoding='utf-8')
    out_csv = root / args.output_csv
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    with out_csv.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['address', 'event_type', 'count', 'status', 'top_label', 'top_bucket', 'source_file', 'notes'])
        w.writeheader()
        w.writerows(result_rows)
    lines = ['# Runtime Validation Report', '']
    if not runtime_rows:
        lines += ['No runtime evidence rows are currently imported.', '', 'Import traces first, then rerun this validator.']
    else:
        lines += [
            f'- Runtime rows checked: **{len(runtime_rows)}**',
            f'- Matched rows: **{matched}**',
            f'- Unmatched rows: **{unmatched}**',
            '', '## Top unmatched runtime addresses'
        ]
        top_unmatched = [r for r in result_rows if r['status'] == 'unmatched'][:25]
        if top_unmatched:
            for r in top_unmatched:
                lines.append(f'- `{r["address"]}` `{r["event_type"]}` count={r["count"]} source={r["source_file"]}')
        else:
            lines.append('- none')
        lines += ['', '## Top matched runtime addresses']
        top_matched = [r for r in result_rows if r['status'] == 'matched'][:25]
        if top_matched:
            for r in top_matched:
                lines.append(f'- `{r["address"]}` -> **{r["top_label"]}** ({r["top_bucket"]}) count={r["count"]}')
        else:
            lines.append('- none')
    out_md = root / args.output_md
    out_md.parent.mkdir(parents=True, exist_ok=True)
    out_md.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    db.close()
    print(out_md)
    print(out_json)
    print(out_csv)


if __name__ == '__main__':
    main()
