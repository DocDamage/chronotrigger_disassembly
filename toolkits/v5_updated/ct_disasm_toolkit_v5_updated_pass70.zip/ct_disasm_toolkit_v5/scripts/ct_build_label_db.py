#!/usr/bin/env python3
from __future__ import annotations

import argparse, sqlite3
from pathlib import Path
from ct_label_parse import iter_label_rows

SCHEMA = """
CREATE TABLE IF NOT EXISTS labels (
    id INTEGER PRIMARY KEY,
    pass_num INTEGER NOT NULL,
    section TEXT,
    address_range TEXT,
    address_start INTEGER,
    address_end INTEGER,
    address_kind TEXT,
    label TEXT NOT NULL,
    qualifier TEXT,
    status_bucket TEXT,
    notes TEXT,
    source_file TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_labels_addr ON labels(address_start, address_end);
CREATE INDEX IF NOT EXISTS idx_labels_label ON labels(label);
CREATE INDEX IF NOT EXISTS idx_labels_pass ON labels(pass_num);
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
"""

def main() -> None:
    ap = argparse.ArgumentParser(description='Build a persistent SQLite label database from pass label markdown files.')
    ap.add_argument('--dir', default='.')
    ap.add_argument('--output', default='data/ct_label_db.sqlite')
    args = ap.parse_args()
    root = Path(args.dir).resolve()
    out = Path(args.output).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    rows = list(iter_label_rows(root))
    con = sqlite3.connect(out)
    cur = con.cursor()
    cur.executescript(SCHEMA)
    cur.execute('DELETE FROM labels')
    cur.execute('DELETE FROM meta')
    cur.executemany(
        'INSERT INTO labels (pass_num, section, address_range, address_start, address_end, address_kind, label, qualifier, status_bucket, notes, source_file) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [(r['pass_num'], r['section'], r['address_range'], r['address_start'], r['address_end'], r['address_kind'], r['label'], r['qualifier'], r['status_bucket'], r['notes'], r['source_file']) for r in rows]
    )
    cur.executemany('INSERT INTO meta(key, value) VALUES (?, ?)', [('row_count', str(len(rows))), ('source_dir', str(root)), ('latest_pass', str(max((r['pass_num'] for r in rows), default=0)))])
    con.commit(); con.close()
    print(out) ; print(f'rows={len(rows)}')

if __name__ == '__main__':
    main()
