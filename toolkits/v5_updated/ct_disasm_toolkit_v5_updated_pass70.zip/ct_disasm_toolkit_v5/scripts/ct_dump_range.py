#!/usr/bin/env python3
from __future__ import annotations

import argparse
from ct_common import RomImage, default_rom_path, fmt_pc, fmt_snes, hexdump, hirom_to_pc, parse_int, parse_snes_addr, pc_to_hirom

def main() -> None:
    ap = argparse.ArgumentParser(description="Dump a ROM range as hex/bytes/words/longs.")
    ap.add_argument("start", help="SNES start address like C1:B80D")
    ap.add_argument("--length", required=True, help="Length in bytes, e.g. 0x80")
    ap.add_argument("--width", type=int, default=16, help="Bytes per line for raw hex dump")
    ap.add_argument("--bytes", action="store_true", help="Also show flat byte list")
    ap.add_argument("--words", action="store_true", help="Also show little-endian 16-bit words")
    ap.add_argument("--longs", action="store_true", help="Also show little-endian 24-bit longs")
    ap.add_argument("--rom", help="ROM path")
    args = ap.parse_args()

    rom = RomImage.load(default_rom_path(args.rom))
    start_snes = parse_snes_addr(args.start)
    length = parse_int(args.length)
    blob = rom.read(start_snes, length)
    start_pc = hirom_to_pc(start_snes, rom.size)

    print(f"ROM:   {rom.path}")
    print(f"SNES:  {fmt_snes(start_snes)}")
    print(f"PC:    {fmt_pc(start_pc)}")
    print(f"LEN:   0x{length:X} ({length})")
    print()
    print(hexdump(rom, start_snes, blob, width=args.width))

    if args.bytes:
        print("\n[bytes]")
        print(" ".join(f"{b:02X}" for b in blob))

    if args.words:
        print("\n[words]")
        for i in range(0, len(blob) - 1, 2):
            w = blob[i] | (blob[i+1] << 8)
            print(f"{fmt_snes(pc_to_hirom(start_pc + i))}: {w:04X}")

    if args.longs:
        print("\n[longs]")
        for i in range(0, len(blob) - 2, 3):
            v = blob[i] | (blob[i+1] << 8) | (blob[i+2] << 16)
            print(f"{fmt_snes(pc_to_hirom(start_pc + i))}: {v:06X}")

if __name__ == "__main__":
    main()
