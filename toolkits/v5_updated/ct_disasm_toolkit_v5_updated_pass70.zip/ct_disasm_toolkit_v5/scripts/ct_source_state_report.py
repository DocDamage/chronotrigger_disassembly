#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser(description='Generate the V5 source state report from source/meta/source_manifest.json and freeze map.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--manifest', default='source/meta/source_manifest.json')
    ap.add_argument('--freeze-json', default='state/range_freeze.json')
    ap.add_argument('--output-md', default='reports/ct_source_state.md')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    manifest_path = root / args.manifest
    freeze_path = root / args.freeze_json
    manifest = json.loads(manifest_path.read_text(encoding='utf-8')) if manifest_path.exists() else {'banks': {}, 'total_rows': 0}
    freeze = json.loads(freeze_path.read_text(encoding='utf-8')) if freeze_path.exists() else {'entries': []}
    lines = ['# Source State Report', '', f'- Total label rows represented: **{manifest.get("total_rows", 0)}**', f'- Frozen/stable ranges: **{len(freeze.get("entries", []))}**', '', '## Banks']
    for bank, info in sorted(manifest.get('banks', {}).items()):
        lines.append(f'- {bank}: `{info["file"]}`  groups={info["address_groups"]} rows={info["rows"]}')
    lines.append('')
    lines.append('## Notes')
    lines.append('- This is a scaffold-first source tree, not a byte-perfect assembled disassembly yet.')
    lines.append('- Use the rebuild/diff report to track assembler integration progress.')
    out = root / args.output_md
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(out)


if __name__ == '__main__':
    main()
