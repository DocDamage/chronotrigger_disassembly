#!/usr/bin/env python3
from __future__ import annotations

import argparse, sqlite3

def main() -> None:
    ap = argparse.ArgumentParser(description='Query the SQLite label DB by address or label text.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--label')
    ap.add_argument('--address')
    ap.add_argument('--latest-only', action='store_true')
    ap.add_argument('--limit', type=int, default=50)
    args = ap.parse_args()
    con = sqlite3.connect(args.db)
    cur = con.cursor()
    base = 'SELECT pass_num, address_range, label, status_bucket, qualifier, notes, source_file FROM labels'
    clauses, params = [], []
    if args.label:
        clauses.append('label LIKE ?')
        params.append(f"%{args.label}%")
    if args.address:
        clauses.append("REPLACE(address_range, ':', '') LIKE ?")
        params.append(f"%{args.address.replace(':','').upper()}%")
    where = (' WHERE ' + ' AND '.join(clauses)) if clauses else ''
    if args.latest_only:
        sql = f"""
        SELECT q.pass_num, q.address_range, q.label, q.status_bucket, q.qualifier, q.notes, q.source_file
        FROM ({base}{where}) q JOIN (
            SELECT address_range, MAX(pass_num) AS max_pass FROM labels GROUP BY address_range
        ) x ON q.address_range = x.address_range AND q.pass_num = x.max_pass
        ORDER BY q.pass_num DESC, q.address_range LIMIT ?
        """
    else:
        sql = f"{base}{where} ORDER BY pass_num DESC, address_range LIMIT ?"
    params.append(args.limit)
    for row in cur.execute(sql, params).fetchall():
        print(' | '.join('' if v is None else str(v) for v in row))
    con.close()

if __name__ == '__main__':
    main()
