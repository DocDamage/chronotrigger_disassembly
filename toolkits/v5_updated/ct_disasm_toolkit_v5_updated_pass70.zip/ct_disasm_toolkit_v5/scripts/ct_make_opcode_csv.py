#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path

def main() -> None:
    ap = argparse.ArgumentParser(description="Create starter opcode tracking CSVs.")
    ap.add_argument("--output-dir", default=".", help="Where to write the CSVs")
    args = ap.parse_args()

    outdir = Path(args.output_dir)
    outdir.mkdir(parents=True, exist_ok=True)

    files = {
        "ct_c1_master_opcode_matrix.csv": [
            "global_opcode_hex","decimal","slice","dispatch_addr","label","status","evidence_pass","notes"
        ],
        "ct_c1_selector_control_matrix.csv": [
            "selector_byte_hex","decimal","dispatch_addr","label","status","evidence_pass","notes"
        ],
        "ct_service7_wrapper_matrix.csv": [
            "wrapper_opcode_hex","dispatch_addr","label","status","evidence_pass","notes"
        ],
    }

    for name, cols in files.items():
        p = outdir / name
        if p.exists() and len(p.read_text(encoding='utf-8').splitlines()) > 1:
            print(f'{p} (preserved)')
            continue
        with p.open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(cols)
        print(p)

if __name__ == "__main__":
    main()
