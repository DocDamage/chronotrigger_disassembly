#!/usr/bin/env python3
from __future__ import annotations

import argparse
from ct_common import RomImage, default_rom_path, fmt_pc, fmt_snes, parse_snes_addr, pc_to_hirom

def iter_calls(blob: bytes, target: int):
    tgt_bank = (target >> 16) & 0xFF
    tgt_word = target & 0xFFFF
    lo = tgt_word & 0xFF
    hi = (tgt_word >> 8) & 0xFF

    for i in range(len(blob) - 3):
        op = blob[i]
        # JSR abs / JMP abs / JSR (abs,X)
        if op in {0x20, 0x4C, 0xFC} and blob[i+1] == lo and blob[i+2] == hi:
            yield (i, "bank-local", op)
        # JSL long / JMP long
        if op in {0x22, 0x5C} and i + 3 < len(blob):
            if blob[i+1] == lo and blob[i+2] == hi and blob[i+3] == tgt_bank:
                yield (i, "long", op)

def iter_word_refs(blob: bytes, target: int):
    tgt_word = target & 0xFFFF
    lo = tgt_word & 0xFF
    hi = (tgt_word >> 8) & 0xFF
    for i in range(len(blob) - 1):
        if blob[i] == lo and blob[i+1] == hi:
            yield i

def iter_raw_refs(blob: bytes, target: int):
    b0 = target & 0xFF
    b1 = (target >> 8) & 0xFF
    b2 = (target >> 16) & 0xFF
    for i in range(len(blob) - 2):
        if blob[i] == b0 and blob[i+1] == b1 and blob[i+2] == b2:
            yield i

OP_NAMES = {
    0x20: "JSR abs",
    0x22: "JSL long",
    0x4C: "JMP abs",
    0x5C: "JMP long",
    0xFC: "JSR (abs,X)",
}

def main() -> None:
    ap = argparse.ArgumentParser(description="Search for callsites/xrefs/raw references to a target address.")
    ap.add_argument("target", help="Target SNES address like C1:AC14")
    ap.add_argument("--mode", choices=["calls", "word", "raw"], default="calls")
    ap.add_argument("--bank", help="Optional bank filter like C1 for word/raw scans")
    ap.add_argument("--rom", help="ROM path")
    ap.add_argument("--limit", type=int, default=500, help="Max hits to print")
    args = ap.parse_args()

    rom = RomImage.load(default_rom_path(args.rom))
    target = parse_snes_addr(args.target)

    if args.bank:
        bank = int(args.bank.replace(":", ""), 16)
        start = ((bank & 0x3F) << 16)
        end = start + 0x10000
        blob = rom.data[start:end]
        base_pc = start
    else:
        blob = rom.data
        base_pc = 0

    count = 0
    if args.mode == "calls":
        for pc_off, kind, op in iter_calls(blob, target):
            pc = base_pc + pc_off
            print(f"{fmt_snes(pc_to_hirom(pc))}  {fmt_pc(pc)}  {OP_NAMES.get(op, hex(op))}  {kind}")
            count += 1
            if count >= args.limit:
                break
    elif args.mode == "word":
        for pc_off in iter_word_refs(blob, target):
            pc = base_pc + pc_off
            print(f"{fmt_snes(pc_to_hirom(pc))}  {fmt_pc(pc)}  word-match")
            count += 1
            if count >= args.limit:
                break
    else:
        for pc_off in iter_raw_refs(blob, target):
            pc = base_pc + pc_off
            print(f"{fmt_snes(pc_to_hirom(pc))}  {fmt_pc(pc)}  raw-24")
            count += 1
            if count >= args.limit:
                break

    print(f"Hits shown: {count}")

if __name__ == "__main__":
    main()
