#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path

LABEL_FILE_RE = re.compile(r"chrono_trigger_labels_pass(\d+)\.md$")
HEADING_RE = re.compile(r"^###\s+(.+?)\s*$")

def parse_heading(text: str):
    line = text.strip()
    # Try "ADDR  label  [status]"
    m = re.match(r"^(?P<addr>(?:[0-9A-F]{2}:)?[0-9A-F]{4}(?:\.\.(?:[0-9A-F]{2}:)?[0-9A-F]{4})?)\s{2,}(?P<label>.+?)(?:\s+\[(?P<qual>[^\]]+)\])?$", line)
    if m:
        return m.group('addr'), m.group('label').strip(), (m.group('qual') or '').strip()
    # Fallback: split first token if it looks like an address
    parts = line.split(None, 1)
    if len(parts) == 2 and re.match(r"^(?:[0-9A-F]{2}:)?[0-9A-F]{4}", parts[0]):
        return parts[0], parts[1].strip(), ''
    return '', line, ''

def main() -> None:
    ap = argparse.ArgumentParser(description="Export Chrono Trigger labels markdown into a starter CSV database.")
    ap.add_argument("--dir", default=".", help="Directory containing chrono_trigger_labels_pass*.md")
    ap.add_argument("--output", default="ct_label_db_starter.csv", help="Output CSV path")
    args = ap.parse_args()

    root = Path(args.dir)
    rows = []
    for path in sorted(root.iterdir()):
        m = LABEL_FILE_RE.match(path.name)
        if not m:
            continue
        pass_num = int(m.group(1))
        section = ""
        current_addr = ""
        current_label = ""
        current_qual = ""
        notes = []
        for raw in path.read_text(encoding="utf-8").splitlines():
            line = raw.rstrip()
            if line.startswith("## "):
                section = line[3:].strip()
                continue
            hm = HEADING_RE.match(line)
            if hm:
                if current_label:
                    rows.append({
                        "pass": pass_num,
                        "section": section,
                        "address_range": current_addr,
                        "label": current_label,
                        "qualifier": current_qual,
                        "notes": " ".join(n.strip('- ').strip() for n in notes if n.strip()).strip(),
                        "source_file": path.name,
                    })
                current_addr, current_label, current_qual = parse_heading(hm.group(1))
                notes = []
                continue
            if current_label and line.strip().startswith("-"):
                notes.append(line.strip())

        if current_label:
            rows.append({
                "pass": pass_num,
                "section": section,
                "address_range": current_addr,
                "label": current_label,
                "qualifier": current_qual,
                "notes": " ".join(n.strip('- ').strip() for n in notes if n.strip()).strip(),
                "source_file": path.name,
            })

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["pass","section","address_range","label","qualifier","notes","source_file"])
        writer.writeheader()
        writer.writerows(rows)

    print(f"Wrote {len(rows)} rows to {out}")

if __name__ == "__main__":
    main()
