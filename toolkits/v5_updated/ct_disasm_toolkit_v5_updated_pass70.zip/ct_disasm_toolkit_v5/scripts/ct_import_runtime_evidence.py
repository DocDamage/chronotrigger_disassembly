\
#!/usr/bin/env python3
from __future__ import annotations

import argparse, csv, json, re, sqlite3
from collections import Counter, defaultdict
from pathlib import Path

ADDR_RE = re.compile(r'(?<![0-9A-F])(?:([0-9A-F]{2}):([0-9A-F]{4})|(7E):([0-9A-F]{4})|0x([0-9A-F]{6}))(?![0-9A-F])', re.I)
CPU_HINT = re.compile(r'\b(exec|execute|jsr|jmp|jsl|call)\b', re.I)
WRITE_HINT = re.compile(r'\b(write|store|sta|stz)\b', re.I)
READ_HINT = re.compile(r'\b(read|load|lda|ldx|ldy)\b', re.I)

SCHEMA = """
CREATE TABLE IF NOT EXISTS runtime_evidence (
  id INTEGER PRIMARY KEY,
  source_file TEXT NOT NULL,
  source_kind TEXT NOT NULL,
  address TEXT NOT NULL,
  event_type TEXT NOT NULL,
  count INTEGER NOT NULL,
  notes TEXT
);
CREATE INDEX IF NOT EXISTS idx_runtime_addr ON runtime_evidence(address);
"""

def norm_addr(text: str) -> str | None:
    m = ADDR_RE.search(text)
    if not m:
        return None
    if m.group(1):
        return f"{m.group(1).upper()}:{m.group(2).upper()}"
    if m.group(3):
        return f"7E:{m.group(4).upper()}"
    raw = m.group(5).upper()
    if len(raw) == 6:
        return f"{raw[:2]}:{raw[2:]}"
    return None

def classify_event(line: str) -> str:
    if CPU_HINT.search(line):
        return 'execute'
    if WRITE_HINT.search(line):
        return 'write'
    if READ_HINT.search(line):
        return 'read'
    return 'mention'

def parse_text(path: Path):
    rows = Counter()
    notes = defaultdict(list)
    for line in path.read_text(encoding='utf-8', errors='ignore').splitlines():
        addr = norm_addr(line)
        if not addr:
            continue
        event = classify_event(line)
        rows[(addr, event)] += 1
        if len(notes[(addr, event)]) < 3:
            notes[(addr, event)].append(line.strip())
    return [(addr, event, count, ' | '.join(notes[(addr, event)])) for (addr, event), count in sorted(rows.items())]

def parse_csv(path: Path):
    out = []
    with path.open(encoding='utf-8', newline='') as f:
        for row in csv.DictReader(f):
            addr = norm_addr(row.get('address', '') or '')
            if not addr:
                continue
            event = (row.get('event_type') or 'mention').strip() or 'mention'
            count = int((row.get('count') or '1').strip() or '1')
            notes = (row.get('notes') or '').strip()
            out.append((addr, event, count, notes))
    return out

def parse_json(path: Path):
    data = json.loads(path.read_text(encoding='utf-8'))
    items = data if isinstance(data, list) else data.get('events', [])
    out = []
    for item in items:
        addr = norm_addr(str(item.get('address', '')))
        if not addr:
            continue
        event = str(item.get('event_type', 'mention'))
        count = int(item.get('count', 1))
        notes = str(item.get('notes', ''))
        out.append((addr, event, count, notes))
    return out

def ingest_file(path: Path):
    suffix = path.suffix.lower()
    if suffix == '.csv':
        return 'csv', parse_csv(path)
    if suffix == '.json':
        return 'json', parse_json(path)
    return 'text', parse_text(path)

def main() -> None:
    ap = argparse.ArgumentParser(description='Import bsnes/debugger/runtime evidence into the workspace DB and summary files.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--trace-dir', default='traces/imported')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--summary-json', default='reports/runtime/runtime_evidence_summary.json')
    ap.add_argument('--summary-md', default='reports/runtime/runtime_evidence_summary.md')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    trace_dir = root / args.trace_dir
    db_path = root / args.db
    trace_dir.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(db_path)
    cur = con.cursor()
    cur.executescript(SCHEMA)
    cur.execute('DELETE FROM runtime_evidence')
    total_rows = 0
    files_seen = []
    per_addr = Counter()
    per_event = Counter()
    for path in sorted(p for p in trace_dir.iterdir() if p.is_file() and p.name != 'README.md'):
        kind, rows = ingest_file(path)
        for addr, event, count, notes in rows:
            cur.execute('INSERT INTO runtime_evidence(source_file, source_kind, address, event_type, count, notes) VALUES (?, ?, ?, ?, ?, ?)',
                        (path.name, kind, addr, event, count, notes))
            total_rows += 1
            files_seen.append(path.name)
            per_addr[addr] += count
            per_event[event] += count
    con.commit(); con.close()
    summary = {
        'trace_files': sorted(set(files_seen)),
        'import_rows': total_rows,
        'top_addresses': per_addr.most_common(25),
        'event_type_totals': dict(per_event),
    }
    sj = root / args.summary_json; sj.parent.mkdir(parents=True, exist_ok=True)
    sj.write_text(json.dumps(summary, indent=2), encoding='utf-8')
    lines = ['# Runtime Evidence Summary', '', f'- Trace files imported: **{len(summary["trace_files"])}**', f'- Import rows: **{total_rows}**', '', '## Event totals']
    if per_event:
        for k, v in sorted(per_event.items()):
            lines.append(f'- {k}: **{v}**')
    else:
        lines.append('- none yet')
    lines += ['', '## Top addresses']
    if per_addr:
        for addr, cnt in per_addr.most_common(25):
            lines.append(f'- `{addr}` -> **{cnt}**')
    else:
        lines.append('- no runtime evidence imported yet')
    sm = root / args.summary_md; sm.parent.mkdir(parents=True, exist_ok=True)
    sm.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(sj)
    print(sm)

if __name__ == '__main__':
    main()
