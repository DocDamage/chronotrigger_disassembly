\
#!/usr/bin/env python3
from __future__ import annotations

import argparse, csv, sqlite3
from collections import defaultdict
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser(description='Detect obvious label/address/status conflicts in the current workspace.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--output-md', default='reports/ct_conflict_report.md')
    ap.add_argument('--output-csv', default='reports/conflicts/ct_conflicts.csv')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    con = sqlite3.connect(root / args.db)
    con.row_factory = sqlite3.Row
    rows = con.execute('SELECT * FROM labels ORDER BY address_start, pass_num').fetchall()
    con.close()
    by_addr = defaultdict(list)
    by_label = defaultdict(list)
    for row in rows:
        by_addr[row['address_range']].append(row)
        by_label[row['label']].append(row)
    conflicts = []
    for addr, items in by_addr.items():
        labels = sorted({r['label'] for r in items})
        if len(labels) > 1:
            conflicts.append({'type': 'address_multiple_labels', 'key': addr, 'details': ' | '.join(labels)})
    for label, items in by_label.items():
        addrs = sorted({r['address_range'] for r in items})
        if len(addrs) > 1:
            conflicts.append({'type': 'label_multiple_addresses', 'key': label, 'details': ' | '.join(addrs)})
    out_csv = root / args.output_csv
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    with out_csv.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['type', 'key', 'details'])
        w.writeheader(); w.writerows(conflicts)
    lines = ['# Conflict Report', '', f'- Total conflicts detected: **{len(conflicts)}**', '', '## Conflict list']
    if conflicts:
        for c in conflicts[:200]:
            lines.append(f"- `{c['type']}` :: **{c['key']}** :: {c['details']}")
    else:
        lines.append('- no obvious structural conflicts detected')
    lines += ['', '## Notes', '- This report is intentionally conservative. It flags likely review items, not guaranteed mistakes.', '']
    out_md = root / args.output_md
    out_md.parent.mkdir(parents=True, exist_ok=True)
    out_md.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(out_md)
    print(out_csv)

if __name__ == '__main__':
    main()
