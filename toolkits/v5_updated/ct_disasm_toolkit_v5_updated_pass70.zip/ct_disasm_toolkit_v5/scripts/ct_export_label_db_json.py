#!/usr/bin/env python3
from __future__ import annotations

import argparse, json, sqlite3
from pathlib import Path

def row_to_dict(cursor, row):
    return {col[0]: row[idx] for idx, col in enumerate(cursor.description)}

def main() -> None:
    ap = argparse.ArgumentParser(description='Export the SQLite label DB to structured JSON.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--output', default='data/ct_label_db.json')
    args = ap.parse_args()
    con = sqlite3.connect(args.db)
    con.row_factory = row_to_dict
    cur = con.cursor()
    labels = cur.execute('SELECT * FROM labels ORDER BY pass_num, address_start, label').fetchall()
    latest = cur.execute("""
        SELECT l.* FROM labels l JOIN (
            SELECT address_range, MAX(pass_num) AS max_pass FROM labels GROUP BY address_range
        ) x ON l.address_range = x.address_range AND l.pass_num = x.max_pass
        ORDER BY l.address_start, l.label
    """).fetchall()
    meta = {r['key']: r['value'] for r in cur.execute('SELECT key, value FROM meta ORDER BY key').fetchall()}
    con.close()
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({'meta': meta, 'labels': labels, 'latest_by_address_range': latest}, indent=2), encoding='utf-8')
    print(out)

if __name__ == '__main__':
    main()
