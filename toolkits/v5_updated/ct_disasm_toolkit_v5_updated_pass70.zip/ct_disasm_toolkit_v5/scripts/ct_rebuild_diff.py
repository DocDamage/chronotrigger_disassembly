#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def md5(data: bytes) -> str:
    return hashlib.md5(data).hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser(description='Build the V5 rebuild/diff report scaffold or compare a rebuilt ROM.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--rom', default=None)
    ap.add_argument('--rebuilt-rom', default='build/rebuild/chrono_trigger_rebuilt.sfc')
    ap.add_argument('--output-md', default='reports/ct_rebuild_diff_report.md')
    ap.add_argument('--output-json', default='reports/ct_rebuild_diff_report.json')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    rom_path = Path(args.rom).resolve() if args.rom else None
    rebuilt_path = (root / args.rebuilt_rom).resolve() if not Path(args.rebuilt_rom).is_absolute() else Path(args.rebuilt_rom)
    payload = {'mode': 'scaffold', 'rom': str(rom_path) if rom_path else None, 'rebuilt_rom': str(rebuilt_path)}
    lines = ['# Rebuild / Diff Report', '']
    if not rom_path or not rom_path.exists() or not rebuilt_path.exists():
        lines += [
            'Assembler-bound rebuild comparison is not available yet.',
            '',
            '## Current status',
            '- Source tree scaffold exists in `source/`.',
            '- Freeze map exists in `state/range_freeze.json`.',
            '- This report will switch to real byte-diff mode once a rebuilt ROM is supplied.',
            '',
            '## Expected next step',
            f'- Original ROM: `{rom_path}`' if rom_path else '- Original ROM: **not supplied**',
            f'- Rebuilt ROM target: `{rebuilt_path}`',
            '',
            'Run again with both ROMs present to get a real byte-difference report.'
        ]
    else:
        a = rom_path.read_bytes()
        b = rebuilt_path.read_bytes()
        payload['mode'] = 'compare'
        payload['original_size'] = len(a)
        payload['rebuilt_size'] = len(b)
        payload['original_md5'] = md5(a)
        payload['rebuilt_md5'] = md5(b)
        diffs = []
        prefix_diff_count = 0
        for i, (x, y) in enumerate(zip(a, b)):
            if x != y:
                prefix_diff_count += 1
                if len(diffs) < 200:
                    diffs.append({'offset': i, 'orig': x, 'rebuilt': y})
        payload['first_diffs'] = diffs
        payload['diff_count_prefix'] = prefix_diff_count
        if len(a) != len(b):
            payload['size_mismatch'] = True
        lines += [
            f'- Original size: **{len(a)}** bytes',
            f'- Rebuilt size: **{len(b)}** bytes',
            f'- Original MD5: `{payload["original_md5"]}`',
            f'- Rebuilt MD5: `{payload["rebuilt_md5"]}`',
            f'- Diff count across shared prefix: **{payload["diff_count_prefix"]}**',
            ''
        ]
        if diffs:
            lines.append('## First differences')
            for d in diffs[:50]:
                lines.append(f'- `0x{d["offset"]:06X}` : `{d["orig"]:02X}` -> `{d["rebuilt"]:02X}`')
        else:
            lines.append('No differences found across the shared prefix.')
    (root / args.output_md).write_text('\n'.join(lines) + '\n', encoding='utf-8')
    (root / args.output_json).write_text(json.dumps(payload, indent=2), encoding='utf-8')
    print(root / args.output_md)
    print(root / args.output_json)


if __name__ == '__main__':
    main()
