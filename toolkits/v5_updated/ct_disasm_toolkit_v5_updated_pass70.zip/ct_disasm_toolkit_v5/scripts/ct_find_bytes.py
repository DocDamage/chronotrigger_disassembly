#!/usr/bin/env python3
from __future__ import annotations

import argparse
from ct_common import RomImage, default_rom_path, fmt_pc, fmt_snes, parse_pattern, pc_to_hirom

def main() -> None:
    ap = argparse.ArgumentParser(description="Search the ROM for a byte pattern, supporting ?? wildcards.")
    ap.add_argument("pattern", help='Pattern like "22 ?? ?? C1" or "FE FF"')
    ap.add_argument("--rom", help="ROM path")
    ap.add_argument("--limit", type=int, default=200, help="Max hits to print")
    args = ap.parse_args()

    rom = RomImage.load(default_rom_path(args.rom))
    patt = parse_pattern(args.pattern)
    plen = len(patt)

    hits = []
    blob = rom.data
    for i in range(0, len(blob) - plen + 1):
        ok = True
        for j, want in enumerate(patt):
            if want is not None and blob[i+j] != want:
                ok = False
                break
        if ok:
            hits.append(i)
            if len(hits) >= args.limit:
                break

    print(f"ROM: {rom.path}")
    print(f"Pattern: {args.pattern}")
    print(f"Hits shown: {len(hits)}")
    for pc in hits:
        print(f"{fmt_snes(pc_to_hirom(pc))}  {fmt_pc(pc)}")

if __name__ == "__main__":
    main()
