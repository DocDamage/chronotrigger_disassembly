\
#!/usr/bin/env python3
from __future__ import annotations

import argparse, csv, sqlite3
from pathlib import Path


def read_csv_rows(path: Path):
    if not path.exists():
        return []
    with path.open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def main() -> None:
    ap = argparse.ArgumentParser(description='Generate evidence pages for master opcodes and important handler addresses.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--output-dir', default='evidence_pages/global_opcodes')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    out_dir = root / args.output_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(root / args.db)
    con.row_factory = sqlite3.Row
    master = read_csv_rows(root / 'data' / 'ct_c1_master_opcode_coverage_full.csv')
    for row in master:
        op = row['global_opcode_hex']
        path = out_dir / f'opcode_{op}.md'
        dispatch = (row.get('dispatch_addr') or '').strip()
        matching = []
        if dispatch:
            matching = con.execute('SELECT * FROM labels WHERE address_range LIKE ? OR label LIKE ? ORDER BY pass_num DESC', (f'%{dispatch}%', f'%opcode_{op.lower()}%')).fetchall()
        else:
            matching = con.execute('SELECT * FROM labels WHERE label LIKE ? ORDER BY pass_num DESC', (f'%opcode_{op.lower()}%',)).fetchall()
        lines = [f'# Global Opcode {op}', '', f"- Status: **{row.get('status', 'unknown')}**", f"- Dispatch address: **{dispatch or 'unresolved'}**", f"- Evidence pass: **{row.get('evidence_pass') or 'n/a'}**", f"- Notes: {row.get('notes') or 'n/a'}", '', '## Matching label evidence']
        if matching:
            for m in matching[:12]:
                lines.append(f"- pass {m['pass_num']}: `{m['address_range']}` **{m['label']}** ({m['status_bucket']})")
                if m['notes']:
                    lines.append(f"  - {m['notes']}")
        else:
            lines.append('- no direct label rows matched yet')
        path.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    con.close()
    print(out_dir)

if __name__ == '__main__':
    main()
