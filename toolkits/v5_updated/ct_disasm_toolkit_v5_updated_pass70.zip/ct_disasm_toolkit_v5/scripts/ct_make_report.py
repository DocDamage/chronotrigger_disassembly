\
#!/usr/bin/env python3
from __future__ import annotations

import argparse, csv, json, sqlite3
from pathlib import Path


def read_csv_rows(path: Path):
    if not path.exists():
        return []
    with path.open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def main() -> None:
    ap = argparse.ArgumentParser(description='Generate a workspace state report from the current toolkit data.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--output', default='reports/ct_workspace_report.md')
    ap.add_argument('--state-json', default='state/current_state.json')
    args = ap.parse_args()
    root = Path(args.root)
    con = sqlite3.connect(root / args.db)
    cur = con.cursor()
    row_count = cur.execute('SELECT COUNT(*) FROM labels').fetchone()[0]
    latest_pass = cur.execute('SELECT MAX(pass_num) FROM labels').fetchone()[0] or 0
    strong = cur.execute("SELECT COUNT(*) FROM labels WHERE status_bucket='strong'").fetchone()[0]
    provisional = cur.execute("SELECT COUNT(*) FROM labels WHERE status_bucket='provisional'").fetchone()[0]
    alias = cur.execute("SELECT COUNT(*) FROM labels WHERE status_bucket='alias'").fetchone()[0]
    caution = cur.execute("SELECT COUNT(*) FROM labels WHERE status_bucket='caution'").fetchone()[0]
    runtime_tables = {r[0] for r in cur.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    runtime_rows = cur.execute('SELECT COUNT(*) FROM runtime_evidence').fetchone()[0] if 'runtime_evidence' in runtime_tables else 0
    con.close()
    master_rows = read_csv_rows(root / 'data' / 'ct_c1_master_opcode_coverage_full.csv')
    selector_rows = read_csv_rows(root / 'data' / 'ct_c1_selector_control_coverage_full.csv')
    service7_rows = read_csv_rows(root / 'data' / 'ct_service7_wrapper_coverage_full.csv')
    xref_path = root / 'data' / 'ct_hot_xref_cache.json'
    xref_targets = 0
    if xref_path.exists():
        xref_targets = len(json.loads(xref_path.read_text(encoding='utf-8')).get('targets', {}))
    completion_path = root / 'reports' / 'completion' / 'ct_completion_score.json'
    completion = {'overall_completion_percent': 38}
    if completion_path.exists():
        completion = json.loads(completion_path.read_text(encoding='utf-8'))
    state = {
        'latest_pass': latest_pass,
        'current_live_seam': 'Early global opcode band inside C1:B80D master dispatch, with pack-fed opcode observations from pass 61.',
        'completion_estimate_percent': completion.get('overall_completion_percent', 38),
        'label_rows': row_count,
        'strong_labels': strong,
        'provisional_labels': provisional,
        'alias_labels': alias,
        'caution_labels': caution,
        'runtime_evidence_rows': runtime_rows,
        'xref_cache_targets': xref_targets,
        'rom_expected_crc32': '2D206BF7',
        'rom_expected_md5': 'a2bc447961e52fd2227baed164f729dc',
    }
    state_path = root / args.state_json; state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(json.dumps(state, indent=2), encoding='utf-8')
    lines = [
        '# Chrono Trigger Workspace Report','',
        '## Current top-of-stack',
        f"- Latest pass: **{latest_pass}**",
        f"- Current live seam: **{state['current_live_seam']}**",
        f"- Completion estimate: **~{state['completion_estimate_percent']}%**",'',
        '## Label database',
        f"- Total label rows: **{row_count}**",
        f"- Strong: **{strong}**",
        f"- Provisional: **{provisional}**",
        f"- Alias: **{alias}**",
        f"- Caution: **{caution}**",
        f"- Runtime evidence rows: **{runtime_rows}**",'',
        '## Coverage worksheets',
        f"- Master C1 global opcode worksheet rows: **{len(master_rows)}**",
        f"- Selector-control worksheet rows: **{len(selector_rows)}**",
        f"- Service-7 wrapper worksheet rows: **{len(service7_rows)}**",'',
        '## Xref cache', f"- Hot targets cached: **{xref_targets}**",'',
        '## v4 generated artifacts',
        '- `reports/ct_completion_score.md`',
        '- `reports/ct_conflict_report.md`',
        '- `reports/code_data_score.md`',
        '- `graph/ct_knowledge_graph_summary.md`',
        '- `dossiers/C1_dossier.md`',
        '- `asm_skeleton/banks/`', '',
        '## Immediate next work',
        '1. Re-read the community context note before doing new naming work.',
        '2. Re-open the pass 59–61 late-pack/master-dispatch seam.',
        '3. Continue the early global opcode band inside `C1:B80D..C1:B95F`.',
        '4. Import runtime evidence when static ownership proof stalls.', '',
        '## Still required for full disassembly',
        '- Complete bank-by-bank code/data separation',
        '- Finish global opcode and VM coverage',
        '- Finish decompressor grammar / format work',
        '- Freeze subsystem ownership boundaries across banks',
        '- Build a rebuildable source tree and validate against ROM fingerprints',
        ''
    ]
    out = root / args.output; out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text('\n'.join(lines), encoding='utf-8')
    print(out); print(state_path)

if __name__ == '__main__':
    main()
