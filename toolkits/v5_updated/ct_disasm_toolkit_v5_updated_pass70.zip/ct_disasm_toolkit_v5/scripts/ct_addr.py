#!/usr/bin/env python3
from __future__ import annotations

import argparse
from ct_common import default_rom_path, fmt_pc, fmt_snes, hirom_to_pc, parse_snes_addr, pc_to_hirom, RomImage

def main() -> None:
    ap = argparse.ArgumentParser(description="Convert Chrono Trigger HiROM SNES addresses to PC offsets and back.")
    ap.add_argument("address", help="Address like C1:B80D, C1B80D, 0x31B80D, or a PC offset with --mode pc-to-snes")
    ap.add_argument("--mode", choices=["snes-to-pc", "pc-to-snes"], default="snes-to-pc")
    ap.add_argument("--rom", help="ROM path for range validation")
    args = ap.parse_args()

    rom = None
    rom_path = default_rom_path(args.rom)
    if rom_path.exists():
        rom = RomImage.load(rom_path)

    if args.mode == "snes-to-pc":
        snes = parse_snes_addr(args.address)
        pc = hirom_to_pc(snes, rom.size if rom else None)
        print(f"SNES: {fmt_snes(snes)}")
        print(f"PC:   {fmt_pc(pc)}")
    else:
        pc = int(args.address, 0)
        snes = pc_to_hirom(pc)
        print(f"PC:   {fmt_pc(pc)}")
        print(f"SNES: {fmt_snes(snes)}")

if __name__ == "__main__":
    main()
