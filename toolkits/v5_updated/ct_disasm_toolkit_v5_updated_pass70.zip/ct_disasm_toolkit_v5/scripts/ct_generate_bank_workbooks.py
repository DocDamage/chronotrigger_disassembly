#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

BANKS = {
    'C1': {
        'title': 'Primary control / opcode / selector / service bank',
        'current_state': 'Strongest live area. Master global opcode dispatch at B80D..B95F, selector-control dispatch at AC14/AC2E, service-7 wrapper/query stack, tail replay/controller layer, panel/tilemap builders, and many late control helpers.',
        'next_targets': ['Early global opcode band inside B80D master dispatch', 'Observed pack-fed global opcodes from pass 61', 'Late pack executor sub-ops and downstream consumers'],
        'anchor_addrs': ['C1:B80D','C1:B85F','C1:B88D','C1:B8BB','C1:AC14','C1:AFD7','C1:8C0A'],
    },
    'FD': {
        'title': 'Readiness / normalization / occupancy support bank',
        'current_state': 'Strongly advanced. Seed math, normalization, head/tail occupancy maps, and several battle-facing helpers are structurally pinned.',
        'next_targets': ['Remaining owner paths around occupant withholding/materialization support', 'Cross-check helper families against late executor use'],
        'anchor_addrs': ['FD:B24D','FD:B2A3','FD:B4E0','FD:B820','FD:B8F7','FD:AB01'],
    },
    'CC': {
        'title': 'Descriptor / pointer / table bank',
        'current_state': 'Heavily used as data substrate. Many table families are known, but not all semantic owners are frozen.',
        'next_targets': ['Continue exact semantics of late selector pointer-record tables', 'Tighten config-page / descriptor / lane-anchor table ownership'],
        'anchor_addrs': ['CC:2AB0','CC:2E31','CC:8B08','CC:FA23','CC:FA29','CC:FADD','CC:F903'],
    },
    'CF': {
        'title': 'DMA / upload support bank',
        'current_state': 'Key upload proof exists for 0B40 -> VRAM 7A00, but the whole bank is not mapped.',
        'next_targets': ['Map additional consumers of 0B40/0CC0/0E80 products', 'Separate generic DMA helpers from panel-specific callers'],
        'anchor_addrs': ['CF:[0B40 upload path]'],
    },
    'C0': {
        'title': 'Downstream consumer / parallel source plane',
        'current_state': 'Consumer-side proof exists for 0E80 and related panel outputs, but the bank is not deeply split.',
        'next_targets': ['Consumer paths around A2B0..A335', 'Parallel source-plane ownership vs panel-facing presentation'],
        'anchor_addrs': ['C0:A2B0','C0:A335'],
    },
    'D1': {
        'title': 'Template / strip source bank',
        'current_state': 'Three strip/tilemap template families are pinned as sources, but variant-selection context is still incomplete.',
        'next_targets': ['Caller-side selection of 5800 / 5A50 / 5BD0', 'Additional template families for companion strips and records'],
        'anchor_addrs': ['D1:5800','D1:59FC','D1:5A50','D1:5BD0'],
    },
}
TEMPLATE = """# Bank {bank} Workbook

## Bank role
{title}

## Current state
{current_state}

## Anchor addresses
{anchors}

## Evidence log
- add exact pass references, byte dumps, and caller/callee relationships here

## Strong labels already tied to this bank
- fill from report / label DB during active work

## Provisional or caution labels
- keep the dangerous guesses here until promoted or killed

## Next targets
{next_targets}

## Open questions
- 
"""

def main() -> None:
    ap = argparse.ArgumentParser(description='Generate bank workbook markdown and CSV logs.')
    ap.add_argument('--output-dir', default='bank_workbooks')
    args = ap.parse_args()
    outdir = Path(args.output_dir); outdir.mkdir(parents=True, exist_ok=True)
    index_lines = ['# Bank Workbook Index','']
    for bank, info in BANKS.items():
        md = outdir / f'{bank}_workbook.md'
        csv_path = outdir / f'{bank}_evidence_log.csv'
        anchors = '\n'.join(f'- `{a}`' for a in info['anchor_addrs'])
        next_targets = '\n'.join(f'- {x}' for x in info['next_targets'])
        md.write_text(TEMPLATE.format(bank=bank, title=info['title'], current_state=info['current_state'], anchors=anchors, next_targets=next_targets), encoding='utf-8')
        csv_path.write_text('address_or_range,label,status,evidence_pass,notes\n', encoding='utf-8')
        index_lines.append(f'- [{bank} workbook]({md.name})')
    (outdir / 'README.md').write_text('\n'.join(index_lines) + '\n', encoding='utf-8')
    print(outdir)

if __name__ == '__main__':
    main()
