\
#!/usr/bin/env python3
from __future__ import annotations

import argparse, csv, json, sqlite3
from collections import defaultdict
from pathlib import Path


def read_csv_rows(path: Path):
    if not path.exists():
        return []
    with path.open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def bank_of(addr_start):
    if addr_start is None:
        return None
    if addr_start > 0xFFFF:
        return f"{(addr_start >> 16) & 0xFF:02X}"
    return f"{(addr_start >> 16) & 0xFF:02X}" if addr_start > 0xFFFFFF else None


def main() -> None:
    ap = argparse.ArgumentParser(description='Build a lightweight knowledge graph from labels, coverage sheets, and runtime evidence.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--output-json', default='graph/ct_knowledge_graph.json')
    ap.add_argument('--summary-md', default='graph/ct_knowledge_graph_summary.md')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    con = sqlite3.connect(root / args.db)
    con.row_factory = sqlite3.Row
    labels = con.execute('SELECT * FROM labels ORDER BY pass_num, address_start, label').fetchall()
    runtime_tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    runtime = []
    if 'runtime_evidence' in runtime_tables:
        runtime = con.execute('SELECT address, event_type, SUM(count) AS total FROM runtime_evidence GROUP BY address, event_type ORDER BY total DESC').fetchall()
    con.close()

    nodes = []
    edges = []
    seen = set()

    def add_node(node_id, kind, **attrs):
        if node_id in seen:
            return
        seen.add(node_id)
        d = {'id': node_id, 'kind': kind}
        d.update(attrs)
        nodes.append(d)

    bank_members = defaultdict(int)
    for row in labels:
        lid = f"label:{row['label']}:{row['pass_num']}:{row['address_range']}"
        bank = bank_of(row['address_start'])
        add_node(lid, 'label', label=row['label'], pass_num=row['pass_num'], address=row['address_range'], status=row['status_bucket'])
        add_node(f"pass:{row['pass_num']}", 'pass', pass_num=row['pass_num'])
        edges.append({'from': f"pass:{row['pass_num']}", 'to': lid, 'kind': 'introduced_or_reinforced'})
        if bank:
            add_node(f"bank:{bank}", 'bank', bank=bank)
            edges.append({'from': f"bank:{bank}", 'to': lid, 'kind': 'contains'})
            bank_members[bank] += 1

    master = read_csv_rows(root / 'data' / 'ct_c1_master_opcode_coverage_full.csv')
    for row in master:
        op = row['global_opcode_hex']
        oid = f'opcode:c1:{op}'
        add_node(oid, 'opcode', opcode=op, slice=row.get('slice', ''), status=row.get('status', 'unknown'))
        dispatch = (row.get('dispatch_addr') or '').strip()
        if dispatch:
            aid = f'addr:{dispatch}'
            add_node(aid, 'address', address=dispatch)
            edges.append({'from': oid, 'to': aid, 'kind': 'dispatches_to'})

    for row in runtime:
        addr = row['address']
        aid = f'addr:{addr}'
        add_node(aid, 'address', address=addr)
        rid = f'runtime:{addr}:{row["event_type"]}'
        add_node(rid, 'runtime_event', address=addr, event_type=row['event_type'], count=row['total'])
        edges.append({'from': rid, 'to': aid, 'kind': 'confirms'})

    graph = {'nodes': nodes, 'edges': edges}
    out = root / args.output_json; out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(graph, indent=2), encoding='utf-8')

    lines = ['# Knowledge Graph Summary', '', f'- Nodes: **{len(nodes)}**', f'- Edges: **{len(edges)}**', '']
    lines += ['## Bank coverage from label graph']
    for bank, count in sorted(bank_members.items(), key=lambda kv: (-kv[1], kv[0])):
        lines.append(f'- `{bank}` -> **{count}** label-linked nodes')
    lines += ['', '## Runtime-confirmed addresses']
    rt_any = False
    for row in runtime[:25]:
        rt_any = True
        lines.append(f"- `{row['address']}` [{row['event_type']}] -> **{row['total']}**")
    if not rt_any:
        lines.append('- none yet')
    lines += ['', '## Strong current graph take', '- The graph is now good enough to tie pass evidence, bank ownership, master opcode coverage, and imported runtime proof together in one place.', '']
    sm = root / args.summary_md
    sm.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(out)
    print(sm)

if __name__ == '__main__':
    main()
