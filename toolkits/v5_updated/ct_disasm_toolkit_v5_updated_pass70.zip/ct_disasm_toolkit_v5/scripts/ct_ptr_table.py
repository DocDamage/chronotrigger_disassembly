#!/usr/bin/env python3
from __future__ import annotations

import argparse
from ct_common import RomImage, default_rom_path, fmt_pc, fmt_snes, hirom_to_pc, parse_int, parse_snes_addr, pc_to_hirom

def main() -> None:
    ap = argparse.ArgumentParser(description="Inspect pointer tables in the Chrono Trigger ROM.")
    ap.add_argument("start", help="SNES start address")
    ap.add_argument("--count", required=True, help="Number of entries")
    ap.add_argument("--kind", choices=["local16", "long24"], default="local16")
    ap.add_argument("--bank", help="Required for local16 if not implied by start address; e.g. C1")
    ap.add_argument("--rom", help="ROM path")
    args = ap.parse_args()

    rom = RomImage.load(default_rom_path(args.rom))
    start_snes = parse_snes_addr(args.start)
    start_pc = hirom_to_pc(start_snes, rom.size)
    count = parse_int(args.count)
    bank = int(args.bank, 16) if args.bank else ((start_snes >> 16) & 0xFF)

    step = 2 if args.kind == "local16" else 3
    blob = rom.data[start_pc:start_pc + (count * step)]

    print(f"ROM: {rom.path}")
    print(f"Table: {fmt_snes(start_snes)} / {fmt_pc(start_pc)}")
    print(f"Kind: {args.kind}")
    print()

    for i in range(count):
        off = i * step
        entry_pc = start_pc + off
        entry_snes = pc_to_hirom(entry_pc)
        if args.kind == "local16":
            ptr = blob[off] | (blob[off+1] << 8)
            target = (bank << 16) | ptr
            extra = ""
            if ptr >= 0x8000:
                try:
                    extra = f" -> {fmt_pc(hirom_to_pc(target, rom.size))}"
                except Exception:
                    extra = " -> [unmapped]"
            print(f"[{i:02d}] {fmt_snes(entry_snes)}  {ptr:04X} -> {fmt_snes(target)}{extra}")
        else:
            ptr = blob[off] | (blob[off+1] << 8) | (blob[off+2] << 16)
            extra = ""
            try:
                extra = f" -> {fmt_pc(hirom_to_pc(ptr, rom.size))}"
            except Exception:
                extra = " -> [unmapped]"
            print(f"[{i:02d}] {fmt_snes(entry_snes)}  {ptr:06X} -> {fmt_snes(ptr)}{extra}")

if __name__ == "__main__":
    main()
