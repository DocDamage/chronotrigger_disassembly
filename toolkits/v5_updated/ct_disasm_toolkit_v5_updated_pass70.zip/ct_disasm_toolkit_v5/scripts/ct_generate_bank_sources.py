#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import sqlite3
from collections import defaultdict
from pathlib import Path

STATUS_RANK = {'strong': 4, 'alias': 3, 'caution': 2, 'provisional': 1, 'unspecified': 0}


def fmt_addr(addr: int) -> str:
    return f"{(addr >> 16) & 0xFF:02X}:{addr & 0xFFFF:04X}"


def bank_name(bank: int) -> str:
    if bank in (0x7E, 0x7F):
        return f"wram_{bank:02X}"
    return f"bank_{bank:02X}"


def sanitize(text: str) -> str:
    text = re.sub(r'[^0-9A-Za-z]+', '_', text).strip('_')
    text = re.sub(r'_+', '_', text)
    if not text:
        text = 'UNNAMED'
    if text[0].isdigit():
        text = 'L_' + text
    return text[:96]


def symbol_name(addr: int, label: str, seen: dict[str, int]) -> str:
    base = sanitize(f"{fmt_addr(addr).replace(':', '_')}__{label}")
    n = seen.get(base, 0)
    seen[base] = n + 1
    return base if n == 0 else f"{base}_{n+1}"


def load_rows(db_path: Path):
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    rows = con.execute(
        """
        SELECT pass_num, address_range, address_start, address_end, address_kind,
               label, qualifier, status_bucket, notes, source_file
        FROM labels
        WHERE address_start IS NOT NULL
        ORDER BY address_start, pass_num, label
        """
    ).fetchall()
    con.close()
    latest = {}
    for r in rows:
        key = (r['address_range'], r['label'])
        if key not in latest or r['pass_num'] >= latest[key]['pass_num']:
            latest[key] = dict(r)
    return sorted(latest.values(), key=lambda r: (r['address_start'], r['pass_num'], r['label']))


def write_bank_file(path: Path, bank: int, rows: list[dict]) -> dict:
    groups = defaultdict(list)
    for r in rows:
        groups[r['address_start']].append(r)
    lines = [
        '; -----------------------------------------------------------------------------',
        f'; AUTO-GENERATED Chrono Trigger V5 source scaffold :: {bank_name(bank)}',
        '; This file is intentionally assembler-neutral scaffolding.',
        '; Labels, provenance, notes, and confidence are preserved from the evidence DB.',
        '; TODO blocks remain until byte-accurate reconstruction exists.',
        '; -----------------------------------------------------------------------------',
        '',
    ]
    symbol_seen: dict[str, int] = {}
    symbol_lines: list[str] = []
    manifest_rows: list[dict] = []
    for addr in sorted(groups):
        bucket = sorted(groups[addr], key=lambda r: (STATUS_RANK.get(r['status_bucket'], 0), r['pass_num']), reverse=True)
        top = bucket[0]
        lines += [
            '; =============================================================================',
            f'; {fmt_addr(addr)}  top-status={top["status_bucket"]}  labels={len(bucket)}',
            '; =============================================================================',
        ]
        for r in bucket:
            sym = symbol_name(addr, r['label'], symbol_seen)
            symbol_lines.append(f'{sym} = ${addr:06X}')
            lines.append(f'; [{r["status_bucket"]}] pass {r["pass_num"]} :: {r["label"]}')
            if r['qualifier']:
                lines.append(f'; qualifier: {r["qualifier"]}')
            if r['notes']:
                lines.append(f'; notes: {r["notes"]}')
            lines.append(f'; source: {r["source_file"]}')
            lines.append(f'{sym}:')
            lines.append(f'    ; TODO: reconstruct body / data for {fmt_addr(addr)}')
            if normalize_end(addr, r['address_end']) != addr:
                lines.append(f'    ; known span hint: {fmt_addr(addr)}..{fmt_addr(normalize_end(addr, r['address_end']))}')
            lines.append('')
            manifest_rows.append({
                'bank': f'{bank:02X}',
                'address': fmt_addr(addr),
                'status': r['status_bucket'],
                'pass_num': r['pass_num'],
                'label': r['label'],
                'symbol': sym,
                'source_file': r['source_file'],
            })
    path.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return {'symbols': symbol_lines, 'manifest_rows': manifest_rows, 'address_groups': len(groups), 'row_count': len(rows)}



def normalize_end(start: int, end: int | None) -> int:
    if end is None:
        return start
    if end < start and end < 0x10000 and start > 0xFFFF:
        return (start & 0xFF0000) | end
    return end


def main() -> None:
    ap = argparse.ArgumentParser(description='Generate V5 source workspace scaffolds from the label DB.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--output-dir', default='source')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    db_path = root / args.db
    out = root / args.output_dir
    banks_dir = out / 'banks'
    includes_dir = out / 'includes'
    meta_dir = out / 'meta'
    ranges_dir = out / 'ranges'
    for d in (banks_dir, includes_dir, meta_dir, ranges_dir):
        d.mkdir(parents=True, exist_ok=True)
    rows = load_rows(db_path)
    banks = defaultdict(list)
    for r in rows:
        bank = (r['address_start'] >> 16) & 0xFF
        banks[bank].append(r)
    all_symbols: list[str] = []
    manifest = {'banks': {}, 'total_rows': len(rows), 'generated_from': str(db_path)}
    source_index = ['# Source State Index', '', 'Generated from the persistent label DB.', '']
    for bank in sorted(banks):
        stem = bank_name(bank)
        bank_file = banks_dir / f'{stem}.asm'
        result = write_bank_file(bank_file, bank, banks[bank])
        all_symbols.extend(result['symbols'])
        manifest['banks'][f'{bank:02X}'] = {
            'file': str(bank_file.relative_to(root)),
            'address_groups': result['address_groups'],
            'rows': result['row_count'],
        }
        source_index.append(f'## {bank:02X}')
        source_index.append(f'- File: `{bank_file.relative_to(root)}`')
        source_index.append(f'- Address groups: **{result["address_groups"]}**')
        source_index.append(f'- Rows: **{result["row_count"]}**')
        source_index.append('')
        csv_lines = ['bank,address,status,pass_num,label,symbol,source_file']
        for row in result['manifest_rows']:
            csv_lines.append(','.join([
                row['bank'], row['address'], row['status'], str(row['pass_num']),
                '"' + row['label'].replace('"', '""') + '"', row['symbol'], row['source_file']
            ]))
        (ranges_dir / f'{stem}_ranges.csv').write_text('\n'.join(csv_lines) + '\n', encoding='utf-8')
    (includes_dir / 'all_symbols.inc').write_text('; AUTO-GENERATED symbol include\n' + '\n'.join(all_symbols) + '\n', encoding='utf-8')
    (meta_dir / 'source_manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    (meta_dir / 'source_index.md').write_text('\n'.join(source_index) + '\n', encoding='utf-8')
    (out / 'README.md').write_text(
        '# Generated Source Workspace\n\n'
        'This tree is the V5 source-maintenance layer. It is intentionally scaffold-first and assembler-neutral.\n\n'
        '- `banks/` contains per-bank source scaffolds\n'
        '- `includes/all_symbols.inc` contains generated symbol assignments\n'
        '- `meta/source_manifest.json` contains a machine-readable summary\n'
        '- `ranges/` contains per-bank CSV indexes\n',
        encoding='utf-8'
    )
    print(out)


if __name__ == '__main__':
    main()
