\
#!/usr/bin/env python3
from __future__ import annotations

import argparse, sqlite3
from collections import Counter
from pathlib import Path

BANKS = ['C1', 'FD', 'CC', 'CF', 'C0', 'D1']


def bank_of(addr_start):
    if addr_start is None:
        return None
    if addr_start > 0xFFFF:
        return f"{(addr_start >> 16) & 0xFF:02X}"
    return None


def main() -> None:
    ap = argparse.ArgumentParser(description='Generate per-bank dossiers from the persistent label DB.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--output-dir', default='dossiers')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    out_dir = root / args.output_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(root / args.db)
    con.row_factory = sqlite3.Row
    rows = con.execute('SELECT * FROM labels ORDER BY pass_num, address_start, label').fetchall()
    con.close()
    grouped = {b: [] for b in BANKS}
    for row in rows:
        bank = bank_of(row['address_start'])
        if bank in grouped:
            grouped[bank].append(row)
    for bank in BANKS:
        items = grouped[bank]
        status = Counter(r['status_bucket'] for r in items)
        latest = max((r['pass_num'] for r in items), default=0)
        lines = [f'# Bank {bank} Dossier', '', f'- Label rows: **{len(items)}**', f'- Latest pass touching bank: **{latest}**', '']
        lines += ['## Status mix']
        for k, v in sorted(status.items()):
            lines.append(f'- {k}: **{v}**')
        lines += ['', '## Top labels carried in this bank']
        for row in items[:25]:
            lines.append(f"- `{row['address_range']}`  **{row['label']}**  ({row['status_bucket']}, pass {row['pass_num']})")
        lines += ['', '## Highest-value open work']
        if bank == 'C1':
            lines += [
                '- early global opcode band inside `C1:B80D..C1:B95F`',
                '- resume conditions between opcode slices',
                '- unresolved handler semantics above the proved late-pack/master-dispatch seam',
            ]
        elif bank == 'FD':
            lines += [
                '- deeper ownership around readiness/timer normalization and seeding families',
                '- decompressor/data-format work remains outside the currently solved timer and lane helpers',
            ]
        elif bank == 'CC':
            lines += ['- freeze more table ownership and table family semantics so fewer entries remain generic descriptors']
        else:
            lines += ['- continue separating hard proof from architecture wording; current bank coverage is still partial']
        lines += ['', '## Notes', '- Generated from the persistent label DB. Use this as the fast bank-local briefing before reopening pass notes.', '']
        (out_dir / f'{bank}_dossier.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(out_dir)

if __name__ == '__main__':
    main()
