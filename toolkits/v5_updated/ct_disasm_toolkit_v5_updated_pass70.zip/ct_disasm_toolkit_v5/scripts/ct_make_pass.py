#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
from pathlib import Path

PASS_RE = re.compile(r"chrono_trigger_disasm_pass(\d+)\.md$")
LABEL_RE = re.compile(r"chrono_trigger_labels_pass(\d+)\.md$")

PASS_TEMPLATE = """# Chrono Trigger Disassembly — Pass {n}

## Scope
- fill this in

## Starting point
- previous top-of-stack:
- current target seam:

## Work performed
- 

## Findings
- 

## Strong labels / semantics added
- 

## Corrections made this pass
- 

## Still unresolved
- 

## Next recommended target
- 
"""

LABEL_TEMPLATE = """# Chrono Trigger Labels — Pass {n}

## Strong labels
- 

## Provisional labels
- 

## Alias / wrapper / caution labels
- 
"""

def main() -> None:
    ap = argparse.ArgumentParser(description="Create the next disassembly pass + labels markdown files.")
    ap.add_argument("--dir", default=".", help="Working directory with pass files")
    args = ap.parse_args()

    root = Path(args.dir)
    nums = []
    for p in root.iterdir():
        m = PASS_RE.match(p.name)
        if m:
            nums.append(int(m.group(1)))
    next_n = (max(nums) + 1) if nums else 1

    pass_path = root / f"chrono_trigger_disasm_pass{next_n}.md"
    label_path = root / f"chrono_trigger_labels_pass{next_n}.md"

    pass_path.write_text(PASS_TEMPLATE.format(n=next_n), encoding="utf-8")
    label_path.write_text(LABEL_TEMPLATE.format(n=next_n), encoding="utf-8")

    print(pass_path)
    print(label_path)

if __name__ == "__main__":
    main()
