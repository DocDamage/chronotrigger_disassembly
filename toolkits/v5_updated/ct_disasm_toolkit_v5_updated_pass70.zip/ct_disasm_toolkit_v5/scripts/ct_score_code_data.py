\
#!/usr/bin/env python3
from __future__ import annotations

import argparse, json, sqlite3
from collections import defaultdict
from pathlib import Path
from ct_common import RomImage, default_rom_path, hirom_to_pc, pc_to_hirom

LIKELY_BRANCH = {0x20, 0x22, 0x4C, 0x6C, 0x7C, 0x60, 0x6B, 0x80, 0x82, 0x90, 0xB0, 0xF0, 0xD0, 0x10, 0x30, 0x50, 0x70}


def bank_of(addr_start):
    if addr_start is None or addr_start <= 0xFFFF:
        return None
    return (addr_start >> 16) & 0xFF


def main() -> None:
    ap = argparse.ArgumentParser(description='Heuristic code/data scoring for known hot banks/ranges.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--rom', default=None)
    ap.add_argument('--output-json', default='reports/code_data_score.json')
    ap.add_argument('--output-md', default='reports/code_data_score.md')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    db = sqlite3.connect(root / args.db)
    db.row_factory = sqlite3.Row
    rows = db.execute('SELECT * FROM labels WHERE address_start IS NOT NULL ORDER BY address_start').fetchall()
    db.close()
    rom_path = default_rom_path(args.rom)
    results = {}
    try:
        rom = RomImage.load(rom_path)
    except FileNotFoundError:
        rom = None
    grouped = defaultdict(list)
    for row in rows:
        b = bank_of(row['address_start'])
        if b is not None:
            grouped[b].append(row)
    summary_lines = ['# Code/Data Scoring', '']
    if rom is None:
        summary_lines += ['- ROM not found locally while generating this report.', '- Place the ROM beside the toolkit and rerun the resume/bootstrap command for heuristic scoring.', '']
    for bank, items in sorted(grouped.items()):
        windows = defaultdict(lambda: {'labels': 0, 'strong': 0, 'hits': 0, 'bytes': []})
        for row in items:
            win = (row['address_start'] & 0xFFFF) // 0x100
            windows[win]['labels'] += 1
            if row['status_bucket'] == 'strong':
                windows[win]['strong'] += 1
            if rom is not None:
                try:
                    pc = hirom_to_pc(row['address_start'], rom.size)
                    blob = rom.data[pc:pc+16]
                    windows[win]['bytes'].extend(blob)
                except Exception:
                    pass
        scored = []
        for win, data in windows.items():
            score = data['strong'] * 2 + data['labels']
            if data['bytes']:
                score += sum(1 for b in data['bytes'] if b in LIKELY_BRANCH)
            klass = 'mixed'
            if score >= 10:
                klass = 'likely_code'
            elif score <= 3:
                klass = 'likely_data'
            scored.append({'window_hex': f'{win:02X}00-{win:02X}FF', 'score': score, 'class': klass, 'label_rows': data['labels'], 'strong_rows': data['strong']})
        results[f'{bank:02X}'] = sorted(scored, key=lambda d: (-d['score'], d['window_hex']))[:20]
        summary_lines.append(f'## Bank {bank:02X}')
        for row in results[f'{bank:02X}'][:10]:
            summary_lines.append(f"- `{row['window_hex']}` -> **{row['class']}** (score {row['score']}, labels {row['label_rows']}, strong {row['strong_rows']})")
        summary_lines.append('')
    (root / args.output_json).write_text(json.dumps(results, indent=2), encoding='utf-8')
    (root / args.output_md).write_text('\n'.join(summary_lines) + '\n', encoding='utf-8')
    print(root / args.output_json)
    print(root / args.output_md)

if __name__ == '__main__':
    main()
