#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
from pathlib import Path

LABEL_RE = re.compile(r"chrono_trigger_labels_pass(\d+)\.md$")

def main() -> None:
    ap = argparse.ArgumentParser(description="Merge Chrono Trigger label markdown files into one consolidated file.")
    ap.add_argument("--dir", default=".", help="Working directory")
    ap.add_argument("--output", default="chrono_trigger_labels_merged.md", help="Output markdown file")
    args = ap.parse_args()

    root = Path(args.dir)
    files = sorted((int(m.group(1)), p) for p in root.iterdir() if (m := LABEL_RE.match(p.name)))

    out = [f"# Chrono Trigger Labels — Merged\n"]
    out.append(f"Merged from {len(files)} pass label files.\n")

    for n, path in files:
        out.append(f"\n---\n\n## Pass {n}\n")
        out.append(path.read_text(encoding="utf-8"))

    out_path = root / args.output
    out_path.write_text("\n".join(out), encoding="utf-8")
    print(out_path)

if __name__ == "__main__":
    main()
