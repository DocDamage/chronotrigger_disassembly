#!/usr/bin/env python3
from __future__ import annotations

import re
from pathlib import Path

LABEL_FILE_RE = re.compile(r"chrono_trigger_labels_pass(\d+)\.md$")
HEADING_RE = re.compile(r"^###\s+(.+?)\s*$")
ADDR_TOKEN_RE = re.compile(r"(?:[0-9A-F]{2}:)?[0-9A-F]{4,6}", re.IGNORECASE)

def parse_heading(text: str):
    line = text.strip()
    m = re.match(r"^(?P<addr>(?:[0-9A-F]{2}:)?[0-9A-F]{4}(?:\.\.(?:[0-9A-F]{2}:)?[0-9A-F]{4})?)\s{2,}(?P<label>.+?)(?:\s+\[(?P<qual>[^\]]+)\])?$", line)
    if m:
        return m.group('addr'), m.group('label').strip(), (m.group('qual') or '').strip()
    parts = line.split(None, 1)
    if len(parts) == 2 and re.match(r"^(?:[0-9A-F]{2}:)?[0-9A-F]{4}", parts[0]):
        return parts[0], parts[1].strip(), ''
    return '', line, ''

def normalize_status(section: str, qualifier: str) -> str:
    text = f"{section} {qualifier}".lower()
    if 'strong' in text:
        return 'strong'
    if 'provisional' in text or 'tentative' in text:
        return 'provisional'
    if 'alias' in text or 'wrapper' in text:
        return 'alias'
    if 'caution' in text:
        return 'caution'
    return 'unspecified'

def _addr_token_to_int(tok: str):
    tok = tok.replace(':', '')
    try:
        return int(tok, 16)
    except ValueError:
        return None

def parse_address_range(addr: str):
    if not addr:
        return None, None, ''
    tokens = [_addr_token_to_int(t) for t in ADDR_TOKEN_RE.findall(addr)]
    tokens = [t for t in tokens if t is not None]
    if not tokens:
        return None, None, ''
    if '..' in addr and len(tokens) >= 2:
        return tokens[0], tokens[-1], 'range'
    if len(tokens) >= 2:
        return tokens[0], tokens[-1], 'composite'
    return tokens[0], tokens[0], 'single'

def iter_label_rows(root: Path):
    for path in sorted(root.iterdir()):
        m = LABEL_FILE_RE.match(path.name)
        if not m:
            continue
        pass_num = int(m.group(1))
        section = ''
        current_addr = ''
        current_label = ''
        current_qual = ''
        notes = []
        for raw in path.read_text(encoding='utf-8').splitlines():
            line = raw.rstrip()
            if line.startswith('## '):
                section = line[3:].strip()
                continue
            hm = HEADING_RE.match(line)
            if hm:
                if current_label and current_addr:
                    addr_start, addr_end, addr_kind = parse_address_range(current_addr)
                    yield {
                        'pass_num': pass_num,
                        'section': section,
                        'address_range': current_addr,
                        'address_start': addr_start,
                        'address_end': addr_end,
                        'address_kind': addr_kind,
                        'label': current_label,
                        'qualifier': current_qual,
                        'status_bucket': normalize_status(section, current_qual),
                        'notes': ' '.join(n.strip('- ').strip() for n in notes if n.strip()).strip(),
                        'source_file': path.name,
                    }
                current_addr, current_label, current_qual = parse_heading(hm.group(1))
                notes = []
                continue
            if current_label and line.strip().startswith('-'):
                notes.append(line.strip())
        if current_label and current_addr:
            addr_start, addr_end, addr_kind = parse_address_range(current_addr)
            yield {
                'pass_num': pass_num,
                'section': section,
                'address_range': current_addr,
                'address_start': addr_start,
                'address_end': addr_end,
                'address_kind': addr_kind,
                'label': current_label,
                'qualifier': current_qual,
                'status_bucket': normalize_status(section, current_qual),
                'notes': ' '.join(n.strip('- ').strip() for n in notes if n.strip()).strip(),
                'source_file': path.name,
            }
