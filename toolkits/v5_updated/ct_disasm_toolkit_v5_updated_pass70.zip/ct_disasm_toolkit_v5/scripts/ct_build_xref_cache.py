#!/usr/bin/env python3
from __future__ import annotations

import argparse, json
from pathlib import Path
from ct_common import RomImage, default_rom_path, fmt_pc, fmt_snes, parse_snes_addr, pc_to_hirom

OP_NAMES = {0x20: 'JSR abs', 0x22: 'JSL long', 0x4C: 'JMP abs', 0x5C: 'JMP long', 0xFC: 'JSR (abs,X)'}

def iter_calls(blob: bytes, target: int):
    tgt_bank = (target >> 16) & 0xFF
    tgt_word = target & 0xFFFF
    lo = tgt_word & 0xFF; hi = (tgt_word >> 8) & 0xFF
    for i in range(len(blob) - 3):
        op = blob[i]
        if op in {0x20, 0x4C, 0xFC} and blob[i+1] == lo and blob[i+2] == hi:
            yield (i, 'bank-local', OP_NAMES.get(op, hex(op)))
        if op in {0x22, 0x5C} and i + 3 < len(blob):
            if blob[i+1] == lo and blob[i+2] == hi and blob[i+3] == tgt_bank:
                yield (i, 'long', OP_NAMES.get(op, hex(op)))

def iter_word_refs(blob: bytes, target: int):
    tgt_word = target & 0xFFFF
    lo = tgt_word & 0xFF; hi = (tgt_word >> 8) & 0xFF
    for i in range(len(blob) - 1):
        if blob[i] == lo and blob[i+1] == hi:
            yield i

def iter_raw_refs(blob: bytes, target: int):
    b0 = target & 0xFF; b1 = (target >> 8) & 0xFF; b2 = (target >> 16) & 0xFF
    for i in range(len(blob) - 2):
        if blob[i] == b0 and blob[i+1] == b1 and blob[i+2] == b2:
            yield i

def main() -> None:
    ap = argparse.ArgumentParser(description='Build a JSON xref cache for a target list.')
    ap.add_argument('--targets', default='targets/hot_xref_targets.txt')
    ap.add_argument('--rom')
    ap.add_argument('--output', default='data/ct_hot_xref_cache.json')
    args = ap.parse_args()
    rom = RomImage.load(default_rom_path(args.rom))
    target_file = Path(args.targets)
    targets = [line.strip() for line in target_file.read_text(encoding='utf-8').splitlines() if line.strip() and not line.strip().startswith('#')]
    cache = {'rom_path': str(rom.path), 'rom_crc32': rom.crc32, 'rom_md5': rom.md5, 'targets': {}}
    for t in targets:
        target = parse_snes_addr(t)
        calls = [{'at_snes': fmt_snes(pc_to_hirom(i)), 'at_pc': fmt_pc(i), 'kind': kind, 'op': op} for i, kind, op in iter_calls(rom.data, target)]
        words = [{'at_snes': fmt_snes(pc_to_hirom(i)), 'at_pc': fmt_pc(i)} for i in iter_word_refs(rom.data, target)]
        raws = [{'at_snes': fmt_snes(pc_to_hirom(i)), 'at_pc': fmt_pc(i)} for i in iter_raw_refs(rom.data, target)]
        cache['targets'][t] = {'calls': calls[:500], 'word_refs': words[:1000], 'raw_refs': raws[:1000]}
    out = Path(args.output); out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(cache, indent=2), encoding='utf-8')
    print(out)

if __name__ == '__main__':
    main()
