\
#!/usr/bin/env python3
from __future__ import annotations

import argparse, sqlite3
from collections import defaultdict
from pathlib import Path

BANKS = ['C0', 'C1', 'CC', 'CF', 'D1', 'FD']


def bank_of(addr_start):
    if addr_start is None or addr_start <= 0xFFFF:
        return None
    return f"{(addr_start >> 16) & 0xFF:02X}"


def main() -> None:
    ap = argparse.ArgumentParser(description='Generate assembler-ready bank skeleton files from the current label DB.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--output-dir', default='asm_skeleton/banks')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    out_dir = root / args.output_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(root / args.db)
    con.row_factory = sqlite3.Row
    rows = con.execute('SELECT * FROM labels WHERE address_start IS NOT NULL ORDER BY address_start, pass_num').fetchall()
    con.close()
    grouped = defaultdict(list)
    for row in rows:
        b = bank_of(row['address_start'])
        if b:
            grouped[b].append(row)
    for bank in BANKS:
        lines = [f'; Chrono Trigger bank {bank} skeleton', '; Generated from current evidence. This is not a complete reassemblable bank yet.', '', f'.bank ${bank}', '']
        seen = set()
        for row in grouped.get(bank, []):
            key = (row['address_range'], row['label'])
            if key in seen:
                continue
            seen.add(key)
            lines.append(f'; {row["address_range"]} [{row["status_bucket"]}] pass {row["pass_num"]}')
            safe = row['label'].replace(' ', '_')
            safe = ''.join(ch if ch.isalnum() or ch == '_' else '_' for ch in safe)
            if not safe or safe[0].isdigit():
                safe = f'lbl_{safe}'
            lines.append(f'{safe}:')
            lines.append(f'    ; TODO: lift real code/data for {row["address_range"]}')
            if row['notes']:
                lines.append(f'    ; {row["notes"][:140]}')
            lines.append('')
        (out_dir / f'bank_{bank}.asm').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    manifest = root / 'asm_skeleton' / 'README.md'
    manifest.write_text('# Assembler Skeleton\n\nThese bank files are placeholders generated from the current evidence base.\nThey are for structured lift work, not for fake rebuild claims.\n', encoding='utf-8')
    print(out_dir)

if __name__ == '__main__':
    main()
