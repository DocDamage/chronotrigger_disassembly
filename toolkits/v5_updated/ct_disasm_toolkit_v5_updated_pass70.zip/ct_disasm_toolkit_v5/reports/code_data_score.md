# Code/Data Scoring

## Bank 7E
- `AF00-AFFF` -> **likely_code** (score 89, labels 24, strong 6)
- `AE00-AEFF` -> **likely_code** (score 41, labels 10, strong 4)
- `B100-B1FF` -> **likely_code** (score 38, labels 16, strong 4)
- `9F00-9FFF` -> **likely_code** (score 35, labels 18, strong 0)
- `B200-B2FF` -> **likely_code** (score 26, labels 8, strong 4)
- `A600-A6FF` -> **likely_code** (score 18, labels 4, strong 3)
- `B300-B3FF` -> **likely_code** (score 16, labels 4, strong 4)
- `5E00-5EFF` -> **likely_code** (score 15, labels 9, strong 3)
- `9500-95FF` -> **likely_code** (score 15, labels 2, strong 2)
- `9300-93FF` -> **likely_code** (score 12, labels 3, strong 3)

## Bank C0
- `A200-A2FF` -> **mixed** (score 9, labels 2, strong 0)

## Bank C1
- `B800-B8FF` -> **likely_code** (score 22, labels 6, strong 5)
- `AB00-ABFF` -> **likely_code** (score 21, labels 5, strong 4)
- `B900-B9FF` -> **likely_code** (score 14, labels 2, strong 2)
- `FD00-FDFF` -> **likely_code** (score 13, labels 1, strong 1)
- `9700-97FF` -> **likely_code** (score 12, labels 2, strong 2)
- `9000-90FF` -> **likely_code** (score 11, labels 4, strong 3)
- `0700-07FF` -> **likely_code** (score 10, labels 4, strong 3)
- `0800-08FF` -> **likely_code** (score 10, labels 4, strong 3)
- `0100-01FF` -> **mixed** (score 9, labels 3, strong 3)
- `0900-09FF` -> **mixed** (score 9, labels 3, strong 3)

## Bank CC
- `FA00-FAFF` -> **likely_code** (score 21, labels 6, strong 5)
- `2E00-2EFF` -> **mixed** (score 7, labels 3, strong 2)
- `F800-F8FF` -> **mixed** (score 5, labels 1, strong 0)
- `F900-F9FF` -> **mixed** (score 5, labels 1, strong 1)
- `9400-94FF` -> **mixed** (score 4, labels 1, strong 1)
- `8B00-8BFF` -> **likely_data** (score 3, labels 1, strong 1)

## Bank CF
- `E300-E3FF` -> **mixed** (score 5, labels 1, strong 1)

## Bank D1
- `5800-58FF` -> **mixed** (score 9, labels 7, strong 1)
- `5A00-5AFF` -> **mixed** (score 4, labels 2, strong 1)
- `5B00-5BFF` -> **mixed** (score 4, labels 2, strong 1)
- `5900-59FF` -> **likely_data** (score 3, labels 1, strong 1)

## Bank FD
- `B800-B8FF` -> **likely_code** (score 32, labels 9, strong 4)
- `A800-A8FF` -> **likely_code** (score 21, labels 5, strong 4)
- `A900-A9FF` -> **likely_code** (score 12, labels 2, strong 2)
- `B200-B2FF` -> **mixed** (score 8, labels 3, strong 1)
- `B900-B9FF` -> **likely_data** (score 2, labels 1, strong 0)

