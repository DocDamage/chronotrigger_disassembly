# Source State Report

- Total label rows represented: **230**
- Frozen/stable ranges: **110**

## Banks
- 7E: `source/banks/wram_7E.asm`  groups=55 rows=123
- C0: `source/banks/bank_C0.asm`  groups=2 rows=2
- C1: `source/banks/bank_C1.asm`  groups=55 rows=61
- CC: `source/banks/bank_CC.asm`  groups=10 rows=13
- CF: `source/banks/bank_CF.asm`  groups=1 rows=1
- D1: `source/banks/bank_D1.asm`  groups=4 rows=12
- FD: `source/banks/bank_FD.asm`  groups=15 rows=18

## Notes
- This is a scaffold-first source tree, not a byte-perfect assembled disassembly yet.
- Use the rebuild/diff report to track assembler integration progress.
