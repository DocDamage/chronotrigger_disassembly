# Global opcode 0D

Dispatch: `C1:92A3`

Current best label: `ct_global_opcode_0D_mark_non_subject_selected_entries_by_relation_mode05_zero_then_reduce`

Pass 65 proved this opcode skips the current subject slot, marks selected entries whose relation-query mode-05 result leaves `9872 == 0`, then reduces them through `AE21`. The final replay gate still depends on residual `9872` plus operand `+1`, so the top-level contract remains provisional.
