# Global Opcode 04

- Status: **strong**
- Dispatch address: **C1:B815**
- Evidence pass: **32**
- Notes: Random 4-way stream-control/advance command

## Matching label evidence
- no direct label rows matched yet
