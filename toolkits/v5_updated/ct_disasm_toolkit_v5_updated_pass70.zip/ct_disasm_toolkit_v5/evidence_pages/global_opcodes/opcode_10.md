# Global opcode 10

Dispatch: `C1:93E6`

Current best label: `ct_global_opcode_10_gate_tail_replay_on_current_subject_row_column_band_query`

Pass 65 proved this opcode chooses relation-query mode `09/0A/0B/0C` from operands `+2/+3`, runs the query on the current subject slot only, and succeeds when `9872 == 0`. Those modes collapse to coarse current-subject row/column band tests.
