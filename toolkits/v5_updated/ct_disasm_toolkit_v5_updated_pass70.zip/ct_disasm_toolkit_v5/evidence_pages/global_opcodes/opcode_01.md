# Global Opcode 01

- Status: **observed**
- Dispatch address: **C1:8EAB**
- Evidence pass: **62**
- Notes: Pack-fed observed; heavier selector/filter body partially reopened in pass 62 but not yet frozen

## Matching label evidence
- no direct label rows matched yet
