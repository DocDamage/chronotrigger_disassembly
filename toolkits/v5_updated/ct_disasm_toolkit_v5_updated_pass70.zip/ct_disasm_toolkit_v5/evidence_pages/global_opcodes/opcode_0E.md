# Global opcode 0E

Dispatch: `C1:9314`

Current best label: `ct_global_opcode_0E_mark_non_subject_selected_entries_by_parameterized_relation_mode_zero_then_reduce`

Pass 65 proved this is the parameterized sibling of `0D`: it seeds `986E = operand2 + 0x06`, marks zero-result candidates, and reduces them through `AE21`, but still ends on the same unresolved residual-`9872` / operand-`+1` replay gate.
