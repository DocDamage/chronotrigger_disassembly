# Global opcode 0C

Dispatch: `C1:925D`

Current best label: `ct_global_opcode_0C_gate_tail_replay_on_relation_mode04_current_subject_vs_selection_head`

Pass 65 proved this is a relation-query mode-04 gate between the current subject slot (`B252+3`) and `AECC[0]`, with operand `+1` selecting whether `9872` must be zero or nonzero before replay continues through `8C3E`.
