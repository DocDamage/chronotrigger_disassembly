# Global Opcode 07

- Status: **strong**
- Dispatch address: **C1:9082**
- Evidence pass: **62**
- Notes: Uses B320[B252]; mode byte selects >= vs <= compare against immediate operand

## Matching label evidence
- pass 62: `C1:9082..C1:90BD` **ct_global_opcode_07_gate_tail_replay_on_current_b320_compare_mode** (strong)
  - Reads compare byte from `CC:[B1D2 + 1]` and mode byte from `CC:[B1D2 + 2]`. Uses current slot index `B252` to read `B320[B252]`. Proven compare modes: mode `!= 1` -> success when `B320[current] >= operand1` mode `== 1` -> success when `B320[current] <= operand1` Success -> `JSR $8C3E` Failure -> `AF24 = 1` Final gameplay-facing noun for `B320[x]` still wants more caller proof.
