# Global Opcode 21

- Status: **strong**
- Dispatch address: **C1:97C0**
- Evidence pass: **62**
- Notes: Adjacent sibling gate; succeeds only when AF15[B252] == 0

## Matching label evidence
- pass 62: `C1:97C0..C1:97D4` **ct_global_opcode_21_gate_tail_replay_on_current_af15_zero** (strong)
  - Immediate adjacent sibling of opcode `20`. Uses current index `B252`. Success only when `AF15[B252] == 0`. Success -> `JSR $8C3E` Failure -> `AF24 = 1` Useful carry-forward proof that opcode `20` is part of a real replay-gate family.
