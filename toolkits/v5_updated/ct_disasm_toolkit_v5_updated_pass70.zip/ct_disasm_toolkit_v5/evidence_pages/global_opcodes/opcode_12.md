# Global opcode 12

Dispatch: `C1:9474`

Current best label: `ct_global_opcode_12_gate_tail_replay_on_current_b19e_b19f_pair_mode`

Pass 65 proved this is a two-byte direct current-slot record gate over `B19E/B19F + 4*B252`, with operand `+1` selecting the high-nibble class, operand `+2` selecting the second-byte value, and operand `+3` selecting both-match vs both-differ mode.
