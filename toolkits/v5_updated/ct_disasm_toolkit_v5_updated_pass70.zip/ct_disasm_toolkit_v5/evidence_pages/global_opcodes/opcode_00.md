# Global Opcode 00

- Status: **strong**
- Dispatch address: **C1:8EA7**
- Evidence pass: **62**
- Notes: Unconditional JSR $8C3E ; RTS wrapper into replay/controller layer

## Matching label evidence
- pass 62: `C1:8EA7..C1:8EAA` **ct_global_opcode_00_unconditional_tail_replay_step** (strong)
  - Direct body is only: `JSR $8C3E ; RTS`. Global opcode `00` is therefore an unconditional handoff into the tail replay/controller layer. This is a master-table opcode mapping, not a standalone subsystem root.
