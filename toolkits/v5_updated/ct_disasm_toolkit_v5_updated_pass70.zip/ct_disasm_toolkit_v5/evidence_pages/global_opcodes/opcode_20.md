# Global Opcode 20

- Status: **strong**
- Dispatch address: **C1:97AB**
- Evidence pass: **62**
- Notes: Succeeds only when AEB3[B252] is nonzero

## Matching label evidence
- pass 62: `C1:97AB..C1:97BF` **ct_global_opcode_20_gate_tail_replay_on_current_aeb3_nonzero** (strong)
  - Uses current index `B252`. Reads `AEB3[B252]`. Success only when that byte is nonzero. Success -> `JSR $8C3E` Failure -> `AF24 = 1` Final gameplay-facing noun for `AEB3[x]` is still intentionally open.
