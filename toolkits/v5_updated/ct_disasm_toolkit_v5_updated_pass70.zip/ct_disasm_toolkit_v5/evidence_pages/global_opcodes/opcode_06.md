# Global Opcode 06

- Status: **strong**
- Dispatch address: **C1:9045**
- Evidence pass: **62**
- Notes: Lexicographic 24-bit compare: current 96F1..96F3 >= immediate triplet

## Matching label evidence
- pass 62: `C1:9045..C1:9081` **ct_global_opcode_06_gate_tail_replay_when_96f1_96f3_triplet_gte_immediate** (strong)
  - Reads a 3-byte immediate operand from `CC:[B1D2 + 1..3]`. Compares that operand lexicographically against current WRAM bytes: `96F1` `96F2` `96F3` Success when current triplet >= immediate triplet. Success -> `JSR $8C3E` Failure -> `AF24 = 1` Gameplay-facing noun for `96F1..96F3` remains intentionally open.
