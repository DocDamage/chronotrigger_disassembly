# Global Opcode 05

- Status: **strong**
- Dispatch address: **C1:9013**
- Evidence pass: **62**
- Notes: Counts AF02!=FF and AF15==0 tail entries; succeeds when count <= immediate operand

## Matching label evidence
- pass 62: `C1:9013..C1:9043` **ct_global_opcode_05_gate_tail_replay_by_live_unwithheld_tail_count_max** (strong)
  - Reads one immediate operand byte from `CC:[B1D2 + 1]`. Counts tail entries where: `AF02[x] != FF` and `AF15[x] == 0` Success path is taken when the resulting count is **less than or equal to** the immediate operand. Success -> `JSR $8C3E` Failure -> `AF24 = 1` This strengthens the old pass-57 count gate by pinning the compare direction.
