# Global opcode 0F

Dispatch: `C1:938D`

Current best label: `ct_global_opcode_0F_gate_tail_replay_on_relation_mode08_current_subject_vs_selection_head`

Pass 65 proved this is a direct relation-query mode-08 gate between the current subject slot and `AECC[0]`. Operand `+2` is packed into `9871`; operand `+1` selects the final zero/nonzero polarity of `9872`.
