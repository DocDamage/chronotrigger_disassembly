# Global opcode 11

Dispatch: `C1:942A`

Current best label: `ct_global_opcode_11_gate_tail_replay_on_current_b19e_upper_nibble_class`

Pass 65 proved this is not a relation-query wrapper. It is a direct gate over `B19E + 4*B252`, comparing the upper nibble against class `0x40` or `0x50` with equality/inequality selected by operand `+3`.
