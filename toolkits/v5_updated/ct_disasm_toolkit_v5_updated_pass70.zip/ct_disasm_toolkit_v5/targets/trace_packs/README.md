# Trace target packs

These packs are the hottest runtime-confirmation seams carried forward from session 2.

Recommended use:
- set breakpoints / logging around the listed CPU addresses
- log WRAM writes for the listed fields
- import the resulting trace with `ct_import_runtime_evidence.py`
