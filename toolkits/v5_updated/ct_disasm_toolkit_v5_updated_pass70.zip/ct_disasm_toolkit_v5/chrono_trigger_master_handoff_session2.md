# Chrono Trigger (USA) SNES ROM — Master Handoff After Session 2 (Passes 32–61)

## Purpose
This file is the **current master handoff** after continuing development from the original session-1 handoff.

It is meant to do four jobs:

1. preserve the exact state reached in this session
2. prevent future drift, relabeling, and fake certainty
3. give the next worker a concrete continuation point
4. spell out what still has to happen before this ROM can honestly be called **completely disassembled**

This handoff assumes the earlier baseline handoff (`chrono_trigger_master_handoff_session1.md`) has already been read.

---

## ROM target
- Target ROM: `Chrono Trigger (USA).sfc`
- Build identity: headerless USA revision, HiROM, FastROM, 4 MiB
- Known fingerprint from the original handoff baseline:
  - CRC32: `2D206BF7`
  - MD5: `a2bc447961e52fd2227baed164f729dc`

---

## Executive status
The project is **meaningfully farther along than the session-1 handoff**, but it is still **nowhere near a finished full disassembly project** in the “bank-split, code/data-separated, source-rebuildable” sense.

### Best one-line description of current status
The disassembly now has a strong grasp on:

- ROM identity, boot/init chain, and WRAM decompression entry flow
- the `7F:2000` slot/object VM and multiple connected runtime families
- major render/cache/OAM/metasprite paths
- the bank-`C1` service-dispatch and CC-stream command architecture
- a large, battle-facing lane/panel/readiness branch traced through services, selector packs, roster/occupant maps, tilemap strips, numeric HP/MP readouts, and readiness gauges

But it still does **not** have:

- bank-by-bank code/data separation
- complete opcode specs for all major interpreters
- full subsystem ownership across the ROM
- complete format specs for all content/data banks
- a rebuildable source tree
- a build pipeline that can reproduce the original ROM layout

---

## Completion estimate
## Estimated total completion: **~38% overall**  
### Confidence: **medium-low**, with about **±8%** uncertainty

This percentage is **not a byte-count claim** and **not a “lines of asm written” claim**.  
It is a practical engineering estimate of how far the project is from a credible **complete ROM disassembly**.

The estimate is based on the gap between:
- what is already structurally understood
- versus what would still be required for a full code/data-separated, symbolized, source-rebuildable project

### Why the estimate is not higher
A lot of important runtime logic is now understood, but the expensive finishing work is still largely missing:
- global bank coverage
- global code/data separation
- complete opcode tables
- full content-bank format specs
- full decompressor/compressor grammar
- full source-tree split
- reproducible build output

### Why the estimate is not lower
The project is not in the “blind poking” phase anymore.  
Large parts of the runtime spine are now real:
- boot/init
- decompression
- object VM
- movement/render/cache
- relation-query services
- C1 command interpretation
- battle-facing lane/readiness/panel branch

### Domain-by-domain estimate
| Domain | State | Approx completion |
|---|---|---|
| ROM identity, boot chain, init/reset, early DMA | Very strong | 95% |
| WRAM decompressor pipeline | Partial-to-strong | 50% |
| `7F:2000` object/slot VM scheduler and major handler families | Partial | 35% |
| Movement, palette/effect, render cache, OAM/metasprite pipeline | Strong | 70% |
| Bank `C1` relation-query / service-dispatch / CC command interpreter | Strong in solved lanes, incomplete overall | 60% |
| Battle-facing lane/panel/readiness subsystem studied in passes 41-61 | Strong in traced branch, incomplete at whole-engine level | 55% |
| Bank-by-bank code/data separation across whole ROM | Early | 5% |
| Complete data-format specs for all content banks | Early | 15% |
| Rebuildable source tree and reproducible build | Not started in any serious way | 0% |

---

## Mandatory first action for the next worker
## **Do this first before any new reverse-engineering work: refresh community research**

The next worker should begin with a fresh context sweep across the Chrono Trigger hacking/modding community **before** diving back into the ROM.

This is not because community docs replace ROM proof.  
They do not.  
It matters because they can:
- prevent duplicate work
- expose known terminology and prior conventions
- surface existing offset docs, RAM-map facts, AI/event formats, and tool limitations
- reduce the risk of inventing bad subsystem names for already-studied areas

### Minimum research targets
1. **Chrono Compendium**
   - Utilities page
   - Modification page
   - Tutorials page
   - Temporal Flux Event Encyclopedia
   - Chrono Trigger Modification forum / Kajar Laboratories threads

2. **Data Crystal**
   - main Chrono Trigger SNES page
   - RAM map
   - Enemy AI documentation
   - any relevant technical subpages that intersect the current seam

3. **Debugger/tooling context**
   - Geiger’s SNES9x debugger references
   - bsnes / bsnes-plus debugger capabilities
   - usage-map / trace / breakpoint workflows that can validate uncertain static conclusions

### What the community research currently tells us
From the research done in this session, the community ecosystem is centered much more on:
- editors
- offsets
- RAM maps
- event/AI/music/graphics docs
- Temporal Flux workflows
- Geiger toolchain knowledge

than on a public, finished, rebuildable source-level disassembly.

That means outside material is best used as:
- **cross-check context**
- **naming discipline**
- **address sanity**
- **debugger workflow guidance**

and **not** as replacement proof for ROM-side static analysis.

### Research URLs collected in this session
- Chrono Compendium Utilities: https://www.chronocompendium.com/Term/Utilities_%28Chrono_Trigger%29.html
- Chrono Compendium Tutorials: https://www.chronocompendium.com/Term/Tutorials_%28Chrono_Trigger%29.html
- Chrono Compendium Modification: https://www.chronocompendium.com/Term/Modification.html
- Chrono Compendium Temporal Flux Event Encyclopedia: https://www.chronocompendium.com/Term/Temporal_Flux_Event_Encyclopedia.html
- Chrono Compendium forum / Chrono Trigger Modification: https://www.chronocompendium.com/Forums/index.php?board=101.0
- Data Crystal main page: https://datacrystal.tcrf.net/wiki/Chrono_Trigger_%28SNES%29
- Data Crystal RAM map: https://datacrystal.tcrf.net/wiki/Chrono_Trigger_%28SNES%29/RAM_map
- Data Crystal Enemy AI Documentation: https://datacrystal.tcrf.net/wiki/Chrono_Trigger_%28SNES%29/Enemy_AI_Documentation
- bsnes GitHub: https://github.com/bsnes-emu/bsnes
- bsnes-plus GitHub: https://github.com/devinacker/bsnes-plus

---

## Baseline inherited from the original session-1 handoff
The previous handoff established the following as already strong enough to trust:

- exact ROM fingerprint/build identity
- reset path and early boot chain
- RAM interrupt trampolines
- descriptor-driven init/decompress path
- existence and role of the WRAM decompressor
- `7F:2000` slot/object VM + scheduler existence
- palette/effect descriptor families and runtime logic
- direct embedding of palette commands into the object VM
- movement magnitude/timer/state/facing/integrator logic
- camera-relative bucket maintenance
- bucket traversal feeding sprite/OAM emission
- metasprite class sizing and cache/materializer split
- class-3 full build path
- render chunk/template staging system
- bank-`C1` relation-query service existence
- four real bank-`C1` CC-stream command tables

The original handoff also left these as the highest-value unresolved questions:

- bank-`C1` group 1 and group 2 command handlers
- full C1 opcode family coverage
- full object-VM opcode coverage
- extended-slot arrays
- decompressor grammar
- bank-by-bank code/data separation
- subsystem ownership boundaries
- rebuildable source tree

This session started from that baseline and stayed mostly on the bank-`C1` / battle-facing panel/readiness seam that grew out of it.

---

## Session-2 chronology (everything done in this session)
- **Pass 32** — Re-opened bank `C1` group-1 (`B85F`) and group-2 (`B88D`) CC-stream command handlers; proved `FD:BA4A` is a command-advance/skip table for opcodes `0x00..0x16`; identified many group-1 entries as aliases/stubs; solved group-1 `0x04` as a real random 4-way stream-advance/branch-style command; pinned `$AF24` as short-circuit/abort-style status and `$B3B8` as post-handler continuation selector.
- **Pass 33** — Decoded the remaining late group-2 cluster: `9E78`, `9F5A`, `9FD2`, and `A396`; split them into an eligible-slot selector/finalizer family and table-based byte-writer families; proved `A396` is a thin wrapper around `FD:A990`; tightened `AC46`, `AD09`, and `AD35` as shared helpers.
- **Pass 34** — Solved the early unresolved group-2 pair: `0x01 -> 99BE` and `0x02 -> 9A39/9A3D`; proved `99BE` is a one-entry seeded finalize path via `$5E15[$AEC8]`; proved `9A39` is only a wrapper and `9A3D` is the real body; separated the two handlers by seed source, mode bits, and validation/commit path.
- **Pass 35** — Worked the helper seam: `FD:AB01`, `C1:AC89`, `C1:ACCE`, `C1:ACF2`, `C1:AD09`, `C1:AD35`, and `C1:C1DD`; proved `ACCE` is just the `AEE5 -> 0E` normalizer; tightened `C1:C1DD` to a validation + candidate-list materializer; established `FD:AB01` as real linear code.
- **Pass 36** — Cracked the common tail at `C1:C55F`; proved it is a descriptor-driven candidate expansion/finalization pipeline; pinned `$3A` as common-tail mode selector and `$0C` as descriptor index into `CC:2AB0`; identified packet-writer dispatch through `C95C` and `C78D..C813`; tightened `C6D9` as the final `AD8E` compaction/count phase.
- **Pass 37** — Solved the `JSR $0003` ownership problem: `C1:0003/0045` is the bank-C1 local service dispatcher, `C1:0051` is the primary service jump table, `C736` routes to service 5 (relation-query block), and `C741` routes to service 7 (separate candidate-list query family); pinned `1FDD`/`1FEA` as service-7 subdispatcher/submode table; showed `$99C0` and `$A62D` are twin bounded result vectors.
- **Pass 38** — Decoded the four real service-7 bodies: `2332` as a seeded half-open band scan, `23A4` as a three-vertex inclusion scan using fixed slots `0/1/2`, `2701` as a 16-unit cell-radius scan using square table `CC:FB6F`, and `25A3` as a dual-anchor oriented inclusion path; strengthened `$9604` as the partition selector and `27AD/27C5` as shared tails.
- **Pass 39** — Opened the wrapper layer above service 7 by cracking the wrapper opcode table at `1FF8`; classified wrapper families above `2332/23A4/25A3/2701`; pinned `27FA`, `2814`, and `282D` as result-cursor helpers; strengthened `$960D`, `$960C`, `$9613`, `$9614`, and `$2980`.
- **Pass 40** — Traced the producers of `$960D`, `$960F`, `$9614`, and `$EF`; proved service 7 sits under a cursor/grid-style outer controller with three distinct launch families feeding `$960D`; pinned `$9609` as service-7 replay/follow-up counter, `$960F` as current/preferred source slot, and `$95DC[x]` as a per-slot 3-state submode selector; separated fixed, dynamic, and table-driven launch families.
- **Pass 41** — Worked the sink at `16DA..1713` into `93EE..93F4`; proved the sink is two coordinated write systems: a 3-entry pending-slot FIFO at `99D4..99D8` and a larger per-record metadata table keyed by `CC:FAF0`; pinned `93EE.bit6` as pending/consumable record flag, `93EE.bit7` as linked/active ring marker, `93EF.bit6` as a separate reservation latch, `93F3` as a packed nibble-pair dispatch byte, and `93F4` as the launch-table token copy.
- **Pass 42** — Focused on the `93F3` lane-dispatch side; tightened the nibbles to lane IDs `0/1/2` with `F = none`; pinned `C1:B575..B6C9` as the canonical-record lane reconciler; proved `FD:A8A5` is a lane-block eligibility gate over three `0x80`-spaced WRAM blocks; proved `FD:A93C`/`FD:A95F` are a two-phase enabled-lane dispatcher pair; tightened `FD:A8CE`/`FD:A8FE` as canonical-record lane clear/reset helpers.
- **Pass 43** — Followed service 2 from the `FD:A8FE` path and tightened the carried-state family; proved `C1:1BAA` is a 3-lane roster removal + reseat controller and that `1B19`, `1B69`, and `1BAA` form one coherent lane controller; pinned `1C3A` as a `0x180`-byte workspace template restore; tightened the `B158 / AFAB / 99DD / 9F22 / B188 / B03A` family as a per-lane carried-state bundle.
- **Pass 44** — Cracked the `0B40` workspace harder by finding the DMA consumer in bank `CF`; proved `0B40` is a VRAM-uploaded tilemap staging buffer and `99E2` is its pending-upload/dirty counter; pinned `D1:5800`, `D1:5A50`, and `D1:5BD0` as the three ROM template sources; strengthened `1C3A` to a default tilemap-template restore; proved `0B40` uploads to VRAM `7A00` as `0x0180` bytes and then clears `99E2`.
- **Pass 45** — Moved from template restore to in-place mutation; corrected the `0B40` geometry to a stronger 32 words x 6 rows; pinned `C1:0929` as the first real in-place `0B40` panel-segment blitter; pinned `D1:59FC` as a 6-row x 7-word panel-segment template; pinned `C1:07FD` as a three-position horizontal panel-strip compositor driven by active lane roster `A6D9/A6DA/A6DB`.
- **Pass 46** — Split the broad `07FD` area correctly; proved the real `0B40` three-slot composer starts at `081F`; proved `07BD` and `07EE` are sibling companion-strip blitters into `0CC0..0E08`, not more `0B40` code; proved `0CC0..0E08` is a paired-byte companion strip with `0x40` row stride; proved `0958` rebuilds a separate `0x180`-byte companion record buffer at `0E80..0FFF`; tightened caller-context roles of the three base strip templates.
- **Pass 47** — Worked the consumer side of `0CC0..0E08` and `0E80..0FFF`; pinned `0299` as the full `0CC0` companion-strip rebuild entry; hardened `CC:FA23..FA3F` into 3-entry lane-anchor offset tables and `CC:FADD` into the live lane-block base table (`0000/0080/0100`); pinned `06F0` as a scaled segmented bar/meter renderer into `0CC0`; pinned `CC:FAE9` as the `0E80` lane-marker anchor table; pinned `1918` as the old-marker clear/current-marker stamp path; found read-side proof for `0E80` from bank `C0`.
- **Pass 48** — Decoded the dynamic glyph groups through `9499..949F`; pinned `011F` as a 3-digit decimal tile formatter, `0174` as a 2-digit formatter, `104E` as a leading-zero blanker, and `CC:F903` as the decimal digit tile table; proved the dynamic glyph groups in `0299` are numeric fields rendered from lane-selected record data at `5E30/5E32/5E34`.
- **Pass 49** — Identified the actual meaning of the numeric fields and the warning path through `A10F`; corrected `011B` to a 3-bit right-shift entry; pinned `5E30/5E32` as current HP / max HP, `5E2F.bit0` as the low-HP/critical threshold flag, and `A10F` as a lane-local HP-threshold presentation selector; kept `5E34` strongest as current MP without overclaiming more than the bytes proved.
- **Pass 50** — Worked the bar path through `99DD / 9F22 / 06F0`; tightened it from a generic meter to the party-lane active-time/readiness gauge; read `B158 -> AFAB -> BD6F` as a base-rate to status-modified-rate chain; pinned `BD6F` as the helper that halves/doubles the lane time increment based on battle-status bits with a minimum floor clamp; pinned `B725` as the visible gauge export initializer and reframed `BDE0 / BE50 / BED0` as the gauge-advance/ready-transition side.
- **Pass 51** — Pushed upstream into the readiness seed/control path; tightened `06F0` on the math side so `99DD` is current/fill export and `9F22` is goal/cap export; showed the `BE00` family updates goal only while the `BE80/BF00` families update current + goal together; used `B390` to bridge `B158` into `AFAB / 99DD / 9F22`; identified the strongest upstream seed family as `FD:B820..B850`; pinned `CC:2E31` as a 16-step speed-like stat -> readiness bonus table.
- **Pass 52** — Killed the pass-51 random/bias idea and solved the seed formula; proved `C1:C90B` is the multiply helper; proved the first `$2C` term is `($2990 & 7) * 0x10` and the second is `speed * 6`; tightened `CC:2E31` from one table into an 8x16 config-page table family; pinned the exact primary seed formula as `0x69 - (speed * 6) + CC:2E31[(($2990 & 7) * 16) + (speed - 1)]`; carried the sibling family forward as the same core formula feeding `B15B/AFAE` with extra side effects.
- **Pass 53** — Resolved the primary-vs-sibling ambiguity by proving `B158..B162`, `AFAB..AFB5`, and `B03A..B044` are one contiguous 11-slot readiness/timer family; showed the split is a 3-slot visible head plus 8-slot runtime tail; used `80FD..811D`, `FD:B4E0..B54D`, and `FD:B800..B94F` to prove contiguous seeding; showed only the head copies into visible export buffers `99DD..99DF` and `9F22..9F24`.
- **Pass 54** — Solved the normalization block at `FD:B8F7`; proved it is a minimum-positive subtractive normalization across the unified 11-slot readiness work array; proved it finds the smallest eligible positive `AFAB` value, computes `(min - 1)`, and subtracts that from every eligible positive slot; proved zeros and `AEFF == FF` slots are preserved; proved the visible head export is fed by post-normalized values.
- **Pass 55** — Solved the owner side of `AEFF`; pinned `AEFF..AF09` as the battle-slot occupant index map, `AF0A..AF14` as the remembered/default occupant map, `AEC5` as the visible-head occupied-slot count, and `B1BE` as the battler -> visible-head-slot inverse map; anchored this in the real producer/consumer chain through `FD:B24D..B2A3`, `FB06..FB2C`, `B279..B2C0`, `BE50..BF24`, and `FD:B363...`.
- **Pass 56** — Closed the tail-half of the occupant model; pinned `FD:B2A3..B2DD` as the canonical tail occupant-map builder; froze `AEFF..AF09` and `AF0A..AF14` harder as unified 11-slot live vs canonical occupant-map families; proved `AF02..AF09` is the tail live/materialized submap and `AF0D..AF14` is the tail canonical/remembered submap; tightened `AEC6` as canonical populated tail-slot count; proved `AF15.bit7` means canonically present but withheld from the live tail map.
- **Pass 57** — Followed the withheld-tail behavior into consumers; upgraded `AF15.bit7` from passive not-live to a real deferred-materialization state; proved `AB03..AB49` builds a withheld-tail candidate list and randomly reduces it to one slot if multiple exist; proved `AED3..AEFB` materializes a canonical tail occupant into the live tail map; proved normal tail dispatch and tail-count gating ignore flagged entries.
- **Pass 58** — Traced ownership of the withheld-tail helpers; showed `AB03` and `AED3` sit under local indexed-dispatch tables in bank `C1`; pinned `ABC9` as the live-tail sibling to the withheld-tail selector; locked `AAAB..AAF8` and `AB4E..AB90` as fixed single-entry selector wrappers and `AB9B` as a dynamic visible-slot selector over entries `0/1/2`; whole-ROM static scan found no direct `JSR/JMP/JSL` callers to `AB03` or `AED3`, supporting the read that `AED3` is a narrower occupant-ID deferred-reinsertion helper.
- **Pass 59** — Solved the selector ownership correction; proved `B8F3` is not a separate selector-wrapper table but part of the same inline selector-control dispatch table already reached from `AC14/AC2E`; tightened `B8BB..B95F` as one inline selector-control dispatch table; mapped exact selector-control bytes for fixed selectors, withheld-tail random reducer, visible-slot min selector, and live-tail random reducer.
- **Pass 60** — Worked the late selector-control band `0x39..0x52`; proved it is not the missing `$0E -> AED3` reinsertion bridge; pinned `0x49 -> AFD7` as the first clearly top-level late entry and proved it seeds a separate late selector-pack executor; pinned `CC:8B08` as a 4-byte late selector pointer-record table; proved the executor runs `FE/FF`-delimited micro-packs and dispatches sub-ops through `B80D`; gave structural roles to `B239`, `B1CF`, and `B24A`.
- **Pass 61** — Solved the `B80D` ownership problem; pinned `B80D` as the master bank-C1 opcode dispatch table, with `B85F`, `B88D`, and `B8BB` as interior slices rather than separate roots; proved the late-tail pack system feeds global C1 opcode bytes back into the shared dispatcher; corrected `B242[x]` to the per-tail last-executed global opcode byte; tightened `8C0A..8CF7` as the tail replay/controller layer around the shared dispatcher.

---

## Current state after pass 61

### What is now strong enough to treat as established
These are the strongest live conclusions as of pass 61.

#### 1. Bank `C1` dispatch architecture
- `C1:0003/0045` is the real bank-local service dispatcher
- `C1:0051` is the primary service jump table
- `C1:B80D` is the **master bank-`C1` opcode dispatch table**
- `C1:B85F`, `C1:B88D`, and `C1:B8BB` are interior slices of that master table, not separate roots

#### 2. Relation-query / candidate-query layer
- service 5 remains the relation-query block
- service 7 is a real candidate-list/spatial-query family, not a loose pile of helpers
- service-7 bodies now include:
  - half-open band scan
  - three-vertex inclusion scan
  - cell-radius scan
  - dual-anchor oriented inclusion path

#### 3. Descriptor/common-tail pipeline
- `C1:C55F` is a descriptor-driven candidate expansion/finalization path
- packet writer dispatch and compaction/count phases are real and structurally mapped

#### 4. Record/lane reconciliation branch
- `93EE..93F4` and `99D4..99D8` are real record/FIFO structures
- `93F3` is a packed lane/category dispatch byte
- `FD:A8A5`, `A93C`, `A95F`, `A8CE`, and `A8FE` now form a meaningful lane reconciliation/clear/reset family

#### 5. Tilemap/panel strip branch
- `0B40` is a VRAM-uploaded tilemap staging buffer
- `99E2` is the upload-dirty counter
- `0CC0..0E08` is a paired-byte companion strip
- `0E80..0FFF` is a separate companion record buffer
- three ROM templates at `D1:5800 / 5A50 / 5BD0` feed this system
- panel composition is lane-driven

#### 6. Numeric field rendering
- decimal tile formatting is now real, not speculative
- the numeric fields built through `0299` are lane-selected readouts sourced from real battle-facing record data
- strongest current read:
  - current HP
  - max HP
  - current MP
- low-HP threshold presentation logic is real

#### 7. Readiness/gauge branch
- `06F0` is a scaled segmented bar/meter renderer
- `99DD` is current/fill export
- `9F22` is goal/cap export
- `B158..B162`, `AFAB..AFB5`, and `B03A..B044` form a unified 11-slot readiness/timer family
- the split is:
  - **head (3 slots)** = visible/export-facing
  - **tail (8 slots)** = runtime-facing
- normalization at `FD:B8F7` is now exact:
  - smallest eligible positive value
  - subtract `(min - 1)` from eligible positives
  - preserve zero
  - preserve empty slots

#### 8. Occupant-map / roster side
- `AEFF..AF09` = live occupant index map
- `AF0A..AF14` = canonical/remembered occupant map
- `B1BE` = battler -> visible-head-slot inverse map
- tail live vs canonical halves are now structurally solved
- `AF15.bit7` is deferred/withheld tail materialization state
- `AB03` and `ABC9` are selector helpers on the withheld/live tail side
- `AED3` is a narrower reinsertion/materialization helper than originally suspected

#### 9. Late selector-pack executor
- the late-band logic is not the missing direct reinsertion bridge
- `AFD7` seeds a late selector-pack executor
- `CC:8B08` is a 4-byte pointer-record table for those late packs
- those packs are `FE/FF`-delimited micro-packs
- they feed **global bank-`C1` opcode bytes** back into the shared master dispatcher
- `B242[x]` is a per-tail “last executed global opcode byte” state field

---

## Best current high-level model of the branch worked in passes 32–61
The strongest current interpretation is that this session mapped a **battle-facing party-lane controller / record / panel / readiness branch** rooted inside bank `C1`, where:

1. selector wrappers and service dispatch choose candidate slots/lanes/records
2. lane reconciliation and roster logic maintain active/pending/canonical structures
3. tilemap and companion-strip builders compose panel-visible structures
4. numeric renderers read HP/MP-like fields from lane-selected records
5. readiness/gauge logic exports fill/cap state for the visible head slots
6. tail slots remain runtime-facing and can be withheld/deferred before materializing live
7. late selector packs replay global bank-`C1` opcodes back through the master dispatcher

This is strong enough to guide continuation, but still **not strong enough to declare the entire subsystem fully named and complete**.

---

## Where we are exactly right now
### Top-of-stack pass
- **Pass 61** is the current top-of-stack

### Current live seam
The cleanest continuation seam after pass 61 is:

1. the **early global opcode band** inside the master `C1:B80D` table, especially the pack-fed opcodes already observed:
   - `00`
   - `01`
   - `02`
   - `04`
   - `05`
   - `06`
   - `07`
   - `09`
   - `0A`
   - `0B`
   - `0F`
   - `12`
   - `15`
   - `1B`
   - `20`

2. the remaining unresolved bridge from late selector-pack control into the exact `$0E -> AED3` reinsertion path

3. better ownership naming around the late-band tail replay/controller layer (`8C0A..8CF7`, `B239`, `B24A`, `B263`)

### What should **not** be reopened casually
Do **not** restart these unless new evidence disproves them:
- `B80D` as master `C1` dispatcher
- `0B40` as VRAM-uploaded tilemap staging buffer
- `011F/0174` as decimal formatters
- `5E30/5E32` as current HP / max HP
- `06F0` as bar/meter renderer
- `AEFF..AF09` and `AF0A..AF14` as live/canonical occupant maps
- `AF15.bit7` as withheld/deferred tail materialization state

---

## What still needs to be done for a **complete** ROM disassembly
This is the serious remaining workload.

### A. Finish the community research/context refresh first
Before more labeling work:
- re-scan Chrono Compendium, Data Crystal, and modification threads
- cross-check any new findings for:
  - known offset docs
  - established event/AI nomenclature
  - debugger workflows
  - already-known RAM meanings
- do **not** let community docs override ROM proof

### B. Finish global bank-`C1` opcode coverage
This is the most direct continuation target.
Still needed:
- complete handler-by-handler spec for the master `B80D` space
- exact semantics for remaining early-band opcodes
- exact role of the late selector-pack executor and every micro-pack sub-op
- cleaner ownership of replay/controller helpers
- final resolution of the `$0E -> AED3` reinsertion bridge

### C. Finish the `7F:2000` object/slot VM
Still incomplete:
- full opcode table coverage
- operand lengths
- control-flow rules
- side-effect mapping
- clear partition between map/event/object script commands vs battle-facing hooks

### D. Finish decompressor/compressor understanding
Still needed:
- exact decompressor command grammar
- formal token grammar
- edge cases / terminators / length semantics
- matching compressor-side understanding or at least enough to reproduce valid streams

### E. Finish unresolved data-format work
Still incomplete:
- remaining template/chunk header bits
- full metasprite source/content specs for all classes
- unresolved extended-record tail arrays
- script/content bank data formats outside the currently solved islands

### F. Global code/data separation
This is one of the largest missing tasks.
Needed:
- bank-by-bank code/data pass
- conservative marking of jump tables, inline data, and pointer tables
- cross-bank xref maps
- callgraph and bank ownership map
- “unknown but data” vs “unknown but probably code” triage

### G. Subsystem ownership boundaries
Still needed:
- hard separation between:
  - battle-specific logic
  - map/event/object logic
  - shared utility code
  - render/UI builders
  - data marshaling paths

No broad subsystem claim should be finalized until caller proof supports it.

### H. Create a real symbolized source tree
Still needed:
- split disassembly into banks/files
- normalize labels
- separate strong labels from provisional ones
- create include files / tables / macros as needed
- keep correction history so old bad labels do not creep back in

### I. Build reproducibility
Still needed:
- assembler project layout
- exact ROM mapping directives
- section placement
- binary include strategy
- checksum / header verification
- final “rebuild matches original ROM” validation

Until this exists, the project is **not** a completed disassembly no matter how many routines are semantically understood.

---

## Recommended order of work from here
This is the best practical order now.

1. **Research refresh in the Chrono Trigger community**
2. **Continue the early-band `B80D` opcode coverage**
3. **Resolve late-pack executor + reinsertion bridge**
4. **Finish `C1` master opcode map and service ownership**
5. **Return to unresolved `7F:2000` VM opcode coverage**
6. **Finish decompressor grammar**
7. **Resolve remaining data-format islands**
8. **Start disciplined bank-by-bank code/data separation**
9. **Split into a real source tree**
10. **Pursue rebuildability and binary-match validation**

---

## How to use bsnes / bsnes-plus from here
bsnes was mentioned because runtime confirmation is going to matter more as the project moves from static structural discovery into edge-case control flow.

### Best future uses
- verify whether suspicious late-band bytes are actually emitted in live control streams
- breakpoint on writes to:
  - `0B40`
  - `0CC0`
  - `0E80`
  - `99DD`
  - `9F22`
  - `AEFF..AF15`
  - `B242`
- trace pack execution through:
  - `AFD7`
  - `B80D`
  - `8C0A..8CF7`
- generate usage-map or trace-log evidence for unresolved code/data boundaries

### Why bsnes / bsnes-plus may matter more later
The remaining work is increasingly about:
- alias-vs-real-entry ambiguity
- runtime-only pack execution
- data/code boundary validation
- proving whether rarely reached handlers are live or dead

That is exactly where debugger-grade traces become more valuable than static inspection alone.

---

## Ground rules going forward
These rules remain mandatory.

1. **Do not relabel unresolved tables just because nearby data looks suggestive.**
2. **Prefer unresolved over wrong.**
3. **Keep code/data separation conservative.**
4. **Do not claim battle/map/event ownership without caller proof.**
5. **Preserve corrections when later passes invalidate earlier assumptions.**
6. **Treat pass 61 as the current top-of-stack.**
7. **Separate strong labels from provisional labels.**
8. **Do not confuse “I understand one branch well” with “the whole subsystem is solved.”**
9. **Do not confuse semantic understanding with rebuildability.**
10. **Do the community research refresh first next session.**

---

## Artifact inventory generated in this session
- `chrono_trigger_disasm_pass32.md`
- `chrono_trigger_disasm_pass33.md`
- `chrono_trigger_disasm_pass34.md`
- `chrono_trigger_disasm_pass35.md`
- `chrono_trigger_disasm_pass36.md`
- `chrono_trigger_disasm_pass37.md`
- `chrono_trigger_disasm_pass38.md`
- `chrono_trigger_disasm_pass39.md`
- `chrono_trigger_disasm_pass40.md`
- `chrono_trigger_disasm_pass41.md`
- `chrono_trigger_disasm_pass42.md`
- `chrono_trigger_disasm_pass43.md`
- `chrono_trigger_disasm_pass44.md`
- `chrono_trigger_disasm_pass45.md`
- `chrono_trigger_disasm_pass46.md`
- `chrono_trigger_disasm_pass47.md`
- `chrono_trigger_disasm_pass48.md`
- `chrono_trigger_disasm_pass49.md`
- `chrono_trigger_disasm_pass50.md`
- `chrono_trigger_disasm_pass51.md`
- `chrono_trigger_disasm_pass52.md`
- `chrono_trigger_disasm_pass53.md`
- `chrono_trigger_disasm_pass54.md`
- `chrono_trigger_disasm_pass55.md`
- `chrono_trigger_disasm_pass56.md`
- `chrono_trigger_disasm_pass57.md`
- `chrono_trigger_disasm_pass58.md`
- `chrono_trigger_disasm_pass59.md`
- `chrono_trigger_disasm_pass60.md`
- `chrono_trigger_disasm_pass61.md`
- `chrono_trigger_labels_pass32.md`
- `chrono_trigger_labels_pass33.md`
- `chrono_trigger_labels_pass34.md`
- `chrono_trigger_labels_pass35.md`
- `chrono_trigger_labels_pass36.md`
- `chrono_trigger_labels_pass37.md`
- `chrono_trigger_labels_pass38.md`
- `chrono_trigger_labels_pass39.md`
- `chrono_trigger_labels_pass40.md`
- `chrono_trigger_labels_pass41.md`
- `chrono_trigger_labels_pass42.md`
- `chrono_trigger_labels_pass43.md`
- `chrono_trigger_labels_pass44.md`
- `chrono_trigger_labels_pass45.md`
- `chrono_trigger_labels_pass46.md`
- `chrono_trigger_labels_pass47.md`
- `chrono_trigger_labels_pass48.md`
- `chrono_trigger_labels_pass49.md`
- `chrono_trigger_labels_pass50.md`
- `chrono_trigger_labels_pass51.md`
- `chrono_trigger_labels_pass52.md`
- `chrono_trigger_labels_pass53.md`
- `chrono_trigger_labels_pass54.md`
- `chrono_trigger_labels_pass55.md`
- `chrono_trigger_labels_pass56.md`
- `chrono_trigger_labels_pass57.md`
- `chrono_trigger_labels_pass58.md`
- `chrono_trigger_labels_pass59.md`
- `chrono_trigger_labels_pass60.md`
- `chrono_trigger_labels_pass61.md`

---

## Bottom line
This session materially advanced the project.

The biggest gains were:
- turning bank `C1` from “a bag of helpers” into a structured dispatcher/interpreter/service ecosystem
- tracing one major battle-facing lane/panel/readiness branch far enough to identify real data structures, render paths, and control logic
- correcting multiple false splits and orphan-helper assumptions
- upgrading `B80D` to its proper role as the master bank-`C1` opcode dispatch table

But the project is still **far** from a finished whole-ROM disassembly.

If the next worker wants the highest-value continuation:
1. do the community research refresh first
2. continue the master `B80D` opcode band
3. resolve the remaining reinsertion/late-pack bridge
4. then move outward toward full VM coverage, global bank separation, and source-tree construction
