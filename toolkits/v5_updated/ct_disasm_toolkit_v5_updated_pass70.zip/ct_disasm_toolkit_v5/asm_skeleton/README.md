# Assembler Skeleton

These bank files are placeholders generated from the current evidence base.
They are for structured lift work, not for fake rebuild claims.
