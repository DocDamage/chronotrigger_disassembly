; Chrono Trigger bank CC skeleton
; Generated from current evidence. This is not a complete reassemblable bank yet.

.bank $CC

; CC:2E31 [strong] pass 51
ct_cc_speed_like_stat_to_readiness_bonus_table:
    ; TODO: lift real code/data for CC:2E31
    ; 16-byte signed step table: Smooth +4-step ladder from negative to small positive bonus. Consumed directly by the `FD:B820..B850` readiness s

; CC:2E31 [strong] pass 52
ct_cc_battle_speed_page_speed_to_readiness_seed_adjust_table:
    ; TODO: lift real code/data for CC:2E31
    ; 8 pages of 16 signed-byte entries each. Page selected by `($2990 & 7)`. Entry selected by `(speed - 1)`. Supplies the additive adjustment te

; CC:2E31 [unspecified] pass 52
old_wording__speed_like_stat____readiness_bonus_table_________________soft_replaced_:
    ; TODO: lift real code/data for CC:2E31
    ; Too narrow after page-selection proof. Replaced by `ct_cc_battle_speed_page_speed_to_readiness_seed_adjust_table`.

; CC:8B08..CC:8C53 [strong] pass 60
ct_late_selector_control_pointer_records:
    ; TODO: lift real code/data for CC:8B08..CC:8C53
    ; Indexed at 4-byte stride by the late selector-control family. `AFD7` proves the first word of each record is used as a pointer seed. For `0x

; CC:94A0 [strong] pass 46
ct_cc_companion_record_template_table:
    ; TODO: lift real code/data for CC:94A0
    ; ROM template source copied by `C1:09B0`. Used as structured record data, not code.

; CC:F8ED [provisional] pass 48
ct_cc_live_three_lane_record_block_offsets_0000_0080_0100:
    ; TODO: lift real code/data for CC:F8ED
    ; Proven live subgroup used by the numeric writer path: `0000` `0080` `0100` Acts as the lane-selected record-block offset table for the dynam

; CC:F903 [strong] pass 48
ct_cc_decimal_digit_tile_table_73_to_7c:
    ; TODO: lift real code/data for CC:F903
    ; Live digit tile codes used by `011F` and `0174` are: `73 74 75 76 77 78 79 7A 7B 7C` Strongest safe reading: decimal digit tile codes for `0

; CC:FA23 [provisional] pass 46
__CC_FA29___CC_FADD__ct_cc_companion_strip_selector_tables____provisional_:
    ; TODO: lift real code/data for CC:FA23
    ; These tables clearly feed `C1:08E8` slice-local updates in the `0CC0` companion strip. Exact semantics of each selector lane remain open.

; CC:FA23..CC:FA3F [strong] pass 47
ct_cc_companion_strip_lane_anchor_offset_family:
    ; TODO: lift real code/data for CC:FA23..CC:FA3F
    ; Family of 3-entry 16-bit offset tables. Every table uses `0x80` lane spacing. Proven live subgroups: `FA23` = `0029,00A9,0129` `FA29` = `001

; CC:FA41 [strong] pass 46
ct_cc_companion_strip_template_a_6x7_bytes:
    ; TODO: lift real code/data for CC:FA41
    ; Compact ROM byte template consumed only by `C1:07BD` in this pass. Structurally matches the proven `6-row x 7-byte` loop.

; CC:FA6B [strong] pass 46
ct_cc_companion_strip_template_b_6x7_bytes:
    ; TODO: lift real code/data for CC:FA6B
    ; Compact ROM byte template consumed only by `C1:07EE` in this pass. Structurally matches the proven `6-row x 7-byte` loop.

; CC:FADD [strong] pass 47
ct_cc_companion_strip_lane_block_offsets_0000_0080_0100:
    ; TODO: lift real code/data for CC:FADD
    ; Proven live words used by `C1:08BF`: `0000` `0080` `0100` Exact role: the three base offsets for the lane blocks inside the `0CC0` strip.

; CC:FAE9 [strong] pass 47
ct_cc_companion_record_lane_marker_offsets_0002_0082_0102:
    ; TODO: lift real code/data for CC:FAE9
    ; Proven live words: `0002` `0082` `0102` Used by `C1:1918..1969` to clear/stamp one of three `0E80` lane marker positions.

