; Chrono Trigger bank CF skeleton
; Generated from current evidence. This is not a complete reassemblable bank yet.

.bank $CF

; CF:E380 [strong] pass 44
ct_cf_upload_pending_tilemap_0b40_to_vram_7a00:
    ; TODO: lift real code/data for CF:E380
    ; Cross-bank sink for the `0B40` render buffer. If `99E2 != 0`, configures DMA to upload `0x0180` bytes from `00:0B40`

