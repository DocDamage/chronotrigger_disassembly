; Chrono Trigger bank FD skeleton
; Generated from current evidence. This is not a complete reassemblable bank yet.

.bank $FD

; FD:A811 [provisional] pass 53
ct_fd_runtime_tail_slot_record_ptr_table:
    ; TODO: lift real code/data for FD:A811
    ; Indexed by the tail seeder through a 16-bit table lookup. Supplies the record source used to read at least: byte `+0x38` (effective speed in

; FD:A8A5 [strong] pass 42
ct_fd_service7_lane_block_is_eligible:
    ; TODO: lift real code/data for FD:A8A5
    ; Tests one of three `0x80`-spaced WRAM lane blocks selected by lane ID Uses: `5E4A + lane*0x80`, bit 7 `5E4E + lane*0x80` OR `5E53 + lane*0x8

; FD:A8CE [strong] pass 42
ct_fd_service7_clear_canonical_record_lane:
    ; TODO: lift real code/data for FD:A8CE
    ; Computes `X = lane * 7`. Clears canonical fixed-record fields: `93EE + X` `93EF + X` `93F3 + X = FF` Then resets matching lane-carried state

; FD:A8FE [strong] pass 42
ct_fd_service7_clear_occupied_lane_and_refresh_service2:
    ; TODO: lift real code/data for FD:A8FE
    ; Checks `B188[lane]`. If the lane is marked/occupied, performs the same canonical-record clear

; FD:A93C [strong] pass 42
ct_fd_service7_dispatch_enabled_lane_clear_phase:
    ; TODO: lift real code/data for FD:A93C
    ; Iterates enabled lanes in `B3E7..B3E9`. Calls `FD:A8CE` for each enabled lane.

; FD:A95F [strong] pass 42
ct_fd_service7_dispatch_enabled_lane_refresh_phase:
    ; TODO: lift real code/data for FD:A95F
    ; Iterates enabled lanes in `B3E7..B3E9`. Calls `FD:A8FE` for each enabled lane.

; FD:B24D..FD:B27E [provisional] pass 55
ct_fd_initialize_head_battle_slot_occupant_maps_from_party_state:
    ; TODO: lift real code/data for FD:B24D..FD:B27E
    ; The head-map construction is strong. The exact upstream gameplay noun for the `2980` validity source is still left slightly cautious.

; FD:B28F..FD:B2A3 [provisional] pass 55
ct_fd_rebuild_visible_head_battler_to_slot_inverse_map:
    ; TODO: lift real code/data for FD:B28F..FD:B2A3
    ; Previously only loosely understood as a small inverse/lookup rebuild. Pass 55 freezes the exact source and direction: source: `AEFF[0..2]` d

; FD:B2A3..B2DD [strong] pass 56
ct_build_tail_live_and_canonical_occupant_maps:
    ; TODO: lift real code/data for FD:B2A3..B2DD
    ; Iterates 8 source records with stride `0x0C` rooted at `29C4`. Uses: `29C5 + n*0x0C` as the admit/skip gate `29C4 + n*0x0C` as the copied oc

; FD:B800..FD:B94F [strong] pass 53
ct_fd_seed_battle_slot_readiness_head_and_tail_partitions:
    ; TODO: lift real code/data for FD:B800..FD:B94F
    ; Unified seed routine for the contiguous readiness arrays. Fixed head loop seeds slots `0..2`. Tail loop seeds the later runtime-slot partiti

; FD:B820..FD:B850 [strong] pass 51
ct_fd_seed_visible_lane_readiness_from_speed_like_stat:
    ; TODO: lift real code/data for FD:B820..FD:B850
    ; Iterates selected visible participants. Clamps record byte `+0x38` to `0x10`. Uses the clamped value to index `CC:2E31`. Combines that table

; FD:B820..FD:B850 [strong] pass 52
ct_fd_seed_primary_visible_lane_readiness_from_config_and_speed:
    ; TODO: lift real code/data for FD:B820..FD:B850
    ; Primary visible-lane seed family. Computes page = `($2990 & 7)`. Loads adjustment from `CC:2E31[page*16 + speed - 1]`. Computes final seed: 

; FD:B820..FD:B850 [unspecified] pass 52
old_wording__seed_____from_speed_like_stat___________________soft_replaced_:
    ; TODO: lift real code/data for FD:B820..FD:B850
    ; Too narrow after config-field/page proof. Replaced by `ct_fd_seed_primary_visible_lane_readiness_from_config_and_speed`.

; FD:B8C0..FD:B8E0 [provisional] pass 51
ct_fd_seed_visible_lane_readiness_sibling_family:
    ; TODO: lift real code/data for FD:B8C0..FD:B8E0
    ; Structural sibling of `FD:B820..B850`. Writes to `B15B/AFAE` and sets `B03D`. Almost certainly the adjacent visible-lane seed family, but st

; FD:B8C0..FD:B8E0 [provisional] pass 52
ct_fd_seed_sibling_visible_lane_readiness_from_config_and_speed:
    ; TODO: lift real code/data for FD:B8C0..FD:B8E0
    ; Uses the same core formula as the primary family: `0x69 - speed*6 + adjustment` Stores to: `B15B` `AFAE` Sets `B03D` only when `AF02[slot] !

; FD:B8F5..FD:B93A [provisional] pass 53
ct_fd_normalize_head_readiness_work_before_visible_export:
    ; TODO: lift real code/data for FD:B8F5..FD:B93A
    ; This is the shared normalization/pre-export tail before the copy into `99DD..99DF` and `9F22..9F24`. Clearly head-export facing. Exact minim

; FD:B8F7..FD:B93A [strong] pass 54
ct_fd_normalize_active_battle_slot_readiness_to_minimum_one_before_head_export:
    ; TODO: lift real code/data for FD:B8F7..FD:B93A
    ; Real post-seed normalization body. Scans the unified work array `AFAB..AFB5`. Selects the smallest eligible **positive** entry. Computes sub

; FD:B91B..FD:B939 [provisional] pass 54
ct_fd_subtract_selected_minimum_minus_one_from_active_positive_readiness_entries:
    ; TODO: lift real code/data for FD:B91B..FD:B939
    ; This is the arithmetic heart of the normalization routine. Useful as an internal sublabel if the disassembly later wants finer block labels.

