; Chrono Trigger bank C0 skeleton
; Generated from current evidence. This is not a complete reassemblable bank yet.

.bank $C0

; C0:A270..C0:A335 [provisional] pass 48
ct_c0_parallel_source_plane_consumer_band:
    ; TODO: lift real code/data for C0:A270..C0:A335
    ; Not promoted to a final high-level subsystem name. But this band now has stronger proven structure: reads `7F:0C00/X`, `7F:0C80/X`, `7F:0E00

; C0:A2B0..A335 [unspecified] pass 47
consumer_path____________________________________________unlabeled_as_final_routine_:
    ; TODO: lift real code/data for C0:A2B0..A335
    ; Pass 47 found direct `0E00/0E80` read-side proof there. Exact routine entry and full higher-level purpose are still open. The consumer relat

