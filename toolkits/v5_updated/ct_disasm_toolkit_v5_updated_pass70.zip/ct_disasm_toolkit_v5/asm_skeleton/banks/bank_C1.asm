; Chrono Trigger bank C1 skeleton
; Generated from current evidence. This is not a complete reassemblable bank yet.

.bank $C1

; C1:011B [strong] pass 49
ct_c1_lsr3_entry:
    ; TODO: lift real code/data for C1:011B
    ; Mid-routine entry into the `LSR` helper band. Executes exactly three `LSR A` operations before `RTS`. Corrects pass 48’s earlier loose `>> 8

; C1:011F [strong] pass 48
ct_c1_format_u16_as_three_decimal_tile_bytes_949d_949f:
    ; TODO: lift real code/data for C1:011F
    ; Uses `9499` as the numeric working input. Repeatedly subtracts `0x64` and `0x0A` to derive hundreds/tens/ones. Maps those digits through `CC

; C1:0174 [strong] pass 48
ct_c1_format_u16_as_two_decimal_tile_bytes_949e_949f:
    ; TODO: lift real code/data for C1:0174
    ; Repeatedly subtracts `0x0A` to derive tens and ones. Maps through `CC:F903`. Emits tile bytes to `949E`, `949F` and blanks `949C`, `949D` wi

; C1:0299 [strong] pass 47
ct_c1_rebuild_full_companion_strip_0cc0:
    ; TODO: lift real code/data for C1:0299
    ; Begins by clearing/filling the full paired-byte `0CC0` strip. Stamps layout-dependent fixed glyphs based on `9F20`. Iterates the three lane 

; C1:06F0 [strong] pass 47
ct_c1_render_scaled_lane_bar_into_0cc0:
    ; TODO: lift real code/data for C1:06F0
    ; Uses `FA35[lane] + 0x1A` as the bar anchor. Scales per-lane state through the hardware divide helper at `C1:00D7`. Emits repeated `67` / `6F

; C1:06F0 [unspecified] pass 50
ct_c1_render_lane_active_time_gauge_into_0cc0:
    ; TODO: lift real code/data for C1:06F0
    ; Pass 47 proved this was a scaled segmented bar renderer. Pass 50 tightens the gameplay-facing meaning of that bar through the upstream produ

; C1:06F0 [unspecified] pass 50
old_wording__render_scaled_lane_bar_into_0CC0_______________replaced_:
    ; TODO: lift real code/data for C1:06F0
    ; Too generic after pass 50. The ROM now supports a materially harder gameplay-facing reading: active-time/readiness gauge renderer.

; C1:07BD [strong] pass 46
ct_c1_blit_companion_strip_template_a_into_0cc0_pair29:
    ; TODO: lift real code/data for C1:07BD
    ; Outer loop = 6 rows. Inner loop = 7 source bytes per row. Reads from `CC:FA41`. Writes source byte to `0CC0+Y`, then constant `0x29` to `0CC

; C1:07EE [strong] pass 46
ct_c1_blit_companion_strip_template_b_into_0cc0_pair29:
    ; TODO: lift real code/data for C1:07EE
    ; Same loop shape as `C1:07BD`. Reads from `CC:FA6B` instead of `CC:FA41`. Writes the same paired-byte pattern into the `0CC0` family.

; C1:07FD [strong] pass 45
ct_c1_compose_three_slot_panel_strip_into_0b40:
    ; TODO: lift real code/data for C1:07FD
    ; Checks the three active-roster entries `A6D9 / A6DA / A6DB`. For each occupied entry, calls `C1:0929` with one of three horizontal destinati

; C1:081F [strong] pass 46
ct_c1_compose_three_slot_panel_strip_into_0b40:
    ; TODO: lift real code/data for C1:081F
    ; Corrected entry boundary for the pass-45 panel-strip composer. Begins with `STZ $84`, checks `A6D9/A6DA/A6DB`, selects destination offsets i

; C1:086D [strong] pass 46
ct_c1_clear_current_companion_strip_slice_0cc0:
    ; TODO: lift real code/data for C1:086D
    ; Uses `95D5` to select a local slice. Clears two adjacent columns across six rows inside the `0CC0` companion strip family. Strongest safe re

; C1:08E8 [strong] pass 46
ct_c1_update_current_companion_strip_slice:
    ; TODO: lift real code/data for C1:08E8
    ; Writes back into the same `0CC0 / 0D00` companion-strip family after slice clear. Uses selector tables rooted at `CC:FA23`, `CC:FA29`, and `

; C1:08E8 [unspecified] pass 47
ct_c1_fill_current_companion_strip_slice_from_anchor_table:
    ; TODO: lift real code/data for C1:08E8
    ; Pass 46 proved this was a slice-local `0CC0` update helper. Pass 47 tightens that role: it selects an anchor from `FA23` or `FA29` then fill

; C1:0929 [strong] pass 45
ct_c1_blit_6row_panel_segment_into_0b40_merge_left_border:
    ; TODO: lift real code/data for C1:0929
    ; Dynamic `0B40` patcher using source data from `D1:59FC`. Writes 6 rows with a destination stride of `0x40` bytes per row. Copies either: 7 w

; C1:0958 [strong] pass 46
ct_c1_rebuild_companion_record_buffer_0e80:
    ; TODO: lift real code/data for C1:0958
    ; Clears exactly `0x0180` bytes at `0E80+Y`. Then enters a 3-iteration build loop calling `C1:09B0`. Strongest safe reading: rebuild a full-si

; C1:09B0 [strong] pass 46
ct_c1_emit_fixed_format_companion_record:
    ; TODO: lift real code/data for C1:09B0
    ; Checks the `C1:1580` per-entry control table. Copies 11 bytes from `CC:94A0` to `0B5E + 11*index` using `MVN`. Emits additional paired bytes

; C1:104E [strong] pass 48
ct_c1_blank_leading_zero_decimal_tiles_949d_949e:
    ; TODO: lift real code/data for C1:104E
    ; Converts tile `0x73` at `949D` to `0xFF`. Converts tile `0x73` at `949E` to `0xFF` only when `949D` is already blank. This is a leading-zero

; C1:1918 [strong] pass 47
ct_c1_refresh_current_0e80_lane_marker_glyphs:
    ; TODO: lift real code/data for C1:1918
    ; Clears the old marker block selected by `991F`. Stamps the current marker block selected by `95E5`. Writes `60/61/62/63` plus companion `29`

; C1:1B19 [strong] pass 43
ct_c1_service1_enqueue_lane_and_mark_record_active:
    ; TODO: lift real code/data for C1:1B19
    ; Local service-1 entry for the 3-lane controller. If the current lane is not already active in `A6D9[x]`, maps it through `CC:FAF0`,

; C1:1B69 [strong] pass 43
ct_c1_promote_pending_lane_into_active_roster:
    ; TODO: lift real code/data for C1:1B69
    ; Pulls the head of the pending lane queue at `95D6` into the active roster. Clears `9F38[lane]`, seeds small per-lane state bytes, stores the

; C1:1BAA [strong] pass 43
ct_c1_service2_remove_lane_and_reseat_active_controller:
    ; TODO: lift real code/data for C1:1BAA
    ; Local service-2 entry for the same 3-lane controller. Deletes the input lane from either: the pending-admission queue (`95D6..95D8`), or the

; C1:1C3A [strong] pass 43
ct_c1_service2_restore_workspace_template_0b40:
    ; TODO: lift real code/data for C1:1C3A
    ; Common tail reached from service 2. Copies `0x180` bytes from `D1:5800` into WRAM rooted at `0B40`. Exact high-level meaning of the workspac

; C1:1C3A [strong] pass 44
ct_c1_service2_restore_default_tilemap_template_0b40:
    ; TODO: lift real code/data for C1:1C3A
    ; Strengthened from pass 43. No longer just “restore workspace template.” Specifically restores the default `0x180`-byte tilemap/upload templa

; C1:8C0A..C1:8C37 [strong] pass 57
ct_iterate_live_unwithheld_tail_entries_for_dispatch:
    ; TODO: lift real code/data for C1:8C0A..C1:8C37
    ; Consumes tail entries only when: `AF15.bit7` is clear `AF02[x] != FF` `B2B6[x] == 0` Passes the live occupant ID in `AF02[x]` to `AFD2`. Con

; C1:8C0A..C1:8CF7 [strong] pass 61
ct_replay_tail_pack_segments_and_record_per_tail_state:
    ; TODO: lift real code/data for C1:8C0A..C1:8CF7
    ; Front-end clears/rebuilds per-tail replay state for the live, unwithheld tail map. Records executed global opcode bytes into `ct_tail_last_e

; C1:8EA7..C1:8EAA [strong] pass 62
ct_global_opcode_00_unconditional_tail_replay_step:
    ; TODO: lift real code/data for C1:8EA7..C1:8EAA
    ; Direct body is only: `JSR $8C3E ; RTS`. Global opcode `00` is therefore an unconditional handoff into the tail replay/controller layer. This

; C1:9012..C1:9043 [provisional] pass 57
ct_gate_tail_dispatch_by_live_unwithheld_count:
    ; TODO: lift real code/data for C1:9012..C1:9043
    ; Counts tail entries where: `AF02[x] != FF` `AF15[x] == 0` Compares that count against a descriptor byte from `CC:[B1D2 + 1]`. Dispatches to 

; C1:9013..C1:9043 [strong] pass 62
ct_global_opcode_05_gate_tail_replay_by_live_unwithheld_tail_count_max:
    ; TODO: lift real code/data for C1:9013..C1:9043
    ; Reads one immediate operand byte from `CC:[B1D2 + 1]`. Counts tail entries where: `AF02[x] != FF` and `AF15[x] == 0` Success path is taken w

; C1:9045..C1:9081 [strong] pass 62
ct_global_opcode_06_gate_tail_replay_when_96f1_96f3_triplet_gte_immediate:
    ; TODO: lift real code/data for C1:9045..C1:9081
    ; Reads a 3-byte immediate operand from `CC:[B1D2 + 1..3]`. Compares that operand lexicographically against current WRAM bytes: `96F1` `96F2` 

; C1:9082..C1:90BD [strong] pass 62
ct_global_opcode_07_gate_tail_replay_on_current_b320_compare_mode:
    ; TODO: lift real code/data for C1:9082..C1:90BD
    ; Reads compare byte from `CC:[B1D2 + 1]` and mode byte from `CC:[B1D2 + 2]`. Uses current slot index `B252` to read `B320[B252]`. Proven comp

; C1:97AB..C1:97BF [strong] pass 62
ct_global_opcode_20_gate_tail_replay_on_current_aeb3_nonzero:
    ; TODO: lift real code/data for C1:97AB..C1:97BF
    ; Uses current index `B252`. Reads `AEB3[B252]`. Success only when that byte is nonzero. Success -> `JSR $8C3E` Failure -> `AF24 = 1` Final ga

; C1:97C0..C1:97D4 [strong] pass 62
ct_global_opcode_21_gate_tail_replay_on_current_af15_zero:
    ; TODO: lift real code/data for C1:97C0..C1:97D4
    ; Immediate adjacent sibling of opcode `20`. Uses current index `B252`. Success only when `AF15[B252] == 0`. Success -> `JSR $8C3E` Failure ->

; C1:9E78 [unspecified] pass 56
ct_g2_cmd10_materialize_tail_slots_from_canonical_map:
    ; TODO: lift real code/data for C1:9E78
    ; Earlier passes already proved the scan gates: `AF0D[x] != FF` `AF02[x] == FF` `AF15.bit7` clear Pass 56 upgrades the noun: this command mate

; C1:AAAB..C1:AAF8 [strong] pass 58
ct_fixed_single_entry_selector_wrappers_3_through_10:
    ; TODO: lift real code/data for C1:AAAB..C1:AAF8
    ; Family of tiny wrappers: `AECC = literal` `AECB = 1` `RTS` Covered literal values: `3..10`.

; C1:AB03..C1:AB49 [strong] pass 57
ct_build_withheld_tail_candidate_list_and_random_reduce_to_one:
    ; TODO: lift real code/data for C1:AB03..C1:AB49
    ; Scans all 8 tail entries. Collects slot indices with `AF15.bit7` set into `AECC`. Stores the candidate count in `AECB`. If `AECB >= 2`, uses

; C1:AB4E..C1:AB90 [strong] pass 58
ct_fixed_single_entry_selector_wrappers_0_through_6:
    ; TODO: lift real code/data for C1:AB4E..C1:AB90
    ; Family of tiny wrappers: `AECC = literal` `AECB = 1` `RTS` Covered literal values: `0..6`.

; C1:AB9B..C1:ABC8 [strong] pass 58
ct_select_one_visible_entry_0_1_2_by_min_lane_value:
    ; TODO: lift real code/data for C1:AB9B..C1:ABC8
    ; Compares three lane-local values: `5E30` `5EB0` `5F30` Selects exactly one visible entry index: `0`, `1`, or `2` Stores that selected entry 

; C1:ABC9..C1:AC13 [strong] pass 58
ct_build_live_tail_slot_candidate_list_and_random_reduce_to_one:
    ; TODO: lift real code/data for C1:ABC9..C1:AC13
    ; Scans the unified live occupant map starting at slot index `3`. Uses `B252 + 3` as the upper live-tail bound. Appends non-`FF` live slot ind

; C1:AC14..C1:AC45 [strong] pass 59
ct_resolve_inline_selector_control_byte_into_selection_result:
    ; TODO: lift real code/data for C1:AC14..C1:AC45
    ; Reads the next selector-control byte from the CC stream. If negative, uses the preset path through `AED8`. Otherwise dispatches through `ct_

; C1:AED3..C1:AEFB [strong] pass 57
ct_materialize_deferred_tail_entry_by_canonical_occupant_id:
    ; TODO: lift real code/data for C1:AED3..C1:AEFB
    ; Scans tail slots `0..7`. Matches target occupant ID in `$0E` against the canonical tail map `AF0D[x]`. Requires that the live tail map `AF02

; C1:AFD7..C1:B08E [strong] pass 60
ct_execute_late_selector_pack_and_capture_tail_result:
    ; TODO: lift real code/data for C1:AFD7..C1:B08E
    ; Top-level late-family executor proved in this pass. Loads a pointer from `ct_late_selector_control_pointer_records`. Uses `B4AA` to select/a

; C1:B094..C1:B0B3 [provisional] pass 49
ct_c1_update_lane_low_hp_threshold_flag:
    ; TODO: lift real code/data for C1:B094..C1:B0B3
    ; Previously part of a vague flag-maintenance band. Pass 49 proves this exact routine clears and re-establishes `5E2F.bit0` from the `maxHP/8`

; C1:B279..C1:B2C0 [provisional] pass 55
ct_c1_restore_or_clear_live_battle_slot_occupant_from_default_map:
    ; TODO: lift real code/data for C1:B279..C1:B2C0
    ; Strong structure: restores `AEFF[Y]` from `AF0A[Y]` when a remembered occupant exists later clears `AEFF[Y] = FF` on failure/removal path Ke

; C1:B390 [strong] pass 51
ct_c1_seed_lane_gauge_exports_from_b158:
    ; TODO: lift real code/data for C1:B390
    ; Directly mirrors `B158,Y` into: `AFAB,Y` `99DD,Y` `9F22,Y` Strongest safe reading: direct seed/export mirror from the upstream readiness see

; C1:B4AA..C1:B4E6 [strong] pass 60
ct_select_tail_local_segment_within_late_selector_pack:
    ; TODO: lift real code/data for C1:B4AA..C1:B4E6
    ; Previously just an opaque helper reached from the late family. Pass 60 proves it is the segment-selection / pointer-adjust helper that sits 

; C1:B575 [strong] pass 42
ct_c1_service7_reconcile_canonical_record_lane_pairs:
    ; TODO: lift real code/data for C1:B575
    ; Initializes `B3EB..B3F3` to `FF`, seeds root lane IDs `0/1/2`, This is the concrete front-end of the downstream `93F3` family.

; C1:B725 [strong] pass 50
ct_c1_init_lane_active_time_gauge_exports:
    ; TODO: lift real code/data for C1:B725
    ; Clears the visible lane-progress exports `99DD..99DF`. Seeds the visible lane-threshold/cap exports `9F22..9F24` to `0x30`. Also resets the 

; C1:B80D..C1:B95F [strong] pass 61
ct_c1_master_opcode_dispatch_table:
    ; TODO: lift real code/data for C1:B80D..C1:B95F
    ; Root indexed `JSR` table used by the late-pack executor. Interior slices line up exactly with the previously solved local tables. Current pr

; C1:B85F..C1:B88C [strong] pass 61
ct_c1_group1_opcode_dispatch_slice:
    ; TODO: lift real code/data for C1:B85F..C1:B88C
    ; Keep the useful local group-1 numbering from earlier passes. But this is now proved to be a slice entrypoint inside `ct_c1_master_opcode_dis

; C1:B88D..C1:B8BA [strong] pass 61
ct_c1_group2_opcode_dispatch_slice:
    ; TODO: lift real code/data for C1:B88D..C1:B8BA
    ; Same correction as the group-1 table. Useful local numbering remains valid. Root ownership now belongs to `ct_c1_master_opcode_dispatch_tabl

; C1:B8BB..C1:B95F [strong] pass 59
ct_inline_selector_control_dispatch_table:
    ; TODO: lift real code/data for C1:B8BB..C1:B95F
    ; Directly dispatched by `C1:AC2E  JSR ($B8BB,X)`. `X` is formed from the non-negative inline selector-control byte read by `AC14`. Proven tab

; C1:B8BB..C1:B95F [strong] pass 61
ct_c1_inline_selector_control_dispatch_slice:
    ; TODO: lift real code/data for C1:B8BB..C1:B95F
    ; Same correction again for the selector-control table. `AC14` still dispatches here by local selector-control byte. But this slice is inside 

; C1:B8F3..C1:B92B [provisional] pass 58
ct_selector_wrapper_table_candidate:
    ; TODO: lift real code/data for C1:B8F3..C1:B92B
    ; Coherent pointer run of 29 entries: dynamic selector wrappers fixed single-entry wrappers `AB03` `AB9B` `ABC9` Strongly looks like a real lo

; C1:B961 [strong] pass 42
ct_c1_local_service2_wrapper:
    ; TODO: lift real code/data for C1:B961
    ; Exact wrapper: `LDA #$02` `JSR $0003` `RTL` Invokes local service 2 through the bank-C1 dispatcher.

; C1:BD6F [strong] pass 50
ct_c1_apply_status_modifiers_to_lane_time_increment:
    ; TODO: lift real code/data for C1:BD6F
    ; Starts from `AFAB[x]`. Halves it when the `5E4D|5E52` status family has bit `0x80` set. Doubles it with saturation when `5E4B` bit `0x20` is

; C1:BDE0..C1:BF25 [unspecified] pass 50
ct_c1_advance_lane_active_time_gauge_and_ready_transition_family:
    ; TODO: lift real code/data for C1:BDE0..C1:BF25
    ; Three sibling update families that: seed `AFAB` from `B158` apply `BD6F` advance one or both lane-bar exports with saturation set/update lan

; C1:C90B [strong] pass 52
ct_c1_mul_u16_dp28_dp2a_to_dp2c_lowword:
    ; TODO: lift real code/data for C1:C90B
    ; Shift/add multiply helper. Consumes 16-bit inputs in `$28` and `$2A`. Writes the low word of the product to `$2C`. This is the real arithmet

; C1:CC74..C1:CCC5 [provisional] pass 49
ct_c1_lane_selected_resource_spend_on_5e34_family:
    ; TODO: lift real code/data for C1:CC74..C1:CCC5
    ; Subtracts a computed quantity from exactly one of: `5E34` `5EB4` `5F34` Strongly looks like a lane-selected spend/update path for the field 

; C1:FB06..C1:FB2C [provisional] pass 55
ct_c1_rebuild_head_battle_slot_occupant_maps_with_extra_guard:
    ; TODO: lift real code/data for C1:FB06..C1:FB2C
    ; Same structural model as `FD:B24D..B27E`. Extra exclusion via `A09B[X]` is proven. Final caller-facing subsystem name still wants one more p

; C1:FDBF [strong] pass 52
ct_c1_jsl_mul_u16_dp28_dp2a_to_dp2c_lowword:
    ; TODO: lift real code/data for C1:FDBF
    ; Thin long-call wrapper: `JSR $C90B` `RTL` Useful because the seed families call it twice with different inputs.

