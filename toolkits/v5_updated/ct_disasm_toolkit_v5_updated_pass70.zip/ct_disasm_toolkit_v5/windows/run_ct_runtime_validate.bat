@echo off
python scripts/ct_runtime_validate.py %*
