@echo off
python scripts\ct_build_xref_cache.py --targets targets\hot_xref_targets.txt --output data\ct_hot_xref_cache.json
