@echo off
python scripts/ct_source_state_report.py %*
