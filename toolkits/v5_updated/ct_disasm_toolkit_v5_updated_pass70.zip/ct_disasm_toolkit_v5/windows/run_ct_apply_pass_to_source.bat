@echo off
python scripts/ct_apply_pass_to_source.py %*
