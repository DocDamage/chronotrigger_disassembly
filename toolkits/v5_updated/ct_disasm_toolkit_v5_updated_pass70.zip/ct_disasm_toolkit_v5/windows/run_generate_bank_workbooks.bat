@echo off
python scripts\ct_generate_bank_workbooks.py --output-dir bank_workbooks
