@echo off
if "%~1"=="" goto :usage
python scripts\ct_addr.py %1 %2 %3 %4 %5
goto :eof
:usage
echo Usage: windows\run_addr.bat C1:B80D
