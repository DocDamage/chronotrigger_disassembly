@echo off
python scripts/ct_completion_score.py --root . --db data/ct_label_db.sqlite --output-json reports/completion/ct_completion_score.json --output-md reports/ct_completion_score.md
