@echo off
python scripts\ct_make_opcode_csv.py --output-dir data
