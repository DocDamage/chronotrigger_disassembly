@echo off
python scripts/ct_rebuild_diff.py %*
