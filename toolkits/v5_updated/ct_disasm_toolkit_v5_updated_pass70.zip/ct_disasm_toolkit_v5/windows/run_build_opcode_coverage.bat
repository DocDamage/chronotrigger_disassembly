@echo off
python scripts\ct_build_opcode_coverage.py --data-dir data
