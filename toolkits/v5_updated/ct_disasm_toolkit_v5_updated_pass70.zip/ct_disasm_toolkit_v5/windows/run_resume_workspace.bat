@echo off
python scripts\ct_resume_workspace.py --workdir .
