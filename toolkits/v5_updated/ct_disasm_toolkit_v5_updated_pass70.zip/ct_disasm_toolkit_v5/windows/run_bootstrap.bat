@echo off
python scripts\ct_session_bootstrap.py --workdir .
