@echo off
python scripts/ct_generate_asm_skeleton.py --root . --db data/ct_label_db.sqlite --output-dir asm_skeleton/banks
