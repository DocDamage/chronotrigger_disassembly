@echo off
python scripts\ct_export_label_db_json.py --db data\ct_label_db.sqlite --output data\ct_label_db.json
