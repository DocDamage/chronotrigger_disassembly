@echo off
python scripts\ct_make_report.py --root . --db data\ct_label_db.sqlite --output reports\ct_workspace_report.md --state-json state\current_state.json
