@echo off
python scripts\ct_build_label_db.py --dir . --output data\ct_label_db.sqlite
