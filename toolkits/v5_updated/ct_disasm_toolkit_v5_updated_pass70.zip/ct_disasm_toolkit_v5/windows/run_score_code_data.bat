@echo off
python scripts/ct_score_code_data.py --root . --db data/ct_label_db.sqlite --output-json reports/code_data_score.json --output-md reports/code_data_score.md
