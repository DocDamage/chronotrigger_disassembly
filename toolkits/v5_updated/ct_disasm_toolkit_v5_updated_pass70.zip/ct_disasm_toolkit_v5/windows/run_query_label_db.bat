@echo off
python scripts\ct_query_label_db.py %*
