@echo off
python scripts/ct_detect_conflicts.py --root . --db data/ct_label_db.sqlite --output-md reports/ct_conflict_report.md --output-csv reports/conflicts/ct_conflicts.csv
