@echo off
python scripts/ct_generate_bank_dossiers.py --root . --db data/ct_label_db.sqlite --output-dir dossiers
