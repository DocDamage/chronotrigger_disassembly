@echo off
python scripts/ct_generate_unresolved_dashboard.py %*
