@echo off
python scripts/ct_freeze_ranges.py %*
