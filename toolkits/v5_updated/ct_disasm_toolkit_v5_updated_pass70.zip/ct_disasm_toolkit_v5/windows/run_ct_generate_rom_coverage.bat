@echo off
python scripts/ct_generate_rom_coverage.py %*
