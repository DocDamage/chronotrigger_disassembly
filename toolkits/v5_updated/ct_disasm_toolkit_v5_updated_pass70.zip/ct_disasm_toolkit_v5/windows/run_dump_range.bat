@echo off
if "%~1"=="" goto :usage
python scripts\ct_dump_range.py %1 %2 %3 %4 %5 %6 %7 %8
goto :eof
:usage
echo Usage: windows\run_dump_range.bat C1:B80D --length 0x80 --width 16
