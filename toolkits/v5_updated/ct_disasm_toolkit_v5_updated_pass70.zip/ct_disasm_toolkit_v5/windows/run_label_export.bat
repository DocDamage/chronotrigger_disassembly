@echo off
python scripts\ct_export_label_db.py --dir . --output data\ct_label_db_starter.csv
