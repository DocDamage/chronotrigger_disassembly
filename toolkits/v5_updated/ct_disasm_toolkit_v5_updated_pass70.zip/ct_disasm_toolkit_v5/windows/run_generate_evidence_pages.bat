@echo off
python scripts/ct_generate_evidence_pages.py --root . --db data/ct_label_db.sqlite --output-dir evidence_pages/global_opcodes
