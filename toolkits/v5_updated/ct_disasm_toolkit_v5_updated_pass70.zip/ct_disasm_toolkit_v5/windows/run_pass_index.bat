@echo off
python scripts\ct_pass_index.py --dir .
