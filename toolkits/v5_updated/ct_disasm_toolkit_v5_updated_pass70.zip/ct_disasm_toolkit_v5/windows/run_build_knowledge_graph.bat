@echo off
python scripts/ct_build_knowledge_graph.py --root . --db data/ct_label_db.sqlite --output-json graph/ct_knowledge_graph.json --summary-md graph/ct_knowledge_graph_summary.md
