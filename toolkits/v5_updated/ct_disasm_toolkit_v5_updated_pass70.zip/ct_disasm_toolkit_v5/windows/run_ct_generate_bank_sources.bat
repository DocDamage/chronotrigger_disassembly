@echo off
python scripts/ct_generate_bank_sources.py %*
