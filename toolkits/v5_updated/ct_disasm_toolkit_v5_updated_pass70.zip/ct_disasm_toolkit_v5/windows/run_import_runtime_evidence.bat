@echo off
python scripts/ct_import_runtime_evidence.py --root . --trace-dir traces/imported --db data/ct_label_db.sqlite --summary-json reports/runtime/runtime_evidence_summary.json --summary-md reports/runtime/runtime_evidence_summary.md
