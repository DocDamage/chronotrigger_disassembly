@echo off
python scripts\ct_label_diff.py %1 %2
