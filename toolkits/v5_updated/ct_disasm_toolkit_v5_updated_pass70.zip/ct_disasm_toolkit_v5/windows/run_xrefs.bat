@echo off
if "%~2"=="" goto :usage
python scripts\ct_xrefs.py %1 --mode %2 %3 %4 %5 %6 %7 %8
goto :eof
:usage
echo Usage: windows\run_xrefs.bat C1:B80D calls
