# Tool Manifest

## Core toolkit layers
- V1/V2 helper scripts: address conversion, dumps, xrefs, pass scaffolding
- V3 state layer: label DB, query/diff, opcode coverage, bank workbooks, resume bootstrap
- V4 evidence layer: runtime evidence import, graph build, bank dossiers, evidence pages, code/data scoring, assembler skeletons, conflict scan, completion scoring

## Highest-value startup commands
```bash
python3 scripts/ct_resume_workspace.py --workdir .
python3 scripts/ct_query_label_db.py --db data/ct_label_db.sqlite --contains master_opcode
python3 scripts/ct_detect_conflicts.py --root . --db data/ct_label_db.sqlite
```

## V5 additions
- scripts/ct_generate_bank_sources.py
- scripts/ct_freeze_ranges.py
- scripts/ct_runtime_validate.py
- scripts/ct_generate_unresolved_dashboard.py
- scripts/ct_generate_rom_coverage.py
- scripts/ct_rebuild_diff.py
- scripts/ct_apply_pass_to_source.py
- scripts/ct_source_state_report.py
- source/
- state/range_freeze.json

## Maintenance refresh additions
- scripts/ct_dispatch_family_report.py
- scripts/ct_trace_dispatcher.py
- scripts/ct_apu_packet_summary.py
- dynamic evidence-weighted completion scoring
- fixed latest-pass/current-seam propagation in workspace + unresolved reports

## Runtime evidence refresh additions
- scripts/ct_runtime_capture_plan.py
- recursive trace import with richer CSV/JSON/text parsing
- weighted runtime validation report
- targets/runtime_capture_profiles.json
- traces/templates/*runtime*
- notes/runtime_evidence_workflow.md
