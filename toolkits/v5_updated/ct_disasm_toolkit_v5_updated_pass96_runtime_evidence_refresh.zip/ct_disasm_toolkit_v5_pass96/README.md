# Chrono Trigger ROM Disassembly Toolkit v5

This is the **source-construction and validation layer** on top of the V4 evidence workspace.

V4 turned pass notes into structured evidence.
V5 turns that evidence into a **maintainable source workspace**, **range-freeze map**,
**runtime validation reports**, **ROM coverage views**, and a **rebuild/diff scaffold**.

## What v5 adds
- generated `source/` tree with per-bank source scaffolds and symbol includes
- range freeze / lock system seeded from strong evidence
- pass-to-source merge helper
- runtime validation report against imported trace evidence
- ROM coverage map in Markdown + HTML
- unresolved-work dashboard
- runtime capture plan + debugger evidence templates for WRAM and APU tracing
- rebuild/diff scaffold that can compare a rebuilt ROM once assembler integration exists
- source-state manifest and index

## Current project anchor
This toolkit is aligned to the current project state where:
- **Pass 96** is the latest completed pass in the bundled notes
- the active work sits in the **C7 low-bank sound/APU seam** around `0155`, the `0x18..0x3F` bridge, and the sound-slot/APU helper chain right after it
- the pass-94/95 noun upgrade on the low-bank/C7 side is real: this is now a sound/APU packet workspace and dispatcher family, not generic low-bank packet machinery
- the required first move before new naming work is still to refresh the current seam from `notes/next_session_start_here.md` and the generated reports, not from stale README anchors

## Suggested startup
1. Read `notes/community_research_first.md`
2. Run:
   ```bash
   python3 scripts/ct_resume_workspace.py --workdir .
   ```
3. Then read:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `reports/ct_unresolved_dashboard.md`
   - `reports/ct_rom_coverage.md`
   - `reports/ct_source_state.md`
   - `reports/ct_rebuild_diff_report.md`
   - `dossiers/C1_dossier.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `notes/next_session_start_here.md`
4. Resume from `notes/next_session_start_here.md`; for the bundled state that means tightening `0155` and the immediate `0x18..0x3F` bridge while the C7 send path is warm, then circling back to `CE0F`.

## ROM handling
The toolkit does **not** bundle the ROM.
Place your own `Chrono Trigger (USA).sfc` beside the toolkit when doing local work.
Expected fingerprint for the working ROM:
- CRC32: `2D206BF7`
- MD5: `a2bc447961e52fd2227baed164f729dc`

## Honest limitation
V5 gives you a real **source workspace scaffold** and a **rebuild comparison hook**,
but it still does **not** ship a finished Chrono Trigger assembler toolchain. The rebuild
report is intentionally a scaffold until you bind it to your preferred assembler.
