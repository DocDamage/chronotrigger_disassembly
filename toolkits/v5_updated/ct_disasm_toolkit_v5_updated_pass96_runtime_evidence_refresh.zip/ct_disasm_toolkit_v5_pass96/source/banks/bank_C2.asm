; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_C2
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; C2:0003  top-status=strong  labels=1
; =============================================================================
; [strong] pass 93 :: ct_c2_branch_to_57df_stream_state_initializer_veneer
; qualifier: strong
; notes: Exact body: `JMP $57DF`. Lands at exact target `C2:57DF`. Strongest safe reading: veneer for the stream-state initializer behind the `CD:025E` dual-call tail.
; source: chrono_trigger_labels_pass93.md
C2_0003_ct_c2_branch_to_57df_stream_state_initializer_veneer:
    ; TODO: reconstruct body / data for C2:0003
    ; known span hint: C2:0003..C2:0005

; =============================================================================
; C2:0009  top-status=strong  labels=1
; =============================================================================
; [strong] pass 93 :: ct_c2_branch_to_5823_stream_token_dispatch_stage_veneer
; qualifier: strong
; notes: Exact body: `JMP $5823`. Lands at exact target `C2:5823`. Strongest safe reading: veneer for the token/stream dispatch stage immediately following `C2:0003` in the `CD:025E` follow-up chain.
; source: chrono_trigger_labels_pass93.md
C2_0009_ct_c2_branch_to_5823_stream_token_dispatch_stage_veneer:
    ; TODO: reconstruct body / data for C2:0009
    ; known span hint: C2:0009..C2:000B

; =============================================================================
; C2:57DF  top-status=strong  labels=1
; =============================================================================
; [strong] pass 93 :: ct_c2_init_stream_state_from_020c_0214_packet_workspace
; qualifier: strong structural
; notes: Exact prologue saves flags and direct page, then sets `D = 0x0200`. Treats `020C` as an index/selector: masks it to `00FF` doubles it uses it as `Y` Reads a **16-bit entry** through exact long-indirect pointer `[020D],Y` and stores that into `0231`. Copies exact byte `020F -> 0233`. Therefore proves the live `020D..020F` packet family is consumed as a long pointer base for the selected stream/table entry. Seeds exact local state: `0230 = 00` `0234 = 00` or `08` depending on exact comparison of `0214` with `02` if `0214` is negative, forcibly clears `0234` `0215 = 04` `023D = 0200` `023F = 00` `0217 = 00` Returns immediately with `RTL` after the seed. Strongest safe reading: exact stream-state initializer behind the `020C..0214` packet/workspace family used by `CD:025E` before `C2:0009` runs.
; source: chrono_trigger_labels_pass93.md
C2_57DF_ct_c2_init_stream_state_from_020c_0214_packet_workspace:
    ; TODO: reconstruct body / data for C2:57DF
    ; known span hint: C2:57DF..C2:5822

; =============================================================================
; C2:5823  top-status=strong  labels=1
; =============================================================================
; [strong] pass 93 :: ct_c2_dispatch_prepared_stream_state_into_four_handler_families
; qualifier: strong structural
; notes: Exact prologue saves flags and direct page, then sets `D = 0x0200`. Calls exact local helper `JSR $584A`. If that helper returns carry set, exits immediately. Otherwise reads exact local mode/state byte `0230`. Doubles that byte and dispatches through the exact four-entry table at `5842`: `58B2` `5BF5` `5C3E` `5C77` Clears `A` on the common exit path, restores state, then returns with `RTL`. Strongest safe reading: exact token/stream dispatch stage over the state seeded by `57DF`, with four concrete downstream handler families.
; source: chrono_trigger_labels_pass93.md
C2_5823_ct_c2_dispatch_prepared_stream_state_into_four_handler_families:
    ; TODO: reconstruct body / data for C2:5823
    ; known span hint: C2:5823..C2:5841

; =============================================================================
; C2:584A  top-status=strong  labels=1
; =============================================================================
; [strong] pass 94 :: ct_c2_dispatch_0215_substate_through_micro_jump_gate_before_main_token_family_split
; qualifier: strong structural
; notes: Exact opening body: loads `0215` doubles it uses exact indexed indirect jump `JMP ($5851,X)` Therefore this range is a **pure substate jump gate**, not generic arithmetic. The table collapses to a small exact set of entry bodies: `5893` = `SEC ; RTS` `5895` = immediate clear-carry continue path via `BRA` into `CLC ; RTS` `5897` / `589B` = two entry points into the same seed/update body that: seed `0234` with `08` or `14` clear `0217` subtract `08` from `0234` when `(0214 & 0x0F) == 0x02` return with clear carry Strongest safe reading: exact `0215`-driven pre-dispatch micro-gate that either forces early exit by carry or prepares local state and returns “continue”.
; source: chrono_trigger_labels_pass94.md
C2_584A_ct_c2_dispatch_0215_substate_through_micro_jump_gate_before_main_token_family_split:
    ; TODO: reconstruct body / data for C2:584A
    ; known span hint: C2:584A..C2:58B1

; =============================================================================
; C2:58B2  top-status=strong  labels=1
; =============================================================================
; [strong] pass 94 :: ct_c2_consume_next_stream_token_and_dispatch_primary_token_families
; qualifier: strong structural
; notes: Exact opening behavior: reads the next byte through direct-indirect pointer `[0231]` increments the live stream pointer at `0231` then splits on the token value Exact family split now frozen: `token >= 0xA0` stores token into `0235` calls exact local helper `JSR $5DC4` decrements `0213` loops this path while `0213` remains nonzero then sets `0215 = 0x10` and returns `0x21 <= token < 0xA0` stores raw token into `023B` indexes the exact long table rooted at `DE:FA00` seeds `0237/0239/023A` sets `0230 = 0x01` jumps directly into `5BF5` `token < 0x21` dispatches through the exact local jump table rooted at `5903` Strongest safe reading: exact primary stream-token consumer / dispatcher behind the `57DF -> 5823` chain.
; source: chrono_trigger_labels_pass94.md
C2_58B2_ct_c2_consume_next_stream_token_and_dispatch_primary_token_families:
    ; TODO: reconstruct body / data for C2:58B2
    ; known span hint: C2:58B2..C2:5902

; =============================================================================
; C2:5BF5  top-status=strong  labels=1
; =============================================================================
; [strong] pass 95 :: ct_c2_consume_first_downstream_long_stream_family_into_0235_then_route_by_023a_0213_exhaustion
; qualifier: strong structural
; notes: Consumes the active long-pointer stream through exact direct-page indirect-long reads from `[0237]`. Advances the live pointer by exact `INC 0237` steps. Materializes the consumed entry into exact local word `0235`. Calls exact shared helper `JSR $5DC4`. Decrements exact counters `023A` and `0213`. Reduces their post-decrement zero/nonzero state to a four-way indexed jump through the exact table at `5C28`. Exact four-way outcomes now frozen: both exhausted -> force `0215 = 0x10`, return `023A` remains but `0213` exhausted -> store the live tail state directly into `0215`, return `023A` exhausted but `0213` remains -> jump back to `58B2` both remain -> enter the next downstream family at `5C3C/5C3E` Strongest safe reading: first downstream long-stream family behind `58B2`, routing by the exact exhaustion state of `023A` and `0213`.
; source: chrono_trigger_labels_pass95.md
C2_5BF5_ct_c2_consume_first_downstream_long_stream_family_into_0235_then_route_by_023a_0213_exha:
    ; TODO: reconstruct body / data for C2:5BF5
    ; known span hint: C2:5BF5..C2:5C3D

; =============================================================================
; C2:5C3E  top-status=strong  labels=1
; =============================================================================
; [strong] pass 95 :: ct_c2_consume_second_downstream_long_stream_family_with_exact_c2d4_rebase_before_shared_materializer
; qualifier: strong structural
; notes: Consumes the next entry from the same exact long pointer `[0237]`. Adds exact base `C2:D4` before storing the word into `0235`. Calls the same exact shared helper `JSR $5DC4`. Decrements the same exact counters `023A` and `0213`. Dispatches through the exact four-entry jump table at `5C61`. Exact outcomes now frozen: case 0 -> clears `0230`, forces `0215 = 0x10`, returns case 1 -> forces `0215 = 0x10`, returns case 2 -> clears `0230`, jumps back to `58B2` case 3 -> branches directly into the third family at `5C77` Strongest safe reading: second downstream long-stream family with an exact `+C2D4` rebasing step before the shared materializer runs.
; source: chrono_trigger_labels_pass95.md
C2_5C3E_ct_c2_consume_second_downstream_long_stream_family_with_exact_c2d4_rebase_before_shared_:
    ; TODO: reconstruct body / data for C2:5C3E
    ; known span hint: C2:5C3E..C2:5C76

; =============================================================================
; C2:5C77  top-status=strong  labels=1
; =============================================================================
; [strong] pass 95 :: ct_c2_consume_terminal_downstream_long_stream_family_and_self_loop_while_both_counters_remain_live
; qualifier: strong structural
; notes: Reuses the same exact long pointer `[0237]`, exact `0235` materialization, exact `JSR $5DC4`, and exact decrement pair `023A` / `0213`. Dispatches through the exact four-entry jump table at `5CAA`. Exact outcomes now frozen: case 0 -> clears `0230`, forces `0215 = 0x10`, returns case 1 -> forces `0215 = 0x10`, returns case 2 -> clears `0230`, jumps back to `58B2` case 3 -> branches back into `5C77` itself Strongest safe reading: terminal self-looping downstream family in the chained C2 long-stream stage.
; source: chrono_trigger_labels_pass95.md
C2_5C77_ct_c2_consume_terminal_downstream_long_stream_family_and_self_loop_while_both_counters_r:
    ; TODO: reconstruct body / data for C2:5C77
    ; known span hint: C2:5C77..C2:5CBF

; =============================================================================
; C2:5D1D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 95 :: ct_c2_scan_active_long_stream_for_exact_ef_or_00_sentinels_with_bounded_lengths
; qualifier: strong
; notes: Contains three exact bounded scanners over `[0237],Y`: scan for `0xEF` up to `Y == 0x000A` scan for `0xEF` up to `Y == 0x000B` scan for `0x00` up to `Y == 0x0005` Each returns the exact `Y` position. Strongest safe reading: local bounded sentinel-scan helper cluster used to derive inner counts from the active long stream.
; source: chrono_trigger_labels_pass95.md
C2_5D1D_ct_c2_scan_active_long_stream_for_exact_ef_or_00_sentinels_with_bounded_lengths:
    ; TODO: reconstruct body / data for C2:5D1D
    ; known span hint: C2:5D1D..C2:5D55

