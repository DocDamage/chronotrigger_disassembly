; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: wram_7F
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; 7F:01EC  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 92 :: ct_c0_multi_packet_submit_special_case_selector_byte
; qualifier: provisional strengthened
; notes: Pass 92 proves `C0:1BE6..1CFB` only treats exact value `1` specially. That exact special case then still requires `2A1F.bit5 == 0` before selecting the alternate packet body at `1C90`. Strongest safe reading: special-case selector byte for the sibling gated multi-packet submit helper.
; source: chrono_trigger_labels_pass92.md
L_7F_01EC_ct_c0_multi_packet_submit_special_case_selector_byte:
    ; TODO: reconstruct body / data for 7F:01EC

