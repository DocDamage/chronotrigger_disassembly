; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_C7
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; C7:0004  top-status=strong  labels=1
; =============================================================================
; [strong] pass 93 :: ct_c7_branch_to_0140_low_bank_packet_dispatcher_veneer
; qualifier: strong
; notes: Exact body: `JMP $0140`. Lands at exact target `C7:0140`. Strongest safe reading: veneer for the low-bank packet opcode-family dispatcher behind all the `1E00..` command-packet submit helpers.
; source: chrono_trigger_labels_pass93.md
C7_0004_ct_c7_branch_to_0140_low_bank_packet_dispatcher_veneer:
    ; TODO: reconstruct body / data for C7:0004
    ; known span hint: C7:0004..C7:0006

; =============================================================================
; C7:0140  top-status=strong  labels=2
; =============================================================================
; [strong] pass 94 :: ct_c7_dispatch_1e00_sound_command_opcode_families_into_apu_port_handlers
; qualifier: strong structural
; notes: Pass 93 already froze this range as the exact `1E00` opcode-family dispatcher. Pass 94 upgrades the subsystem noun with downstream proof: opcode `0x70` lands at `08E3`, which performs exact traffic through `2140..2143` opcode `0x71` lands at `0755`, which also performs exact repeated writes through `2141..2143` the `0x10..0x17` gate table at `0AD9` is now exact Strongest safe reading: exact low-bank **sound/APU command** opcode-family dispatcher over the `1E00..` workspace.
; source: chrono_trigger_labels_pass94.md
C7_0140_ct_c7_dispatch_1e00_sound_command_opcode_families_into_apu_port_handlers:
    ; TODO: reconstruct body / data for C7:0140
    ; known span hint: C7:0140..C7:019D

; [strong] pass 93 :: ct_c7_dispatch_1e00_packet_opcode_families_into_low_bank_handlers
; qualifier: strong structural
; notes: Exact prologue saves `B`, `D`, flags, `A`, `X`, and `Y`. Sets exact direct page to `D = 0x1E00`. Forces `DB = 0x00`. Reads exact packet header bytes from the `1E00..` workspace, including `1E00` and `1E05`. If `1E05` is negative, diverts into the special path at `01A1`. If `1E00 == 00`, exits immediately. Exact opcode-family split from `1E00` is now frozen: `0x10..0x17` -> indexed indirect jump through table `0AD9` `0x18..0x2F` -> `JMP $061C` `0x30..0x3F` -> `JMP $071D` `0x70` -> `JMP $08E3` `0x71` -> `JMP $0755` Unsupported / finished paths clear exact byte `1E00` before restoring state and returning with `RTL`. Strongest safe reading: exact low-bank packet opcode-family dispatcher over the `1E00..` command packet workspace.
; source: chrono_trigger_labels_pass93.md
C7_0140_ct_c7_dispatch_1e00_packet_opcode_families_into_low_bank_handlers:
    ; TODO: reconstruct body / data for C7:0140
    ; known span hint: C7:0140..C7:019D

; =============================================================================
; C7:0192  top-status=strong  labels=1
; =============================================================================
; [strong] pass 94 :: ct_c7_common_dispatch_exit_and_register_restore_epilogue
; qualifier: strong
; notes: Exact body: `SEP #$20` `STZ $00` `REP #$20` `REP #$10` restores `Y`, `X`, `A`, flags, direct page, and bank returns with `RTL` Strongest safe reading: exact common dispatcher exit / cleanup epilogue used by the low-bank C7 sound-command side.
; source: chrono_trigger_labels_pass94.md
C7_0192_ct_c7_common_dispatch_exit_and_register_restore_epilogue:
    ; TODO: reconstruct body / data for C7:0192
    ; known span hint: C7:0192..C7:01A0

; =============================================================================
; C7:01A1  top-status=strong  labels=1
; =============================================================================
; [strong] pass 95 :: ct_c7_negative_1e05_special_path_rebuild_candidate_slot_strips_at_1f00_and_1f20_before_reconcile
; qualifier: strong structural
; notes: Validates exact selector byte `1E01` against exact long value at `C7:0AE9`. Calls exact local helpers `0734` and `0A39`. Copies `1E01 -> 1E05`. Clears two exact 0x20-byte strips through the loop over `1EFE..1F1E` and `1F1E..1F3E`. Scans backward through exact live strip `1E20..1E3E` to seed the last-active index in `0C`. Seeds exact staging pointers: `12 = 1F00` `14 = 1F20` Walks the exact long table rooted at `C7:0E11`: writes nonzero entries into `[12]` / `1F00..` writes entries not already present in `1E20..1E3E` into `[14]` / `1F20..` If `1F20 == 0`, jumps directly to `037B`. Strongest safe reading: candidate rebuild / staging gate for the negative-`1E05` special sound-command path.
; source: chrono_trigger_labels_pass95.md
C7_01A1_ct_c7_negative_1e05_special_path_rebuild_candidate_slot_strips_at_1f00_and_1f20_before_r:
    ; TODO: reconstruct body / data for C7:01A1
    ; known span hint: C7:01A1..C7:0216

; =============================================================================
; C7:0217  top-status=strong  labels=1
; =============================================================================
; [strong] pass 95 :: ct_c7_reconcile_unmatched_1f20_candidates_into_live_1e20_1e40_1e60_slot_state_using_apu_command_07
; qualifier: strong structural
; notes: Prunes dead entries from live `1E20..1E3E` if absent from the candidate strip at `1F00..1F1E`. Finds the first open live slot and the last occupied live slot. If those are equal, jumps directly to `0326`. Otherwise sends exact APU command byte `0x07` through `$2141`. Iterates over unmatched/new strip `1F20..1F3E`. Migrates/mirrors exact values into the live strips `1E20..`, `1E40..`, and `1E62..` while writing exact triplets through `$2142/$2143`. Updates exact local byte `84` through repeated calls to `09DA`. On the no-free-slot path, sends exact zero payload through `$2142/$2143` and rebuilds `1EFE..1F7E` from exact table `C7:0E0F`. Strongest safe reading: live-slot reconcile / migration phase of the negative-`1E05` path using APU command `0x07`.
; source: chrono_trigger_labels_pass95.md
C7_0217_ct_c7_reconcile_unmatched_1f20_candidates_into_live_1e20_1e40_1e60_slot_state_using_apu_:
    ; TODO: reconstruct body / data for C7:0217
    ; known span hint: C7:0217..C7:0325

; =============================================================================
; C7:037B  top-status=strong  labels=1
; =============================================================================
; [strong] pass 95 :: ct_c7_emit_staged_special_path_blocks_from_1f80_with_apu_command_02
; qualifier: strong structural
; notes: Seeds exact pointer `12 = 1F80`. Walks candidate strip `1F00..1F1E` and writes paired output words into `1F80..`. Uses exact long table `C7:0BA4` for the paired-output build when entries are already present in live `1E20..`. Sends an exact command-`0x02` block header through APU ports: `$2143 = 0x1E` `$2142 = 0x80` `$2141 = 0x02` Streams the exact staged `1F80..1FBF` block. Sends two more exact command-`0x02` blocks rooted at: `1F40..` using exact table `C7:0C20` `1FC0..` using exact table `C7:0C9C` Repeatedly updates exact local byte `84` through `JSR 09DA` and normalizes it back to `0xE0`. Strongest safe reading: staged command-`0x02` emit phase of the negative-`1E05` special sound-command path.
; source: chrono_trigger_labels_pass95.md
C7_037B_ct_c7_emit_staged_special_path_blocks_from_1f80_with_apu_command_02:
    ; TODO: reconstruct body / data for C7:037B
    ; known span hint: C7:037B..C7:04B0

; =============================================================================
; C7:04B1  top-status=strong  labels=1
; =============================================================================
; [strong] pass 96 :: ct_c7_finish_negative_1e05_special_path_by_updating_current_live_slot_then_sending_two_exact_command_03_burst_phases
; qualifier: strong structural
; notes: Runs immediately after the staged command-`0x02` emit phase at `037B..04B0`. Uses the first candidate value already loaded from `1F00` and scans backward through live strip `1E20..1E3E`. Stores exact local slot selector/index state into `FC`. Updates exact latch bytes `1E10 / 1E11` through the carry/result logic at `04C2..04D2`. If exact local byte `F3` is nonzero, calls shared helper `0922` before continuing. Sends an exact command-`0x03` header through APU ports: `$2143 = 0x20` `$2142 = 0x00` `$2141 = 0x03` Then selects a table-backed burst source from exact long table `C7:0D18` using selector `1E05` and streams that variable-length triplet body through `$2141/$2142/$2143`. Resets exact local byte `84` to `0xE0`. Then computes an exact `36 * selector` block offset and streams a second exact 12-triplet command-`0x03` body from table block `C7:1871 + 36*selector`. Finishes by writing exact terminator/reset byte `0xE0`, storing `1E05 = 0xE0`, calling exact cleanup helper `0A12`, and exiting through common dispatcher exit `0192`. Strongest safe reading: post-emit tail of the negative-`1E05` special sound-command path, updating current live-slot/latch state and sending two exact command-`0x03` burst phases before final cleanup.
; source: chrono_trigger_labels_pass96.md
C7_04B1_ct_c7_finish_negative_1e05_special_path_by_updating_current_live_slot_then_sending_two_e:
    ; TODO: reconstruct body / data for C7:04B1
    ; known span hint: C7:04B1..C7:061B

; =============================================================================
; C7:061C  top-status=strong  labels=1
; =============================================================================
; [strong] pass 96 :: ct_c7_send_exact_four_byte_apu_packet_from_1e00_1e03_then_apply_fc_threshold_fixup_if_needed
; qualifier: strong
; notes: Sends exact bytes `1E03 / 1E02 / 1E01 / 1E00` through `$2143/$2142/$2141/$2140`. Retries until `$2140` echoes the just-written opcode byte. If exact opcode byte `1E00 == 0xFC`, compares exact selector low nibble `1E01 & 0x0F` against exact local byte `F0` and calls `09FD` when they differ. Exits through the common dispatcher epilogue at `0192`. Strongest safe reading: exact immediate 4-byte APU packet sender for the low-bank `0x18..0x2F` family, with one exact `0xFC` threshold-fixup case.
; source: chrono_trigger_labels_pass96.md
C7_061C_ct_c7_send_exact_four_byte_apu_packet_from_1e00_1e03_then_apply_fc_threshold_fixup_if_ne:
    ; TODO: reconstruct body / data for C7:061C
    ; known span hint: C7:061C..C7:064F

; =============================================================================
; C7:0655  top-status=strong  labels=1
; =============================================================================
; [strong] pass 96 :: ct_c7_emit_current_slot_triplet_stream_from_0aea_table_and_refresh_live_1e40_1e63_bounds
; qualifier: strong structural
; notes: Called directly from the live-slot reconcile loop at `034F`. Reads exact current live-slot index from `1C` and exact current live selector from `1E20 + X`. Converts `(selector - 1)` into an exact `*3` index into the long-pointer table at `C7:0AEA`. Seeds exact source pointer `12/13/14` from that table. Sends an exact command-`0x03` header using the live base pair already stored in `1E60 + X` / `1E61 + X`: `$2142 = 1E60 + X` `$2143 = 1E61 + X` `$2141 = 0x03` Reads the first two bytes of the selected stream and stores them exactly into: `1E40 + X` `1E41 + X` Adds those exact bytes to the live base pair and stores the sums exactly into: `1E62 + X` `1E63 + X` Treats the first data byte as an exact triplet-count and streams the remaining body through `$2141/$2142/$2143` with wrap-safe split logic. Normalizes exact local byte `84` back to `0xE0` before returning. Strongest safe reading: exact per-slot command-`0x03` table-stream emitter that refreshes the live `1E40..1E63` bound/extent strips for the current sound slot.
; source: chrono_trigger_labels_pass96.md
C7_0655_ct_c7_emit_current_slot_triplet_stream_from_0aea_table_and_refresh_live_1e40_1e63_bounds:
    ; TODO: reconstruct body / data for C7:0655
    ; known span hint: C7:0655..C7:071C

; =============================================================================
; C7:071D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 96 :: ct_c7_table_drive_opcode_30_3f_family_into_1e00_1e03_then_tail_jump_to_0155
; qualifier: strong
; notes: Masks exact opcode byte `1E00` to its low nibble. Multiplies by four and indexes the exact table rooted at `C7:0A98`. Seeds exact packet bytes `1E02` and `1E00` from that table. Tail-jumps to `0155`, reusing the same low-bank packet sender / dispatcher flow. Strongest safe reading: exact table-driven bridge from the `0x30..0x3F` family into the shared low-bank packet-send path.
; source: chrono_trigger_labels_pass96.md
C7_071D_ct_c7_table_drive_opcode_30_3f_family_into_1e00_1e03_then_tail_jump_to_0155:
    ; TODO: reconstruct body / data for C7:071D
    ; known span hint: C7:071D..C7:0733

; =============================================================================
; C7:0734  top-status=strong  labels=1
; =============================================================================
; [strong] pass 96 :: ct_c7_helper_currently_collapses_to_exact_1e00_or_04_due_to_dead_selector_scan_stub_at_0ad8
; qualifier: strong correction
; notes: Reads exact opcode byte `1E00`. If `1E00 >= 0x14`, forces exact `1E00 |= 0x04` and returns. Otherwise enters a selector-scan loop rooted at exact address `C7:0AD8`. In the current ROM image, the very first byte at `C7:0AD8` is exact sentinel `0xFF`, so the scan exits immediately. That means the helper currently also forces exact `1E00 |= 0x04` for the `< 0x14` case. Strongest safe reading: exact helper that currently collapses to `1E00 |= 0x04`, while retaining a dead/degenerate selector-scan stub rooted at `0AD8`.
; source: chrono_trigger_labels_pass96.md
C7_0734_ct_c7_helper_currently_collapses_to_exact_1e00_or_04_due_to_dead_selector_scan_stub_at_0:
    ; TODO: reconstruct body / data for C7:0734
    ; known span hint: C7:0734..C7:0754

; =============================================================================
; C7:0755  top-status=strong  labels=1
; =============================================================================
; [strong] pass 94 :: ct_c7_handle_opcode_71_as_table_driven_apu_triplet_burst_sender
; qualifier: strong structural
; notes: Exact opening behavior: checks exact per-slot/state byte `1E20` if that state is active and `1E01 == 0`, exits through `0192` Exact setup behavior: computes `(1E01 - 1) * 3` indexes the exact table rooted at `C7:0AEA` Exact hardware-facing behavior: performs repeated three-byte burst writes through `2141 / 2142 / 2143` issues exact fixed follow-up command writes including `2141 = 0x05` later issues exact `2141 = 0x02` with paired `2142/2143` values Exact tail behavior: caches the current `1E01` value into the per-slot strip at `1E20 + X` exits through the common cleanup path at `0192` Strongest safe reading: exact opcode-`0x71` table-driven APU burst sender / uploader over the `1E00..` sound-command workspace.
; source: chrono_trigger_labels_pass94.md
C7_0755_ct_c7_handle_opcode_71_as_table_driven_apu_triplet_burst_sender:
    ; TODO: reconstruct body / data for C7:0755
    ; known span hint: C7:0755..C7:08E2

; =============================================================================
; C7:08E3  top-status=strong  labels=1
; =============================================================================
; [strong] pass 94 :: ct_c7_handle_opcode_70_as_apu_handshake_and_triplet_packet_sender
; qualifier: strong structural
; notes: Exact opening behavior: reads `1E01` compares against the latched pair at `1E10 / 1E11` Exact hardware-facing behavior: performs handshake traffic through `2140` using `0xFE` later uses exact `2140` handshake/reset traffic with `0xE0` performs repeated command/data triplets through `2141 / 2142 / 2143` selects exact command byte `0x05` when `1E00 == 0x70` otherwise uses exact command byte `0x03` on the shared internal path Exact table-backed send behavior: sources repeated triplet payloads from exact tables rooted at `C7:430B` and `C7:5B0D` clears exact local latch byte `F3` before returning in the table-send paths Strongest safe reading: exact opcode-`0x70` APU handshake / packet-send handler behind the `1E00` sound-command dispatcher.
; source: chrono_trigger_labels_pass94.md
C7_08E3_ct_c7_handle_opcode_70_as_apu_handshake_and_triplet_packet_sender:
    ; TODO: reconstruct body / data for C7:08E3
    ; known span hint: C7:08E3..C7:09D8

; =============================================================================
; C7:0922  top-status=strong  labels=1
; =============================================================================
; [strong] pass 96 :: ct_c7_shared_selector_independent_command_03_burst_sender_from_430b_or_5b0d_selected_by_1e10
; qualifier: strong
; notes: Sends an exact command-`0x03`/`0x05` header through APU ports: `$2143 = 0x2F` `$2142 = 0x00` `$2141 = 0x05` when `1E00 == 0x70`, otherwise `$2141 = 0x03` Uses exact local byte `84` and helper `09DA` for the handshake/ack step. If exact byte `1E10 == 0`, selects exact source/count from the table block rooted at `C7:430B`. If exact byte `1E10 != 0`, selects exact source/count from the table block rooted at `C7:5B0D`. Streams the chosen triplet body through `$2141/$2142/$2143`. Clears exact local byte `F3` and normalizes exact `84 = 0xE0` before returning. Strongest safe reading: exact shared selector-independent command-`0x03` burst sender used by the later negative-`1E05` tail when the latch/update side says a resend is needed.
; source: chrono_trigger_labels_pass96.md
C7_0922_ct_c7_shared_selector_independent_command_03_burst_sender_from_430b_or_5b0d_selected_by_:
    ; TODO: reconstruct body / data for C7:0922
    ; known span hint: C7:0922..C7:09D9

; =============================================================================
; C7:09DA  top-status=strong  labels=1
; =============================================================================
; [strong] pass 96 :: ct_c7_write_2140_then_return_incremented_7bit_ack_token_after_echo
; qualifier: strong
; notes: Writes `A` to exact APU port `$2140`. Spins until `$2140` echoes the same byte. Returns exact `((A + 1) & 0x7F)`. Strongest safe reading: exact low-bank APU echo/ack helper that advances the local 7-bit handshake token.
; source: chrono_trigger_labels_pass96.md
C7_09DA_ct_c7_write_2140_then_return_incremented_7bit_ack_token_after_echo:
    ; TODO: reconstruct body / data for C7:09DA
    ; known span hint: C7:09DA..C7:09E9

; =============================================================================
; C7:09EA  top-status=strong  labels=1
; =============================================================================
; [strong] pass 96 :: ct_c7_restore_2140_from_84_then_normalize_84_back_to_e0
; qualifier: strong
; notes: Writes exact local byte `84` to `$2140` and spins until echoed. Forces exact `84 = 0xE0` before returning. Strongest safe reading: exact low-bank APU reset/normalization helper paired with the `09DA` ack helper.
; source: chrono_trigger_labels_pass96.md
C7_09EA_ct_c7_restore_2140_from_84_then_normalize_84_back_to_e0:
    ; TODO: reconstruct body / data for C7:09EA
    ; known span hint: C7:09EA..C7:09FC

; =============================================================================
; C7:09FD  top-status=strong  labels=1
; =============================================================================
; [strong] pass 96 :: ct_c7_trim_live_slot_strips_against_exact_threshold_derived_from_selector_handshake_nibble
; qualifier: strong structural
; notes: Stores the incoming exact threshold nibble into local byte `F0`. Derives exact comparison byte `F2` from that nibble. Scans exact live strip `1E63..` in even steps. When it finds an entry meeting the threshold rule, zeroes the trailing live strips from that point onward: `1E20..` `1E40..` `1E62..` Strongest safe reading: exact live-slot trim helper used by the selector-table handshake path to clamp the trailing live strips against the selector-derived threshold nibble.
; source: chrono_trigger_labels_pass96.md
C7_09FD_ct_c7_trim_live_slot_strips_against_exact_threshold_derived_from_selector_handshake_nibb:
    ; TODO: reconstruct body / data for C7:09FD
    ; known span hint: C7:09FD..C7:0A38

; =============================================================================
; C7:0A39  top-status=strong  labels=1
; =============================================================================
; [strong] pass 96 :: ct_c7_selector_table_backed_apu_handshake_gate_with_negative_status_unwind_to_common_exit
; qualifier: strong structural
; notes: Uses exact selector byte `1E01 & 0x7F` as a `*2` index into the table at `C7:241D`. Seeds exact local bytes: `02` from `C7:241E + index` `03` from low nibble of `C7:241D + index` If exact local nibble `03` differs from exact local byte `F0`, calls exact trim helper `09FD`. Sends an exact four-byte APU handshake packet through `$2143/$2142/$2141/$2140` using: `$2143 = 03` `$2142 = 02` `$2141 = 1E01` `$2140 = 1E00` Retries until `$2140` echoes the just-written opcode byte. Then stores exact `84 = ((1E00 + 1) & 0x7F)`. If exact status byte read from `$2141` is negative, writes `84` back through `$2140`, waits for the decremented echo, discards the local return frame, and jumps directly to common exit `0192`. Otherwise returns normally. Strongest safe reading: exact selector-table-backed APU handshake / gate helper with one fatal negative-status unwind path.
; source: chrono_trigger_labels_pass96.md
C7_0A39_ct_c7_selector_table_backed_apu_handshake_gate_with_negative_status_unwind_to_common_exi:
    ; TODO: reconstruct body / data for C7:0A39
    ; known span hint: C7:0A39..C7:0A97

; =============================================================================
; C7:0AD9  top-status=strong  labels=1
; =============================================================================
; [strong] pass 94 :: ct_c7_packet_opcode_10_17_gate_table_to_active_handler_or_common_exit
; qualifier: strong
; notes: Exact eight-entry 16-bit table for packet opcodes `0x10..0x17`: `0x10 -> 01A1` `0x11 -> 01A1` `0x12 -> 0192` `0x13 -> 0192` `0x14 -> 01A1` `0x15 -> 01A1` `0x16 -> 0192` `0x17 -> 0192` Strongest safe reading: exact two-target early gate for the `0x10..0x17` family, splitting to either the active handler (`01A1`) or the immediate common exit (`0192`).
; source: chrono_trigger_labels_pass94.md
C7_0AD9_ct_c7_packet_opcode_10_17_gate_table_to_active_handler_or_common_exit:
    ; TODO: reconstruct body / data for C7:0AD9
    ; known span hint: C7:0AD9..C7:0AE8

