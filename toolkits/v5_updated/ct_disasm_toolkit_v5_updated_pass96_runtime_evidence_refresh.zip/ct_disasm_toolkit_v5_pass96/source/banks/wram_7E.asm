; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: wram_7E
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; 7E:020C  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 93 :: ct_cd_shared_c2_dual_call_packet_workspace_seeded_by_025e
; qualifier: provisional strengthened
; notes: Pass 92 proved `CD:025E..0295` seeds this exact packet/workspace family before calling `C2:0003` and `C2:0009`. Pass 93 now proves more of the exact consumer contract: `020C` is used as a masked/doubled selector index `020D..020F` are consumed as a long pointer base by `C2:57DF` `0214` controls the seed of exact local byte `0234` Strongest safe reading: shared C2 dual-call packet workspace whose selector/pointer family is consumed directly by the `57DF -> 5823` chain.
; source: chrono_trigger_labels_pass93.md
L_7E_020C_ct_cd_shared_c2_dual_call_packet_workspace_seeded_by_025e:
    ; TODO: reconstruct body / data for 7E:020C
    ; known span hint: 7E:020C..7E:0214

; =============================================================================
; 7E:0237  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 95 :: ct_c2_active_long_stream_cursor_and_inner_counter_family_for_downstream_chained_handlers
; qualifier: provisional strengthened
; notes: Pass 94 already proved `58B2` seeds this family from the exact table rooted at `DE:FA00`. Pass 95 proves more of the exact consumer contract: `0237..0239` is the active long stream cursor consumed by `5BF5 / 5C3E / 5C77` `023A` is decremented by all three downstream families and participates in the exact four-way tail routing Strongest safe reading: active long stream cursor + inner counter family for the chained downstream C2 handlers.
; source: chrono_trigger_labels_pass95.md
L_7E_0237_ct_c2_active_long_stream_cursor_and_inner_counter_family_for_downstream_chained_handle:
    ; TODO: reconstruct body / data for 7E:0237
    ; known span hint: 7E:0237..7E:023A

; =============================================================================
; 7E:0300  top-status=strong  labels=1
; =============================================================================
; [strong] pass 78 :: ct_c3_unpack_source_pointer
; qualifier: strong structural
; notes: Caller-provided source pointer consumed by the standard `C3:0002 -> C3:0557` unpack/materialize worker.
; source: chrono_trigger_labels_pass78.md
L_7E_0300_ct_c3_unpack_source_pointer:
    ; TODO: reconstruct body / data for 7E:0300
    ; known span hint: 7E:0300..7E:0302

; =============================================================================
; 7E:0303  top-status=strong  labels=1
; =============================================================================
; [strong] pass 78 :: ct_c3_unpack_destination_pointer
; qualifier: strong structural
; notes: Caller-provided destination pointer for the same worker. `C3:0557` writes through the WRAM port using this destination address.
; source: chrono_trigger_labels_pass78.md
L_7E_0303_ct_c3_unpack_destination_pointer:
    ; TODO: reconstruct body / data for 7E:0303
    ; known span hint: 7E:0303..7E:0305

; =============================================================================
; 7E:0306  top-status=strong  labels=1
; =============================================================================
; [strong] pass 78 :: ct_c3_unpack_output_size_or_destination_advance
; qualifier: strong structural
; notes: Exact worker exit stores `Y - start_dest_offset` here. Service-04 immediately uses it as the termination point for the materialized `2D00..` workspace.
; source: chrono_trigger_labels_pass78.md
L_7E_0306_ct_c3_unpack_output_size_or_destination_advance:
    ; TODO: reconstruct body / data for 7E:0306
    ; known span hint: 7E:0306..7E:0307

; =============================================================================
; 7E:0520  top-status=strong  labels=2
; =============================================================================
; [strong] pass 83 :: ct_palette_effect_descriptor_queue_8x12byte_records
; qualifier: strong structural
; notes: Passes 8–9 already proved the `0x0C` stride and 8-slot queue shape. Pass 83 adds exact header-walk proof through `D1:F411` / `D1:F457`, covering slot headers at `0520/052C/0538/0544/0550/055C/0568/0574`. Strongest safe reading: full 8-record palette/effect descriptor queue.
; source: chrono_trigger_labels_pass83.md
L_7E_0520_ct_palette_effect_descriptor_queue_8x12byte_records:
    ; TODO: reconstruct body / data for 7E:0520
    ; known span hint: 7E:0520..7E:057F

; [strong] pass 82 :: ct_palette_effect_descriptor_active_slab_3x12byte_records
; qualifier: stronger support
; notes: Passes 8–9 already proved `0520 + n*0C` is a palette/effect descriptor family. Pass 82 adds exact slab-level proof: `D1:E91A` restores `0544..0567 -> 0520..0543`, and `D1:E984` snapshots `0520..0543 -> 0544..0567`. Strongest safe reading: active 3-record descriptor slab.
; source: chrono_trigger_labels_pass82.md
L_7E_0520_ct_palette_effect_descriptor_active_slab_3x12byte_records:
    ; TODO: reconstruct body / data for 7E:0520
    ; known span hint: 7E:0520..7E:0543

; =============================================================================
; 7E:0544  top-status=strong  labels=1
; =============================================================================
; [strong] pass 82 :: ct_palette_effect_descriptor_secondary_slab_3x12byte_records
; qualifier: stronger support
; notes: Exact `0x24`-byte partner slab adjacent to `0520..0543`. `D1:E91A` copies this slab back into the active slab. `D1:E984` copies the active slab outward into this slab and biases fields afterward.
; source: chrono_trigger_labels_pass82.md
L_7E_0544_ct_palette_effect_descriptor_secondary_slab_3x12byte_records:
    ; TODO: reconstruct body / data for 7E:0544
    ; known span hint: 7E:0544..7E:0567

; =============================================================================
; 7E:0568  top-status=strong  labels=1
; =============================================================================
; [strong] pass 83 :: ct_palette_effect_descriptor_tail_slab_2x12byte_records
; qualifier: stronger support
; notes: The tail two descriptor slots are now surfaced directly by `D1:F411` / `D1:F457` via header bytes at `0568` and `0574`. Pass 82 did not touch these tail slots directly; pass 83 proves they participate in the same header-shadow gate.
; source: chrono_trigger_labels_pass83.md
L_7E_0568_ct_palette_effect_descriptor_tail_slab_2x12byte_records:
    ; TODO: reconstruct body / data for 7E:0568
    ; known span hint: 7E:0568..7E:057F

; =============================================================================
; 7E:0B40  top-status=strong  labels=4
; =============================================================================
; [strong] pass 45 :: / 00:0B40  ct_c1_tilemap_strip_buffer_32x6_words_vram7a00     [strong]
; notes: Corrected from pass 44’s provisional geometry. The proven row stride from `C1:0929` is `0x40` bytes, yielding a 32-word by 6-row layout
; source: chrono_trigger_labels_pass45.md
L_7E_0B40_00_0B40_ct_c1_tilemap_strip_buffer_32x6_words_vram7a00_strong:
    ; TODO: reconstruct body / data for 7E:0B40

; [strong] pass 44 :: / 00:0B40  ct_c1_tilemap_staging_buffer_vram7a00_0180        [strong]
; notes: `0x180`-byte WRAM staging buffer. Written from ROM templates at `D1:5800`, `D1:5A50`, and `D1:5BD0`. Uploaded by DMA from the low-bank WRAM mirror `00:0B40` to VRAM address `7A00`
; source: chrono_trigger_labels_pass44.md
L_7E_0B40_00_0B40_ct_c1_tilemap_staging_buffer_vram7a00_0180_strong:
    ; TODO: reconstruct body / data for 7E:0B40

; [provisional] pass 45 :: ct_c1_lane_roster_strip_tilemap_buffer
; qualifier: provisional
; notes: Supported by the strong link from `C1:07FD` to the active-roster state. Kept provisional because the final gameplay-facing subsystem name is still open.
; source: chrono_trigger_labels_pass45.md
L_7E_0B40_ct_c1_lane_roster_strip_tilemap_buffer:
    ; TODO: reconstruct body / data for 7E:0B40

; [provisional] pass 45 :: ct_c1_panel_or_screen_tilemap_buffer
; qualifier: provisional -> corrected context
; notes: Still not given a final human-facing UI name. But now known much more concretely as a 32x6 strip buffer with dynamic three-slot panel composition.
; source: chrono_trigger_labels_pass45.md
L_7E_0B40_ct_c1_panel_or_screen_tilemap_buffer:
    ; TODO: reconstruct body / data for 7E:0B40

; =============================================================================
; 7E:0CC0  top-status=provisional  labels=3
; =============================================================================
; [provisional] pass 50 :: ct_c1_companion_paired_byte_strip_buffer
; qualifier: strengthened
; notes: Earlier passes had already established HP/max HP/MP numeric content and the segmented bar. Pass 50 tightens the bar specifically to the lane active-time/readiness gauge. The strip now reads more coherently as a battle-status lane display.
; source: chrono_trigger_labels_pass50.md
L_7E_0CC0_ct_c1_companion_paired_byte_strip_buffer:
    ; TODO: reconstruct body / data for 7E:0CC0
    ; known span hint: 7E:0CC0..7E:0E08

; [provisional] pass 47 :: ct_c1_three_lane_status_or_command_strip
; qualifier: provisional
; notes: Pass 47 makes the three-lane, layout-driven presentation role much stronger. Still not safe to commit to the final gameplay-facing subsystem name.
; source: chrono_trigger_labels_pass47.md
L_7E_0CC0_ct_c1_three_lane_status_or_command_strip:
    ; TODO: reconstruct body / data for 7E:0CC0
    ; known span hint: 7E:0CC0..7E:0E08

; [provisional] pass 46 :: ct_c1_roster_presentation_companion_strip
; qualifier: provisional
; notes: Strongly linked to the same roster/strip refresh band as `0B40`. Kept provisional because the final gameplay-facing subsystem name is still unresolved.
; source: chrono_trigger_labels_pass46.md
L_7E_0CC0_ct_c1_roster_presentation_companion_strip:
    ; TODO: reconstruct body / data for 7E:0CC0
    ; known span hint: 7E:0CC0..7E:0E08

; =============================================================================
; 7E:0E80  top-status=provisional  labels=3
; =============================================================================
; [provisional] pass 47 :: ct_c1_companion_record_buffer_0x180
; qualifier: strengthened
; notes: Pass 46 proved the writer-side rebuild path. Pass 47 adds: lane-marker anchor table `FAE9` current-lane marker refresh at `C1:1918` hard read-side consumer proof in bank `C0` This region is now known to participate in downstream composition, not just local build logic.
; source: chrono_trigger_labels_pass47.md
L_7E_0E80_ct_c1_companion_record_buffer_0x180:
    ; TODO: reconstruct body / data for 7E:0E80
    ; known span hint: 7E:0E80..7E:0FFF

; [provisional] pass 47 :: ct_c1_three_lane_marker_record_presentation_block
; qualifier: provisional
; notes: Strongly tied to lane markers and downstream consumption. Still not safe to collapse into “text”, “command labels”, or any narrower final name.
; source: chrono_trigger_labels_pass47.md
L_7E_0E80_ct_c1_three_lane_marker_record_presentation_block:
    ; TODO: reconstruct body / data for 7E:0E80
    ; known span hint: 7E:0E80..7E:0FFF

; [provisional] pass 46 :: ct_c1_roster_presentation_companion_records
; qualifier: provisional
; notes: Strongly linked to the same refresh band and built in three iterations. Still not safe to call text, icon metadata, or anything more specific yet.
; source: chrono_trigger_labels_pass46.md
L_7E_0E80_ct_c1_roster_presentation_companion_records:
    ; TODO: reconstruct body / data for 7E:0E80
    ; known span hint: 7E:0E80..7E:0FFF

; =============================================================================
; 7E:2040  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 82 :: ct_d1_first_48color_palette_band_work_pair_a
; qualifier: provisional strengthened
; notes: Seeded from `D0:FD00` by `D1:E984`. Later promoted/cleared by `D1:E91A`. Final gameplay-facing band noun still open.
; source: chrono_trigger_labels_pass82.md
L_7E_2040_ct_d1_first_48color_palette_band_work_pair_a:
    ; TODO: reconstruct body / data for 7E:2040
    ; known span hint: 7E:2040..7E:209F

; =============================================================================
; 7E:20A0  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 82 :: ct_d1_promoted_48color_palette_band_pair_a
; qualifier: provisional strengthened
; notes: Filled only by `D1:E91A` from `7E:2040..209F`. Strongest safe reading: promoted/latched counterpart of the first work band.
; source: chrono_trigger_labels_pass82.md
L_7E_20A0_ct_d1_promoted_48color_palette_band_pair_a:
    ; TODO: reconstruct body / data for 7E:20A0
    ; known span hint: 7E:20A0..7E:20FF

; =============================================================================
; 7E:2120  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 82 :: and 7E:2320..7E:237F  ct_d1_secondary_palette_band_pairs_seeded_to_7fff   [provisional strengthened]
; notes: Seeded to `0x7FFF` by `D1:E899`. Later consumed by the nearby `D1:E71D..E77A` swap path. Final higher-level noun remains open.
; source: chrono_trigger_labels_pass82.md
L_7E_2120_and_7E_2320_7E_237F_ct_d1_secondary_palette_band_pairs_seeded_to_7fff_provisional_stre:
    ; TODO: reconstruct body / data for 7E:2120
    ; known span hint: 7E:2120..7E:217F

; =============================================================================
; 7E:21A0  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 82 :: and 7E:23A0..7E:23FF  ct_d1_tertiary_palette_band_pairs_seeded_to_7fff   [provisional strengthened]
; notes: Seeded to `0x7FFF` by `D1:E8C1`. Also tied to the nearby `D1:E71D..E77A` swap/exchange seam.
; source: chrono_trigger_labels_pass82.md
L_7E_21A0_and_7E_23A0_7E_23FF_ct_d1_tertiary_palette_band_pairs_seeded_to_7fff_provisional_stren:
    ; TODO: reconstruct body / data for 7E:21A0
    ; known span hint: 7E:21A0..7E:21FF

; =============================================================================
; 7E:2240  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 82 :: ct_d1_first_48color_palette_band_work_pair_b
; qualifier: provisional strengthened
; notes: Exact partner band written alongside `7E:2040..209F` by both `D1:E984` and `D1:E91A`. Final noun still open.
; source: chrono_trigger_labels_pass82.md
L_7E_2240_ct_d1_first_48color_palette_band_work_pair_b:
    ; TODO: reconstruct body / data for 7E:2240
    ; known span hint: 7E:2240..7E:229F

; =============================================================================
; 7E:22A0  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 82 :: ct_d1_promoted_48color_palette_band_pair_b
; qualifier: provisional strengthened
; notes: Exact partner band written alongside `7E:20A0..20FF` by `D1:E91A`.
; source: chrono_trigger_labels_pass82.md
L_7E_22A0_ct_d1_promoted_48color_palette_band_pair_b:
    ; TODO: reconstruct body / data for 7E:22A0
    ; known span hint: 7E:22A0..7E:22FF

; =============================================================================
; 7E:2990  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 52 :: low 3 bits  ct_cfg_battle_speed_field                                [strengthened]
; notes: This pass proves the low 3 bits are consumed directly as an 8-way page selector in the readiness seed branch. The whole byte is still a broader config byte, but the low field is no longer vague. Strongest safe reading: battle-speed option field.
; source: chrono_trigger_labels_pass52.md
L_7E_2990_low_3_bits_ct_cfg_battle_speed_field_strengthened:
    ; TODO: reconstruct body / data for 7E:2990

; =============================================================================
; 7E:29AE  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 92 :: ct_c0_multi_packet_submit_default_second_packet_byte
; qualifier: provisional strengthened
; notes: Pass 92 proves the default `bit6 == 0` packet sequence at `C0:1BE6` reads this exact byte into `1E01` before submitting packet `1E00 = 0x11`. Strongest safe reading: live byte consumed as the default second-packet payload in the sibling multi-packet submit path.  I have **not** frozen the final engine-facing noun of `C2:0003`. I have **not** frozen the final engine-facing noun of `C2:0009`. I have **not** frozen the final engine-facing noun of `C7:0004`; pass 91 + pass 92 now freeze multiple exact local packet builders and submit sequences around it, not the final subsystem name. I have **not** frozen the final gameplay-facing noun of the broader pass-88/89 lane+raster workspace. I have **not** returned to the first exact clean-code external reader of `CE0F` yet.
; source: chrono_trigger_labels_pass92.md
L_7E_29AE_ct_c0_multi_packet_submit_default_second_packet_byte:
    ; TODO: reconstruct body / data for 7E:29AE

; =============================================================================
; 7E:2D00  top-status=strong  labels=2
; =============================================================================
; [strong] pass 79 :: ct_c1_service04_packed_tile_row_or_tile_batch_workspace
; qualifier: strong correction
; notes: Pass 78 already proved this is a packed row/materialization workspace consumed by `4943`. Pass 79 strengthens the noun: the local `CD:13E6` builder modes are exact tile orientation modes over 32-byte tile-shaped blocks. Strongest safe reading now: packed tile-row / tile-batch workspace for the late service-04 graphics assembly path.
; source: chrono_trigger_labels_pass79.md
L_7E_2D00_ct_c1_service04_packed_tile_row_or_tile_batch_workspace:
    ; TODO: reconstruct body / data for 7E:2D00
    ; known span hint: 7E:2D00..7E:2DFF

; [strong] pass 78 :: ct_c1_service04_packed_fragment_row_stream_workspace
; qualifier: strong correction
; notes: Pass 77 proved this is a packed stream consumed by `4943`. Pass 78 tightens that noun: `CD:0015/002A` populate six fixed row-sections at offsets `000C/000E/0010/0012/0014/0016`, and `C3:0002` materializes packed bytes into the same workspace. Strongest safe reading: packed fragment-row stream workspace for the service-04 decode path.
; source: chrono_trigger_labels_pass78.md
L_7E_2D00_ct_c1_service04_packed_fragment_row_stream_workspace:
    ; TODO: reconstruct body / data for 7E:2D00
    ; known span hint: 7E:2D00..7E:2DFF

; =============================================================================
; 7E:5D00  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 77 :: ct_c1_service04_output_slot_records_16x8_stride
; qualifier: provisional strengthened
; notes: Pass 77 corrects the stride math: this family is addressed at `5D00 + 8*slot`. The shared `4833` tail seeds bytes `+0/+1` to zero and bytes `+2/+3` from the `D1:50A2 / D1:50A3` family for sixteen slots. Final gameplay-facing noun of the slot record remains one notch below frozen.
; source: chrono_trigger_labels_pass77.md
L_7E_5D00_ct_c1_service04_output_slot_records_16x8_stride:
    ; TODO: reconstruct body / data for 7E:5D00
    ; known span hint: 7E:5D00..7E:5D7F

; =============================================================================
; 7E:5D80  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 85 :: ct_cd_auxiliary_indexed_byte_counter_strip
; qualifier: provisional strengthened
; notes: Auxiliary token `0xE5` increments one byte in this strip using the immediate operand as index. Final gameplay-facing noun remains open, but this is clearly an indexed byte strip actively mutated by the auxiliary VM.
; source: chrono_trigger_labels_pass85.md
L_7E_5D80_ct_cd_auxiliary_indexed_byte_counter_strip:
    ; TODO: reconstruct body / data for 7E:5D80
    ; known span hint: 7E:5D80..7E:5DFF

; =============================================================================
; 7E:5D9A  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 81 :: ct_cd_auxiliary_token_80_parallel_table_builder_arm_latch
; qualifier: provisional strengthened
; notes: Set to `1` by sub-op `0x13` before entering the shared `2D53` builder tail.
; source: chrono_trigger_labels_pass81.md
L_7E_5D9A_ct_cd_auxiliary_token_80_parallel_table_builder_arm_latch:
    ; TODO: reconstruct body / data for 7E:5D9A

; =============================================================================
; 7E:5D9B  top-status=strong  labels=1
; =============================================================================
; [strong] pass 79 :: ct_cd_optional_auxiliary_descriptor_stage_active_flag
; qualifier: strong structural
; notes: Cleared at stage start by `0D28`. Checked by `1609` before any runtime-slot ticking occurs. Cleared again when the stage-level local completion condition is met.
; source: chrono_trigger_labels_pass79.md
L_7E_5D9B_ct_cd_optional_auxiliary_descriptor_stage_active_flag:
    ; TODO: reconstruct body / data for 7E:5D9B

; =============================================================================
; 7E:5DA0  top-status=strong  labels=2
; =============================================================================
; [strong] pass 87 :: ct_cd_d1_current_three_pair_point_bundle
; qualifier: strong structural, orientation corrected locally
; notes: Pass 86 correctly froze this family as a real three-pair point bundle. Pass 87 tightens the local `EC28 -> F9AF` orientation: the downstream column rasterizer proves the **second** byte of each pair is the column/X byte. Therefore the strongest local reading for this path is `5DA0 = row/Y-like`, `5DA1 = column/X-like`. I am keeping that orientation correction local until one more consumer proves it globally.  I have **not** frozen the final presentation noun of the four-point bundle at `CD0D..CD1B`. I have **not** frozen the final higher-level noun of the four WRAM target strips rooted by `CD:38AA..38B1`. I have **not** frozen the first exact external reader of `CE0F`. I have **not** promoted the remaining low-half `CE0F` code-like hits, because they still sit inside dense script/data neighborhoods.
; source: chrono_trigger_labels_pass87.md
L_7E_5DA0_ct_cd_d1_current_three_pair_point_bundle:
    ; TODO: reconstruct body / data for 7E:5DA0
    ; known span hint: 7E:5DA0..7E:5DA5

; [strong] pass 85 :: ct_cd_auxiliary_current_sixbyte_live_vector
; qualifier: strong structural
; notes: Auxiliary token `0xE3` snapshots these six live bytes outward into the indexed `CAEA..CAF5` record family. Auxiliary token `0xE4` reads `5DA0` specifically as the current index/selector byte mirrored into `CD25`. Strongest safe reading: current six-byte live vector family consumed by the late auxiliary token cluster.  I have **not** frozen the final gameplay-facing noun of the `5D80` strip. I have **not** frozen the final noun of the `5DA0..5DA5` live vector family. I have **not** frozen the final noun of the indexed destination record family at `CAEA..CAF5`. I have **not** yet tied this `0xE0..0xE8` control family all the way into the final presentation/system noun. I have **not** yet frozen the first exact external reader(s) of `CDC8` and `CE0F`.
; source: chrono_trigger_labels_pass85.md
L_7E_5DA0_ct_cd_auxiliary_current_sixbyte_live_vector:
    ; TODO: reconstruct body / data for 7E:5DA0
    ; known span hint: 7E:5DA0..7E:5DA5

; =============================================================================
; 7E:5DA1  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 81 :: ct_cd_auxiliary_token_80_clamped_state_byte_31_d4
; qualifier: provisional strengthened
; notes: Sub-op `0x12` clamps this byte into `[0x31, 0xD4]`.
; source: chrono_trigger_labels_pass81.md
L_7E_5DA1_ct_cd_auxiliary_token_80_clamped_state_byte_31_d4:
    ; TODO: reconstruct body / data for 7E:5DA1

; =============================================================================
; 7E:5E2F  top-status=strong  labels=1
; =============================================================================
; [strong] pass 49 :: ct_c1_lane_low_hp_critical_flag                      [strong]
; notes: Cleared, then conditionally set in `C1:B094..B0B3`. Condition is driven by `5E30` versus `5E32 >> 3`. Strongest safe reading: low-HP / critical threshold flag.
; source: chrono_trigger_labels_pass49.md
L_7E_5E2F_ct_c1_lane_low_hp_critical_flag_strong:
    ; TODO: reconstruct body / data for 7E:5E2F

; =============================================================================
; 7E:5E30  top-status=strong  labels=2
; =============================================================================
; [strong] pass 49 :: ct_c1_lane_current_hp
; qualifier: strong
; notes: Rendered as the first 3-digit numeric lane field in `C1:0299`. Compared against `5E32 >> 3` in both UI and non-UI logic. Mutated directly and clamped against `5E32` in `C1:EC90..ECD7`. Strongest safe reading now: current HP.
; source: chrono_trigger_labels_pass49.md
L_7E_5E30_ct_c1_lane_current_hp:
    ; TODO: reconstruct body / data for 7E:5E30

; [provisional] pass 48 :: ct_c1_lane_primary_numeric_field
; qualifier: provisional
; notes: Rendered through `011F` as a 3-digit decimal field in `C1:0299`. Structurally related to the `5E32` field by a pre-render compare. Final gameplay-facing meaning still open.
; source: chrono_trigger_labels_pass48.md
L_7E_5E30_ct_c1_lane_primary_numeric_field:
    ; TODO: reconstruct body / data for 7E:5E30

; =============================================================================
; 7E:5E32  top-status=strong  labels=2
; =============================================================================
; [strong] pass 49 :: ct_c1_lane_max_hp
; qualifier: strong
; notes: Rendered as the second 3-digit numeric lane field in `C1:0299`. Divided by 8 for the low-HP threshold test. Used as the clamp/cap for `5E30` in `C1:EC90..ECD7`. Strongest safe reading now: max HP.
; source: chrono_trigger_labels_pass49.md
L_7E_5E32_ct_c1_lane_max_hp:
    ; TODO: reconstruct body / data for 7E:5E32

; [provisional] pass 48 :: ct_c1_lane_secondary_numeric_field
; qualifier: provisional
; notes: Rendered through `011F` as a second 3-digit decimal field. Its high byte is compared against `5E30` before rendering. Final gameplay-facing meaning still open.
; source: chrono_trigger_labels_pass48.md
L_7E_5E32_ct_c1_lane_secondary_numeric_field:
    ; TODO: reconstruct body / data for 7E:5E32

; =============================================================================
; 7E:5E34  top-status=provisional  labels=2
; =============================================================================
; [provisional] pass 49 :: ct_c1_lane_current_mp
; qualifier: provisional
; notes: Rendered as the third lane numeric field through the 2-digit formatter. Participates in a lane-selected subtract/update path at `C1:CC74..CCC5`. Grouped tightly with the now-strong HP pair in the same per-lane panel record. Strongest safe reading now: current MP. Kept provisional only because pass 49 did not yet pin the cleanest possible direct “tech cost / MP spend” caller chain.
; source: chrono_trigger_labels_pass49.md
L_7E_5E34_ct_c1_lane_current_mp:
    ; TODO: reconstruct body / data for 7E:5E34

; [provisional] pass 48 :: ct_c1_lane_aux_two_digit_numeric_field
; qualifier: provisional
; notes: Rendered through `0174` as a 2-digit decimal field. Final gameplay-facing meaning still open.
; source: chrono_trigger_labels_pass48.md
L_7E_5E34_ct_c1_lane_aux_two_digit_numeric_field:
    ; TODO: reconstruct body / data for 7E:5E34

; =============================================================================
; 7E:5E4B  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 50 :: ct_c1_lane_haste_like_rate_modifier_bit               [provisional]
; source: chrono_trigger_labels_pass50.md
L_7E_5E4B_ct_c1_lane_haste_like_rate_modifier_bit_provisional:
    ; TODO: reconstruct body / data for 7E:5E4B

; =============================================================================
; 7E:5E4D  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 50 :: bit7  ct_c1_lane_slow_like_rate_modifier_bit_family [provisional]
; notes: ROM proof is strong for the functional behavior: one family doubles the increment one family halves it Exact final human-facing status names are still intentionally kept one step conservative.
; source: chrono_trigger_labels_pass50.md
L_7E_5E4D_bit7_ct_c1_lane_slow_like_rate_modifier_bit_family_provisional:
    ; TODO: reconstruct body / data for 7E:5E4D
    ; known span hint: 7E:5E4D..7E:5E52

; =============================================================================
; 7E:93EE  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_c1_service7_record_status_flags
; qualifier: strong
; notes: Strengthened by `FD:A8CE` / `FD:A8FE`, which explicitly clear this field
; source: chrono_trigger_labels_pass42.md
L_7E_93EE_ct_c1_service7_record_status_flags:
    ; TODO: reconstruct body / data for 7E:93EE

; =============================================================================
; 7E:93EF  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_c1_service7_record_aux_flags
; qualifier: strong
; notes: Strengthened by `FD:A8CE` / `FD:A8FE`, which explicitly clear this field
; source: chrono_trigger_labels_pass42.md
L_7E_93EF_ct_c1_service7_record_aux_flags:
    ; TODO: reconstruct body / data for 7E:93EF

; =============================================================================
; 7E:93F3  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_c1_service7_record_lane_pair
; qualifier: strong
; notes: Stronger than pass 41. The packed byte is no longer just “small dispatch categories.” It is now best read as a packed pair of **lane IDs** for the canonical `0` `1` `2` `F` = none / disabled
; source: chrono_trigger_labels_pass42.md
L_7E_93F3_ct_c1_service7_record_lane_pair:
    ; TODO: reconstruct body / data for 7E:93F3

; =============================================================================
; 7E:9499  top-status=strong  labels=1
; =============================================================================
; [strong] pass 48 :: ct_c1_decimal_tile_format_input_u16
; qualifier: strong
; notes: Working numeric input consumed by `011F` and `0174`. Loaded from per-lane record fields during `C1:0299` numeric field emission.
; source: chrono_trigger_labels_pass48.md
L_7E_9499_ct_c1_decimal_tile_format_input_u16:
    ; TODO: reconstruct body / data for 7E:9499

; =============================================================================
; 7E:949C  top-status=strong  labels=1
; =============================================================================
; [strong] pass 48 :: ct_c1_decimal_tile_format_output_4bytes
; qualifier: strong
; notes: Shared 4-byte tile buffer emitted by the decimal formatter helpers. `949C` is used as a blank/fill slot. `949D..949F` hold the generated digit tiles before they are copied into the strip.
; source: chrono_trigger_labels_pass48.md
L_7E_949C_ct_c1_decimal_tile_format_output_4bytes:
    ; TODO: reconstruct body / data for 7E:949C
    ; known span hint: 7E:949C..7E:949F

; =============================================================================
; 7E:95D6  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_pending_lane_admission_queue
; qualifier: strong
; notes: Root of the 3-entry pending-admission queue consumed by `1B69` and compacted by `1BAA`.
; source: chrono_trigger_labels_pass43.md
L_7E_95D6_ct_c1_pending_lane_admission_queue:
    ; TODO: reconstruct body / data for 7E:95D6

; =============================================================================
; 7E:95DA  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_pending_lane_admission_count
; qualifier: strong
; notes: Pending queue count / append index for `95D6..95D8`.
; source: chrono_trigger_labels_pass43.md
L_7E_95DA_ct_c1_pending_lane_admission_count:
    ; TODO: reconstruct body / data for 7E:95DA

; =============================================================================
; 7E:96F1  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 62 :: ct_c1_global_24bit_replay_gate_triplet_state
; qualifier: provisional
; notes: Pass 62 proves these three bytes are compared lexicographically against the immediate operand in global opcode `06`. Earlier work already showed they are globally cleared by another command family. The mechanical role is now real. The gameplay/system-facing noun still wants more caller-side proof.
; source: chrono_trigger_labels_pass62.md
L_7E_96F1_ct_c1_global_24bit_replay_gate_triplet_state:
    ; TODO: reconstruct body / data for 7E:96F1
    ; known span hint: 7E:96F1..7E:96F3

; =============================================================================
; 7E:9877  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 76 :: ct_c1_service04_working_profile_and_derived_output_bytes
; qualifier: provisional strengthened
; notes: Modes `1` and `2` both populate this neighborhood before entering the shared `4833` runner. The bytes are then consumed by the bank-`CD/D1/CE` derivation chain and the output/materialization tail. Exact per-byte nouns remain open, but this is now clearly a service-04 working-profile/output buffer family.  service-04 modes `0` and `3` at `475A / 475B` are still open the final gameplay-facing noun for the `4833 / 48EC / 4943` output is still not frozen the 17-byte `CC:213F -> AEE6..AEF6` descriptor fields still want a dedicated pass now that the service-04 mode picture is cleaner
; source: chrono_trigger_labels_pass76.md
L_7E_9877_ct_c1_service04_working_profile_and_derived_output_bytes:
    ; TODO: reconstruct body / data for 7E:9877
    ; known span hint: 7E:9877..7E:9885

; =============================================================================
; 7E:99B5  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 81 :: ct_cd_auxiliary_token_80_indexed_clearable_state_bytes   [provisional strengthened]
; notes: Sub-op `0x0F` clears one indexed byte chosen by `CD00`.
; source: chrono_trigger_labels_pass81.md
L_7E_99B5_ct_cd_auxiliary_token_80_indexed_clearable_state_bytes_provisional_strengthened:
    ; TODO: reconstruct body / data for 7E:99B5

; =============================================================================
; 7E:99D2  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 81 :: ct_cd_auxiliary_token_80_mirrored_pair_arm_flags
; qualifier: provisional strengthened
; notes: Sub-op `0x11` sets bit 7 before seeding the mirrored/complement pair around `99D3`.
; source: chrono_trigger_labels_pass81.md
L_7E_99D2_ct_cd_auxiliary_token_80_mirrored_pair_arm_flags:
    ; TODO: reconstruct body / data for 7E:99D2

; =============================================================================
; 7E:99D3  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 81 :: ct_cd_auxiliary_token_80_mirrored_pair_seed_byte
; qualifier: provisional strengthened
; notes: Used by sub-op `0x11` as the source byte whose complement around `0x80` is also emitted.
; source: chrono_trigger_labels_pass81.md
L_7E_99D3_ct_cd_auxiliary_token_80_mirrored_pair_seed_byte:
    ; TODO: reconstruct body / data for 7E:99D3

; =============================================================================
; 7E:99DD  top-status=provisional  labels=8
; =============================================================================
; [provisional] pass 47 :: ct_c1_lane_display_value_for_scaled_bar
; qualifier: provisional
; notes: Read by `C1:06F0` as one input to the segmented bar renderer. Reset/clear paths still mirror it from broader lane-carried state. Strong structural role, but final gameplay-facing meaning still open.
; source: chrono_trigger_labels_pass47.md
L_7E_99DD_ct_c1_lane_display_value_for_scaled_bar:
    ; TODO: reconstruct body / data for 7E:99DD

; [provisional] pass 43 :: ct_c1_lane_primary_value_export_a
; qualifier: provisional
; notes: Export mirror updated from the same lane-carried value family as `B158/AFAB`.
; source: chrono_trigger_labels_pass43.md
L_7E_99DD_ct_c1_lane_primary_value_export_a:
    ; TODO: reconstruct body / data for 7E:99DD

; [provisional] pass 42 :: ct_c1_service7_lane_shadow_value_1
; qualifier: provisional
; source: chrono_trigger_labels_pass42.md
L_7E_99DD_ct_c1_service7_lane_shadow_value_1:
    ; TODO: reconstruct body / data for 7E:99DD

; [unspecified] pass 54 :: ct_visible_head_lane_readiness_current_export
; qualifier: strengthened
; notes: Pass 51 already pinned this as current/fill export. Pass 54 proves the exported values are specifically the **post-normalized head work values**.
; source: chrono_trigger_labels_pass54.md
L_7E_99DD_ct_visible_head_lane_readiness_current_export:
    ; TODO: reconstruct body / data for 7E:99DD
    ; known span hint: 7E:99DD..7E:99DF

; [unspecified] pass 51 :: ct_c1_lane_active_time_gauge_current_fill_export
; qualifier: strengthened
; notes: `C1:06F0` loads it as the renderer numerator/current-side value. Goal-only update families do **not** necessarily overwrite it. Snap/full commit families explicitly mirror it equal to `9F22`. Replaces the looser “progress export” wording with a harder current-fill role.
; source: chrono_trigger_labels_pass51.md
L_7E_99DD_ct_c1_lane_active_time_gauge_current_fill_export:
    ; TODO: reconstruct body / data for 7E:99DD

; [unspecified] pass 51 :: old wording “lane_active_time_gauge_progress_export”                    [replaced]
; notes: Too generic after the renderer-side numerator proof. Replaced by `ct_c1_lane_active_time_gauge_current_fill_export`.
; source: chrono_trigger_labels_pass51.md
L_7E_99DD_old_wording_lane_active_time_gauge_progress_export_replaced:
    ; TODO: reconstruct body / data for 7E:99DD

; [unspecified] pass 50 :: ct_c1_lane_active_time_gauge_progress_export
; qualifier: strengthened
; notes: Visible lane-bar input used by `C1:06F0`. Initialized to zero by `B725`. Updated in the readiness-gauge advance families. Best reading now: visible active-time/readiness gauge progress export.
; source: chrono_trigger_labels_pass50.md
L_7E_99DD_ct_c1_lane_active_time_gauge_progress_export:
    ; TODO: reconstruct body / data for 7E:99DD

; [unspecified] pass 50 :: old wording “display value for scaled bar”                 [replaced]
; notes: Replaced by `ct_c1_lane_active_time_gauge_progress_export`.
; source: chrono_trigger_labels_pass50.md
L_7E_99DD_old_wording_display_value_for_scaled_bar_replaced:
    ; TODO: reconstruct body / data for 7E:99DD

; =============================================================================
; 7E:99DE  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 50 :: / 7E:99DF  ct_c1_lane_active_time_gauge_progress_export_1_2 [provisional]
; source: chrono_trigger_labels_pass50.md
L_7E_99DE_7E_99DF_ct_c1_lane_active_time_gauge_progress_export_1_2_provisional:
    ; TODO: reconstruct body / data for 7E:99DE

; =============================================================================
; 7E:99E2  top-status=strong  labels=1
; =============================================================================
; [strong] pass 44 :: ct_c1_tilemap_upload_pending_counter
; qualifier: strong
; notes: Dirty/request latch (or small counter) for the `0B40 -> VRAM 7A00` upload. Multiple bank-`C1` paths `INC` it after rewriting `0B40`. `CF:E380` checks it, performs the DMA upload, then clears it.
; source: chrono_trigger_labels_pass44.md
L_7E_99E2_ct_c1_tilemap_upload_pending_counter:
    ; TODO: reconstruct body / data for 7E:99E2

; =============================================================================
; 7E:9F20  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 49 :: ct_c1_companion_strip_layout_mode_3state
; qualifier: strengthened
; notes: Earlier passes proved it selects layout variants. With the HP/maxHP/MP field family now resolved harder, the layout mode is better understood as repositioning a stable status-field bundle rather than arbitrary numeric fragments.
; source: chrono_trigger_labels_pass49.md
L_7E_9F20_ct_c1_companion_strip_layout_mode_3state:
    ; TODO: reconstruct body / data for 7E:9F20

; =============================================================================
; 7E:9F22  top-status=provisional  labels=8
; =============================================================================
; [provisional] pass 54 :: ct_visible_head_lane_readiness_goal_export
; qualifier: strengthened
; notes: Pass 51 already pinned this as goal/cap export in the gauge-facing path. Pass 54 proves this mirror copy at `B93B..B94F` receives the same **post-normalized head work values** in this initializer path.
; source: chrono_trigger_labels_pass54.md
L_7E_9F22_ct_visible_head_lane_readiness_goal_export:
    ; TODO: reconstruct body / data for 7E:9F22
    ; known span hint: 7E:9F22..7E:9F24

; [provisional] pass 47 :: ct_c1_lane_display_divisor_or_capacity
; qualifier: provisional
; notes: Read by `C1:06F0` as the other scaling input to the segmented bar renderer. Exact human-facing meaning still unresolved.
; source: chrono_trigger_labels_pass47.md
L_7E_9F22_ct_c1_lane_display_divisor_or_capacity:
    ; TODO: reconstruct body / data for 7E:9F22

; [provisional] pass 43 :: ct_c1_lane_primary_value_export_b
; qualifier: provisional
; notes: Second export mirror updated from the same lane-carried value family as `B158/AFAB`.
; source: chrono_trigger_labels_pass43.md
L_7E_9F22_ct_c1_lane_primary_value_export_b:
    ; TODO: reconstruct body / data for 7E:9F22

; [provisional] pass 42 :: ct_c1_service7_lane_shadow_value_2
; qualifier: provisional
; notes: Three destinations that receive `B158[lane]` during lane clear/reset. Their exact downstream semantics are still open.
; source: chrono_trigger_labels_pass42.md
L_7E_9F22_ct_c1_service7_lane_shadow_value_2:
    ; TODO: reconstruct body / data for 7E:9F22

; [unspecified] pass 51 :: ct_c1_lane_active_time_gauge_goal_or_cap_export
; qualifier: strengthened
; notes: `C1:06F0` loads it as the denominator/goal-side value for the gauge math. `C1:BE00..BE2A` updates it without also updating `99DD`. Equal-write paths force `99DD == 9F22` to export a full/ready bar. Replaces the narrower pass-50 “cap export” wording with a harder goal/denominator role.
; source: chrono_trigger_labels_pass51.md
L_7E_9F22_ct_c1_lane_active_time_gauge_goal_or_cap_export:
    ; TODO: reconstruct body / data for 7E:9F22

; [unspecified] pass 51 :: old wording “lane_active_time_gauge_cap_export”                         [replaced]
; notes: Too narrow after the goal-only update path at `C1:BE00..BE2A` and the snap/full mirror paths. Replaced by `ct_c1_lane_active_time_gauge_goal_or_cap_export`.
; source: chrono_trigger_labels_pass51.md
L_7E_9F22_old_wording_lane_active_time_gauge_cap_export_replaced:
    ; TODO: reconstruct body / data for 7E:9F22

; [unspecified] pass 50 :: ct_c1_lane_active_time_gauge_cap_export
; qualifier: strengthened
; notes: Second visible lane-bar input used by `C1:06F0`. Initialized to `0x30` by `B725`. Updated by the readiness-gauge advance families. Best reading now: visible active-time/readiness gauge threshold/cap export.
; source: chrono_trigger_labels_pass50.md
L_7E_9F22_ct_c1_lane_active_time_gauge_cap_export:
    ; TODO: reconstruct body / data for 7E:9F22

; [unspecified] pass 50 :: old wording “display divisor or capacity”                  [replaced]
; notes: Replaced by `ct_c1_lane_active_time_gauge_cap_export`.
; source: chrono_trigger_labels_pass50.md
L_7E_9F22_old_wording_display_divisor_or_capacity_replaced:
    ; TODO: reconstruct body / data for 7E:9F22

; =============================================================================
; 7E:9F23  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 50 :: / 7E:9F24  ct_c1_lane_active_time_gauge_cap_export_1_2      [provisional]
; notes: `B725` proves these are sibling exports for the other visible lanes. Their human-facing meaning matches lane 0 strongly. Kept grouped/provisional only because pass 50 focused on the branch semantics more than on per-lane alias cleanup.
; source: chrono_trigger_labels_pass50.md
L_7E_9F23_7E_9F24_ct_c1_lane_active_time_gauge_cap_export_1_2_provisional:
    ; TODO: reconstruct body / data for 7E:9F23

; =============================================================================
; 7E:9F38  top-status=provisional  labels=2
; =============================================================================
; [provisional] pass 47 :: ct_c1_lane_emitted_aux_or_mask
; qualifier: provisional, unchanged
; notes: Pass 47 stayed on the strip/record presentation seam. Positive writer side remains intentionally unresolved.
; source: chrono_trigger_labels_pass47.md
L_7E_9F38_ct_c1_lane_emitted_aux_or_mask:
    ; TODO: reconstruct body / data for 7E:9F38

; [provisional] pass 42 :: ct_c1_service7_slot_aux_flags_for_emitted_records
; qualifier: provisional
; notes: Carried forward from pass 41. Still a valid sink-side label because its low bits feed `93EF` on emit,  Pass 42 materially tightened the downstream `93F3` family: the nibble The main unresolved seam has shifted again:
; source: chrono_trigger_labels_pass42.md
L_7E_9F38_ct_c1_service7_slot_aux_flags_for_emitted_records:
    ; TODO: reconstruct body / data for 7E:9F38

; =============================================================================
; 7E:9FFA  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 81 :: ct_cd_auxiliary_token_80_subop_1b_8byte_counter_or_flag_strip
; qualifier: provisional strengthened
; notes: Incremented across eight consecutive byte positions by sub-op `0x1B`. Final noun remains open.
; source: chrono_trigger_labels_pass81.md
L_7E_9FFA_ct_cd_auxiliary_token_80_subop_1b_8byte_counter_or_flag_strip:
    ; TODO: reconstruct body / data for 7E:9FFA
    ; known span hint: 7E:9FFA..7E:A001

; =============================================================================
; 7E:A05B  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 77 :: ct_c1_service04_per_row_emitted_fragment_record_counts
; qualifier: provisional strengthened
; notes: `4943` clears `A05B[current_row]` on row start. It increments the same entry once for each emitted 4-byte workspace record. Strongest safe reading so far: per-row emitted fragment/quad record counts.
; source: chrono_trigger_labels_pass77.md
L_7E_A05B_ct_c1_service04_per_row_emitted_fragment_record_counts:
    ; TODO: reconstruct body / data for 7E:A05B
    ; known span hint: 7E:A05B..7E:A07A

; =============================================================================
; 7E:A07B  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 77 :: ct_c1_service04_output_slot_active_flags_16_bytes
; qualifier: provisional strengthened
; notes: The shared `4833` tail stores `1` here for each of the sixteen seeded output slots. Strongest safe reading so far: per-slot active/emit flags for the `5D00..` output record family.  I have **not** fully frozen the final player-facing noun of the emitted `4500.. -> 5D00..` object family. I have **not** decoded `C3:0002`, which still matters because it materializes the packed `2D00..` stream consumed by `4943`. I have **not** frozen the exact per-byte meanings of the 7-byte mode-2/mode-3 profile records. `A2D3` and `A05B` are materially tighter than before, but they still stop just short of a perfect final noun.
; source: chrono_trigger_labels_pass77.md
L_7E_A07B_ct_c1_service04_output_slot_active_flags_16_bytes:
    ; TODO: reconstruct body / data for 7E:A07B
    ; known span hint: 7E:A07B..7E:A08A

; =============================================================================
; 7E:A10F  top-status=strong  labels=3
; =============================================================================
; [strong] pass 49 :: ct_c1_lane_hp_threshold_numeric_attr_selector
; qualifier: strong
; notes: Reset per lane before numeric field generation in `C1:0299`. Incremented only through the `currentHP` versus `maxHP/8` compare path. Immediately consumed to choose between paired-byte values `0x29` and `0x2D` for the lane’s rendered digits. Strongest safe reading: lane-local HP-threshold presentation selector/count.
; source: chrono_trigger_labels_pass49.md
L_7E_A10F_ct_c1_lane_hp_threshold_numeric_attr_selector:
    ; TODO: reconstruct body / data for 7E:A10F

; [provisional] pass 48 :: ct_c1_numeric_threshold_or_warning_counter
; qualifier: provisional
; notes: Incremented when the pre-render compare between `5E30` and `5E32 >> 8` fails in one direction. Strongly acts like a counter or warning latch related to numeric inconsistency/overflow. Final semantics remain unresolved.
; source: chrono_trigger_labels_pass48.md
L_7E_A10F_ct_c1_numeric_threshold_or_warning_counter:
    ; TODO: reconstruct body / data for 7E:A10F

; [unspecified] pass 49 :: old wording “numeric threshold or warning counter”
; qualifier: replaced
; notes: Too vague after pass 49. The ROM now supports a harder reading: a lane-local HP-threshold presentation selector/count.
; source: chrono_trigger_labels_pass49.md
L_7E_A10F_old_wording_numeric_threshold_or_warning_counter:
    ; TODO: reconstruct body / data for 7E:A10F

; =============================================================================
; 7E:A280  top-status=strong  labels=1
; =============================================================================
; [strong] pass 77 :: ct_c1_service04_ce_fragment_group_start_pointers_16_words
; qualifier: strong structural
; notes: Seeded by `48EC`. Holds the parsed CE-stream start pointer for each fragment group. Initial entry `0` is seeded from `9885` before group parsing advances.
; source: chrono_trigger_labels_pass77.md
L_7E_A280_ct_c1_service04_ce_fragment_group_start_pointers_16_words:
    ; TODO: reconstruct body / data for 7E:A280
    ; known span hint: 7E:A280..7E:A29F

; =============================================================================
; 7E:A2A0  top-status=strong  labels=1
; =============================================================================
; [strong] pass 77 :: ct_c1_service04_ce_fragment_group_unit_counts_16_bytes
; qualifier: strong structural
; notes: Written by `48EC` alongside `A280`. Holds the committed per-group count of 4-byte units derived from the segmented CE stream.
; source: chrono_trigger_labels_pass77.md
L_7E_A2A0_ct_c1_service04_ce_fragment_group_unit_counts_16_bytes:
    ; TODO: reconstruct body / data for 7E:A2A0
    ; known span hint: 7E:A2A0..7E:A2AF

; =============================================================================
; 7E:A2D3  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 77 :: ct_c1_service04_current_packed_fragment_decode_bytes
; qualifier: provisional strengthened
; notes: Filled by `4943` from the packed `2D00..` stream using the low-nibble count from the batch header byte. The bytes are shifted in-place and their carry result controls whether 4-byte records are emitted into the `4500..` workspace.
; source: chrono_trigger_labels_pass77.md
L_7E_A2D3_ct_c1_service04_current_packed_fragment_decode_bytes:
    ; TODO: reconstruct body / data for 7E:A2D3
    ; known span hint: 7E:A2D3..7E:A2E2

; =============================================================================
; 7E:A650  top-status=strong  labels=1
; =============================================================================
; [strong] pass 77 :: ct_c1_service04_current_fragment_output_row_index
; qualifier: strong structural
; notes: Used by `4943` to choose a row base through `CC:F7C0`. Also indexes the `A05B` produced-record count family.
; source: chrono_trigger_labels_pass77.md
L_7E_A650_ct_c1_service04_current_fragment_output_row_index:
    ; TODO: reconstruct body / data for 7E:A650

; =============================================================================
; 7E:A652  top-status=strong  labels=1
; =============================================================================
; [strong] pass 77 :: ct_c1_service04_current_packed_fragment_stream_cursor
; qualifier: strong structural
; notes: The active `2D00..` cursor used by `4943`. Advanced repeatedly as compact fragment data and emitted-record payload bytes are consumed.
; source: chrono_trigger_labels_pass77.md
L_7E_A652_ct_c1_service04_current_packed_fragment_stream_cursor:
    ; TODO: reconstruct body / data for 7E:A652

; =============================================================================
; 7E:A6D9  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_active_lane_roster_marker_per_lane
; qualifier: strong
; notes: Three-entry per-lane active-roster membership marker. `FF` = absent/inactive. Nonnegative = lane is present in the local active controller.
; source: chrono_trigger_labels_pass43.md
L_7E_A6D9_ct_c1_active_lane_roster_marker_per_lane:
    ; TODO: reconstruct body / data for 7E:A6D9

; =============================================================================
; 7E:A6DD  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_current_active_lane
; qualifier: strong
; notes: Current active lane for the local 3-lane controller. Reseated by service 2 when the current lane is removed.
; source: chrono_trigger_labels_pass43.md
L_7E_A6DD_ct_c1_current_active_lane:
    ; TODO: reconstruct body / data for 7E:A6DD

; =============================================================================
; 7E:A6DE  top-status=strong  labels=1
; =============================================================================
; [strong] pass 43 :: ct_c1_active_lane_count
; qualifier: strong
; notes: Active-lane count for the local 3-lane controller. Incremented when a pending lane is promoted; decremented when an active lane is removed.
; source: chrono_trigger_labels_pass43.md
L_7E_A6DE_ct_c1_active_lane_count:
    ; TODO: reconstruct body / data for 7E:A6DE

; =============================================================================
; 7E:A6DF  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 43 :: ct_c1_lane_roster_change_sentinel
; qualifier: provisional
; notes: Forced to `FEh` in both the pending->active promotion path and the active-lane removal path. Structurally real, but exact downstream meaning still needs more proof.
; source: chrono_trigger_labels_pass43.md
L_7E_A6DF_ct_c1_lane_roster_change_sentinel:
    ; TODO: reconstruct body / data for 7E:A6DF

; =============================================================================
; 7E:AD89  top-status=strong  labels=1
; =============================================================================
; [strong] pass 74 :: ct_c1_pending_stat_delta_packet_amount_seed
; qualifier: strong structural
; notes: 16-bit amount consumed by `EBF8` before queue write. Negated first when `B202.bit7` is set.
; source: chrono_trigger_labels_pass74.md
L_7E_AD89_ct_c1_pending_stat_delta_packet_amount_seed:
    ; TODO: reconstruct body / data for 7E:AD89
    ; known span hint: 7E:AD89..7E:AD8A

; =============================================================================
; 7E:AD9B  top-status=strong  labels=1
; =============================================================================
; [strong] pass 74 :: ct_c1_transient_packet_workspace_record_index
; qualifier: strong structural
; notes: Record selector used by the `0x2C * record + 4 * slot` packet-workspace addressing formula. Explicitly cleared by `FD:ACEE`.
; source: chrono_trigger_labels_pass74.md
L_7E_AD9B_ct_c1_transient_packet_workspace_record_index:
    ; TODO: reconstruct body / data for 7E:AD9B

; =============================================================================
; 7E:AD9C  top-status=strong  labels=1
; =============================================================================
; [strong] pass 74 :: ct_c1_transient_packet_workspace_records_4x11x4
; qualifier: strong structural
; notes: Transient packet workspace proven by the `0x2C` record stride and the `0xB0`-byte clear size in `FD:ACEE`. Strongest safe structure: 4 records × 11 slots × 4 bytes.
; source: chrono_trigger_labels_pass74.md
L_7E_AD9C_ct_c1_transient_packet_workspace_records_4x11x4:
    ; TODO: reconstruct body / data for 7E:AD9C
    ; known span hint: 7E:AD9C..7E:AE4B

; =============================================================================
; 7E:AE55  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 74 :: ct_c1_materialization_descriptor_option_flags
; qualifier: provisional strengthened
; notes: Loaded from table-driven descriptor bytes around `CC:6FCC...`. Consumed by the `8CF9` tail. Bit `3` suppresses arming the alternate continuation pointer in `B2C0`. Other bits still need more proof.
; source: chrono_trigger_labels_pass74.md
L_7E_AE55_ct_c1_materialization_descriptor_option_flags:
    ; TODO: reconstruct body / data for 7E:AE55

; =============================================================================
; 7E:AE91  top-status=strong  labels=1
; =============================================================================
; [strong] pass 76 :: ct_c1_service04_source_or_current_slot_selector
; qualifier: strong structural
; notes: Service-04 modes `1` and `2` immediately branch on whether `AE91 < 3` or `AE91 >= 3`. This byte selects the source/current slot family for the active service-04 profile loader.
; source: chrono_trigger_labels_pass76.md
L_7E_AE91_ct_c1_service04_source_or_current_slot_selector:
    ; TODO: reconstruct body / data for 7E:AE91

; =============================================================================
; 7E:AE92  top-status=strong  labels=1
; =============================================================================
; [strong] pass 76 :: ct_c1_service04_mode_selector
; qualifier: strong
; notes: Directly consumed by `431D`. Values `0..3` select service-04 mode handlers through the `7A63` table. Values `>=4` fall back to mode `0`.
; source: chrono_trigger_labels_pass76.md
L_7E_AE92_ct_c1_service04_mode_selector:
    ; TODO: reconstruct body / data for 7E:AE92

; =============================================================================
; 7E:AE93  top-status=strong  labels=1
; =============================================================================
; [strong] pass 76 :: ct_c1_service04_profile_or_pattern_index
; qualifier: strong structural
; notes: Used directly as the record selector in service-04 mode `2` via `X = 7 * AE93`. Also gates family selection inside mode `1` and suppresses/permits parts of the shared `4833` tail. This is no longer generic follow-up scratch; it is a real service-04 profile/pattern index.
; source: chrono_trigger_labels_pass76.md
L_7E_AE93_ct_c1_service04_profile_or_pattern_index:
    ; TODO: reconstruct body / data for 7E:AE93

; =============================================================================
; 7E:AE94  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 76 :: ct_c1_service04_optional_cd0018_stage_suppress_or_override_flag
; qualifier: provisional strengthened
; notes: The shared `4833` runner only enters the optional `JSL CD:0018` stage when `AE94 == 0`. Strongest safe reading so far: suppress/override flag for one optional service-04 substage.
; source: chrono_trigger_labels_pass76.md
L_7E_AE94_ct_c1_service04_optional_cd0018_stage_suppress_or_override_flag:
    ; TODO: reconstruct body / data for 7E:AE94

; =============================================================================
; 7E:AEC5  top-status=strong  labels=2
; =============================================================================
; [strong] pass 55 :: ct_visible_head_occupied_slot_count
; qualifier: strong
; notes: Incremented when canonical head-slot rebuilds admit a valid visible occupant. Reset and rebuilt in both: `FD:B24D..B27E` `C1:FB06..FB2C`
; source: chrono_trigger_labels_pass55.md
L_7E_AEC5_ct_visible_head_occupied_slot_count:
    ; TODO: reconstruct body / data for 7E:AEC5

; [unspecified] pass 55 :: ct_visible_head_active_slot_count
; qualifier: strengthened
; notes: Tightened from generic “active slot count” wording. Specifically counts admitted visible-head occupants during head-map rebuild.
; source: chrono_trigger_labels_pass55.md
L_7E_AEC5_ct_visible_head_active_slot_count:
    ; TODO: reconstruct body / data for 7E:AEC5

; =============================================================================
; 7E:AEC6  top-status=strong  labels=2
; =============================================================================
; [strong] pass 56 :: ct_canonical_tail_slot_count
; qualifier: strong
; notes: Reset by the canonical tail-map builder at `FD:B2A3`. Incremented once per admitted tail source record. Counts populated canonical tail entries, not merely currently live tail occupants.
; source: chrono_trigger_labels_pass56.md
L_7E_AEC6_ct_canonical_tail_slot_count:
    ; TODO: reconstruct body / data for 7E:AEC6

; [provisional] pass 53 :: ct_runtime_tail_slot_count
; qualifier: strengthened
; notes: Used as the bound for the tail seeder loop in `FD:B867..B8EC`. Best current reading: live/populated tail-slot count rather than total capacity.
; source: chrono_trigger_labels_pass53.md
L_7E_AEC6_ct_runtime_tail_slot_count:
    ; TODO: reconstruct body / data for 7E:AEC6

; =============================================================================
; 7E:AECB  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 57 :: / 7E:AECC  global labels should remain cautious
; notes: in `AB03`, `AECC` temporarily holds withheld tail-slot indices in `AB03`, `AECB` temporarily holds the count of those withheld candidates  the compare/gate exists the final noun still wants wrapper proof the mechanical meaning is now strong the exact scenario/use case still wants caller proof this pass proves it suppresses dispatch in `8C0A` the exact state meaning remains open
; source: chrono_trigger_labels_pass57.md
L_7E_AECB_7E_AECC_global_labels_should_remain_cautious:
    ; TODO: reconstruct body / data for 7E:AECB

; =============================================================================
; 7E:AEE6  top-status=strong  labels=1
; =============================================================================
; [strong] pass 75 :: ct_c1_current_followup_descriptor_profile_record_17bytes
; qualifier: strong structural
; notes: Destination of the `BF7F` copy. Holds the currently loaded 17-byte follow-up/descriptor profile selected by `B18C`.
; source: chrono_trigger_labels_pass75.md
L_7E_AEE6_ct_c1_current_followup_descriptor_profile_record_17bytes:
    ; TODO: reconstruct body / data for 7E:AEE6
    ; known span hint: 7E:AEE6..7E:AEF6

; =============================================================================
; 7E:AEFF  top-status=strong  labels=4
; =============================================================================
; [strong] pass 56 :: ct_battle_slot_live_occupant_map
; qualifier: strengthened
; notes: Unified 11-slot live occupant map. Slots `0..2` = visible head live occupants. Slots `3..10` = tail live/materialized occupants. `FF` means unoccupied / not live in this map.
; source: chrono_trigger_labels_pass56.md
L_7E_AEFF_ct_battle_slot_live_occupant_map:
    ; TODO: reconstruct body / data for 7E:AEFF
    ; known span hint: 7E:AEFF..7E:AF09

; [strong] pass 55 :: ct_battle_slot_occupant_index_map
; qualifier: strong
; notes: Slot-indexed map. Each non-`FF` entry names the battler/participant currently assigned to that slot. `FF` means the slot is unoccupied. Proven by: direct slot initialization at `FD:B24D..B27E` alternate rebuild at `C1:FB06..FB2C` inverse-map construction into `B1BE` at `FD:B28F..B2A3` battler-structured downstream consumption at `FD:B363...`
; source: chrono_trigger_labels_pass55.md
L_7E_AEFF_ct_battle_slot_occupant_index_map:
    ; TODO: reconstruct body / data for 7E:AEFF
    ; known span hint: 7E:AEFF..7E:AF09

; [unspecified] pass 55 :: ct_battle_slot_active_entry_gate_array
; qualifier: replaced
; notes: Too weak after pass 55. Replaced by: `ct_battle_slot_occupant_index_map` The gating behavior from pass 54 remains true, but it is now clearly a consequence of slot occupancy, not the primary noun.
; source: chrono_trigger_labels_pass55.md
L_7E_AEFF_ct_battle_slot_active_entry_gate_array:
    ; TODO: reconstruct body / data for 7E:AEFF
    ; known span hint: 7E:AEFF..7E:AF09

; [unspecified] pass 55 :: “active-entry gate array”
; qualifier: retired as primary noun
; notes: Still true in pass-54 arithmetic terms. No longer the best primary label after pass 55.
; source: chrono_trigger_labels_pass55.md
L_7E_AEFF_active_entry_gate_array:
    ; TODO: reconstruct body / data for 7E:AEFF
    ; known span hint: 7E:AEFF..7E:AF09

; =============================================================================
; 7E:AF02  top-status=strong  labels=1
; =============================================================================
; [strong] pass 56 :: ct_tail_live_occupant_submap
; qualifier: strong
; notes: Tail subrange of the unified live occupant map. Receives occupant IDs from the `29C4` source family. May be forced to `FF` while the canonical tail map still retains the occupant.
; source: chrono_trigger_labels_pass56.md
L_7E_AF02_ct_tail_live_occupant_submap:
    ; TODO: reconstruct body / data for 7E:AF02
    ; known span hint: 7E:AF02..7E:AF09

; =============================================================================
; 7E:AF0A  top-status=strong  labels=4
; =============================================================================
; [strong] pass 56 :: ct_battle_slot_canonical_occupant_map
; qualifier: strengthened
; notes: Unified 11-slot canonical/remembered occupant map. Head half built from the visible source path. Tail half built from the `29C4` source-record family.
; source: chrono_trigger_labels_pass56.md
L_7E_AF0A_ct_battle_slot_canonical_occupant_map:
    ; TODO: reconstruct body / data for 7E:AF0A
    ; known span hint: 7E:AF0A..7E:AF14

; [strong] pass 55 :: ct_battle_slot_default_occupant_index_map
; qualifier: strong
; notes: Initialized in lockstep with `AEFF`. Used by `C1:B279..B28E` to restore live slot occupancy. Shares the same `FF` empty sentinel semantics.
; source: chrono_trigger_labels_pass55.md
L_7E_AF0A_ct_battle_slot_default_occupant_index_map:
    ; TODO: reconstruct body / data for 7E:AF0A
    ; known span hint: 7E:AF0A..7E:AF14

; [unspecified] pass 55 :: ct_battle_slot_occupant_index_mirror
; qualifier: strengthened
; notes: Pass 55 shows this is not just a mirror. It is the remembered/default occupant map used for restoration.
; source: chrono_trigger_labels_pass55.md
L_7E_AF0A_ct_battle_slot_occupant_index_mirror:
    ; TODO: reconstruct body / data for 7E:AF0A
    ; known span hint: 7E:AF0A..7E:AF14

; [unspecified] pass 55 :: “occupant mirror”
; qualifier: retired as primary noun
; notes: Too weak after restore-path proof. Replace with “default / remembered occupant index map”.   Trace direct producer paths for tail-slot occupants beyond the visible-head rebuilders. Re-check the ready-transition helpers with the now-frozen occupant-map model. Target the downstream logic that distinguishes: occupied-but-zero readiness occupied-and-one-step-away readiness occupied-and-larger-positive readiness
; source: chrono_trigger_labels_pass55.md
L_7E_AF0A_occupant_mirror:
    ; TODO: reconstruct body / data for 7E:AF0A
    ; known span hint: 7E:AF0A..7E:AF14

; =============================================================================
; 7E:AF0D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 56 :: ct_tail_canonical_occupant_submap
; qualifier: strong
; notes: Tail subrange of the unified canonical/remembered occupant map. Always receives the admitted occupant ID when the tail-source gate passes.
; source: chrono_trigger_labels_pass56.md
L_7E_AF0D_ct_tail_canonical_occupant_submap:
    ; TODO: reconstruct body / data for 7E:AF0D
    ; known span hint: 7E:AF0D..7E:AF14

; =============================================================================
; 7E:AF15  top-status=strong  labels=4
; =============================================================================
; [strong] pass 57 :: bit 7  ct_tail_deferred_materialization_flag                              [strengthened]
; notes: Stronger than pass 56's “canonical present but not live” wording. Bit 7 now sits inside a proved selection/materialization flow: collected by `AB03` ignored by ordinary live-tail consumers cleared by `AED3` when the entry is materialized into `AF02` Safest current noun: deferred / withheld-from-live tail materialization flag.
; source: chrono_trigger_labels_pass57.md
L_7E_AF15_bit_7_ct_tail_deferred_materialization_flag_strengthened:
    ; TODO: reconstruct body / data for 7E:AF15

; [provisional] pass 53 :: bit 6  ct_runtime_tail_slot_seed_side_effect_flag                     [provisional]
; notes: Set only by the tail seeder when source record byte `+0x0A` has bit 0 set. Real and structurally isolated, but final gameplay-facing meaning is still unresolved.
; source: chrono_trigger_labels_pass53.md
L_7E_AF15_bit_6_ct_runtime_tail_slot_seed_side_effect_flag_provisional:
    ; TODO: reconstruct body / data for 7E:AF15

; [unspecified] pass 56 :: bit 7  ct_tail_canonical_present_but_not_live_flag               [strengthened]
; notes: Set only when the tail-source builder keeps the canonical occupant (`AF0D`) but forces the live occupant (`AF02`) to `FF`. Strong structural meaning: canonical tail entry exists, but it is withheld from the live/materialized tail map. Exact gameplay-facing noun remains cautious.
; source: chrono_trigger_labels_pass56.md
L_7E_AF15_bit_7_ct_tail_canonical_present_but_not_live_flag_strengthened:
    ; TODO: reconstruct body / data for 7E:AF15

; [unspecified] pass 52 :: bit 6  ct_runtime_slot_sibling_seed_side_effect_flag                  [provisional]
; notes: Set by the sibling seed family when record byte `+0x0A` has bit 0 set. Real side effect, but gameplay-facing meaning still unresolved.
; source: chrono_trigger_labels_pass52.md
L_7E_AF15_bit_6_ct_runtime_slot_sibling_seed_side_effect_flag_provisional:
    ; TODO: reconstruct body / data for 7E:AF15

; =============================================================================
; 7E:AFAB  top-status=provisional  labels=9
; =============================================================================
; [provisional] pass 54 :: value `0`  ct_battle_slot_readiness_zero_special_state                [provisional]
; notes: In this routine, zero values are: excluded from minimum selection excluded from subtractive normalization preserved across the pass Strong structural meaning: not an active positive countdown participant. Final gameplay-facing noun still wants one more downstream confirmation.
; source: chrono_trigger_labels_pass54.md
L_7E_AFAB_value_0_ct_battle_slot_readiness_zero_special_state_provisional:
    ; TODO: reconstruct body / data for 7E:AFAB

; [provisional] pass 51 :: ct_c1_lane_readiness_work_value
; qualifier: strengthened
; notes: Receives the same upstream seed as `B158` in the battle-side writer families. Is also the working value advanced by the later goal/snap export families. Stronger now as the work-value/shadow branch for the lane readiness gauge.
; source: chrono_trigger_labels_pass51.md
L_7E_AFAB_ct_c1_lane_readiness_work_value:
    ; TODO: reconstruct body / data for 7E:AFAB

; [provisional] pass 43 :: ct_c1_lane_primary_carried_value_shadow
; qualifier: provisional
; notes: Per-lane shadow/mirror of `B158`.
; source: chrono_trigger_labels_pass43.md
L_7E_AFAB_ct_c1_lane_primary_carried_value_shadow:
    ; TODO: reconstruct body / data for 7E:AFAB

; [provisional] pass 42 :: ct_c1_service7_lane_shadow_value_0
; qualifier: provisional
; source: chrono_trigger_labels_pass42.md
L_7E_AFAB_ct_c1_service7_lane_shadow_value_0:
    ; TODO: reconstruct body / data for 7E:AFAB

; [unspecified] pass 54 :: ct_battle_slot_readiness_work_array
; qualifier: strengthened
; notes: Pass 53 proved this is one unified 11-entry work array. Pass 54 proves it is also the target of a **minimum-positive subtractive normalization**. Smallest eligible positive value is forced to `1` before head export. Zero entries are preserved. `AEFF == FF` entries are preserved.
; source: chrono_trigger_labels_pass54.md
L_7E_AFAB_ct_battle_slot_readiness_work_array:
    ; TODO: reconstruct body / data for 7E:AFAB
    ; known span hint: 7E:AFAB..7E:AFB5

; [unspecified] pass 54 :: ct_visible_head_lane_readiness_work_array
; qualifier: strengthened
; notes: Still the visible head partition. Pass 54 proves these values are exported **after unified 11-slot normalization**, not as raw seeded values.
; source: chrono_trigger_labels_pass54.md
L_7E_AFAB_ct_visible_head_lane_readiness_work_array:
    ; TODO: reconstruct body / data for 7E:AFAB
    ; known span hint: 7E:AFAB..7E:AFAD

; [unspecified] pass 52 :: ct_c1_primary_lane_readiness_work_value
; qualifier: strengthened
; notes: Receives the same formula result as `B158` in the primary seed family. Still the best working/readiness-shadow label.
; source: chrono_trigger_labels_pass52.md
L_7E_AFAB_ct_c1_primary_lane_readiness_work_value:
    ; TODO: reconstruct body / data for 7E:AFAB

; [unspecified] pass 51 :: old wording “lane_active_time_increment_shadow”                         [soft-replaced]
; notes: Too narrow after the direct seed/export mirror proof and the later working-value advances. Soft-replaced by `ct_c1_lane_readiness_work_value`.
; source: chrono_trigger_labels_pass51.md
L_7E_AFAB_old_wording_lane_active_time_increment_shadow_soft_replaced:
    ; TODO: reconstruct body / data for 7E:AFAB

; [unspecified] pass 50 :: ct_c1_lane_active_time_increment_shadow
; qualifier: strengthened
; notes: Working shadow derived from `B158`. Modified by `BD6F` through slow-like / haste-like status effects. Consumed by the gauge-advance families at `BDE0/BE50/BED0`. Best reading now: status-adjusted active-time/readiness increment shadow.
; source: chrono_trigger_labels_pass50.md
L_7E_AFAB_ct_c1_lane_active_time_increment_shadow:
    ; TODO: reconstruct body / data for 7E:AFAB

; =============================================================================
; 7E:AFAE  top-status=provisional  labels=2
; =============================================================================
; [provisional] pass 52 :: ct_c1_sibling_lane_readiness_work_value
; qualifier: provisional
; notes: Formula-aligned sibling of `AFAB`. Final freeze deferred pending more downstream consumer proof.
; source: chrono_trigger_labels_pass52.md
L_7E_AFAE_ct_c1_sibling_lane_readiness_work_value:
    ; TODO: reconstruct body / data for 7E:AFAE

; [unspecified] pass 54 :: ct_runtime_tail_slot_readiness_work_array
; qualifier: strengthened
; notes: Tail partition still not exported directly here. Pass 54 proves it still participates in the same shared normalization pass as the visible head. This is strong evidence that head and tail are one readiness/countdown space, not parallel unrelated arrays.
; source: chrono_trigger_labels_pass54.md
L_7E_AFAE_ct_runtime_tail_slot_readiness_work_array:
    ; TODO: reconstruct body / data for 7E:AFAE
    ; known span hint: 7E:AFAE..7E:AFB5

; =============================================================================
; 7E:B03A  top-status=strong  labels=6
; =============================================================================
; [strong] pass 53 :: ct_battle_slot_readiness_dirty_array
; qualifier: strong
; notes: Contiguous 11-byte readiness update/valid array. Head seeder writes the first 3 entries through `B03A,X`. Tail seeder writes the later entries through `B03D,X = B03A + 3 + X`.
; source: chrono_trigger_labels_pass53.md
L_7E_B03A_ct_battle_slot_readiness_dirty_array:
    ; TODO: reconstruct body / data for 7E:B03A
    ; known span hint: 7E:B03A..7E:B044

; [provisional] pass 52 :: ct_c1_primary_visible_lane_readiness_seed_valid_flag
; qualifier: strengthened
; notes: This pass confirms it is asserted directly by the primary seed family after the exact formula store.
; source: chrono_trigger_labels_pass52.md
L_7E_B03A_ct_c1_primary_visible_lane_readiness_seed_valid_flag:
    ; TODO: reconstruct body / data for 7E:B03A

; [provisional] pass 51 :: ct_c1_visible_lane_readiness_seed_valid_flag
; qualifier: provisional
; notes: Set to `1` by the primary visible-lane seed family at `FD:B820..B850`. Strongly looks like a “valid/seeded/armed” lane flag. Final freeze deferred until the sibling `B03D` path is fully aligned.
; source: chrono_trigger_labels_pass51.md
L_7E_B03A_ct_c1_visible_lane_readiness_seed_valid_flag:
    ; TODO: reconstruct body / data for 7E:B03A

; [provisional] pass 43 :: ct_c1_lane_secondary_dirty_latch
; qualifier: provisional
; notes: Secondary per-lane latch cleared beside `B188` in the lane-reset families. Structurally part of the same carried-state bundle, but exact semantics remain open.
; source: chrono_trigger_labels_pass43.md
L_7E_B03A_ct_c1_lane_secondary_dirty_latch:
    ; TODO: reconstruct body / data for 7E:B03A

; [provisional] pass 42 :: ct_c1_service7_lane_aux_reset_field
; qualifier: provisional
; notes: Cleared during both lane-reset helpers. Real reset role is proven; human-facing meaning is still open.
; source: chrono_trigger_labels_pass42.md
L_7E_B03A_ct_c1_service7_lane_aux_reset_field:
    ; TODO: reconstruct body / data for 7E:B03A

; [unspecified] pass 53 :: ct_visible_head_lane_readiness_dirty_array
; qualifier: strengthened
; notes: Head partition of the contiguous readiness dirty/update array. Asserted directly by the head seeder.
; source: chrono_trigger_labels_pass53.md
L_7E_B03A_ct_visible_head_lane_readiness_dirty_array:
    ; TODO: reconstruct body / data for 7E:B03A
    ; known span hint: 7E:B03A..7E:B03C

; =============================================================================
; 7E:B03D  top-status=provisional  labels=2
; =============================================================================
; [provisional] pass 52 :: ct_c1_sibling_visible_lane_readiness_seed_valid_flag
; qualifier: provisional
; notes: Sibling of `B03A`, but only set under an extra gate (`AF02 != FF`). Final freeze deferred pending tighter alignment with the lane-selection/state machinery.
; source: chrono_trigger_labels_pass52.md
L_7E_B03D_ct_c1_sibling_visible_lane_readiness_seed_valid_flag:
    ; TODO: reconstruct body / data for 7E:B03D

; [unspecified] pass 53 :: ct_runtime_tail_slot_readiness_dirty_array
; qualifier: strengthened
; notes: Tail partition of the contiguous readiness dirty array rooted at `B03A`. Set by the tail seeder only under the extra `AF02 != FF` gate.
; source: chrono_trigger_labels_pass53.md
L_7E_B03D_ct_runtime_tail_slot_readiness_dirty_array:
    ; TODO: reconstruct body / data for 7E:B03D
    ; known span hint: 7E:B03D..7E:B044

; =============================================================================
; 7E:B158  top-status=strong  labels=9
; =============================================================================
; [strong] pass 53 :: ct_battle_slot_readiness_seed_array
; qualifier: strong
; notes: Contiguous 11-byte readiness/base array. Proven by the 11-entry bulk writer at `FD:B4E0..B54D`. Head partition = `B158..B15A`. Tail partition = `B15B..B162`.
; source: chrono_trigger_labels_pass53.md
L_7E_B158_ct_battle_slot_readiness_seed_array:
    ; TODO: reconstruct body / data for 7E:B158
    ; known span hint: 7E:B158..7E:B162

; [provisional] pass 43 :: ct_c1_lane_primary_carried_value
; qualifier: provisional
; notes: Per-lane carried scalar maintained beside the canonical-record lane system. Mirrored into `AFAB`, and exported to `99DD` / `9F22` in the clear/update families.
; source: chrono_trigger_labels_pass43.md
L_7E_B158_ct_c1_lane_primary_carried_value:
    ; TODO: reconstruct body / data for 7E:B158

; [provisional] pass 42 :: ct_c1_service7_lane_carried_value
; qualifier: provisional
; notes: Copied into `AFAB`, `99DD`, and `9F22` during lane clear/reset. Structural role is real; gameplay-facing meaning is still unresolved.
; source: chrono_trigger_labels_pass42.md
L_7E_B158_ct_c1_service7_lane_carried_value:
    ; TODO: reconstruct body / data for 7E:B158

; [unspecified] pass 53 :: ct_visible_head_lane_readiness_seed_array
; qualifier: strengthened
; notes: Previously treated as a standalone “primary pair”. This pass proves it is the fixed 3-entry head partition of the larger 11-slot seed array. These are the entries directly tied to the visible export path.
; source: chrono_trigger_labels_pass53.md
L_7E_B158_ct_visible_head_lane_readiness_seed_array:
    ; TODO: reconstruct body / data for 7E:B158
    ; known span hint: 7E:B158..7E:B15A

; [unspecified] pass 52 :: ct_c1_primary_lane_readiness_seed_value
; qualifier: strengthened
; notes: Still best kept as a seed value rather than a final gameplay-facing name. This pass proves the exact upstream formula feeding it.
; source: chrono_trigger_labels_pass52.md
L_7E_B158_ct_c1_primary_lane_readiness_seed_value:
    ; TODO: reconstruct body / data for 7E:B158

; [unspecified] pass 51 :: ct_c1_lane_readiness_seed_value
; qualifier: strengthened
; notes: This pass proves `B158` is a direct upstream seed into the visible lane-gauge branch. `C1:B390` mirrors it directly into `AFAB/99DD/9F22`. `FD:B820..B850` seeds it from a speed-like stat and bonus table. This is a stronger and safer description than the older purely generic scalar wording.
; source: chrono_trigger_labels_pass51.md
L_7E_B158_ct_c1_lane_readiness_seed_value:
    ; TODO: reconstruct body / data for 7E:B158

; [unspecified] pass 51 :: old wording “lane_base_active_time_increment”                           [soft-replaced]
; notes: Pass 50's increment wording was useful but too narrow. Pass 51 proves `B158` is at least a direct upstream seed value for the readiness-gauge branch. Soft-replaced by `ct_c1_lane_readiness_seed_value` pending one more pass on exact subroles.
; source: chrono_trigger_labels_pass51.md
L_7E_B158_old_wording_lane_base_active_time_increment_soft_replaced:
    ; TODO: reconstruct body / data for 7E:B158

; [unspecified] pass 50 :: / 7E:AFAB old wording “primary carried scalar/shadow”      [replaced]
; notes: Too abstract after the status-modified gauge-rate proof. Replaced by the active-time/readiness increment wording.
; source: chrono_trigger_labels_pass50.md
L_7E_B158_7E_AFAB_old_wording_primary_carried_scalar_shadow_replaced:
    ; TODO: reconstruct body / data for 7E:B158

; [unspecified] pass 50 :: ct_c1_lane_base_active_time_increment
; qualifier: strengthened
; notes: Repeatedly copied into `AFAB` before `BD6F` is applied. Feeds the visible lane-bar branch through the status-modified increment family. Best reading now: base active-time/readiness increment.
; source: chrono_trigger_labels_pass50.md
L_7E_B158_ct_c1_lane_base_active_time_increment:
    ; TODO: reconstruct body / data for 7E:B158

; =============================================================================
; 7E:B15B  top-status=provisional  labels=2
; =============================================================================
; [provisional] pass 52 :: ct_c1_sibling_lane_readiness_seed_value
; qualifier: provisional
; notes: Formula-aligned sibling of `B158`. Final freeze deferred until the exact caller/consumer split is clearer.
; source: chrono_trigger_labels_pass52.md
L_7E_B15B_ct_c1_sibling_lane_readiness_seed_value:
    ; TODO: reconstruct body / data for 7E:B15B

; [unspecified] pass 53 :: ct_runtime_tail_slot_readiness_seed_array
; qualifier: strengthened
; notes: Previously labeled as a separate “sibling” seed pair. This pass proves it is the tail partition of the same contiguous seed array rooted at `B158`. Seeded by the same config/speed formula as the head partition.
; source: chrono_trigger_labels_pass53.md
L_7E_B15B_ct_runtime_tail_slot_readiness_seed_array:
    ; TODO: reconstruct body / data for 7E:B15B
    ; known span hint: 7E:B15B..7E:B162

; =============================================================================
; 7E:B188  top-status=strong  labels=2
; =============================================================================
; [strong] pass 43 :: ct_c1_lane_occupied_refresh_latch
; qualifier: strong
; notes: Per-lane occupied/refresh-required latch. Directly gates whether the lane-clear path at `FD:A8FE` escalates into local service 2.
; source: chrono_trigger_labels_pass43.md
L_7E_B188_ct_c1_lane_occupied_refresh_latch:
    ; TODO: reconstruct body / data for 7E:B188

; [provisional] pass 42 :: ct_c1_service7_lane_occupied_or_latched_flag
; qualifier: provisional
; notes: Gates the extra refresh path in `FD:A8FE`. Strongly looks like a lane-occupied / lane-latched byte, but still needs
; source: chrono_trigger_labels_pass42.md
L_7E_B188_ct_c1_service7_lane_occupied_or_latched_flag:
    ; TODO: reconstruct body / data for 7E:B188

; =============================================================================
; 7E:B1BE  top-status=strong  labels=2
; =============================================================================
; [strong] pass 55 :: ct_battler_to_visible_head_slot_inverse_map                 [strong]
; notes: Rebuilt from `AEFF[0..2]` at `FD:B28F..B2A3`. Semantics: `B1BE[battler] = visible head slot`. Consumed directly by `C1:BE50..BF24`.
; source: chrono_trigger_labels_pass55.md
L_7E_B1BE_ct_battler_to_visible_head_slot_inverse_map_strong:
    ; TODO: reconstruct body / data for 7E:B1BE

; [unspecified] pass 55 :: ct_visible_lane_inverse_lookup                               [strengthened]
; notes: Pass 55 makes the direction exact: battler index -> visible head slot Used by targeted readiness/gauge helpers after `B2EB/B2EC` selection.
; source: chrono_trigger_labels_pass55.md
L_7E_B1BE_ct_visible_lane_inverse_lookup_strengthened:
    ; TODO: reconstruct body / data for 7E:B1BE

; =============================================================================
; 7E:B1CF  top-status=strong  labels=1
; =============================================================================
; [strong] pass 60 :: ct_late_selector_segment_has_chained_second_subopcode_flag
; qualifier: strong
; notes: Set when `CC:[current_segment + 4] != FE`. Governs whether the late executor dispatches a second 4-byte sub-op from `+4`.
; source: chrono_trigger_labels_pass60.md
L_7E_B1CF_ct_late_selector_segment_has_chained_second_subopcode_flag:
    ; TODO: reconstruct body / data for 7E:B1CF

; =============================================================================
; 7E:B1FC  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 75 :: ct_c1_followup_context_flags
; qualifier: provisional strengthened
; notes: `BFAA` sets bit `0x02` on entry and clears it before return. Strongest safe reading so far: this byte carries active/in-progress follow-up-context flags rather than being generic scratch.  `AEE6..AEF6` is structurally a descriptor/profile record, but the per-byte field nouns are still open. `FD:ABA2`'s accumulators and token queues are real, but not yet frozen to final gameplay-facing names. `FD:AC6E` is clearly a queue-consumer / admission runner, but the owning subsystem noun still needs one more tightening pass.
; source: chrono_trigger_labels_pass75.md
L_7E_B1FC_ct_c1_followup_context_flags:
    ; TODO: reconstruct body / data for 7E:B1FC

; =============================================================================
; 7E:B1FD  top-status=strong  labels=1
; =============================================================================
; [strong] pass 74 :: ct_c1_pending_stat_delta_packet_target_slot
; qualifier: strong structural
; notes: Per-slot selector used by packet offset helpers like `E89F` and by `EBF8` queue writes. Seeded directly from the mapped lane in globals `98` and `99`.
; source: chrono_trigger_labels_pass74.md
L_7E_B1FD_ct_c1_pending_stat_delta_packet_target_slot:
    ; TODO: reconstruct body / data for 7E:B1FD

; =============================================================================
; 7E:B202  top-status=strong  labels=1
; =============================================================================
; [strong] pass 74 :: ct_c1_pending_stat_delta_packet_flag_byte
; qualifier: strong structural
; notes: Packet flag source mirrored into `B203` by `EBF8`. Bit `7` = signed-negate before queue write. Bit `6` = secondary-route packet path. Bit `5` = persistent / do-not-auto-clear channel behavior.
; source: chrono_trigger_labels_pass74.md
L_7E_B202_ct_c1_pending_stat_delta_packet_flag_byte:
    ; TODO: reconstruct body / data for 7E:B202

; =============================================================================
; 7E:B239  top-status=strong  labels=2
; =============================================================================
; [strong] pass 61 :: ct_current_c1_master_opcode_byte
; qualifier: strengthened
; notes: Previously carried as a late-pack subopcode byte. Pass 61 proves the stronger architectural read: it is the current opcode byte fed into the master C1 dispatcher. In the late-pack flow, it is the current pack-sourced global opcode byte.
; source: chrono_trigger_labels_pass61.md
L_7E_B239_ct_current_c1_master_opcode_byte:
    ; TODO: reconstruct body / data for 7E:B239

; [strong] pass 60 :: ct_current_late_selector_pack_subopcode
; qualifier: strong
; notes: Loaded from `CC:[B1D2 + 0]` immediately before the `B80D` dispatch. This is the current sub-op byte executed by the late selector-pack executor.
; source: chrono_trigger_labels_pass60.md
L_7E_B239_ct_current_late_selector_pack_subopcode:
    ; TODO: reconstruct body / data for 7E:B239

; =============================================================================
; 7E:B242  top-status=strong  labels=2
; =============================================================================
; [strong] pass 61 :: ct_tail_last_executed_global_opcode_bytes
; qualifier: strong
; notes: Directly proved by: `LDA B239` `STA B242,X` Holds the per-tail last executed global opcode byte. This corrects the older provisional “nonzero result mark” read.
; source: chrono_trigger_labels_pass61.md
L_7E_B242_ct_tail_last_executed_global_opcode_bytes:
    ; TODO: reconstruct body / data for 7E:B242
    ; known span hint: 7E:B242..7E:B249

; [provisional] pass 60 :: ct_tail_late_selector_nonzero_result_mark_bytes
; qualifier: provisional
; notes: Set to `FF` on the nonzero-`AF24` path inside `ct_execute_late_selector_pack_and_capture_tail_result`. Exact higher-level noun remains unresolved.
; source: chrono_trigger_labels_pass60.md
L_7E_B242_ct_tail_late_selector_nonzero_result_mark_bytes:
    ; TODO: reconstruct body / data for 7E:B242
    ; known span hint: 7E:B242..7E:B249

; =============================================================================
; 7E:B24A  top-status=strong  labels=2
; =============================================================================
; [strong] pass 61 :: ct_tail_last_opcode_result_status_bytes
; qualifier: strengthened
; notes: Pass 60 already proved these bytes capture `AF24` after execution. Pass 61 strengthens the surrounding controller context by pairing them directly with: `ct_tail_last_executed_global_opcode_bytes` `B263[x]` Best safe read now: per-tail last-op result/status bytes.
; source: chrono_trigger_labels_pass61.md
L_7E_B24A_ct_tail_last_opcode_result_status_bytes:
    ; TODO: reconstruct body / data for 7E:B24A
    ; known span hint: 7E:B24A..7E:B251

; [provisional] pass 60 :: ct_tail_late_selector_result_status_bytes
; qualifier: strengthened structural
; notes: `B24A[B252]` captures `AF24` after the current late-pack sub-op execution. The exact meaning of each result code is still open. Structural role as per-tail late-executor status capture is now strong.
; source: chrono_trigger_labels_pass60.md
L_7E_B24A_ct_tail_late_selector_result_status_bytes:
    ; TODO: reconstruct body / data for 7E:B24A
    ; known span hint: 7E:B24A..7E:B251

; =============================================================================
; 7E:B263  top-status=provisional  labels=2
; =============================================================================
; [provisional] pass 60 :: ct_tail_late_selector_has_following_segment_flags
; qualifier: provisional
; notes: Incremented when another FE-delimited segment is found and execution chains forward. Cleared when no following segment remains. Strongest safe reading so far: per-tail “has additional late-pack segment / chained segment present” flag or counter.
; source: chrono_trigger_labels_pass60.md
L_7E_B263_ct_tail_late_selector_has_following_segment_flags:
    ; TODO: reconstruct body / data for 7E:B263
    ; known span hint: 7E:B263..7E:B26A

; [unspecified] pass 61 :: ct_tail_has_additional_pack_segment_flags
; qualifier: strengthened
; notes: Still not fully finalized as a gameplay-facing noun. But pass 61 strengthens the structural role: controller-managed per-tail flag/counter for whether later FE-delimited work remains after the current executed segment.
; source: chrono_trigger_labels_pass61.md
L_7E_B263_ct_tail_has_additional_pack_segment_flags:
    ; TODO: reconstruct body / data for 7E:B263
    ; known span hint: 7E:B263..7E:B26A

; =============================================================================
; 7E:B2C0  top-status=strong  labels=1
; =============================================================================
; [strong] pass 74 :: ct_c1_alternate_continuation_pointer_armed_flag
; qualifier: strong structural
; notes: At `8CF9` entry, chooses the alternate continuation pointer in `B273` when nonzero. At `8CF9` tail, armed when the chosen `AECC` is in the nonhead range and `AE55.bit3` does not suppress continuation.  the exact human-facing meanings of transient packet workspace modes `2` and `3` are still open the exact consumer inside the fixed-`7F` follow-up tail is still not fully locked `AE55` is now materially tighter, but only bit `3` is safe to treat as pinned here
; source: chrono_trigger_labels_pass74.md
L_7E_B2C0_ct_c1_alternate_continuation_pointer_armed_flag:
    ; TODO: reconstruct body / data for 7E:B2C0

; =============================================================================
; 7E:B3E7  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_c1_service7_enabled_lane0_flag
; qualifier: strong
; source: chrono_trigger_labels_pass42.md
L_7E_B3E7_ct_c1_service7_enabled_lane0_flag:
    ; TODO: reconstruct body / data for 7E:B3E7

; =============================================================================
; 7E:B3E8  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_c1_service7_enabled_lane1_flag
; qualifier: strong
; source: chrono_trigger_labels_pass42.md
L_7E_B3E8_ct_c1_service7_enabled_lane1_flag:
    ; TODO: reconstruct body / data for 7E:B3E8

; =============================================================================
; 7E:B3E9  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_c1_service7_enabled_lane2_flag
; qualifier: strong
; notes: Final enabled-lane flags derived from the canonical trio’s lane-ID pairs
; source: chrono_trigger_labels_pass42.md
L_7E_B3E9_ct_c1_service7_enabled_lane2_flag:
    ; TODO: reconstruct body / data for 7E:B3E9

; =============================================================================
; 7E:B3EA  top-status=strong  labels=1
; =============================================================================
; [strong] pass 42 :: ct_fd_service7_lane_eligibility_hit
; qualifier: strong
; notes: Scratch result written by `FD:A8A5`. Nonzero means the currently tested lane family has a qualifying lane block.
; source: chrono_trigger_labels_pass42.md
L_7E_B3EA_ct_fd_service7_lane_eligibility_hit:
    ; TODO: reconstruct body / data for 7E:B3EA

; =============================================================================
; 7E:B400  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 91 :: ct_cd_contiguous_eight_strip_workspace_cleared_by_0239_before_c0_followup
; qualifier: provisional strengthened
; notes: Pass 91 proves `CD:0239..025D` clears this exact contiguous `0x0400`-byte span as eight exact `0x80`-byte strips. `D1:F331..F410` calls `CD:0235` immediately before `C0:0008`. Strongest safe reading: contiguous eight-strip workspace cleared just before the final C0 follow-up stage.  I have **not** frozen the final gameplay-facing noun of the broader pass-88/89 lane+raster workspace. I have **not** frozen the final gameplay-facing noun of the `C867..C9EC` template-record workspace. I have **not** frozen the exact role of `C7:0004`; pass 91 only freezes the exact packet builder / submitter behind `C0:0008`. I have **not** returned to the first exact clean-code external reader of `CE0F` yet.
; source: chrono_trigger_labels_pass91.md
L_7E_B400_ct_cd_contiguous_eight_strip_workspace_cleared_by_0239_before_c0_followup:
    ; TODO: reconstruct body / data for 7E:B400
    ; known span hint: 7E:B400..7E:B7FF

; =============================================================================
; 7E:BB06  top-status=caution  labels=1
; =============================================================================
; [caution] pass 81 :: / 7E:BB86.. / 7E:BC06.. and companions  ct_cd_auxiliary_token_80_parallel_bb_bc_builder_tables   [provisional strengthened]
; notes: Sub-op `0x10` seeds the `+1` high-byte members with `0xE0`. Sub-ops `0x00`, `0x0E`, and `0x13` all converge into the shared `2D53` tail that writes the wider family. Final noun still open, but these are clearly parallel structured tables, not scratch.  I have **not** frozen the final noun of the `E500/E850` strided families. I have **not** frozen the final noun of the `BB06/07`, `BB86/87`, and `BC06/07` tables. I have **not** decoded the exact downstream helpers at `D1:E899`, `D1:E8C1`, `D1:E91A`, and `D1:E984`. I have **not** tied the newly-decoded `0x80` sub-op state all the way into the final `4500 -> 5D00 -> A07B` emit noun.
; source: chrono_trigger_labels_pass81.md
L_7E_BB06_7E_BB86_7E_BC06_and_companions_ct_cd_auxiliary_token_80_parallel_bb_bc_builder_tables_:
    ; TODO: reconstruct body / data for 7E:BB06

; =============================================================================
; 7E:C030  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 90 :: ct_d1_local_quartet_table_family_upstream_of_cd0235_c00008
; qualifier: provisional strengthened
; notes: Pass 90 proves `D1:F83D..F8EA` clears and seeds exact quartets at `C030/C031`, `C090/C091`, `C0F0/C0F1`, and `C120/C121`, plus the exact tail bytes near `C0EB..C0EE` and `C14B..C14E`. `D1:F331..F410` calls this helper immediately before `CD:0235` and `C0:0008`. Strongest safe reading: local quartet-table family immediately upstream of the final follow-up tail.
; source: chrono_trigger_labels_pass90.md
L_7E_C030_ct_d1_local_quartet_table_family_upstream_of_cd0235_c00008:
    ; TODO: reconstruct body / data for 7E:C030
    ; known span hint: 7E:C030..7E:C14F

; =============================================================================
; 7E:C15D  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 89 :: ct_d1_primary_curve_written_lane_family_upstream_of_raster_target_workspace
; qualifier: provisional strengthened
; notes: Pass 89 proves `D1:EEC5..F107` writes four exact primary lanes rooted at `C15D / C15F / C161 / C163` over a `0x350` span. Those lanes sit immediately upstream of the pass-88 raster-target workspace and are part of the same local D1-side write pipeline. Final gameplay-facing noun still open.
; source: chrono_trigger_labels_pass89.md
L_7E_C15D_ct_d1_primary_curve_written_lane_family_upstream_of_raster_target_workspace:
    ; TODO: reconstruct body / data for 7E:C15D
    ; known span hint: 7E:C15D..7E:C4AB

; =============================================================================
; 7E:C161  top-status=strong  labels=1
; =============================================================================
; [strong] pass 88 :: ct_ce_d1_dual_bundle_eight_table_raster_target_workspace
; qualifier: stronger structural
; notes: Pass 87 proved the column-rasterizer writes into roots selected through `C161 / C163 / C4E1 / C4E3`. Pass 88 proves those roots belong to a larger structured workspace with exact mirror helpers spanning the full `C161..C7F3` neighborhood. Strongest safe reading: dual-bundle eight-table raster-target workspace with primary and shadow sides.
; source: chrono_trigger_labels_pass88.md
L_7E_C161_ct_ce_d1_dual_bundle_eight_table_raster_target_workspace:
    ; TODO: reconstruct body / data for 7E:C161
    ; known span hint: 7E:C161..7E:C7F3

; =============================================================================
; 7E:C867  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 91 :: ct_ce_nine_stride_2d_template_record_workspace_seeded_by_ee6e
; qualifier: provisional strengthened
; notes: Pass 91 proves `CE:EE6E..EF0D` copies exact `0x1E`-byte blocks into 9 exact destination records rooted at `C867 / C894 / C8C1 / C8EE / C91B / C948 / C975 / C9A2 / C9CF`. The roots are spaced by an exact stride of `0x2D` bytes. Strongest safe reading: nine-record template workspace seeded directly by the first exact CE follow-up stage.
; source: chrono_trigger_labels_pass91.md
L_7E_C867_ct_ce_nine_stride_2d_template_record_workspace_seeded_by_ee6e:
    ; TODO: reconstruct body / data for 7E:C867
    ; known span hint: 7E:C867..7E:C9EC

; =============================================================================
; 7E:CA17  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_pending_d0_tile_block_request_count_or_flag
; qualifier: strong structural
; notes: Incremented by the raw-data token path in `1654`. Cleared/consumed by the `06xx` auxiliary graphics-side follow-up. Strongest safe reading: pending auxiliary tile-block request count/flag.
; source: chrono_trigger_labels_pass80.md
L_7E_CA17_ct_cd_auxiliary_pending_d0_tile_block_request_count_or_flag:
    ; TODO: reconstruct body / data for 7E:CA17

; =============================================================================
; 7E:CA18  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_current_derived_d0_tile_block_source_ptr
; qualifier: strong structural
; notes: Written by the raw-data token path in `1654` after biasing the token with `CA3A`. Consumed by the `06xx` auxiliary graphics-side follow-up. Strongest safe reading: current derived `D0` tile-block source pointer.
; source: chrono_trigger_labels_pass80.md
L_7E_CA18_ct_cd_auxiliary_current_derived_d0_tile_block_source_ptr:
    ; TODO: reconstruct body / data for 7E:CA18
    ; known span hint: 7E:CA18..7E:CA19

; =============================================================================
; 7E:CA32  top-status=strong  labels=2
; =============================================================================
; [strong] pass 79 :: ct_cd_two_auxiliary_descriptor_runtime_slot_structs_2x16
; qualifier: strong structural
; notes: `0D33` clears this range in 16-byte slot steps. `15D5` seeds each active slot from a descriptor pointer looked up in `D1:646C`. `1609` ticks these slots, decrements their countdowns, and interprets stream tokens through `1654`. Strongest safe reading: two active runtime slot structs for the optional auxiliary descriptor stage.
; source: chrono_trigger_labels_pass79.md
L_7E_CA32_ct_cd_two_auxiliary_descriptor_runtime_slot_structs_2x16:
    ; TODO: reconstruct body / data for 7E:CA32
    ; known span hint: 7E:CA32..7E:CA4F

; [provisional] pass 78 :: ct_cd_auxiliary_fragment_work_tables_primary_secondary_tertiary
; qualifier: provisional strengthened
; notes: Cleared by `CD:0D33` before descriptor expansion. Populated indirectly from the `CA93` descriptor list via `15D5`. Final gameplay-facing noun still needs one more pass, but these are now clearly the core auxiliary-stage work tables.
; source: chrono_trigger_labels_pass78.md
L_7E_CA32_ct_cd_auxiliary_fragment_work_tables_primary_secondary_tertiary:
    ; TODO: reconstruct body / data for 7E:CA32
    ; known span hint: 7E:CA32..7E:CA8F

; =============================================================================
; 7E:CA3A  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 80 :: ct_cd_auxiliary_runtime_slot_stream_bias_or_iteration_bytes_2x16
; qualifier: provisional strengthened
; notes: `1654` adds `CA3A,X` to raw data-token values before deriving the `D0`-side source pointer. Token `0x86` increments `CA3A,X` per loop iteration and clears it on termination. Strongest safe reading: slot-local stream bias / iteration side-effect bytes.
; source: chrono_trigger_labels_pass80.md
L_7E_CA3A_ct_cd_auxiliary_runtime_slot_stream_bias_or_iteration_bytes_2x16:
    ; TODO: reconstruct body / data for 7E:CA3A
    ; known span hint: 7E:CA3A..7E:CA49

; =============================================================================
; 7E:CA52  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 79 :: ct_cd_secondary_and_tertiary_auxiliary_descriptor_work_families
; qualifier: provisional strengthened
; notes: Cleared alongside the active runtime slot family in `0D33`. Exact field meanings still need another pass, but these are parallel work families for the same optional auxiliary stage.
; source: chrono_trigger_labels_pass79.md
L_7E_CA52_ct_cd_secondary_and_tertiary_auxiliary_descriptor_work_families:
    ; TODO: reconstruct body / data for 7E:CA52
    ; known span hint: 7E:CA52..7E:CA8F

; =============================================================================
; 7E:CA5A  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 90 :: ct_d1_primary_curve_center_offset_seed_words_paired_with_ca5e_ca60
; qualifier: provisional strengthened
; notes: Pass 90 proves `D1:F47C..F4BF` writes exact negated 16-bit seed words into `CA5A,X` and `CA5C,X`. Pass 89 already proved `D1:EEC5..F107` builds the local center words from `CA5A + CA5E` and `CA5C + CA60`. Strongest safe reading: center-offset seed words paired with the already-frozen `CA5E / CA60` accumulator fields.
; source: chrono_trigger_labels_pass90.md
L_7E_CA5A_ct_d1_primary_curve_center_offset_seed_words_paired_with_ca5e_ca60:
    ; TODO: reconstruct body / data for 7E:CA5A
    ; known span hint: 7E:CA5A..7E:CA5D

; =============================================================================
; 7E:CA5E  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_runtime_slot_paired_16bit_accumulator_fields
; qualifier: strong structural
; notes: Token `0x82` applies eight exact paired add/subtract variants over `CA5E,X` and `CA60,X`. That proves these are real 16-bit accumulator-like fields, not generic scratch. Final gameplay-facing noun still needs another pass.
; source: chrono_trigger_labels_pass80.md
L_7E_CA5E_ct_cd_auxiliary_runtime_slot_paired_16bit_accumulator_fields:
    ; TODO: reconstruct body / data for 7E:CA5E
    ; known span hint: 7E:CA5E..7E:CA71

; =============================================================================
; 7E:CA72  top-status=strong  labels=1
; =============================================================================
; [strong] pass 80 :: ct_cd_auxiliary_runtime_slot_repeat_resume_ptr_and_repeat_count_fields
; qualifier: strong structural
; notes: Tokens `0x83..0x86` prove the role of these fields. `CA72,X` = loop resume pointer. `CA74,X` = repeat countdown.
; source: chrono_trigger_labels_pass80.md
L_7E_CA72_ct_cd_auxiliary_runtime_slot_repeat_resume_ptr_and_repeat_count_fields:
    ; TODO: reconstruct body / data for 7E:CA72
    ; known span hint: 7E:CA72..7E:CA85

; =============================================================================
; 7E:CA93  top-status=strong  labels=2
; =============================================================================
; [strong] pass 79 :: ct_cd_auxiliary_descriptor_id_list_first_two_seed_runtime_slots
; qualifier: strong correction
; notes: `0D33` only consumes the first two live ids here because the runtime expansion loop advances `X` by `0x10` and stops at `0x20`. So the first two live entries seed the two active runtime slots in `CA32..CA4F`.
; source: chrono_trigger_labels_pass79.md
L_7E_CA93_ct_cd_auxiliary_descriptor_id_list_first_two_seed_runtime_slots:
    ; TODO: reconstruct body / data for 7E:CA93
    ; known span hint: 7E:CA93..7E:CA9F

; [provisional] pass 78 :: ct_cd_auxiliary_fragment_descriptor_list
; qualifier: provisional strengthened
; notes: Walked by `CD:0D33` until `FF`. Each live byte triggers a `15D5` descriptor-expansion pass into the `CA32/52/72` work families.  I have **not** fully decoded the four transform/materialization modes under `CD:13E6`. I have **not** frozen the final gameplay-facing noun of the `CA32/52/72` auxiliary work families. I have **not** fully frozen the downstream noun of the `4500.. -> 5D00..` output family. The strongest proof on `C3:0557` is family role, WRAM-port output, and returned output size — not a full codec taxonomy.
; source: chrono_trigger_labels_pass78.md
L_7E_CA93_ct_cd_auxiliary_fragment_descriptor_list:
    ; TODO: reconstruct body / data for 7E:CA93
    ; known span hint: 7E:CA93..7E:CA9F

; =============================================================================
; 7E:CAEA  top-status=strong  labels=2
; =============================================================================
; [strong] pass 86 :: ct_cd_d1_indexed_snapshot_records_of_current_three_pair_point_bundle
; qualifier: strong structural
; notes: Auxiliary token `0xE3` and D1 helper `F5CD..F5F2` both snapshot the current `5DA0..5DA5` bundle into one indexed record rooted here. Exact interleaved write pattern remains `CAEA/CAEC/CAEE/CAF0/CAF2/CAF4`. Strongest safe reading: indexed snapshot record family for the current three-pair point bundle.
; source: chrono_trigger_labels_pass86.md
L_7E_CAEA_ct_cd_d1_indexed_snapshot_records_of_current_three_pair_point_bundle:
    ; TODO: reconstruct body / data for 7E:CAEA
    ; known span hint: 7E:CAEA..7E:CAF5

; [strong] pass 85 :: ct_cd_auxiliary_indexed_sixbyte_snapshot_records_from_5da0_vector
; qualifier: strong structural
; notes: Auxiliary token `0xE3` copies the current `5DA0..5DA5` six-byte live vector into one indexed destination record rooted here. Exact write pattern is interleaved: `CAEA/CAEC/CAEE/CAF0/CAF2/CAF4`. Strongest safe reading: indexed destination record family for six-byte snapshots of the current `5DA0` live vector.
; source: chrono_trigger_labels_pass85.md
L_7E_CAEA_ct_cd_auxiliary_indexed_sixbyte_snapshot_records_from_5da0_vector:
    ; TODO: reconstruct body / data for 7E:CAEA
    ; known span hint: 7E:CAEA..7E:CAF5

; =============================================================================
; 7E:CC64  top-status=strong  labels=1
; =============================================================================
; [strong] pass 87 :: ct_cd_d1_column_raster_target_selector_byte
; qualifier: stronger structural
; notes: `D1:F9AF` stores `X` here before dispatch. `CD:38B6..38E3` masks `CC64.bit0`, combines it with `7C.bit0`, and uses the result to choose one of the four WRAM-port base addresses in `CD:38AA..38B1`. Strongest safe reading: local target-strip selector byte for the column-raster family.
; source: chrono_trigger_labels_pass87.md
L_7E_CC64_ct_cd_d1_column_raster_target_selector_byte:
    ; TODO: reconstruct body / data for 7E:CC64

; =============================================================================
; 7E:CCEA  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 79 :: ct_cd_optional_auxiliary_descriptor_stage_progress_byte
; qualifier: provisional strengthened
; notes: `1609` only services runtime slots while this byte is zero. Incremented when the local two-slot service pass reaches its completion condition. Strongest safe reading: stage-level progression/completion byte for the optional auxiliary descriptor stage.  I have **not** fully frozen the artist-facing noun of the `D0` source entries. I have **not** fully frozen the final gameplay/object noun of the downstream `4500.. -> 5D00..` emit family. I have **not** decoded the entire `16B5..` token-handler table end-to-end. I have **not** fully frozen the exact field meanings of the `CA52 / CA72` parallel work families.
; source: chrono_trigger_labels_pass79.md
L_7E_CCEA_ct_cd_optional_auxiliary_descriptor_stage_progress_byte:
    ; TODO: reconstruct body / data for 7E:CCEA

; =============================================================================
; 7E:CD04  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 81 :: ct_cd_auxiliary_token_80_parallel_table_builder_countdown_or_variation_byte
; qualifier: provisional strengthened
; notes: Cleared/updated by sub-op `0x00` before entering the shared `2D53` builder tail.
; source: chrono_trigger_labels_pass81.md
L_7E_CD04_ct_cd_auxiliary_token_80_parallel_table_builder_countdown_or_variation_byte:
    ; TODO: reconstruct body / data for 7E:CD04

; =============================================================================
; 7E:CD0D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 87 :: ct_d1_four_row_column_point_pair_work_bundle_for_column_rasterizer
; qualifier: strong structural
; notes: `EC28` builds four point pairs here and immediately calls `F9AF`. `F9AF` loads exactly these eight bytes into direct-page work slots `12..19`, sorts them by the second byte, and rasterizes them. Strongest safe reading: four `(row,column)` point-pair work bundle for the D1 column rasterizer.
; source: chrono_trigger_labels_pass87.md
L_7E_CD0D_ct_d1_four_row_column_point_pair_work_bundle_for_column_rasterizer:
    ; TODO: reconstruct body / data for 7E:CD0D
    ; known span hint: 7E:CD0D..7E:CD1B

; =============================================================================
; 7E:CD23  top-status=strong  labels=1
; =============================================================================
; [strong] pass 85 :: ct_cd_auxiliary_5da0_snapshot_stage_count_byte
; qualifier: stronger structural
; notes: Incremented by auxiliary token `0xE4` after mirroring the current `5DA0` byte into `CD25`. Strongest safe reading: local count/state byte for the `E4` snapshot-stage helper family.
; source: chrono_trigger_labels_pass85.md
L_7E_CD23_ct_cd_auxiliary_5da0_snapshot_stage_count_byte:
    ; TODO: reconstruct body / data for 7E:CD23

; =============================================================================
; 7E:CD24  top-status=strong  labels=1
; =============================================================================
; [strong] pass 85 :: ct_cd_auxiliary_immediate_stage_selector_byte
; qualifier: stronger structural
; notes: Written directly by auxiliary token `0xE4` from the following stream byte. Strongest safe reading: local immediate selector/control byte for the same snapshot-stage helper family.
; source: chrono_trigger_labels_pass85.md
L_7E_CD24_ct_cd_auxiliary_immediate_stage_selector_byte:
    ; TODO: reconstruct body / data for 7E:CD24

; =============================================================================
; 7E:CD25  top-status=strong  labels=1
; =============================================================================
; [strong] pass 85 :: ct_cd_auxiliary_snapshot_of_current_5da0_index_byte
; qualifier: stronger structural
; notes: Written by auxiliary token `0xE4` from the current live byte at `5DA0`. Strongest safe reading: mirrored current-index byte for the same local stage family.
; source: chrono_trigger_labels_pass85.md
L_7E_CD25_ct_cd_auxiliary_snapshot_of_current_5da0_index_byte:
    ; TODO: reconstruct body / data for 7E:CD25

; =============================================================================
; 7E:CD2D  top-status=strong  labels=1
; =============================================================================
; [strong] pass 85 :: ct_cd_auxiliary_immediate_control_byte_e1
; qualifier: stronger structural
; notes: Written directly by auxiliary token `0xE1` from the stream. Final higher-level noun remains open.
; source: chrono_trigger_labels_pass85.md
L_7E_CD2D_ct_cd_auxiliary_immediate_control_byte_e1:
    ; TODO: reconstruct body / data for 7E:CD2D

; =============================================================================
; 7E:CD2E  top-status=strong  labels=1
; =============================================================================
; [strong] pass 85 :: ct_cd_auxiliary_immediate_control_byte_e2
; qualifier: stronger structural
; notes: Written directly by auxiliary token `0xE2` from the stream. Final higher-level noun remains open.
; source: chrono_trigger_labels_pass85.md
L_7E_CD2E_ct_cd_auxiliary_immediate_control_byte_e2:
    ; TODO: reconstruct body / data for 7E:CD2E

; =============================================================================
; 7E:CD2F  top-status=strong  labels=2
; =============================================================================
; [strong] pass 83 :: ct_palette_effect_descriptor_header_shadow_bytes_8slots
; qualifier: strong correction
; notes: Exact shadow array for the first byte of all 8 `0520 + n*0C` descriptor slots. Written by `D1:F411`, restored by `D1:F457`. Pass 82's narrower `CD2F..CD34` interpretation is now tightened into this larger 8-byte mirror.
; source: chrono_trigger_labels_pass83.md
L_7E_CD2F_ct_palette_effect_descriptor_header_shadow_bytes_8slots:
    ; TODO: reconstruct body / data for 7E:CD2F
    ; known span hint: 7E:CD2F..7E:CD36

; [provisional] pass 82 :: ct_d1_palette_band_control_triplet_a_seeded_by_e91a
; qualifier: provisional strengthened
; notes: Seeded to `0x30` by `D1:E91A`. Exact final noun remains open.
; source: chrono_trigger_labels_pass82.md
L_7E_CD2F_ct_d1_palette_band_control_triplet_a_seeded_by_e91a:
    ; TODO: reconstruct body / data for 7E:CD2F
    ; known span hint: 7E:CD2F..7E:CD31

; =============================================================================
; 7E:CD32  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 82 :: ct_d1_palette_band_control_triplet_b_seeded_by_e984_or_cleared_by_e91a
; qualifier: provisional strengthened
; notes: Cleared by `D1:E91A`. Seeded to `0x30` by `D1:E984`. Strongest safe reading: paired control/state triplet for the same subcluster.
; source: chrono_trigger_labels_pass82.md
L_7E_CD32_ct_d1_palette_band_control_triplet_b_seeded_by_e984_or_cleared_by_e91a:
    ; TODO: reconstruct body / data for 7E:CD32
    ; known span hint: 7E:CD32..7E:CD34

; =============================================================================
; 7E:CD35  top-status=strong  labels=1
; =============================================================================
; [strong] pass 83 :: ct_palette_effect_descriptor_header_shadow_tail_slots_6_7
; qualifier: strong addition
; notes: Tail two bytes of the new 8-slot shadow array. Correspond to descriptor headers at `0568` and `0574`.
; source: chrono_trigger_labels_pass83.md
L_7E_CD35_ct_palette_effect_descriptor_header_shadow_tail_slots_6_7:
    ; TODO: reconstruct body / data for 7E:CD35
    ; known span hint: 7E:CD35..7E:CD36

; =============================================================================
; 7E:CD3A  top-status=strong  labels=2
; =============================================================================
; [strong] pass 89 :: ct_d1_primary_lane_growth_byte_for_lower_edge_and_ramp_seed_paths
; qualifier: stronger support
; notes: Used by `D1:EDCD..EE2F` for the lower-edge byte stamp path. Used again by `D1:EEA6..EEC4` and `D1:EEC5..F107` to control ramp/profile generation. Strongest safe reading: local growth byte for the primary lower-edge/ramp side.
; source: chrono_trigger_labels_pass89.md
L_7E_CD3A_ct_d1_primary_lane_growth_byte_for_lower_edge_and_ramp_seed_paths:
    ; TODO: reconstruct body / data for 7E:CD3A

; [provisional] pass 81 :: ct_cd_auxiliary_token_80_constant_seed_word_0060
; qualifier: provisional strengthened
; notes: Set to `0x0060` by sub-op `0x14`.
; source: chrono_trigger_labels_pass81.md
L_7E_CD3A_ct_cd_auxiliary_token_80_constant_seed_word_0060:
    ; TODO: reconstruct body / data for 7E:CD3A

; =============================================================================
; 7E:CD3B  top-status=strong  labels=1
; =============================================================================
; [strong] pass 89 :: ct_d1_companion_lane_growth_byte_for_clamped_span_fill_path
; qualifier: stronger support
; notes: Used by `D1:EE33..EE95` to build the clamped companion span. Incremented locally until it reaches `0x09`. Strongest safe reading: local growth byte for the companion span-fill side.  I have **not** frozen the final gameplay-facing noun of the raster-target workspace. I have **not** frozen the exact higher-level caller contract connecting the new primary-lane writer to its final presentation/effect name. I have **not** frozen the first exact external reader of `CE0F` in clean code territory. I have **not** promoted the lone mapped `LDA $CE0F` opcode-pattern hit because it still sits in dense bank-CD script/data territory.
; source: chrono_trigger_labels_pass89.md
L_7E_CD3B_ct_d1_companion_lane_growth_byte_for_clamped_span_fill_path:
    ; TODO: reconstruct body / data for 7E:CD3B

; =============================================================================
; 7E:CD44  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 80 :: ct_cd_auxiliary_token_f2_rewind_latch_count
; qualifier: provisional strengthened
; notes: Incremented by token `0xF3`. Consumed and cleared by token `0xF2` after conditional rewind.
; source: chrono_trigger_labels_pass80.md
L_7E_CD44_ct_cd_auxiliary_token_f2_rewind_latch_count:
    ; TODO: reconstruct body / data for 7E:CD44

; =============================================================================
; 7E:CD45  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 80 :: ct_cd_auxiliary_token_f3_rewind_immediate_staging_byte
; qualifier: provisional strengthened
; notes: Written by token `0xF3`. Structural sibling state for the `0xF2` conditional rewind family.
; source: chrono_trigger_labels_pass80.md
L_7E_CD45_ct_cd_auxiliary_token_f3_rewind_immediate_staging_byte:
    ; TODO: reconstruct body / data for 7E:CD45

; =============================================================================
; 7E:CD46  top-status=provisional  labels=2
; =============================================================================
; [provisional] pass 90 :: ct_cd_auxiliary_token_f5_immediate_or_2a21_seeded_pipeline_byte
; qualifier: provisional strengthened
; notes: Earlier passes proved token `0xF5` writes this byte directly. Pass 90 adds an exact non-token seed path: `D1:F331..F410` writes `00` or `FD` here from `2A21.bit0`. Final gameplay-facing noun still open.  I have **not** frozen the final gameplay-facing noun of the `C030..C14F` quartet family. I have **not** frozen the final gameplay-facing noun of the broader pass-88/89 lane+raster workspace. I have **not** frozen the exact final roles of `CE:EE6E`, `CD:0235`, or `C0:0008`. I have **not** frozen the first exact clean-code external reader of `CE0F`.
; source: chrono_trigger_labels_pass90.md
L_7E_CD46_ct_cd_auxiliary_token_f5_immediate_or_2a21_seeded_pipeline_byte:
    ; TODO: reconstruct body / data for 7E:CD46

; [provisional] pass 80 :: ct_cd_auxiliary_token_f5_immediate_staging_byte
; qualifier: provisional strengthened
; notes: Directly written by token `0xF5`. Final gameplay-facing noun still open.
; source: chrono_trigger_labels_pass80.md
L_7E_CD46_ct_cd_auxiliary_token_f5_immediate_staging_byte:
    ; TODO: reconstruct body / data for 7E:CD46

; =============================================================================
; 7E:CD47  top-status=strong  labels=1
; =============================================================================
; [strong] pass 86 :: ct_d1_cdc8_conditioned_0x80byte_work_strip
; qualifier: strong structural
; notes: `CE:E18E..E1A4` clears this exact `0x80`-byte range only when `CDC8 != 0`. Final higher-level noun remains open, but the clear footprint is exact.
; source: chrono_trigger_labels_pass86.md
L_7E_CD47_ct_d1_cdc8_conditioned_0x80byte_work_strip:
    ; TODO: reconstruct body / data for 7E:CD47
    ; known span hint: 7E:CD47..7E:CDC6

; =============================================================================
; 7E:CDC8  top-status=strong  labels=3
; =============================================================================
; [strong] pass 86 :: ct_d1_seed_side_nonzero_gate_for_cdc8_conditioned_work_strip_clear
; qualifier: stronger structural
; notes: `D1:E984` increments it during the seed/snapshot half. `D1:E97D` clears it during the promote/restore half. `CE:E18E..E1A4` is the first exact external reader: nonzero gates clearing of `CD47..CDC6`; zero skips the clear entirely. Strongest safe reading: seed-side nonzero gate byte for at least one D1-adjacent work-strip clear path.
; source: chrono_trigger_labels_pass86.md
L_7E_CDC8_ct_d1_seed_side_nonzero_gate_for_cdc8_conditioned_work_strip_clear:
    ; TODO: reconstruct body / data for 7E:CDC8

; [alias] pass 86 :: ct_d1_palette_seed_vs_promote_phase_byte
; qualifier: alias / caution retained
; notes: Pass 84 already justified this local noun from `E984 <-> E91A`. Pass 86 does **not** invalidate that reading; it adds exact external clear-gate behavior. Keep both readings in play until a wider cluster noun is frozen.  I have **not** frozen the final gameplay-facing noun of the `5DA0..5DA5` bundle. I have **not** proven whether the three pairs are literal vertices, corners, or another nearby geometric/effect record. I have **not** frozen the first exact external reader of `CE0F`. I have **not** promoted `CD23 / CD24 / CD25` beyond their pass-85 local staging noun, because the remaining valid mapped hits are still not clean enough.
; source: chrono_trigger_labels_pass86.md
L_7E_CDC8_ct_d1_palette_seed_vs_promote_phase_byte:
    ; TODO: reconstruct body / data for 7E:CDC8

; [provisional] pass 82 :: ct_d1_palette_band_seed_snapshot_latch
; qualifier: provisional strengthened
; notes: Incremented by `D1:E984`. Cleared by `D1:E91A`. Strongest safe reading: latch/flag tied to the seed-vs-promote half-cycle.
; source: chrono_trigger_labels_pass82.md
L_7E_CDC8_ct_d1_palette_band_seed_snapshot_latch:
    ; TODO: reconstruct body / data for 7E:CDC8

; =============================================================================
; 7E:CE0E  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 80 :: ct_cd_auxiliary_token_f7_immediate_staging_byte
; qualifier: provisional strengthened
; notes: Directly written by token `0xF7`. Final gameplay-facing noun still open.
; source: chrono_trigger_labels_pass80.md
L_7E_CE0E_ct_cd_auxiliary_token_f7_immediate_staging_byte:
    ; TODO: reconstruct body / data for 7E:CE0E

; =============================================================================
; 7E:CE0F  top-status=strong  labels=2
; =============================================================================
; [strong] pass 84 :: ct_d1_palette_seed_side_arm_or_epoch_byte
; qualifier: stronger support
; notes: `D1:E987` increments it during the seed/snapshot half. `D1:F26E` clears it in the D1 reset subsection. No exact reader is frozen yet. Strongest safe reading: seed-side arm/epoch byte in the same D1 control cluster.
; source: chrono_trigger_labels_pass84.md
L_7E_CE0F_ct_d1_palette_seed_side_arm_or_epoch_byte:
    ; TODO: reconstruct body / data for 7E:CE0F

; [provisional] pass 82 :: ct_d1_palette_band_seed_count_or_arm_latch
; qualifier: provisional strengthened
; notes: Incremented by `D1:E984`. No matching clear is yet proven in this pass. Final noun remains open.
; source: chrono_trigger_labels_pass82.md
L_7E_CE0F_ct_d1_palette_band_seed_count_or_arm_latch:
    ; TODO: reconstruct body / data for 7E:CE0F

; =============================================================================
; 7E:CE10  top-status=strong  labels=1
; =============================================================================
; [strong] pass 81 :: ct_cd_auxiliary_token_f6_rewind_gate_latch
; qualifier: stronger support
; notes: Pass 80 already proved that token `0xF6` consumes and clears this latch. Pass 81 adds the clean setter path: token `0x80:19` increments it directly. Strongest safe reading: rewind gate/latch, not generic scratch.
; source: chrono_trigger_labels_pass81.md
L_7E_CE10_ct_cd_auxiliary_token_f6_rewind_gate_latch:
    ; TODO: reconstruct body / data for 7E:CE10

; =============================================================================
; 7E:CE12  top-status=strong  labels=2
; =============================================================================
; [strong] pass 84 :: ct_d1_palette_suspend_restore_gate_latch_or_pending_count
; qualifier: stronger local reset support
; notes: Pass 83 already proved the local one-shot gate behavior at `D1:F431 / F457`. Pass 84 adds explicit reset proof: `D1:F277` clears it in the D1 reset subsection. Strongest safe reading remains: local suspend/restore gate latch with wider pending-count caution still allowed outside the local pair.  I have **not** proven that nonzero `CFFF` values carry distinct live meanings beyond the local zero/nonzero branch. I have **not** frozen the final gameplay-facing noun of the `2040/20A0/2120/21A0/2240/22A0/2320/23A0` palette-band families. I have **not** frozen the exact external reader(s) of `CDC8` or `CE0F`. I have **not** yet explained why the suspend path clears positive `0x1x` descriptor headers while sparing the signed `0x8x` family.
; source: chrono_trigger_labels_pass84.md
L_7E_CE12_ct_d1_palette_suspend_restore_gate_latch_or_pending_count:
    ; TODO: reconstruct body / data for 7E:CE12

; [strong] pass 83 :: ct_d1_palette_band_promote_snapshot_pending_counter
; qualifier: stronger local gate support
; notes: Earlier passes already proved that `E91A` and `E984` increment `CE12`. Pass 83 proves local one-shot gate behavior in `D1:F431 / D1:F457`: nonzero blocks re-arm, zero blocks restore, and restore clears it. Strongest safe reading: locally gate-like latch behavior inside this D1 consumer pair, even if the wider cluster noun still wants caution.  I have **not** frozen the final gameplay-facing noun of `CFFF`. I have **not** frozen the exact higher-level role of `A101`, `2A21.bit1`, or the `0575.bit6` toggle in `D1:E70A`. I have **not** claimed that `CE12` is globally nothing but a latch; the local gate behavior is exact, but the wider cluster may still be richer. I have **not** yet tied this whole D1 control cluster all the way to the final battle/UI presentation noun.
; source: chrono_trigger_labels_pass83.md
L_7E_CE12_ct_d1_palette_band_promote_snapshot_pending_counter:
    ; TODO: reconstruct body / data for 7E:CE12

; =============================================================================
; 7E:CFFF  top-status=strong  labels=2
; =============================================================================
; [strong] pass 84 :: ct_d1_palette_descriptor_suspend_restore_mode_byte
; qualifier: strong structural
; notes: Local D1 consumer at `D1:F426` tests only zero vs nonzero. `00` selects the restore path at `D1:F457`. Any nonzero value selects the suspend path at `D1:F431`. Written directly by auxiliary token `0xE6` at `CD:18C2`. Also forced to `1` or `0` by primary-slot helpers at `C1:58DB` and `C1:58E4`. Cleared by the D1 reset subsection at `D1:F295`. Strongest safe reading: externally writable zero/nonzero mode byte for the D1 descriptor-header suspend/restore gate.
; source: chrono_trigger_labels_pass84.md
L_7E_CFFF_ct_d1_palette_descriptor_suspend_restore_mode_byte:
    ; TODO: reconstruct body / data for 7E:CFFF

; [provisional] pass 83 :: ct_d1_palette_descriptor_suspend_restore_selector
; qualifier: provisional strengthened
; notes: `CFFF != 0` selects the shadow-and-suspend path at `D1:F431`. `CFFF == 0` selects the restore path at `D1:F457`. Mapped-ROM proof for nonzero writers is still incomplete, so the final gameplay-facing noun remains open.
; source: chrono_trigger_labels_pass83.md
L_7E_CFFF_ct_d1_palette_descriptor_suspend_restore_selector:
    ; TODO: reconstruct body / data for 7E:CFFF

; =============================================================================
; 7E:E500  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 81 :: (strided pair family)  ct_cd_auxiliary_token_80_strided_e500_e502_pair_table_family   [provisional strengthened]
; notes: Sub-op `0x15` clears `E500/E502` in 4-byte steps. Sub-op `0x16` subtracts `0x0010` from active `E500` entries where companion `E850` markers are live. Strongest safe reading: linked strided pair-table family with an activity/marker companion table.
; source: chrono_trigger_labels_pass81.md
L_7E_E500_strided_pair_family_ct_cd_auxiliary_token_80_strided_e500_e502_pair_table_family_provi:
    ; TODO: reconstruct body / data for 7E:E500
    ; known span hint: 7E:E500..7E:EB9F

; =============================================================================
; 7E:E850  top-status=unspecified  labels=1
; =============================================================================
; [unspecified] pass 81 :: (strided marker family)  ct_cd_auxiliary_token_80_strided_e850_activity_marker_family   [provisional strengthened]
; notes: Read by sub-op `0x16` as the gate for whether the matching `E500` entry is decremented. Final noun still open.
; source: chrono_trigger_labels_pass81.md
L_7E_E850_strided_marker_family_ct_cd_auxiliary_token_80_strided_e850_activity_marker_family_pro:
    ; TODO: reconstruct body / data for 7E:E850
    ; known span hint: 7E:E850..7E:EEEF

