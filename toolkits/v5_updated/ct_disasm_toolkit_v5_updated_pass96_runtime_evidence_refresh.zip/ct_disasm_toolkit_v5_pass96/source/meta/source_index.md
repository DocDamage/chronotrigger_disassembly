# Source State Index

Generated from the persistent label DB.

## 00
- File: `source/banks/bank_00.asm`
- Address groups: **3**
- Rows: **4**

## 7E
- File: `source/banks/wram_7E.asm`
- Address groups: **144**
- Rows: **226**

## 7F
- File: `source/banks/wram_7F.asm`
- Address groups: **1**
- Rows: **1**

## C0
- File: `source/banks/bank_C0.asm`
- Address groups: **7**
- Rows: **7**

## C1
- File: `source/banks/bank_C1.asm`
- Address groups: **195**
- Rows: **215**

## C2
- File: `source/banks/bank_C2.asm`
- Address groups: **10**
- Rows: **10**

## C3
- File: `source/banks/bank_C3.asm`
- Address groups: **2**
- Rows: **2**

## C7
- File: `source/banks/bank_C7.asm`
- Address groups: **19**
- Rows: **20**

## CC
- File: `source/banks/bank_CC.asm`
- Address groups: **10**
- Rows: **13**

## CD
- File: `source/banks/bank_CD.asm`
- Address groups: **70**
- Rows: **72**

## CE
- File: `source/banks/bank_CE.asm`
- Address groups: **3**
- Rows: **3**

## CF
- File: `source/banks/bank_CF.asm`
- Address groups: **1**
- Rows: **1**

## D0
- File: `source/banks/bank_D0.asm`
- Address groups: **1**
- Rows: **1**

## D1
- File: `source/banks/bank_D1.asm`
- Address groups: **34**
- Rows: **43**

## FD
- File: `source/banks/bank_FD.asm`
- Address groups: **18**
- Rows: **21**

