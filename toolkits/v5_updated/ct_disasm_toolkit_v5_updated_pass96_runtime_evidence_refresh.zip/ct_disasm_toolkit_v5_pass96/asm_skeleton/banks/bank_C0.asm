; Chrono Trigger bank C0 skeleton
; Generated from current evidence. This is not a complete reassemblable bank yet.

.bank $C0

; C0:0008..C0:000A [strong] pass 91
ct_c0_branch_long_to_1bab_conditional_c70004_packet_submitter_veneer:
    ; TODO: lift real code/data for C0:0008..C0:000A
    ; Exact body: `BRL $1BA0`. Lands at exact target `C0:1BAB`. Strongest safe reading: veneer for the conditional packet-submit helper behind the

; C0:000B..C0:000D [strong] pass 92
ct_c0_branch_long_to_1be6_gated_multi_packet_c70004_submitter_veneer:
    ; TODO: lift real code/data for C0:000B..C0:000D
    ; Exact body: `BRL $1BD8`. Lands at exact target `C0:1BE6`. Strongest safe reading: veneer for the sibling gated multi-packet submit helper in

; C0:1BAB..C0:1BE5 [strong] pass 91
ct_c0_submit_one_of_two_c70004_command_packets_by_2a1f_bit6:
    ; TODO: lift real code/data for C0:1BAB..C0:1BE5
    ; Saves `B` and `D`, sets `D = 0x0100`, and sets `DB = 0x00`. Reads `7E:2A1F` and branches on exact mask `0x40`. If `2A1F.bit6 == 0`: writes `

; C0:1BE6..C0:1CFB [strong] pass 92
ct_c0_submit_gated_multi_packet_c70004_sequence_by_7f01ec_and_2a1f_bits:
    ; TODO: lift real code/data for C0:1BE6..C0:1CFB
    ; Saves `B` and `D`, sets `D = 0x0100`, and sets `DB = 0x00`. Reads exact byte `7F:01EC` and only treats exact value `1` specially. The altern

; C0:A270..C0:A335 [provisional] pass 48
ct_c0_parallel_source_plane_consumer_band:
    ; TODO: lift real code/data for C0:A270..C0:A335
    ; Not promoted to a final high-level subsystem name. But this band now has stronger proven structure: reads `7F:0C00/X`, `7F:0C80/X`, `7F:0E00

; C0:A2B0..A335 [unspecified] pass 47
consumer_path____________________________________________unlabeled_as_final_routine_:
    ; TODO: lift real code/data for C0:A2B0..A335
    ; Pass 47 found direct `0E00/0E80` read-side proof there. Exact routine entry and full higher-level purpose are still open. The consumer relat

; C0:FD00..C0:FDFF [strong] pass 79
ct_c0_bit_reverse_lookup_256:
    ; TODO: lift real code/data for C0:FD00..C0:FDFF
    ; Exact 256-byte bit-reversal table. Example mappings: `01->80`, `02->40`, `03->C0`. Used directly by the `1445` horizontal-flip tile path.

