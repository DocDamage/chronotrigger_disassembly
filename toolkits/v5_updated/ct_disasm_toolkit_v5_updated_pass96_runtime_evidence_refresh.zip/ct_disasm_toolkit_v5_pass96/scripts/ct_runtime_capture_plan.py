#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser(description='Generate a runtime capture plan from the profile manifest.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--profiles-json', default='targets/runtime_capture_profiles.json')
    ap.add_argument('--state-json', default='state/current_state.json')
    ap.add_argument('--output-md', default='reports/runtime/runtime_capture_plan.md')
    ap.add_argument('--output-json', default='reports/runtime/runtime_capture_plan.json')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    profiles = json.loads((root / args.profiles_json).read_text(encoding='utf-8'))
    state = {}
    state_path = root / args.state_json
    if state_path.exists():
        state = json.loads(state_path.read_text(encoding='utf-8'))
    payload = {
        'latest_pass': state.get('latest_pass'),
        'current_live_seam': state.get('current_live_seam', ''),
        'profiles': profiles,
    }
    out_json = root / args.output_json
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(payload, indent=2), encoding='utf-8')

    lines = ['# Runtime Capture Plan', '']
    if state:
        lines += [f'- Latest pass: **{state.get("latest_pass", "?")}**', f'- Live seam: **{state.get("current_live_seam", "")}**', '']
    lines += [
        'Use this when static naming stalls or when you want hard proof for WRAM ownership, APU traffic, or selector-state transitions.',
        '',
        '## Capture order',
        '1. Start with the active C7 low-bank sound/APU seam while it is fresh.',
        '2. Then capture WRAM validation around `CFFF`, `CDC8`, and `CE0F`.',
        '3. Import traces into `traces/imported/` and rerun `python3 scripts/ct_resume_workspace.py --workdir .`.',
        ''
    ]
    for profile in profiles:
        lines += [f"## {profile['name']}", profile['description'], '', '### CPU break / trace points']
        for item in profile.get('cpu_targets', []):
            lines.append(f'- `{item}`')
        lines += ['', '### WRAM / low-bank watches']
        for item in profile.get('wram_targets', []):
            lines.append(f'- `{item}`')
        if profile.get('apu_targets'):
            lines += ['', '### APU / hardware ports']
            for item in profile.get('apu_targets', []):
                lines.append(f'- `{item}`')
        lines += ['', '### Questions this capture should answer']
        for item in profile.get('questions', []):
            lines.append(f'- {item}')
        lines += ['', '### Suggested output file']
        lines.append(f"- `traces/imported/{profile['suggested_file']}`")
        lines.append('')
    out_md = root / args.output_md
    out_md.parent.mkdir(parents=True, exist_ok=True)
    out_md.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(out_md)
    print(out_json)


if __name__ == '__main__':
    main()
