#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path


def latest_rows(con: sqlite3.Connection, label_text: str | None, address_text: str | None, limit: int):
    con.row_factory = sqlite3.Row
    clauses, params = [], []
    if label_text:
        clauses.append('lower(label) LIKE ?')
        params.append(f'%{label_text.lower()}%')
    if address_text:
        norm = address_text.replace(':', '').upper()
        clauses.append("replace(address_range, ':', '') LIKE ?")
        params.append(f'%{norm}%')
    where = (' WHERE ' + ' AND '.join(clauses)) if clauses else ''
    query = f'''
    SELECT pass_num, address_range, label, status_bucket, notes, source_file
    FROM labels
    {where}
    ORDER BY pass_num DESC, address_start ASC
    LIMIT ?
    '''
    params.append(limit)
    return [dict(r) for r in con.execute(query, params)]


def main() -> None:
    ap = argparse.ArgumentParser(description='Inspect a dispatcher family by label text or address.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--xref-json', default='data/ct_hot_xref_cache.json')
    ap.add_argument('--label')
    ap.add_argument('--address')
    ap.add_argument('--limit', type=int, default=12)
    args = ap.parse_args()
    if not args.label and not args.address:
        raise SystemExit('Provide --label or --address')
    root = Path(args.root).resolve()
    con = sqlite3.connect(root / args.db)
    rows = latest_rows(con, args.label, args.address, args.limit)
    con.close()
    xref_payload = json.loads((root / args.xref_json).read_text(encoding='utf-8')) if (root / args.xref_json).exists() else {'targets': {}}
    targets = xref_payload.get('targets', {})
    for r in rows:
        print(f"{r['pass_num']} | {r['address_range']} | {r['status_bucket']} | {r['label']}")
        target = targets.get(r['address_range'])
        if target:
            print(f"  xref calls={len(target.get('calls', []))} word_refs={len(target.get('word_refs', []))}")
            for hit in target.get('calls', [])[:8]:
                print(f"    call {hit.get('at_snes')} {hit.get('op')} {hit.get('kind')}")
        if r.get('notes'):
            print(f"  notes: {r['notes']}")
        print(f"  source: {r['source_file']}")
        print()


if __name__ == '__main__':
    main()
