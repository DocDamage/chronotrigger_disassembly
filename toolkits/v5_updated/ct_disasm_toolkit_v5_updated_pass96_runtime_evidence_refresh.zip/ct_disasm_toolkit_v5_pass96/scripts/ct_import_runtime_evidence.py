#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import re
import sqlite3
from collections import Counter, defaultdict
from pathlib import Path

ADDR_RE = re.compile(r'(?<![0-9A-F])(?:([0-9A-F]{2}):([0-9A-F]{4})|(7E):([0-9A-F]{4})|0x([0-9A-F]{6})|(214[0-3]))(?![0-9A-F])', re.I)
COUNT_RE = re.compile(r'\bcount\s*[=:]\s*(\d+)\b', re.I)
FRAME_RE = re.compile(r'\bframe\s*[:=]?\s*(\d+)\b', re.I)
CPU_HINT = re.compile(r'\b(exec|execute|jsr|jmp|jsl|call|pc=|break(?:point)?|rtl|rts)\b', re.I)
WRITE_HINT = re.compile(r'\b(write|store|sta|stz|->|<=|:=)\b', re.I)
READ_HINT = re.compile(r'\b(read|load|lda|ldx|ldy|<-|=>)\b', re.I)
WATCH_HINT = re.compile(r'\bwatch\b', re.I)
APU_HINT = re.compile(r'\b(?:apu|spc|sound)\b|\b214[0-3]\b', re.I)

SCHEMA = """
DROP TABLE IF EXISTS runtime_evidence;
CREATE TABLE runtime_evidence (
  id INTEGER PRIMARY KEY,
  source_file TEXT NOT NULL,
  source_kind TEXT NOT NULL,
  address TEXT NOT NULL,
  domain TEXT NOT NULL,
  event_type TEXT NOT NULL,
  count INTEGER NOT NULL,
  value_text TEXT,
  frame_hint TEXT,
  notes TEXT
);
CREATE INDEX IF NOT EXISTS idx_runtime_addr ON runtime_evidence(address);
CREATE INDEX IF NOT EXISTS idx_runtime_domain ON runtime_evidence(domain);
CREATE INDEX IF NOT EXISTS idx_runtime_event ON runtime_evidence(event_type);
"""


def norm_addr(text: str) -> str | None:
    if text is None:
        return None
    m = ADDR_RE.search(str(text).upper())
    if not m:
        return None
    if m.group(1):
        return f"{m.group(1).upper()}:{m.group(2).upper()}"
    if m.group(3):
        return f"7E:{m.group(4).upper()}"
    raw = (m.group(5) or '').upper()
    if raw:
        return f"{raw[:2]}:{raw[2:]}"
    io = (m.group(6) or '').upper()
    if io:
        return f"00:{io}"
    return None


def detect_domain(addr: str, line: str = '') -> str:
    if addr.startswith('00:214') or APU_HINT.search(line):
        return 'apu'
    if addr.startswith('7E:'):
        return 'wram'
    if addr.startswith('00:1E') or addr.startswith('00:1F'):
        return 'wram_lowbank'
    return 'cpu'


def classify_event(line: str, addr: str) -> str:
    upper = line.upper()
    if 'BREAK' in upper:
        return 'break'
    if WATCH_HINT.search(line):
        if WRITE_HINT.search(line):
            return 'watch_write'
        if READ_HINT.search(line):
            return 'watch_read'
        return 'watch_hit'
    if addr.startswith('00:214') or APU_HINT.search(line):
        if WRITE_HINT.search(line):
            return 'apu_write'
        if READ_HINT.search(line):
            return 'apu_read'
        return 'apu_mention'
    if CPU_HINT.search(line):
        return 'execute'
    if WRITE_HINT.search(line):
        return 'write'
    if READ_HINT.search(line):
        return 'read'
    return 'mention'


def parse_value_text(text: str) -> str:
    for pat in [r'=\s*([0-9A-F]{1,8})\b', r'->\s*([0-9A-F]{1,8})\b', r'<-\s*([0-9A-F]{1,8})\b', r'value\s*[=:]\s*([^,|;]+)']:
        m = re.search(pat, text, re.I)
        if m:
            return m.group(1).strip()
    return ''


def parse_count(text: str) -> int:
    if text is None:
        return 1
    s = str(text).strip()
    if not s:
        return 1
    if s.isdigit():
        return int(s)
    m = COUNT_RE.search(s)
    return int(m.group(1)) if m else 1


def parse_frame_hint(text: str) -> str:
    m = FRAME_RE.search(text or '')
    return m.group(1) if m else ''


def aggregate_rows(raw_rows):
    counts = Counter()
    notes = defaultdict(list)
    for addr, domain, event, count, value_text, frame_hint, note in raw_rows:
        key = (addr, domain, event, value_text, frame_hint)
        counts[key] += count
        if note and len(notes[key]) < 3:
            notes[key].append(note)
    out = []
    for (addr, domain, event, value_text, frame_hint), count in sorted(counts.items()):
        out.append((addr, domain, event, count, value_text, frame_hint, ' | '.join(notes[(addr, domain, event, value_text, frame_hint)])))
    return out


def parse_text(path: Path):
    raw_rows = []
    for line in path.read_text(encoding='utf-8', errors='ignore').splitlines():
        addr = norm_addr(line)
        if not addr:
            continue
        domain = detect_domain(addr, line)
        event = classify_event(line, addr)
        count = parse_count(line)
        value_text = parse_value_text(line)
        frame_hint = parse_frame_hint(line)
        raw_rows.append((addr, domain, event, count, value_text, frame_hint, line.strip()))
    return aggregate_rows(raw_rows)


def row_get(row: dict, *names: str) -> str:
    lower = {str(k).strip().lower(): v for k, v in row.items()}
    for name in names:
        if name.lower() in lower and lower[name.lower()] not in (None, ''):
            return str(lower[name.lower()])
    return ''


def parse_csv(path: Path):
    raw_rows = []
    with path.open(encoding='utf-8', newline='') as f:
        for row in csv.DictReader(f):
            addr = norm_addr(row_get(row, 'address', 'pc', 'cpu_address', 'wram_address', 'apu_address'))
            if not addr:
                continue
            lineish = ' '.join(str(v) for v in row.values() if v not in (None, ''))
            domain = (row_get(row, 'domain', 'source_type') or detect_domain(addr, lineish)).strip().lower() or detect_domain(addr, lineish)
            event = (row_get(row, 'event_type', 'event', 'type', 'access') or classify_event(lineish, addr)).strip().lower() or 'mention'
            count = parse_count(row_get(row, 'count', 'hits', 'samples'))
            value_text = row_get(row, 'value', 'value_text', 'data', 'observed_value') or parse_value_text(lineish)
            frame_hint = row_get(row, 'frame', 'frame_hint', 'tick') or parse_frame_hint(lineish)
            notes = row_get(row, 'notes', 'comment', 'context', 'details')
            raw_rows.append((addr, domain, event, count, value_text, frame_hint, notes.strip() or lineish.strip()))
    return aggregate_rows(raw_rows)


def parse_json(path: Path):
    data = json.loads(path.read_text(encoding='utf-8'))
    items = data if isinstance(data, list) else data.get('events', [])
    raw_rows = []
    for item in items:
        lineish = json.dumps(item, ensure_ascii=False)
        addr = norm_addr(str(item.get('address', '') or item.get('pc', '') or item.get('cpu_address', '') or item.get('wram_address', '')))
        if not addr:
            continue
        domain = str(item.get('domain') or item.get('source_type') or detect_domain(addr, lineish)).strip().lower()
        event = str(item.get('event_type') or item.get('event') or item.get('type') or classify_event(lineish, addr)).strip().lower()
        count = parse_count(str(item.get('count', item.get('hits', 1))))
        value_text = str(item.get('value_text', item.get('value', item.get('observed_value', '')))).strip() or parse_value_text(lineish)
        frame_hint = str(item.get('frame_hint', item.get('frame', ''))).strip() or parse_frame_hint(lineish)
        notes = str(item.get('notes', item.get('context', ''))).strip()
        raw_rows.append((addr, domain, event, count, value_text, frame_hint, notes or lineish))
    return aggregate_rows(raw_rows)


def ingest_file(path: Path):
    suffix = path.suffix.lower()
    if suffix == '.csv':
        return 'csv', parse_csv(path)
    if suffix == '.json':
        return 'json', parse_json(path)
    return 'text', parse_text(path)


def iter_trace_files(trace_dir: Path):
    for path in sorted(trace_dir.rglob('*')):
        if not path.is_file():
            continue
        if path.name.startswith('.'):
            continue
        if path.name.lower() == 'readme.md':
            continue
        yield path


def main() -> None:
    ap = argparse.ArgumentParser(description='Import bsnes/debugger/runtime evidence into the workspace DB and summary files.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--trace-dir', default='traces/imported')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--summary-json', default='reports/runtime/runtime_evidence_summary.json')
    ap.add_argument('--summary-md', default='reports/runtime/runtime_evidence_summary.md')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    trace_dir = root / args.trace_dir
    db_path = root / args.db
    trace_dir.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(db_path)
    cur = con.cursor()
    cur.executescript(SCHEMA)
    total_rows = 0
    total_observations = 0
    files_seen = []
    per_addr = Counter()
    per_event = Counter()
    per_domain = Counter()
    for path in iter_trace_files(trace_dir):
        kind, rows = ingest_file(path)
        rel_name = str(path.relative_to(trace_dir))
        files_seen.append(rel_name)
        for addr, domain, event, count, value_text, frame_hint, notes in rows:
            cur.execute('INSERT INTO runtime_evidence(source_file, source_kind, address, domain, event_type, count, value_text, frame_hint, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                        (rel_name, kind, addr, domain, event, count, value_text, frame_hint, notes))
            total_rows += 1
            total_observations += count
            per_addr[addr] += count
            per_event[event] += count
            per_domain[domain] += count
    con.commit(); con.close()
    summary = {
        'trace_files': sorted(set(files_seen)),
        'import_rows': total_rows,
        'observation_weight_total': total_observations,
        'top_addresses': per_addr.most_common(25),
        'event_type_totals': dict(per_event),
        'domain_totals': dict(per_domain),
    }
    sj = root / args.summary_json
    sj.parent.mkdir(parents=True, exist_ok=True)
    sj.write_text(json.dumps(summary, indent=2), encoding='utf-8')
    lines = [
        '# Runtime Evidence Summary', '',
        f'- Trace files imported: **{len(summary["trace_files"])}**',
        f'- Import rows: **{total_rows}**',
        f'- Weighted observations: **{total_observations}**', '',
        '## Domain totals'
    ]
    if per_domain:
        for k, v in sorted(per_domain.items()):
            lines.append(f'- {k}: **{v}**')
    else:
        lines.append('- none yet')
    lines += ['', '## Event totals']
    if per_event:
        for k, v in sorted(per_event.items()):
            lines.append(f'- {k}: **{v}**')
    else:
        lines.append('- none yet')
    lines += ['', '## Top addresses']
    if per_addr:
        for addr, cnt in per_addr.most_common(25):
            lines.append(f'- `{addr}` -> **{cnt}**')
    else:
        lines.append('- no runtime evidence imported yet')
    lines += ['', '## Imported files']
    if summary['trace_files']:
        for name in summary['trace_files']:
            lines.append(f'- `{name}`')
    else:
        lines.append('- none')
    sm = root / args.summary_md
    sm.parent.mkdir(parents=True, exist_ok=True)
    sm.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(sj)
    print(sm)

if __name__ == '__main__':
    main()
