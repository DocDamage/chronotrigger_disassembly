#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import sqlite3
from collections import Counter
from pathlib import Path


def addr_to_int(text: str) -> int | None:
    text = str(text).strip().replace('0x', '').replace(':', '')
    try:
        return int(text, 16)
    except ValueError:
        return None


def main() -> None:
    ap = argparse.ArgumentParser(description='Validate imported runtime evidence against the label DB.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--output-md', default='reports/ct_runtime_validation.md')
    ap.add_argument('--output-json', default='reports/runtime/runtime_validation.json')
    ap.add_argument('--output-csv', default='reports/runtime/runtime_validation.csv')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    db = sqlite3.connect(root / args.db)
    db.row_factory = sqlite3.Row
    labels = [dict(r) for r in db.execute('SELECT address_start, address_end, label, status_bucket, pass_num FROM labels WHERE address_start IS NOT NULL ORDER BY address_start')]
    try:
        runtime_rows = [dict(r) for r in db.execute('SELECT source_file, source_kind, address, domain, event_type, count, value_text, frame_hint, notes FROM runtime_evidence ORDER BY count DESC, address')]
    except sqlite3.OperationalError:
        runtime_rows = []
    result_rows = []
    matched = 0
    unmatched = 0
    matched_weight = 0
    unmatched_weight = 0
    per_domain = Counter()
    per_event = Counter()
    matched_labels = Counter()
    unmatched_addresses = Counter()
    for rr in runtime_rows:
        addr_i = addr_to_int(rr['address'])
        matches = []
        if addr_i is not None:
            for lab in labels:
                start = lab['address_start']
                end = lab['address_end'] if lab['address_end'] is not None else start
                if start <= addr_i <= end:
                    matches.append(lab)
        row = {
            'address': rr['address'], 'domain': rr.get('domain', ''), 'event_type': rr['event_type'], 'count': rr['count'],
            'value_text': rr.get('value_text', ''), 'frame_hint': rr.get('frame_hint', ''),
            'source_file': rr['source_file'], 'notes': rr['notes'],
        }
        per_domain[row['domain']] += rr['count']
        per_event[row['event_type']] += rr['count']
        if matches:
            matched += 1
            matched_weight += rr['count']
            top = sorted(matches, key=lambda x: (x['status_bucket'] == 'strong', x['pass_num'], x['address_end'] is not None), reverse=True)[0]
            row.update({'status': 'matched', 'top_label': top['label'], 'top_bucket': top['status_bucket']})
            matched_labels[top['label']] += rr['count']
        else:
            unmatched += 1
            unmatched_weight += rr['count']
            row.update({'status': 'unmatched', 'top_label': '', 'top_bucket': ''})
            unmatched_addresses[rr['address']] += rr['count']
        result_rows.append(row)
    out_json = root / args.output_json
    out_json.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        'runtime_rows': len(runtime_rows),
        'weighted_observations': matched_weight + unmatched_weight,
        'matched_rows': matched,
        'unmatched_rows': unmatched,
        'matched_weight': matched_weight,
        'unmatched_weight': unmatched_weight,
        'domain_totals': dict(per_domain),
        'event_totals': dict(per_event),
        'top_unmatched_addresses': unmatched_addresses.most_common(25),
        'top_matched_labels': matched_labels.most_common(25),
        'rows': result_rows[:500],
    }
    out_json.write_text(json.dumps(payload, indent=2), encoding='utf-8')
    out_csv = root / args.output_csv
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    with out_csv.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['address', 'domain', 'event_type', 'count', 'status', 'top_label', 'top_bucket', 'value_text', 'frame_hint', 'source_file', 'notes'])
        w.writeheader()
        w.writerows(result_rows)
    lines = ['# Runtime Validation Report', '']
    if not runtime_rows:
        lines += ['No runtime evidence rows are currently imported.', '', 'Import traces first, then rerun this validator.', '', 'Recommended first captures:', '- `reports/runtime/runtime_capture_plan.md`', '- `notes/runtime_evidence_workflow.md`']
    else:
        total_weight = matched_weight + unmatched_weight
        match_pct = (matched_weight / total_weight * 100.0) if total_weight else 0.0
        lines += [
            f'- Runtime rows checked: **{len(runtime_rows)}**',
            f'- Weighted observations: **{total_weight}**',
            f'- Matched rows: **{matched}**',
            f'- Unmatched rows: **{unmatched}**',
            f'- Weighted matched observations: **{matched_weight}**',
            f'- Weighted unmatched observations: **{unmatched_weight}**',
            f'- Weighted match rate: **{match_pct:.1f}%**',
            '', '## Domain totals'
        ]
        for dom, cnt in sorted(per_domain.items()):
            lines.append(f'- {dom}: **{cnt}**')
        lines += ['', '## Event totals']
        for evt, cnt in sorted(per_event.items()):
            lines.append(f'- {evt}: **{cnt}**')
        lines += ['', '## Top unmatched runtime addresses']
        if unmatched_addresses:
            for addr, cnt in unmatched_addresses.most_common(25):
                lines.append(f'- `{addr}` count={cnt}')
        else:
            lines.append('- none')
        lines += ['', '## Top matched labels by evidence weight']
        if matched_labels:
            for label, cnt in matched_labels.most_common(25):
                lines.append(f'- `{label}` count={cnt}')
        else:
            lines.append('- none')
    out_md = root / args.output_md
    out_md.parent.mkdir(parents=True, exist_ok=True)
    out_md.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    db.close()
    print(out_md)
    print(out_json)
    print(out_csv)


if __name__ == '__main__':
    main()
