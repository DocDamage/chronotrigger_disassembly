#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sqlite3
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser(description='Generate a focused summary of the current sound/APU packet-side labels.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--output-md', default='reports/ct_apu_packet_summary.md')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    con = sqlite3.connect(root / args.db)
    con.row_factory = sqlite3.Row
    query = '''
    SELECT pass_num, address_range, label, status_bucket, notes
    FROM labels
    WHERE (
      lower(label) LIKE '%apu%' OR lower(label) LIKE '%sound%' OR lower(label) LIKE '%packet%' OR
      lower(label) LIKE '%staged_command%' OR lower(label) LIKE '%special_path%' OR lower(label) LIKE '%low_bank%'
    )
      AND (address_range LIKE '00:%' OR address_range LIKE 'C7:%' OR address_range LIKE 'C2:%')
    ORDER BY pass_num DESC, address_start ASC
    '''
    rows = [dict(r) for r in con.execute(query)]
    con.close()
    latest = {}
    for r in rows:
        key = (r['address_range'], r['label'])
        if key not in latest:
            latest[key] = r
    rows = sorted(latest.values(), key=lambda r: (r['pass_num'], r['address_range']), reverse=True)
    lines = [
        '# Sound / APU Packet Summary', '',
        '- This report is the current noun map for the low-bank packet workspace and the C7-side sound/APU command flow.',
        '- It is meant to keep the pass-94/95 C7 work from dissolving back into vague “packet” language.',
        ''
    ]
    for r in rows[:80]:
        lines.append(f"- `{r['address_range']}` pass {r['pass_num']} [{r['status_bucket']}] :: **{r['label']}**")
        if r.get('notes'):
            lines.append(f"  - {r['notes']}")
    out = root / args.output_md
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(out)


if __name__ == '__main__':
    main()
