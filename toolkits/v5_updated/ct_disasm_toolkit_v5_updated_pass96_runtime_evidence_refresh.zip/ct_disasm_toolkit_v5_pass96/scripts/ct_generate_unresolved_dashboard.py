#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import sqlite3
from collections import defaultdict
from pathlib import Path

PASS_RE = re.compile(r'Latest completed pass:\s*\*\*(\d+)\*\*', re.IGNORECASE)
SEAM_RE = re.compile(r'## Best next seam\s*(.*?)(?:\n## |\Z)', re.IGNORECASE | re.DOTALL)


def read_next_session(root: Path) -> tuple[int | None, str]:
    note = root / 'notes' / 'next_session_start_here.md'
    if not note.exists():
        return None, ''
    text = note.read_text(encoding='utf-8')
    pass_match = PASS_RE.search(text)
    seam_match = SEAM_RE.search(text)
    seam = ''
    if seam_match:
        seam = ' '.join(line.strip('- ').strip() for line in seam_match.group(1).strip().splitlines() if line.strip())
        seam = seam.replace('**', '').replace('`', '')
    return (int(pass_match.group(1)) if pass_match else None), seam


def main() -> None:
    ap = argparse.ArgumentParser(description='Generate the V5 unresolved-work dashboard.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--output-md', default='reports/ct_unresolved_dashboard.md')
    ap.add_argument('--output-json', default='reports/ct_unresolved_dashboard.json')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    con = sqlite3.connect(root / args.db)
    con.row_factory = sqlite3.Row
    rows = [dict(r) for r in con.execute('SELECT pass_num, address_range, address_start, label, status_bucket, notes, source_file FROM labels WHERE address_start IS NOT NULL ORDER BY pass_num DESC, address_start')]
    latest_pass_db = con.execute('SELECT MAX(pass_num) FROM labels').fetchone()[0] or 0
    con.close()
    latest = {}
    for r in rows:
        key = (r['address_range'], r['label'])
        if key not in latest:
            latest[key] = r
    live = [r for r in latest.values() if r['status_bucket'] != 'strong']
    live.sort(key=lambda r: (r['pass_num'], r['address_start']), reverse=True)
    by_bank = defaultdict(list)
    for r in live:
        by_bank[f'{(r['address_start'] >> 16) & 0xFF:02X}'].append(r)
    state_path = root / 'state' / 'current_state.json'
    state = json.loads(state_path.read_text(encoding='utf-8')) if state_path.exists() else {}
    note_pass, seam_from_note = read_next_session(root)
    latest_pass = max(latest_pass_db, int(state.get('latest_pass', 0) or 0), note_pass or 0)
    payload = {
        'current_live_seam': seam_from_note or state.get('current_live_seam', ''),
        'latest_pass': latest_pass,
        'unresolved_rows': len(live),
        'banks': {bank: len(items) for bank, items in sorted(by_bank.items())},
        'top_rows': live[:100],
    }
    out_json = root / args.output_json
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(payload, indent=2), encoding='utf-8')
    lines = ['# Unresolved Work Dashboard', '']
    if payload['current_live_seam']:
        lines.append(f'- Current live seam: **{payload["current_live_seam"]}**')
    lines.append(f'- Latest pass: **{payload["latest_pass"]}**')
    lines.append(f'- Current non-strong rows in the latest-known label state: **{len(live)}**')
    lines += ['', '## Bank pressure']
    for bank, count in sorted(payload['banks'].items()):
        lines.append(f'- {bank}: **{count}** unresolved/provisional rows')
    lines += ['', '## Top unresolved entries']
    for r in live[:60]:
        lines.append(f'- `{r["address_range"]}` [{r["status_bucket"]}] pass {r["pass_num"]} :: {r["label"]}')
        if r['notes']:
            lines.append(f'  - {r["notes"]}')
        lines.append(f'  - source: `{r["source_file"]}`')
    (root / args.output_md).write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(root / args.output_md)
    print(out_json)


if __name__ == '__main__':
    main()
