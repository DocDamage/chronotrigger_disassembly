#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import sqlite3
from pathlib import Path

TOTAL_BANKS_WITH_WRAM = 66  # 64 HiROM banks + WRAM 7E/7F


def read_csv_rows(path: Path):
    if not path.exists():
        return []
    with path.open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def pct(n, d):
    return 0.0 if d == 0 else round((n / d) * 100.0, 1)


def load_json(path: Path, default):
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding='utf-8'))


def clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


def main() -> None:
    ap = argparse.ArgumentParser(description='Build an evidence-weighted completion score for the current disassembly state.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--output-json', default='reports/completion/ct_completion_score.json')
    ap.add_argument('--output-md', default='reports/ct_completion_score.md')
    args = ap.parse_args()
    root = Path(args.root).resolve()

    con = sqlite3.connect(root / args.db)
    cur = con.cursor()
    total_labels = cur.execute('SELECT COUNT(*) FROM labels').fetchone()[0]
    strong = cur.execute("SELECT COUNT(*) FROM labels WHERE status_bucket='strong'").fetchone()[0]
    provisional = cur.execute("SELECT COUNT(*) FROM labels WHERE status_bucket='provisional'").fetchone()[0]
    latest_pass = cur.execute('SELECT MAX(pass_num) FROM labels').fetchone()[0] or 0
    con.close()

    master = read_csv_rows(root / 'data' / 'ct_c1_master_opcode_coverage_full.csv')
    selector = read_csv_rows(root / 'data' / 'ct_c1_selector_control_coverage_full.csv')
    service7 = read_csv_rows(root / 'data' / 'ct_service7_wrapper_coverage_full.csv')
    observed_master = sum(1 for r in master if (r.get('status') or '').lower() not in {'', 'unknown'})
    observed_selector = sum(1 for r in selector if (r.get('status') or '').lower() not in {'', 'unknown'})
    observed_service7 = sum(1 for r in service7 if (r.get('status') or '').lower() not in {'', 'unknown'})

    label_score = min(100.0, round(((strong + provisional * 0.4) / max(total_labels, 1)) * 100.0, 1))
    opcode_score = round((pct(observed_master, len(master)) * 0.55) + (pct(observed_selector, len(selector)) * 0.25) + (pct(observed_service7, len(service7)) * 0.20), 1)

    source_manifest = load_json(root / 'source' / 'meta' / 'source_manifest.json', {'banks': {}, 'total_rows': 0})
    rom_coverage = load_json(root / 'reports' / 'ct_rom_coverage.json', {'banks': []})
    freeze_summary = load_json(root / 'reports' / 'completion' / 'ct_completion_score.json', {})
    # freeze summary above is the old score if present; for freeze ratio we use source-state report inputs instead
    range_freeze = load_json(root / 'state' / 'range_freeze.json', {'entries': []})
    rebuild_diff = load_json(root / 'reports' / 'ct_rebuild_diff_report.json', {})
    runtime_validation = load_json(root / 'reports' / 'runtime' / 'runtime_validation.json', {'runtime_rows': 0, 'matched_rows': 0})

    represented_banks = len(source_manifest.get('banks', {}))
    represented_bank_pct = pct(represented_banks, TOTAL_BANKS_WITH_WRAM)
    frozen_entries = range_freeze.get('entries', [])
    frozen_ratio = pct(len(frozen_entries), max(total_labels, 1))

    # Bank separation should move when more banks/ranges are actually represented, but it should stay conservative.
    bank_sep_score = round(clamp(represented_bank_pct * 0.65 + frozen_ratio * 0.35), 1)

    rebuild_mode = (rebuild_diff.get('mode') or '').lower()
    if rebuild_mode == 'match':
        rebuild_mode_score = 100.0
    elif rebuild_mode == 'diff':
        rebuild_mode_score = 55.0
    elif rebuild_mode == 'scaffold':
        rebuild_mode_score = 15.0
    else:
        rebuild_mode_score = 5.0

    runtime_rows = int(runtime_validation.get('runtime_rows', 0) or 0)
    matched_rows = int(runtime_validation.get('matched_rows', 0) or 0)
    runtime_score = 0.0 if runtime_rows <= 0 else pct(matched_rows, runtime_rows)

    # Rebuild readiness stays materially behind semantic coverage until there is a real assembler-integrated loop.
    rebuild_score = round(clamp(represented_bank_pct * 0.35 + frozen_ratio * 0.35 + rebuild_mode_score * 0.20 + runtime_score * 0.10), 1)

    overall = round(label_score * 0.30 + opcode_score * 0.35 + bank_sep_score * 0.20 + rebuild_score * 0.15, 1)
    snapshot = {
        'latest_pass': latest_pass,
        'label_semantics_score': label_score,
        'opcode_coverage_score': opcode_score,
        'bank_separation_score': bank_sep_score,
        'rebuild_readiness_score': rebuild_score,
        'overall_completion_percent': overall,
        'master_opcode_covered': observed_master,
        'master_opcode_total': len(master),
        'selector_covered': observed_selector,
        'selector_total': len(selector),
        'service7_covered': observed_service7,
        'service7_total': len(service7),
        'represented_bank_count': represented_banks,
        'represented_bank_target': TOTAL_BANKS_WITH_WRAM,
        'represented_bank_percent': represented_bank_pct,
        'frozen_range_count': len(frozen_entries),
        'frozen_range_percent_of_labels': frozen_ratio,
        'runtime_rows': runtime_rows,
        'runtime_matched_rows': matched_rows,
        'rebuild_mode': rebuild_mode or 'unknown',
    }
    oj = root / args.output_json
    oj.parent.mkdir(parents=True, exist_ok=True)
    oj.write_text(json.dumps(snapshot, indent=2), encoding='utf-8')

    lines = [
        '# Completion Score', '',
        f"- Latest pass: **{latest_pass}**",
        f"- Overall completion estimate: **~{overall}%**",
        '', '## Weighted components',
        f"- Label semantics: **{label_score}%**",
        f"- Opcode coverage: **{opcode_score}%**",
        f"- Bank separation: **{bank_sep_score}%**",
        f"- Rebuild readiness: **{rebuild_score}%**",
        '', '## Coverage counts',
        f"- Master C1 opcodes: **{observed_master}/{len(master)}**",
        f"- Selector-control bytes: **{observed_selector}/{len(selector)}**",
        f"- Service-7 wrappers: **{observed_service7}/{len(service7)}**",
        f"- Banks represented in generated source: **{represented_banks}/{TOTAL_BANKS_WITH_WRAM}**",
        f"- Frozen/stable ranges: **{len(frozen_entries)}** ({frozen_ratio} % of label rows)",
        f"- Runtime validation rows: **{matched_rows}/{runtime_rows}**",
        f"- Rebuild mode: **{rebuild_mode or 'unknown'}**",
        '', '## Interpretation',
        '- This is an evidence-weighted estimate, not a fake “almost done” claim.',
        '- Semantic coverage can advance faster than the rebuildable-source layer; the score now reflects that instead of hard-coding those layers flat.',
        '- The expensive endgame is still broad bank separation, decompressor work, and byte-accurate assembler validation.',
        ''
    ]
    om = root / args.output_md
    om.write_text('\n'.join(lines), encoding='utf-8')
    print(oj)
    print(om)


if __name__ == '__main__':
    main()
