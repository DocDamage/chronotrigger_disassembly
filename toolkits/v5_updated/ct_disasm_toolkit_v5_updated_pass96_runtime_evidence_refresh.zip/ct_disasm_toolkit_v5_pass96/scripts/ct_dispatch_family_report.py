#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path

KEYWORDS = ('dispatch', 'dispatcher', 'opcode', 'packet', 'veneer', 'handler', 'stream', 'special_path')


def main() -> None:
    ap = argparse.ArgumentParser(description='Generate a quick dispatcher-family report from the latest labels and xref cache.')
    ap.add_argument('--root', default='.')
    ap.add_argument('--db', default='data/ct_label_db.sqlite')
    ap.add_argument('--xref-json', default='data/ct_hot_xref_cache.json')
    ap.add_argument('--output-md', default='reports/ct_dispatch_family_report.md')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    con = sqlite3.connect(root / args.db)
    con.row_factory = sqlite3.Row
    query = '''
    SELECT pass_num, address_range, label, status_bucket, notes
    FROM labels
    WHERE (
      lower(label) LIKE '%dispatch%' OR lower(label) LIKE '%dispatcher%' OR lower(label) LIKE '%opcode%' OR
      lower(label) LIKE '%packet%' OR lower(label) LIKE '%veneer%' OR lower(label) LIKE '%handler%' OR
      lower(label) LIKE '%stream%' OR lower(label) LIKE '%special_path%'
    )
    ORDER BY pass_num DESC, address_start ASC
    '''
    rows = [dict(r) for r in con.execute(query)]
    con.close()
    latest = {}
    for r in rows:
        key = (r['address_range'], r['label'])
        if key not in latest:
            latest[key] = r
    rows = sorted(latest.values(), key=lambda r: (r['pass_num'], r['address_range']), reverse=True)
    xref_payload = json.loads((root / args.xref_json).read_text(encoding='utf-8')) if (root / args.xref_json).exists() else {'targets': {}}
    targets = xref_payload.get('targets', {})

    lines = [
        '# Dispatcher / Family Report', '',
        '- This report is the fast lane for veneers, packet families, and opcode dispatchers.',
        '- It combines the newest label nouns with hot xref-cache call counts where exact single-address targets already exist.',
        ''
    ]
    for r in rows[:80]:
        target = targets.get(r['address_range'], {})
        call_count = len(target.get('calls', []))
        word_ref_count = len(target.get('word_refs', []))
        lines.append(f"- `{r['address_range']}` pass {r['pass_num']} [{r['status_bucket']}] :: **{r['label']}**")
        lines.append(f"  - xref cache: calls={call_count}, word_refs={word_ref_count}")
        if r.get('notes'):
            lines.append(f"  - {r['notes']}")
    out = root / args.output_md
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(out)


if __name__ == '__main__':
    main()
