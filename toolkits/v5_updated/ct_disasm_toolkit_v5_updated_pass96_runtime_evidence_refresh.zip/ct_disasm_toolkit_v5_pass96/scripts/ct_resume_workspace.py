#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
from pathlib import Path


def run(cmd, cwd: Path):
    print('+', ' '.join(str(x) for x in cmd))
    subprocess.run(cmd, cwd=str(cwd), check=True)


def main() -> None:
    ap = argparse.ArgumentParser(description='One-command resume/bootstrap for the Chrono Trigger disassembly workspace.')
    ap.add_argument('--workdir', default='.')
    ap.add_argument('--rom', default=None)
    args = ap.parse_args()
    root = Path(args.workdir).resolve()
    run(['python3', 'scripts/ct_pass_index.py', '--dir', str(root)], root)
    run(['python3', 'scripts/ct_export_label_db.py', '--dir', str(root), '--output', str(root / 'data' / 'ct_label_db_starter.csv')], root)
    run(['python3', 'scripts/ct_build_label_db.py', '--dir', str(root), '--output', str(root / 'data' / 'ct_label_db.sqlite')], root)
    run(['python3', 'scripts/ct_export_label_db_json.py', '--db', str(root / 'data' / 'ct_label_db.sqlite'), '--output', str(root / 'data' / 'ct_label_db.json')], root)
    run(['python3', 'scripts/ct_make_opcode_csv.py', '--output-dir', str(root / 'data')], root)
    run(['python3', 'scripts/ct_build_opcode_coverage.py', '--data-dir', str(root / 'data')], root)
    xref_out = root / 'data' / 'ct_hot_xref_cache.json'
    if xref_out.exists() and xref_out.stat().st_size > 0:
        print(f'+ reuse existing xref cache: {xref_out}')
    else:
        run(['python3', 'scripts/ct_build_xref_cache.py', '--targets', str(root / 'targets' / 'hot_xref_targets.txt'), '--output', str(xref_out)], root)
    run(['python3', 'scripts/ct_generate_bank_workbooks.py', '--output-dir', str(root / 'bank_workbooks')], root)
    run(['python3', 'scripts/ct_import_runtime_evidence.py', '--root', str(root), '--trace-dir', 'traces/imported', '--db', 'data/ct_label_db.sqlite', '--summary-json', 'reports/runtime/runtime_evidence_summary.json', '--summary-md', 'reports/runtime/runtime_evidence_summary.md'], root)
    run(['python3', 'scripts/ct_build_knowledge_graph.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-json', 'graph/ct_knowledge_graph.json', '--summary-md', 'graph/ct_knowledge_graph_summary.md'], root)
    run(['python3', 'scripts/ct_generate_bank_dossiers.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-dir', 'dossiers'], root)
    run(['python3', 'scripts/ct_generate_evidence_pages.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-dir', 'evidence_pages/global_opcodes'], root)
    if args.rom:
        run(['python3', 'scripts/ct_score_code_data.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--rom', args.rom, '--output-json', 'reports/code_data_score.json', '--output-md', 'reports/code_data_score.md'], root)
    else:
        run(['python3', 'scripts/ct_score_code_data.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-json', 'reports/code_data_score.json', '--output-md', 'reports/code_data_score.md'], root)
    run(['python3', 'scripts/ct_generate_asm_skeleton.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-dir', 'asm_skeleton/banks'], root)
    run(['python3', 'scripts/ct_detect_conflicts.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-md', 'reports/ct_conflict_report.md', '--output-csv', 'reports/conflicts/ct_conflicts.csv'], root)
    run(['python3', 'scripts/ct_generate_bank_sources.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-dir', 'source'], root)
    run(['python3', 'scripts/ct_freeze_ranges.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-json', 'state/range_freeze.json', '--summary-md', 'reports/ct_freeze_summary.md', '--seed-from-db'], root)
    run(['python3', 'scripts/ct_source_state_report.py', '--root', str(root), '--manifest', 'source/meta/source_manifest.json', '--freeze-json', 'state/range_freeze.json', '--output-md', 'reports/ct_source_state.md'], root)
    run(['python3', 'scripts/ct_generate_rom_coverage.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-md', 'reports/ct_rom_coverage.md', '--output-html', 'reports/ct_rom_coverage.html', '--output-json', 'reports/ct_rom_coverage.json'], root)
    run(['python3', 'scripts/ct_runtime_validate.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-md', 'reports/ct_runtime_validation.md', '--output-json', 'reports/runtime/runtime_validation.json', '--output-csv', 'reports/runtime/runtime_validation.csv'], root)
    diff_cmd = ['python3', 'scripts/ct_rebuild_diff.py', '--root', str(root), '--output-md', 'reports/ct_rebuild_diff_report.md', '--output-json', 'reports/ct_rebuild_diff_report.json']
    if args.rom:
        diff_cmd += ['--rom', args.rom]
    run(diff_cmd, root)
    run(['python3', 'scripts/ct_completion_score.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-json', 'reports/completion/ct_completion_score.json', '--output-md', 'reports/ct_completion_score.md'], root)
    run(['python3', 'scripts/ct_make_report.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output', 'reports/ct_workspace_report.md', '--state-json', 'state/current_state.json'], root)
    run(['python3', 'scripts/ct_runtime_capture_plan.py', '--root', str(root), '--profiles-json', 'targets/runtime_capture_profiles.json', '--state-json', 'state/current_state.json', '--output-md', 'reports/runtime/runtime_capture_plan.md', '--output-json', 'reports/runtime/runtime_capture_plan.json'], root)
    run(['python3', 'scripts/ct_generate_unresolved_dashboard.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-md', 'reports/ct_unresolved_dashboard.md', '--output-json', 'reports/ct_unresolved_dashboard.json'], root)
    run(['python3', 'scripts/ct_dispatch_family_report.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--xref-json', 'data/ct_hot_xref_cache.json', '--output-md', 'reports/ct_dispatch_family_report.md'], root)
    run(['python3', 'scripts/ct_apu_packet_summary.py', '--root', str(root), '--db', 'data/ct_label_db.sqlite', '--output-md', 'reports/ct_apu_packet_summary.md'], root)

    print('\nResume bootstrap complete.')
    print('Open these first:')
    print('  - notes/community_research_first.md')
    print('  - notes/next_session_start_here.md')
    print('  - reports/ct_workspace_report.md')
    print('  - reports/ct_completion_score.md')
    print('  - reports/ct_conflict_report.md')
    print('  - reports/ct_unresolved_dashboard.md')
    print('  - reports/ct_dispatch_family_report.md')
    print('  - reports/ct_apu_packet_summary.md')
    print('  - reports/runtime/runtime_capture_plan.md')
    print('  - reports/ct_runtime_validation.md')
    print('  - reports/ct_rom_coverage.md')
    print('  - reports/ct_source_state.md')
    print('  - reports/ct_rebuild_diff_report.md')
    print('  - graph/ct_knowledge_graph_summary.md')
    print('  - dossiers/C1_dossier.md')
    print('  - latest pass + labels')


if __name__ == '__main__':
    main()
