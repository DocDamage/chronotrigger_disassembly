# bsnes Runtime Trace Targets

Use runtime traces as confirmation, not as naming authority.

## Best current targets
- `C7:0140`
- `C7:0155`
- `C7:01A1`
- `C7:04B1`
- `C7:061C`
- `C7:0655`
- `C7:071D`
- `C7:0734`
- `C7:0755`
- `C7:08E3`
- `C7:0A39`
- `CE:E18E`
- `CD:18C2`
- `D1:E91A`
- `D1:E984`

## Best WRAM watches
- `00:1E00..1E10`
- `00:1E20..1E63`
- `00:1F00..1FC0`
- `7E:CFFF`
- `7E:CDC8`
- `7E:CE0F`
- `7E:CD47..CDC6`
- `7E:0B40..0FFF`
- `7E:99DD..99DF`
- `7E:9F22..9F24`
- `7E:AEFF..AF15`
- `7E:AFAB..AFB5`
- `7E:B03A..B044`
- `7E:B158..B162`
- `7E:B242`
- `7E:B24A`
- `7E:B263`

## APU / hardware ports
- `00:2140`
- `00:2141`
- `00:2142`
- `00:2143`
