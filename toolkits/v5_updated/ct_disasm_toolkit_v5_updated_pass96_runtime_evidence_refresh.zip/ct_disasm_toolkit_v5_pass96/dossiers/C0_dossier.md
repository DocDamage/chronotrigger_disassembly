# Bank C0 Dossier

- Label rows: **7**
- Latest pass touching bank: **92**

## Status mix
- provisional: **1**
- strong: **5**
- unspecified: **1**

## Top labels carried in this bank
- `C0:A2B0..A335`  **consumer path                                           [unlabeled as final routine]**  (unspecified, pass 47)
- `C0:A270..C0:A335`  **ct_c0_parallel_source_plane_consumer_band**  (provisional, pass 48)
- `C0:FD00..C0:FDFF`  **ct_c0_bit_reverse_lookup_256**  (strong, pass 79)
- `C0:0008..C0:000A`  **ct_c0_branch_long_to_1bab_conditional_c70004_packet_submitter_veneer**  (strong, pass 91)
- `C0:1BAB..C0:1BE5`  **ct_c0_submit_one_of_two_c70004_command_packets_by_2a1f_bit6**  (strong, pass 91)
- `C0:000B..C0:000D`  **ct_c0_branch_long_to_1be6_gated_multi_packet_c70004_submitter_veneer**  (strong, pass 92)
- `C0:1BE6..C0:1CFB`  **ct_c0_submit_gated_multi_packet_c70004_sequence_by_7f01ec_and_2a1f_bits**  (strong, pass 92)

## Highest-value open work
- continue separating hard proof from architecture wording; current bank coverage is still partial

## Notes
- Generated from the persistent label DB. Use this as the fast bank-local briefing before reopening pass notes.

