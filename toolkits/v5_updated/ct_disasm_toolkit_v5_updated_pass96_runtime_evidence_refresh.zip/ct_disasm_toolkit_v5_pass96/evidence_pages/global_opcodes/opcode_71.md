# Global Opcode 71

- Status: **strong structural**
- Dispatch address: **C1:A7A9**
- Evidence pass: **71**
- Notes: Nonhead AE70 -> ADA1 selector family for positive FD record byte +1D; scans live slots 3..10 and skips the primary-seed slot indexed by B18B.

## Matching label evidence
- pass 94: `C7:0755..C7:08E2` **ct_c7_handle_opcode_71_as_table_driven_apu_triplet_burst_sender** (strong)
  - Exact opening behavior: checks exact per-slot/state byte `1E20` if that state is active and `1E01 == 0`, exits through `0192` Exact setup behavior: computes `(1E01 - 1) * 3` indexes the exact table rooted at `C7:0AEA` Exact hardware-facing behavior: performs repeated three-byte burst writes through `2141 / 2142 / 2143` issues exact fixed follow-up command writes including `2141 = 0x05` later issues exact `2141 = 0x02` with paired `2142/2143` values Exact tail behavior: caches the current `1E01` value into the per-slot strip at `1E20 + X` exits through the common cleanup path at `0192` Strongest safe reading: exact opcode-`0x71` table-driven APU burst sender / uploader over the `1E00..` sound-command workspace.
- pass 71: `C1:A7A9..C1:A7E4` **ct_global_opcode_71_select_nonhead_occupied_live_slots_excluding_primary_seed_by_positive_fd_record_byte_1D** (strong)
  - Nonhead counterpart of the pass-70 visible FD-byte selector family. Scans live slots `3..10`. Skips the primary-seed slot indexed by `B18B`. Uses `AE70 -> ADA1` to select/reduce candidates.
