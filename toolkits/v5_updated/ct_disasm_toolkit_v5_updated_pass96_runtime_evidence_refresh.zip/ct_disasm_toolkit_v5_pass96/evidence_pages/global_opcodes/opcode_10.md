# Global Opcode 10

- Status: **strong structural**
- Dispatch address: **C1:93E6**
- Evidence pass: **65**
- Notes: No AC14. Uses operands2-3 to choose relation mode 09/0A/0B/0C, seeds current subject slot B252+3, and succeeds only when 9872==0; effective tests are coarse current-subject row/column band gates

## Matching label evidence
- pass 94: `C7:0AD9..C7:0AE8` **ct_c7_packet_opcode_10_17_gate_table_to_active_handler_or_common_exit** (strong)
  - Exact eight-entry 16-bit table for packet opcodes `0x10..0x17`: `0x10 -> 01A1` `0x11 -> 01A1` `0x12 -> 0192` `0x13 -> 0192` `0x14 -> 01A1` `0x15 -> 01A1` `0x16 -> 0192` `0x17 -> 0192` Strongest safe reading: exact two-target early gate for the `0x10..0x17` family, splitting to either the active handler (`01A1`) or the immediate common exit (`0192`).
- pass 65: `C1:93E6..C1:9429` **ct_global_opcode_10_gate_tail_replay_on_current_subject_row_column_band_query** (strong)
  - Does not call `AC14`. Selects relation mode `09/0A/0B/0C` from operands `+2/+3`. Uses current subject slot `986F = B252 + 3`. Succeeds only when the chosen mode leaves `9872 == 0`. Effective success regions are: mode `09`: `Y>>4 >= 0x08` mode `0A`: `Y>>4 < 0x08` mode `0B`: `X>>4 >= 0x0B` mode `0C`: `X>>4 < 0x05`
