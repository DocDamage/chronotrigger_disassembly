# Global Opcode 30

- Status: **strong**
- Dispatch address: **C1:9962**
- Evidence pass: **68**
- Notes: Exact shared alias of STZ AF24 ; RTS

## Matching label evidence
- pass 96: `C7:071D..C7:0733` **ct_c7_table_drive_opcode_30_3f_family_into_1e00_1e03_then_tail_jump_to_0155** (strong)
  - Masks exact opcode byte `1E00` to its low nibble. Multiplies by four and indexes the exact table rooted at `C7:0A98`. Seeds exact packet bytes `1E02` and `1E00` from that table. Tail-jumps to `0155`, reusing the same low-bank packet sender / dispatcher flow. Strongest safe reading: exact table-driven bridge from the `0x30..0x3F` family into the shared low-bank packet-send path.
