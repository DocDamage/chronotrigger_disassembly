# Global Opcode 70

- Status: **strong structural**
- Dispatch address: **C1:A765**
- Evidence pass: **71**
- Notes: Scans occupied nonhead live slots 3..10, compares nonzero FD record word +3, stores the minimum-value slot in AECC[0], and forces AECB = 1.

## Matching label evidence
- pass 94: `C7:08E3..C7:09D8` **ct_c7_handle_opcode_70_as_apu_handshake_and_triplet_packet_sender** (strong)
  - Exact opening behavior: reads `1E01` compares against the latched pair at `1E10 / 1E11` Exact hardware-facing behavior: performs handshake traffic through `2140` using `0xFE` later uses exact `2140` handshake/reset traffic with `0xE0` performs repeated command/data triplets through `2141 / 2142 / 2143` selects exact command byte `0x05` when `1E00 == 0x70` otherwise uses exact command byte `0x03` on the shared internal path Exact table-backed send behavior: sources repeated triplet payloads from exact tables rooted at `C7:430B` and `C7:5B0D` clears exact local latch byte `F3` before returning in the table-send paths Strongest safe reading: exact opcode-`0x70` APU handshake / packet-send handler behind the `1E00` sound-command dispatcher.
- pass 71: `C1:A765..C1:A7A8` **ct_global_opcode_70_select_one_nonhead_occupied_live_slot_by_min_nonzero_fd_record_word_03** (strong)
  - Scans occupied live slots `3..10`. Resolves each slot through `FD:A80B + slot*2`. Compares the 16-bit word at `record + 3`. Keeps the smallest nonzero value and stores the corresponding slot into `AECC[0]`. Forces `AECB = 1`.
