# Next Session Start Here

1. Read `notes/community_research_first.md`
2. Open these in order:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `dossiers/C1_dossier.md`
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - latest pass + labels
3. Active top-of-stack seam after pass 76:
   - crack `C1:48EC` and `C1:4943` so the shared service-04 tail gets a final output noun
   - finish service-04 modes `0` and `3` at `C1:475A / C1:475B`
   - return to the per-byte field semantics of the 17-byte `CC:213F -> AEE6..AEF6` descriptor records
4. Specific cleanup targets:
   - decide the best final noun for the `4833 / 48EC / 4943` output family
   - freeze the final roles of `9877..9885`
   - tighten the optional `CD:0018` substage gated by `AE94`
   - re-open `CC:45A6`, `CC:5526`, and the mode-1 `CD:4000..401F` families as data tables rather than code-adjacent blobs
5. Runtime confirmation shortlist:
   - current-tail path `BFAA -> AC57 -> service04 mode1`
   - fixed-`7F` path `895B -> AC57 -> service04 mode2`
   - shared tail `4833`
   - parser/helper pair `48EC` and `4943`
