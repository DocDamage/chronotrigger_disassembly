; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_CE
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; CE:E18E  top-status=strong  labels=1
; =============================================================================
; [strong] pass 86 :: ct_ce_clear_cd47_cdc6_work_strip_only_when_cdc8_nonzero
; qualifier: strong structural
; notes: Exact body: `LDA $CDC8 ; BEQ return ; TDC ; TAX ; REP #$20 ; STZ $CD47,X ; INX ; INX ; CPX #$0080 ; BNE loop ; TDC ; SEP #$20 ; RTL`. Exact behavior: if `CDC8 == 0`, return immediately. If `CDC8 != 0`, clear the exact `0x80`-byte strip `CD47..CDC6`. Strongest safe reading: first exact external `CDC8` reader; nonzero-gated clear helper for one D1-adjacent work strip.
; source: chrono_trigger_labels_pass86.md
CE_E18E_ct_ce_clear_cd47_cdc6_work_strip_only_when_cdc8_nonzero:
    ; TODO: reconstruct body / data for CE:E18E
    ; known span hint: CE:E18E..CE:E1A4

