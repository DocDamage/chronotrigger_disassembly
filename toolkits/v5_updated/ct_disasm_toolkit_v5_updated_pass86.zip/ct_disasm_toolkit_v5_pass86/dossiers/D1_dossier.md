# Bank D1 Dossier

- Label rows: **26**
- Latest pass touching bank: **86**

## Status mix
- provisional: **6**
- strong: **18**
- unspecified: **2**

## Top labels carried in this bank
- `D1:5800`  **/ D1:5A50 / D1:5BD0  ct_d1_tilemap_template_family_16x12_words [provisional]**  (unspecified, pass 44)
- `D1:5800`  **ct_d1_tilemap_template_default_0b40_0180**  (strong, pass 44)
- `D1:5A50`  **ct_d1_tilemap_template_alt_a_0b40_0180**  (strong, pass 44)
- `D1:5BD0`  **ct_d1_tilemap_template_alt_b_0b40_0180**  (strong, pass 44)
- `D1:5800`  **/ D1:5A50 / D1:5BD0  ct_d1_alt_base_strip_layout_family        [provisional]**  (provisional, pass 45)
- `D1:5800`  **/ D1:5A50 / D1:5BD0  ct_d1_base_strip_template_family_32x6     [strong]**  (unspecified, pass 45)
- `D1:5800`  **/ D1:5A50 / D1:5BD0  ct_d1_tilemap_template_family_16x12_words [withdrawn]**  (provisional, pass 45)
- `D1:59FC`  **ct_d1_panel_segment_template_6x7_words**  (strong, pass 45)
- `D1:5800`  **/ D1:5A50 / D1:5BD0  ct_d1_alt_base_strip_layout_family      [strengthened context]**  (provisional, pass 46)
- `D1:5800`  **ct_d1_base_strip_template_default**  (provisional, pass 46)
- `D1:5A50`  **ct_d1_base_strip_template_latched_alt**  (provisional, pass 46)
- `D1:5BD0`  **ct_d1_base_strip_template_transition_alt**  (provisional, pass 46)
- `D1:646C..D1:652B`  **ct_d1_auxiliary_descriptor_pointer_table**  (strong, pass 79)
- `D1:E899..D1:E8C0`  **ct_d1_fill_palette_band_pairs_2040_2240_and_2120_2320_with_7fff_sentinel**  (strong, pass 82)
- `D1:E8C1..D1:E8D4`  **ct_d1_fill_palette_band_pair_21a0_23a0_with_7fff_sentinel**  (strong, pass 82)
- `D1:E91A..D1:E983`  **ct_d1_promote_first_48color_palette_band_and_restore_active_3record_descriptor_slab**  (strong, pass 82)
- `D1:E984..D1:E9EB`  **ct_d1_seed_first_48color_palette_band_from_d0_fd00_and_snapshot_active_descriptor_slab_outward**  (strong, pass 82)
- `D1:E70A..D1:E77B`  **ct_d1_optional_exchange_secondary_and_tertiary_palette_band_pairs**  (strong, pass 83)
- `D1:F411..D1:F426`  **ct_d1_snapshot_palette_descriptor_header_bytes_8slots_to_cd2f_cd36**  (strong, pass 83)
- `D1:F427..D1:F430`  **ct_d1_select_descriptor_header_suspend_or_restore_by_cfff**  (strong, pass 83)
- `D1:F431..D1:F456`  **ct_d1_arm_ce12_shadow_descriptor_headers_and_suspend_family_10_slots**  (strong, pass 83)
- `D1:F457..D1:F473`  **ct_d1_restore_shadowed_descriptor_headers_from_cd2f_cd36_and_clear_ce12**  (strong, pass 83)
- `D1:F260..D1:F297`  **ct_d1_reset_control_cluster_state_including_ce0f_ce12_and_cfff**  (strong, pass 84)
- `D1:EC27..D1:EC5B`  **ct_d1_build_four_endpoint_pairs_from_mulhi_and_current_5da0_5da1_pair_then_call_f9af**  (strong, pass 86)
- `D1:EDCD..D1:EE95`  **ct_d1_expand_current_5da0_5da1_axis_pair_by_cd3a_cd3b_into_four_plane_span_strips**  (strong, pass 86)

## Highest-value open work
- continue separating hard proof from architecture wording; current bank coverage is still partial

## Notes
- Generated from the persistent label DB. Use this as the fast bank-local briefing before reopening pass notes.

