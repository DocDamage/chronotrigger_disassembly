# Chrono Trigger Workspace Report

## Current top-of-stack
- Latest pass: **86**
- Current live seam: **Early global opcode band inside C1:B80D master dispatch, with pack-fed opcode observations from pass 61.**
- Completion estimate: **~61.0%**

## Label database
- Total label rows: **591**
- Strong: **395**
- Provisional: **126**
- Alias: **1**
- Caution: **2**
- Runtime evidence rows: **0**

## Coverage worksheets
- Master C1 global opcode worksheet rows: **170**
- Selector-control worksheet rows: **83**
- Service-7 wrapper worksheet rows: **8**

## Xref cache
- Hot targets cached: **33**

## v4 generated artifacts
- `reports/ct_completion_score.md`
- `reports/ct_conflict_report.md`
- `reports/code_data_score.md`
- `graph/ct_knowledge_graph_summary.md`
- `dossiers/C1_dossier.md`
- `asm_skeleton/banks/`

## Immediate next work
1. Re-read the community context note before doing new naming work.
2. Re-open the pass 59–61 late-pack/master-dispatch seam.
3. Continue the early global opcode band inside `C1:B80D..C1:B95F`.
4. Import runtime evidence when static ownership proof stalls.

## Still required for full disassembly
- Complete bank-by-bank code/data separation
- Finish global opcode and VM coverage
- Finish decompressor grammar / format work
- Freeze subsystem ownership boundaries across banks
- Build a rebuildable source tree and validate against ROM fingerprints
