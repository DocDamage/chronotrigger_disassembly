# Chrono Trigger Labels — Merged

Merged from 55 pass label files.


---

## Pass 32

# Chrono Trigger (USA) — Labels Added / Strengthened in Pass 32

This file contains the labels newly added or materially strengthened in pass 32.

Status tags:
- **[strong]** = safe to carry forward unless contradicted by later control-flow proof
- **[provisional]** = useful working label, but still open to rename/refinement
- **[alias]** = intentional alias/stub label for a table entry landing in shared code or padding-style exits

## New / strengthened command-table labels

```text
FD:BA4A  ct_c1_cmd_00_16_advance_ctrl_table              [provisional]
         First 23 bytes used by group-1 random stream-control path.
         Best current reading: command advance / stream-skip control table,
         not yet a fully solved universal operand-size table.

C1:B85F  ct_c1_group1_cmd_table                          [strong]
C1:B88D  ct_c1_group2_cmd_table                          [strong]
C1:8CE7  ct_c1_group1_dispatch_site                      [strong]
C1:8D88  ct_c1_group2_dispatch_site                      [strong]
```

## Dispatcher-state / interpreter-control labels

```text
7E:AF24  ct_c1_cmd_short_circuit_flag                    [provisional]
         Nonzero causes early handler/dispatch exit behavior.

7E:B3B8  ct_c1_group2_continuation_selector              [provisional]
         0 = fuller continuation path
         1 = alternate continuation path with extra helper stage
         2 = skip directly to common tail
```

## Group 1 labels

```text
C1:9810  ct_c1_g1_op00_body                              [provisional]
C1:983A  ct_c1_g1_op01_op02_shared_body                  [provisional]

C1:98C4  ct_c1_g1_op03_rts_stub                          [alias]
C1:98C5  ct_c1_g1_op04_random_4way_stream_advance        [strong]

C1:9960  ct_c1_g1_op05_rts_stub                          [alias]
C1:9961  ct_c1_g1_op06_rts_stub                          [alias]
C1:9962  ct_c1_g1_op07_clear_short_circuit_and_rts       [alias]
C1:9966  ct_c1_g1_op08_rts_stub                          [alias]
C1:9967  ct_c1_g1_op09_body                              [provisional]
C1:9978  ct_c1_g1_op0A_rts_stub                          [alias]
C1:9979  ct_c1_g1_op0B_clear_short_circuit_and_rts       [alias]
C1:997D  ct_c1_g1_op0C_rts_stub                          [alias]
C1:997E  ct_c1_g1_op0D_rts_stub                          [alias]
C1:997F  ct_c1_g1_op0E_rts_stub                          [alias]
C1:9980  ct_c1_g1_op0F_rts_stub                          [alias]
C1:9981  ct_c1_g1_op10_op16_shared_body                  [provisional]
C1:99B4  ct_c1_g1_op11_to_op15_clear_short_circuit_rts   [alias]
```

## Group 2 labels

```text
C1:99B8  ct_c1_g2_op00_set_continuation_2                [strong]
C1:99BE  ct_c1_g2_op01_body                              [provisional]
C1:9A39  ct_c1_g2_op02_body                              [provisional]
C1:9B46  ct_c1_g2_op03_rts_stub                          [alias]
C1:9B47  ct_c1_g2_op04_varctrl_shared_entry_a            [provisional]
C1:9B48  ct_c1_g2_op05_varctrl_shared_entry_b            [provisional]
C1:9B8C  ct_c1_g2_op06_body                              [provisional]
C1:9B8D  ct_c1_g2_op07_body                              [provisional]
C1:9C6E  ct_c1_g2_op08_body                              [provisional]
C1:9C6F  ct_c1_g2_op09_body                              [provisional]
C1:9CB3  ct_c1_g2_op0A_body                              [provisional]
C1:9D1B  ct_c1_g2_op0B_body                              [provisional]
C1:9D72  ct_c1_g2_op0C_body                              [provisional]
C1:9DCE  ct_c1_g2_op0D_bitmask_state_control             [strong]
C1:9E62  ct_c1_g2_op0E_rts_stub                          [alias]
C1:9E63  ct_c1_g2_op0F_optional_cd0033_then_cont2        [strong]
C1:9E78  ct_c1_g2_op10_body                              [provisional]
C1:9F5A  ct_c1_g2_op11_body                              [provisional]
C1:9FD2  ct_c1_g2_op12_body                              [provisional]
C1:A14E  ct_c1_g2_op13_sat_signed_delta_to_b158          [strong]
C1:A188  ct_c1_g2_op14_multi_target_sat_adjust           [provisional]
C1:A20B  ct_c1_g2_op15_multi_target_sat_adjust           [provisional]
C1:A396  ct_c1_g2_op16_body                              [provisional]
```

## Helper label strengthened in this pass

```text
C1:A3D1  ct_c1_sat_signed_byte_adjust_indirect_y         [strong]
         Adjusts byte at (0E),Y using signed delta in $10 with floor/clamp behavior.
```

## Notes for next pass
- Do not collapse `FD:BA4A` into a hard operand-size table yet.
- Do not assign battle-only or map-only ownership to `9E78/9F5A/9FD2/A396` without caller proof.
- Keep the `CD0033` callsite labels generic until the service role is proven from both caller and callee sides.
- Preserve alias labels; they matter because they keep table density honest.


---

## Pass 33

# Chrono Trigger (USA) — Labels Added / Strengthened in Pass 33

This file contains labels newly added or materially strengthened in pass 33.

Status tags:
- **[strong]** = safe to carry forward unless contradicted by later control-flow proof
- **[provisional]** = useful working label, but still open to rename/refinement
- **[alias]** = intentional alias/stub label for a table entry landing in shared code or padding-style exits

## Shared helper labels strengthened in this pass

```text
C1:AC46  ct_c1_sel_scratch_init_aecc_ad8e_ff                  [strong]
         Fills $AECC.. and $AD8E.. with #$FF across 0x0B entries.

C1:AC14  ct_c1_inline_selector_resolve_to_aecc_ad8e           [provisional]
         Consumes one inline selector control byte, resolves a selection
         path (including JSR ($B8BB,X) path), mirrors resulting list into
         $AD8E, and stores $B2AE = $AECC.

C1:AD09  ct_c1_first_selected_mask_to_ae95                    [strong]
         Builds a #$8000 >> index style mask from the first $AECC entry.

C1:AD35  ct_c1_selected_list_mask_to_ae99                     [strong]
         Iterates the $AECC list and accumulates masks for all selected entries.
```

## Group-2 labels upgraded in this pass

```text
C1:9E78  ct_c1_g2_op10_select_eligible_slots_finalize         [strong]
         Scans 8 candidate entries using AF0D/AF02/AF15 gates,
         appends accepted entries to $AECC, materializes per-slot side effects,
         applies operand-1 field-init mode, builds masks, optional CD0033,
         returns with $B3B8 = 1.

C1:9F5A  ct_c1_g2_op11_group_base_write4_pairs                [strong]
         Uses $B18B to select a base offset from FD:A80B, then writes
         four odd/even operand pairs via STA ($0E),Y. Optional CD0033.

C1:9FD2  ct_c1_g2_op12_group_base_write5_pairs_validate       [strong]
         Uses $B18B to select a base offset from FD:A80B, writes five
         odd/even operand pairs, then performs selector-driven validation/
         commit follow-up using AC14, C1DD, AD09, AD35, FDAAD2, AC89, ACCE.

C1:A396  ct_c1_g2_op16_wrapper_fused_fd_a990                  [strong]
         Thin wrapper around FD:A990 plus AC46/AD09/AD35 and optional CD0033.
```

## Bank-FD helper labels strengthened in this pass

```text
FD:A990  ct_fd_fused_group_base_write_and_slot_select_helper  [strong]
         Long helper combining the table-selected byte-write family with the
         eligible-slot scan/materialize family.

FD:A80B  ct_fd_group_base_offset_table                        [strong]
         16-bit base-offset table indexed by $B18B for the writer-family handlers.
```

## Scratch / state labels newly worth carrying forward

```text
7E:AE95  ct_c1_first_selected_mask                            [provisional]
7E:AE99  ct_c1_selected_list_mask                             [provisional]
7E:AECB  ct_c1_selected_count                                 [provisional]
7E:AECC  ct_c1_selected_list                                  [provisional]
7E:AD8D  ct_c1_saved_selected_count                           [provisional]
7E:AD8E  ct_c1_saved_selected_list                            [provisional]
7E:AE97  ct_c1_selector_result_a                              [provisional]
7E:AE98  ct_c1_selector_result_b                              [provisional]
7E:B3C7  ct_c1_group2_optional_cd0033_flag                    [provisional]
```

## Notes for next pass
- Do not over-name `$AECC` / `$AD8E` beyond “selected list” yet.
- Do not assign a gameplay-facing meaning to `$5FB0/$5FB2` from `0x10` without cross-caller proof.
- Do not rename `C1:C1DD`, `C1:AC89`, or `C1:ACCE` aggressively yet; they are clearly part of the `0x12` commit path, but their exact subsystem role still needs proof.
- Next highest-value targets are still `C1:99BE` and `C1:9A39`.


---

## Pass 34

# Chrono Trigger (USA) — Labels Added / Strengthened in Pass 34

This file contains labels newly added or materially strengthened in pass 34.

Status tags:
- **[strong]** = safe to carry forward unless contradicted by later control-flow proof
- **[provisional]** = useful working label, but still open to rename/refinement
- **[alias]** = intentional alias/stub label for a table entry landing in shared code or wrapper logic

## Group-2 labels upgraded in this pass

```text
C1:99BE  ct_c1_g2_op01_seed_single_from_5e15_finalize        [strong]
         Seeds a one-entry list from $5E15[$AEC8], sets B1FC bit 1,
         captures two inline params into AEE4/AEE5, optionally derives
         B18C for operand-1==1, calls unique long helper FD:AB01,
         then finalizes through AC89/ACCE and returns with B3B8 = 0.

C1:9A39  ct_c1_g2_op02_wrapper_jsr_9a3d                      [strong]
         Table-entry wrapper only: JSR $9A3D ; RTS.

C1:9A3D  ct_c1_g2_op02_seed_from_b16e_validate_commit        [strong]
         Seeds a one-entry list from $B16E[$AEC8], clears B1FC bit 1,
         optionally resolves up to two inline selector bytes through AC14,
         validates through C1DD, then commits through AD09/AD35/FDAAD2/
         AC89/ACCE and returns with B3B8 = 0.
```

## Helper labels strengthened in this pass

```text
FD:AB01  ct_fd_op01_unique_long_helper                        [provisional]
         Unique long helper reached by group-2 opcode 0x01 after the
         one-entry seed + AEE4/AEE5/B18C setup. Do not over-name yet.

C1:9B3B  ct_c1_g2_validation_fail_set_af24_2                 [strong]
         Shared local failure site used by the opcode-0x02 validation path:
         sets AF24 = 2 and then returns through the normal B3B8 = 0 tail.
```

## State labels newly worth carrying forward

```text
7E:AEE5  ct_c1_op01_param2_or_submode                         [provisional]
7E:B18C  ct_c1_primary_seed_or_mode_value                     [provisional]
```

## State notes strengthened in this pass

```text
7E:B1FC bit 1                                                 [provisional]
         Deliberately split by the early group-2 pair:
         set by opcode 0x01, cleared by opcode 0x02.
         Treat as an opcode-mode control bit until helper/caller proof
         gives a safer gameplay-facing name.
```

## Notes for next pass
- Tighten `C1:C1DD`, `C1:AC89`, and `C1:ACCE` before renaming their state outputs aggressively.
- Do not assign gameplay meanings to `$5E15[$AEC8]` or `$B16E[$AEC8]` yet; only their use as distinct one-entry seed sources is proven.
- Do not claim `FD:AB01` is ordinary 65816 code without stronger entry/exit proof.


---

## Pass 35

# Chrono Trigger (USA) — Labels Added / Strengthened in Pass 35

This file contains labels newly added or materially strengthened in pass 35.

Status tags:
- **[strong]** = safe to carry forward unless contradicted by later control-flow proof
- **[provisional]** = useful working label, but still open to rename/refinement
- **[alias]** = intentional alias/stub label for a table entry landing in shared code or wrapper logic

## Long-helper and follow-up packet labels

```text
FD:AB01  ct_fd_op01_resolve_followup_packet_from_b18c         [strong]
         Real linear long helper uniquely used by group-2 opcode 0x01.
         Uses B18C plus hardcoded secondary arg 0x0B through C1:FDBF,
         stores result index in B2C3, then materializes:
           B18E = CC:88CB[result]
           B18F = B18C
           B190 = CC:88CC[result]
           B191 = 0

C1:AC89  ct_c1_merge_opcode_mode_into_b18e_b18f_packet        [strong]
         Opcode-sensitive follow-up packet merger/finalizer.
         ORs (A+3) into B18E, always clears B191, then uses AEE3 to
         specialize the packet:
           op0 -> clear B18F
           op1 -> set B18E bit7, clear B18F, set AEEB=4
           op2 -> set B18E bit6, copy 0E -> B18F
         Returns final B18E in dp10.

C1:ACCE  ct_c1_normalize_aee5_to_dp0e                         [strong]
         Normalizes raw AEE5 into working scratch 0E:
           1/2 -> 04
           3/4 -> 0D
           other values unchanged.

C1:ACF2  ct_c1_snapshot_followup_context_to_ae90_ae93         [strong]
         Stores snapshot state:
           AE90 = 0
           AE91 = B18B
           AE92 = AEE3
           AE93 = AEE4
```

## Mask-builder labels

```text
C1:AD09  ct_c1_build_ae95_one_hot_from_aecc0                  [strong]
         Clears AE95, then if AECB>0 and AECC[0]!=FF, builds
         (0x8000 >> AECC[0]) into AE95.

C1:AD35  ct_c1_build_ae99_mask_from_aecc_list                 [strong]
         Clears AE99, then for each current selected entry in
         AECC[0..AECB-1], ORs (0x8000 >> entry) into AE99.
```

## Validation/materialization labels

```text
C1:C1DD  ct_c1_validate_and_materialize_ad8e_list             [provisional]
         Clears AF23, validates seed/selector context against per-entry
         5E4A/5E4B/5E4C/5E4E/5E53 flags, derives a type byte from
         context-dependent CC tables, then dispatches through a case tree
         that materializes candidate entries into AD8E/AD8D.

C1:C72B  ct_c1_set_af23_fail_and_return                       [strong]
         Shared local failure helper:
           AF23 = 1 ; RTS
```

## State labels strengthened in this pass

```text
7E:B18E  ct_c1_followup_packet_byte0_flags_or_descriptor      [provisional]
7E:B18F  ct_c1_followup_packet_byte1_param_or_descriptor      [provisional]
7E:B190  ct_c1_followup_packet_byte2_mode_or_descriptor       [provisional]
7E:B191  ct_c1_followup_packet_byte3_clear_or_reserved        [provisional]

7E:AE95  ct_c1_first_selected_one_hot_mask                    [strong]
7E:AE99  ct_c1_selected_list_mask                             [strong]

7E:AEE5  ct_c1_op01_raw_secondary_param                       [provisional]
7E:000E  ct_c1_normalized_secondary_param_dp0e                [provisional]
7E:AF23  ct_c1_validation_fail_flag                           [strong]
7E:B2C3  ct_fd_op01_resolved_followup_index                   [provisional]
```

## Type/case notes worth carrying forward for `C1:C1DD`

```text
type 0/5/6  -> single mapped entry from B2AE via C8F7         [provisional]
type 1      -> copy non-FF AEFF[0..2] into AD8E               [provisional]
type 3      -> single mapped entry + extra AF15 high-bit gate [provisional]
type 4      -> fixed AD8E = [0,1,2]                           [provisional]
type 7      -> delegated helper path through C82D             [provisional]
```

## Notes for next pass
- Continue through unresolved later `C1:C1DD` type cases before renaming the type byte or the auxiliary byte `0C`.
- Trace the common downstream path at `C1:C55F` to convert the current “follow-up packet” wording into real subsystem semantics.
- Trace consumers of `B18E..B191` and `AE90..AE93` before assigning gameplay-facing names.


---

## Pass 36

# Chrono Trigger (USA) — Labels Added / Strengthened in Pass 36

This file contains labels newly added or materially strengthened in pass 36.

Status tags:
- **[strong]** = safe to carry forward unless contradicted by later control-flow proof
- **[provisional]** = useful working label, but still open to rename/refinement
- **[alias]** = intentional alias/stub label for a table entry landing in shared code or wrapper logic

## Common-tail pipeline labels

```text
C1:C55F  ct_c1_expand_and_finalize_ad8e_via_cc2ab0_descriptors   [strong]
         Common downstream pipeline reached from multiple C1DD type families.
         Uses mode byte 3A, descriptor index 0C, pointer table CC:2AB0,
         per-record packet emitters/services, bounded result merging from
         99C0 into AD8E/AECC, then final AD8E compaction/count derivation.

C1:C659  ct_c1_handle_empty_query_result_before_local_fail       [provisional]
         Empty-result special handler used when common-tail query results are
         empty and mode != 4. Prepares AE91..AE96 context, chooses AE93 from
         fixed values {7B,7C,7D}, calls AC57, then fails through C72B.

C1:C6D9  ct_c1_compact_ad8e_against_aeff_and_set_ad8d            [strong]
         Final compaction/count phase:
           - removes AD8E entries whose AEFF[entry] == FF by shifting left
           - derives AD8D from first FF terminator
           - sets AF23=1 if bounded list has no terminator
```

## Descriptor pipeline helper labels

```text
C1:C74C  ct_c1_load_seed_selector_context_to_dp00_dp0c           [strong]
         Loads working scratch for the common descriptor pipeline:
           00/02/04 from selector-related state
           06 = B2AE
           0C = B18B
         also mirrors selector bytes into AE97/AE98 when applicable.

C1:C95C  ct_c1_9604_packet_writer_table                          [strong]
         Word table of packet-writer subroutines selected by
         (descriptor_byte1 & 0x7F) * 2.

C1:C78D  ct_c1_emit_9604_packet_mode0                            [strong]
         Writes packet bytes from dp0A/dp00/dp06/dp08/dp0E.

C1:C7A7  ct_c1_emit_9604_packet_mode1                            [strong]
         Writes reduced packet bytes from dp0A/dp06/dp08.

C1:C7BD  ct_c1_emit_9604_packet_mode2                            [strong]
         Writes reduced packet bytes from dp0A/dp08.

C1:C7D1  ct_c1_emit_9604_packet_mode3                            [strong]
         Writes packet bytes from dp00/dp06/dp02.

C1:C7E7  ct_c1_emit_9604_packet_mode4                            [strong]
         Writes packet bytes from dp0A/dp02/dp08.

C1:C7FD  ct_c1_emit_9604_packet_mode5                            [strong]
         Writes packet bytes from dp0A/dp0C/dp08.

C1:C813  ct_c1_emit_9604_packet_mode6                            [strong]
         Writes packet bytes from dp0A/dp0C/dp06/dp08/dp0E.

C1:C736  ct_c1_store_3d_to_986e_and_call_service5                [provisional]
         Descriptor-selected trigger wrapper:
           986E = 3D
           A = 05
           JSR $0003

C1:C741  ct_c1_store_3d_to_99cc_and_call_service7                [provisional]
         Descriptor-selected trigger wrapper:
           99CC = 3D
           A = 07
           JSR $0003
```

## Type-family notes strengthened in this pass

```text
C1:C431  ct_c1dd_type08_tail_aeff_index_materializer            [provisional]
         Builds AD8E from later AEFF-index positions and enters common tail
         with 3A = 1.

C1:C478  ct_c1dd_type09_random_four_bucket_splitter             [provisional]
         Randomized 4-bucket dispatcher using AF22(#64), bytes 00:00FA/00:00FB,
         and delegated jumps into C82D / earlier shared list-builder paths.

C1:C4FA  ct_c1dd_type0b_0c_0d_0e_0f_12_1a_delegate_to_c82d      [strong]
         Shared family:
           JSR C82D
           if AF23!=0 -> fail
           else 3A=2 -> C55F

C1:C51C  ct_c1dd_type10_11_13_14_15_1b_direct_common_tail       [strong]
         Shared family:
           3A=3
           -> C55F

C1:C53C  ct_c1dd_type0a_direct_common_tail_mode1                [strong]
         Shared family:
           3A=1
           -> C55F

C1:C546  ct_c1dd_type32_single_mapped_entry_mode4               [strong]
         Maps B2AE through C8F7, seeds AD8E[0], AD8D=1, 3A=4, 0A=1,
         then enters C55F.
```

## State labels strengthened in this pass

```text
7E:003A  ct_c1_common_tail_mode_3a                              [strong]
         Common-tail post-materialization mode selector.

7E:000C  ct_c1_cc2ab0_descriptor_index                          [strong]
         Nonzero selector used by C55F to index the CC:2AB0 descriptor table.

7E:003B  ct_c1_current_cc2ab0_descriptor_base                   [strong]
         16-bit base pointer loaded from CC:2AB0[0C].

7E:003C  ct_c1_descriptor_service_selector_flag                 [provisional]
         Local boolean derived from descriptor byte1 bit7;
         chooses between C736 vs C741.

7E:003D  ct_c1_descriptor_service_arg0                          [provisional]
         Local byte loaded from descriptor byte0 and consumed by C736/C741.

7E:9604  ct_c1_service_packet_byte0                             [provisional]
7E:9605  ct_c1_service_packet_byte1                             [provisional]
7E:9606  ct_c1_service_packet_byte2                             [provisional]
7E:9607  ct_c1_service_packet_byte3                             [provisional]
7E:9608  ct_c1_service_packet_byte4                             [provisional]
         Packet bytes emitted by the C78D..C813 writer family.

7E:99C0  ct_c1_common_tail_query_result_slots                   [provisional]
         Bounded result vector consumed by C55F and merged into AD8E/AECC.

7E:AD8E  ct_c1_candidate_list_ad8e                              [strong]
7E:AD8D  ct_c1_candidate_count_ad8d                             [strong]

7E:AECC  ct_c1_common_tail_candidate_mirror                     [provisional]
         Parallel mirror of currently accepted common-tail query entries.
```

## Notes worth carrying forward
- Do not assign final subsystem names to the service/query engine behind `JSR $0003` yet.
- Do not assign gameplay semantics to descriptor bytes until the service engine and `$9604..$9608` consumers are traced.
- Type `9` is structurally real but still semantically incomplete.
- The `C1DD -> C55F` seam is now strong enough that future work should focus downstream rather than repeatedly reopening the type dispatch itself.


---

## Pass 37

# Chrono Trigger (USA) — Labels Added / Strengthened in Pass 37

This file contains labels newly added or materially strengthened in pass 37.

Status tags:
- **[strong]** = safe to carry forward unless contradicted by later control-flow proof
- **[provisional]** = useful working label, but still open to rename/refinement
- **[alias]** = intentional alias/stub label for a table entry landing in shared code or wrapper logic

## Bank-C1 local service dispatch labels

```text
C1:0003  ct_c1_local_service_dispatch_entry                     [strong]
         Entry veneer used by in-bank callers. Immediately jumps to C1:0045.

C1:0045  ct_c1_local_service_dispatch_body                      [strong]
         Saves A/X/Y, doubles selector A, dispatches through JSR ($0051,x),
         then restores registers and returns.

C1:0051  ct_c1_local_service_table                              [strong]
         Primary 8-entry local-service jump table.
         Proven entries:
           0 -> 0023
           1 -> 1B19
           2 -> 1BAA
           3 -> 106E
           4 -> 4058
           5 -> 2986
           6 -> 006D
           7 -> 1FDD
```

## Strengthened descriptor-trigger wrapper labels

```text
C1:C736  ct_c1_store_query_mode_to_986e_and_dispatch_service5   [strong]
         Stores descriptor byte0 (3D) into 986E and dispatches
         local service selector A=#05, which lands at C1:2986.

C1:C741  ct_c1_store_query_mode_to_99cc_and_dispatch_service7   [strong]
         Stores descriptor byte0 (3D) into 99CC and dispatches
         local service selector A=#07, which lands at C1:1FDD.
```

## Selector-7 dispatch labels

```text
C1:1FDD  ct_c1_service7_subdispatch_via_99cc                    [strong]
         Secondary submode dispatcher for local service #07.
         Uses 99CC as a 0..6 selector and dispatches via C1:1FEA.

C1:1FEA  ct_c1_service7_mode_table                              [strong]
         7-entry submode table for service #07.
         Proven entries:
           0 -> 25A3
           1 -> 2701
           2 -> 2701
           3 -> 23A4
           4 -> 25A3
           5 -> 23A4
           6 -> 2332

7E:99CC  ct_c1_service7_mode_99cc                               [strong]
         Submode selector register for local service #07.
```

## Selector-7 result-buffer lifecycle labels

```text
C1:27D9  ct_c1_clear_service7_result_vectors_99c0_a62d          [strong]
         Clears 99C0..99CB and A62D..A638 to FF.

C1:27E8  ct_c1_finalize_service7_results_and_mirror_to_a62d     [strong]
         Sets 960C to 80h and mirrors 99C0..99CA into A62D..A637.

7E:99C0  ct_c1_service7_result_slots_99c0                       [strong]
         Bounded result vector produced by service-7 query families.
         Uses FF as empty/terminator marker.

7E:A62D  ct_c1_service7_result_shadow_a62d                      [strong]
         Shadow/mirror vector for service-7 results.
         Cleared in lockstep with 99C0.. and refreshed from it by 27E8.

7E:960C  ct_c1_service7_result_finalize_flags_960c              [provisional]
         Service-7 result/finalization flag byte.
         27E8 stores 80h here before mirroring 99C0 -> A62D.
```

## Service-7 handler family labels

```text
C1:2332  ct_c1_service7_mode6_seeded_axis_window_scan           [provisional]
         Uses 9605 as seed slot, derives a simple +-20h window on one axis,
         scans qualifying slots, appends matches to 99C1+, and stores the
         seed slot in 99C0.

C1:23A4  ct_c1_service7_mode3_5_geometry_scan_family            [provisional]
         Loads multiple coordinates from 1D0C/1D23, orders local bounds,
         performs repeated geometry/math helper calls, and materializes
         qualifying slot indices into 99C0.. .

C1:25A3  ct_c1_service7_mode0_4_extended_spatial_metric_scan    [provisional]
         Consumes the wider 9605/9606/9607/9608 packet set,
         derives several local metrics, and materializes qualifying slot
         indices into 99C0.. .

C1:2701  ct_c1_service7_mode1_2_transformed_delta_threshold_scan [provisional]
         Normalizes coordinates, computes absolute deltas, maps them through
         CC:FB6F, combines the mapped deltas, and keeps candidates whose
         transformed metric compares favorably against 9607.
```

## Notes worth carrying forward
- Service selector #05 and service selector #07 are now cleanly separated.
- Service #05 remains the relation-query subsystem already established earlier.
- Service #07 is a separate candidate-list materialization family keyed by 99CC and fed by 9604..9608.
- Do not over-name the exact gameplay meaning of service-7 submodes yet.
- 99C0/A62D are now strong vector labels; they are not generic scratch anymore.


---

## Pass 38

# Chrono Trigger (USA) — Labels Added / Strengthened in Pass 38

This file contains labels newly added or materially strengthened in pass 38.

Status tags:
- **[strong]** = safe to carry forward unless contradicted by later control-flow proof
- **[provisional]** = useful working label, but still open to rename/refinement
- **[alias]** = intentional alias/stub label for a table entry landing in shared code or wrapper logic

## Strengthened service-7 packet-byte labels

```text
7E:9604  ct_c1_service7_candidate_partition_select              [strong]
         Service-7 partition selector.
         Proven behavior:
           00h -> scan slots 3..10
           !=00h -> scan slots 0..2

7E:9605  ct_c1_service7_primary_slot_param                      [strong]
         Primary service-7 slot parameter.
         Used as the seed slot in modes 6 and 1/2,
         and as the first anchor slot in modes 0/4.

7E:9606  ct_c1_service7_secondary_slot_param                    [provisional]
         Secondary service-7 slot/anchor parameter.
         Used directly by modes 0/4 as the second anchor / preserved slot.

7E:9607  ct_c1_service7_extent_threshold_param                  [strong]
         Generic service-7 extent/threshold parameter.
         Proven uses:
           - direct compare threshold in mode 1/2
           - scaled by *8 as construction magnitude in mode 0/4

7E:9608  ct_c1_service7_anchor_toggle_param                     [provisional]
         Mode-0/4 construction toggle.
         Switches one side of the dual-anchor geometry between
         the 9605-based and 9606-based anchor path.
```

## Strengthened service-7 handler labels

```text
C1:2332  ct_c1_service7_mode6_seeded_1d23_band_scan             [strong]
         Seeded half-open band scan using 1D23[seed] +/- 20h.
         Accepted matches are written to 99C1+ and the seed slot is stored in 99C0.

C1:23A4  ct_c1_service7_mode3_5_three_vertex_inclusion_scan     [strong]
         Three-vertex inclusion scan using coordinates from slots 0/1/2.
         Orders the three vertices, derives wrapped edge-angle sectors,
         and accepts candidates only if they pass all three sector tests.

C1:25A3  ct_c1_service7_mode0_4_dual_anchor_oriented_inclusion  [provisional]
         Dual-anchor oriented inclusion scan derived from the
         9605 -> 9606 direction, with extent (9607 * 8) and toggle 9608.
         Exact outward shape naming still needs one more proof pass.

C1:2701  ct_c1_service7_mode1_2_seeded_cell_radius_scan         [strong]
         Seeded radius scan in 16-unit cell space.
         Uses abs(dx)>>4 / abs(dy)>>4, maps both through the square table
         at CC:FB6F, and accepts iff dx^2 + dy^2 < 9607.
```

## Newly named shared-tail helpers

```text
C1:27AD  ct_c1_service7_optionally_preserve_slot92_by_partition [strong]
         Conditional seed-preserve tail.
         Stores slot 92 into 99C0 only if it belongs to the partition selected by 9604.

C1:27C5  ct_c1_service7_left_compact_results_if_slot0_empty     [strong]
         If 99C0 is still empty/negative, shifts 99C1+ left into 99C0+.
```

## Newly strengthened helper/data labels

```text
C1:011A  ct_c1_divide_a_by_16                                   [strong]
         Four LSR operations; used by mode 1/2 to normalize coordinates into cell space.

CC:FB6F  ct_cc_square_lookup_table                              [strong]
         Lookup table beginning 00,01,04,09,10,19... .
         Used by mode 1/2 as a square table for coarse-radius comparison.
```

## Notes worth carrying forward
- Service-7 is no longer just “spatial query family” in the abstract.
  The core geometric families are now materially pinned.
- `$9604` is now a strong service-7 partition selector, not just a generic packet byte.
- `23A4` is the strongest structural win of the pass: it is a real three-vertex inclusion test over fixed slots 0/1/2.
- `2701` is now firmly a squared-distance cell-radius scan, not merely a transformed delta compare.
- `25A3` still needs one more semantics pass for the cleanest human-readable shape name, but its dual-anchor oriented construction is now real.


---

## Pass 39

# Chrono Trigger (USA) — Labels Added / Strengthened in Pass 39

This file contains labels newly added or materially strengthened in pass 39.

Status tags:
- **[strong]** = safe to carry forward unless contradicted by later control-flow proof
- **[provisional]** = useful working label, but still open to rename/refinement
- **[alias]** = intentional alias/stub label for a table entry landing in shared code or wrapper logic

## New / strengthened code labels

```text
C1:1FF8  ct_c1_service7_wrapper_opcode_table                    [strong]
         33-entry outer wrapper table indexed by ($960D & 7Fh),
         clamped at 20h, then JSR'd through via abs,X indirect.

C1:203A  ct_c1_service7_bounded_eligible_collector             [strong]
         Shared collector body used by multiple wrapper-table entries.
         Caller supplies start/end range and optional whole-vector mirror.
         Preserves $960F specially into $99C0 and appends others into $99C1+.

C1:209A  ct_c1_service7_first3_eligible_collect_mirror_all     [strong]
         Wrapper variant of 203A.
         Scans slots 0..2 and enables whole-vector mirror via $960C.7.

C1:20A9  ct_c1_service7_late_partition_eligible_collect        [strong]
         Wrapper variant of 203A.
         Scans slots 3..10 without forcing whole-vector mirror.

C1:20B6  ct_c1_service7_late_partition_collect_mirror_all      [strong]
         Wrapper variant of 203A.
         Scans slots 3..10 and enables whole-vector mirror via $960C.7.

C1:20C6  ct_c1_service7_full_range_collect_mirror_all          [strong]
         Wrapper variant of 203A.
         Starts at slot 0, upper bound 11, and enables whole-vector mirror.

C1:20D6  ct_c1_service7_direct_passthrough_via_95d5            [strong]
         Direct scalar-result wrapper.
         Copies $95D5 into both $99C0 and $A62D.

C1:20E0  ct_c1_service7_first3_negative_flag_scan              [provisional]
         Fixed first-three-slot scan using sign bits from
         $5E4A/$5ECA/$5F4A under additional per-slot gates.

C1:2136  ct_c1_service7_first3_class5_selector                 [strong]
         First-three-slot selector for the first slot with $2980 == 05h.

C1:2163  ct_c1_service7_first3_class4_selector                 [strong]
         First-three-slot selector for the first slot with $2980 == 04h.

C1:2169  ct_c1_service7_rotated_dual_anchor_wrapper_toggle0    [provisional]
         Builds a later-partition candidate vector, optionally rotates
         the cursor, then preloads $9604..$9608 for 25A3 with $9608 = 0.

C1:21AF  ct_c1_service7_class3_anchor_dual_anchor_wrapper      [provisional]
         Uses the first first-three slot with $2980 == 03h as the
         primary anchor, then builds the 25A3 packet.

C1:2203  ct_c1_service7_rotated_dual_anchor_wrapper_toggle1    [provisional]
         Same broad structure as 2169, but preloads $9608 = 01h for 25A3.

C1:224B  ct_c1_service7_seed960f_radius16_wrapper              [strong]
         Direct packet wrapper for 2701.
         Uses $960F as seed slot and threshold 10h.

C1:225F  ct_c1_service7_rotated_seeded_radius_wrapper          [provisional]
         Builds a later-partition vector, optionally rotates the cursor,
         then seeds 2701 from $99C0[$9614] with threshold 09h or 19h.

C1:22A4  ct_c1_service7_class3_seeded_radius_wrapper           [provisional]
         Seeds 2701 from the first first-three slot with $2980 == 03h,
         with threshold 10h or 19h depending on wrapper opcode.

C1:22D3  ct_c1_service7_class6_seeded_radius19_wrapper         [strong]
         Seeds 2701 from the first first-three slot with $2980 == 06h,
         using threshold 19h.

C1:22F5  ct_c1_service7_rotated_seeded_band_wrapper            [provisional]
         Builds a later-partition vector, optionally rotates the cursor,
         then seeds 2332 from $99C0[$9614].

C1:232A  ct_c1_service7_direct_triangle_wrapper                [provisional]
         Direct wrapper for 23A4:
         STZ $9604 ; JSR $23A4 ; JMP $27E8.
         Real code, but not yet proven to be a 1FF8 table entry.

C1:27FA  ct_c1_service7_result_cursor_next_live                [strong]
         Advances $9614 to the next non-negative $99C0 entry with wraparound.

C1:2814  ct_c1_service7_result_cursor_prev_live                [strong]
         Moves $9614 to the previous non-negative $99C0 entry with wraparound.

C1:282D  ct_c1_service7_result_vector_any_live                 [strong]
         Returns Z set if all entries in $99C0..$99CA are FFh/negative,
         otherwise returns Z clear.
```

## New / strengthened WRAM / state labels

```text
7E:960A  ct_c1_service7_query_epoch_or_scan_counter            [provisional]
         Incremented by the bounded collector and several scalar wrappers.
         Explicitly cleared before cursor-rotation-driven wrapper reuse.

7E:960C  ct_c1_service7_result_vector_mirror_flags             [provisional]
         Sign/bit7 controls whole-vector mirror behavior in the shared
         collector, and 27E8 also sets it before mirroring 99C0.. -> A62D...

7E:960D  ct_c1_service7_wrapper_opcode                         [strong]
         Low 7 bits index the 33-entry wrapper opcode table at C1:1FF8.

7E:960F  ct_c1_service7_preferred_seed_slot                    [provisional]
         Preferred/seed slot used by the common collector and by several
         geometry-packet wrappers.

7E:9613  ct_c1_service7_first_live_result_or_fail_marker       [provisional]
         Outer wrapper tail caches the first non-negative mirrored result
         from A62D.. here, or leaves a negative marker when no result exists.

7E:9614  ct_c1_service7_result_cursor_index                    [strong]
         Cursor index over the live service-7 result vector.
         Rotated by 27FA / 2814.

7E:2980  ct_c1_slot_class_or_discriminator                     [provisional]
         Slot discriminator byte searched explicitly for values
         03h, 04h, 05h, and 06h by wrapper-layer selectors.
```

## Opcode-table aliases worth carrying forward

```text
wrapper opcode 00 -> ct_c1_service7_bounded_eligible_collector                [alias]
wrapper opcode 01 -> ct_c1_service7_first3_eligible_collect_mirror_all        [alias]
wrapper opcode 02 -> ct_c1_service7_direct_passthrough_via_95d5               [alias]
wrapper opcode 03 -> ct_c1_service7_first3_negative_flag_scan                 [alias]
wrapper opcode 04 -> ct_c1_service7_first3_eligible_collect_mirror_all        [alias]
wrapper opcode 05 -> ct_c1_service7_first3_class5_selector                    [alias]
wrapper opcode 06 -> ct_c1_service7_first3_class4_selector                    [alias]
wrapper opcode 07 -> ct_c1_service7_late_partition_eligible_collect           [alias]
wrapper opcode 08 -> ct_c1_service7_late_partition_collect_mirror_all         [alias]
wrapper opcode 09 -> ct_c1_service7_full_range_collect_mirror_all             [alias]
wrapper opcode 0A -> ct_c1_service7_late_partition_collect_mirror_all         [alias]
wrapper opcode 0B -> ct_c1_service7_rotated_dual_anchor_wrapper_toggle0       [alias]
wrapper opcode 0C -> ct_c1_service7_rotated_dual_anchor_wrapper_toggle1       [alias]
wrapper opcode 0D -> ct_c1_service7_class3_anchor_dual_anchor_wrapper         [alias]
wrapper opcode 0E -> ct_c1_service7_bounded_eligible_collector                [alias]
wrapper opcode 0F -> ct_c1_service7_rotated_seeded_band_wrapper               [alias]
wrapper opcode 10 -> ct_c1_service7_bounded_eligible_collector                [alias]
wrapper opcode 11 -> ct_c1_service7_seed960f_radius16_wrapper                 [alias]
wrapper opcode 12 -> ct_c1_service7_rotated_seeded_radius_wrapper             [alias]
wrapper opcode 13 -> ct_c1_service7_class3_seeded_radius_wrapper              [alias]
wrapper opcode 14 -> ct_c1_service7_class3_seeded_radius_wrapper              [alias]
wrapper opcode 15 -> ct_c1_service7_bounded_eligible_collector                [alias]
wrapper opcode 16 -> ct_c1_service7_bounded_eligible_collector                [alias]
wrapper opcode 17 -> ct_c1_service7_bounded_eligible_collector                [alias]
wrapper opcode 18 -> ct_c1_service7_wrapper_noop_rts_2329                     [alias]
wrapper opcode 19 -> ct_c1_service7_bounded_eligible_collector                [alias]
wrapper opcode 1A -> ct_c1_service7_rotated_seeded_radius_wrapper             [alias]
wrapper opcode 1B -> ct_c1_service7_class6_seeded_radius19_wrapper            [alias]
wrapper opcode 1C -> ct_c1_service7_bounded_eligible_collector                [alias]
wrapper opcode 1D -> ct_c1_service7_bounded_eligible_collector                [alias]
wrapper opcode 1E -> ct_c1_service7_bounded_eligible_collector                [alias]
wrapper opcode 1F -> ct_c1_service7_bounded_eligible_collector                [alias]
wrapper opcode 20 -> ct_c1_service7_bounded_eligible_collector                [alias]
```

## Notes worth carrying forward
- The service-7 bodies themselves are no longer the main ambiguity; the wrapper opcode layer is now mostly classified.
- `$9614` is now a real result cursor, not disposable scratch.
- `$960C.7` is materially tied to whole-vector mirror/valid behavior.
- `$2980` has crossed the threshold from “unknown byte” to “real slot discriminator/class field,” even though the human-facing names for its values are still open.
- The best next move is above this layer: trace who preloads `$960D`, `$960F`, `$9614`, and `$EF`.


---

## Pass 40

# Chrono Trigger (USA) — Labels Added / Strengthened in Pass 40

This file contains labels newly added or materially strengthened in pass 40.

Status tags:
- **[strong]** = safe to carry forward unless contradicted by later control-flow proof
- **[provisional]** = useful working label, but still open to rename/refinement
- **[alias]** = intentional alias/stub label for wrapper or branch-entry landing in shared logic

## New / strengthened code labels

```text
C1:1153  ct_c1_service7_outer_current_slot_controller                    [strong]
         Top local controller above service 7.
         Branches between fresh-launch, replay/finalize, and follow-up families.

C1:129C  ct_c1_service7_state0_fixed_wrapper07_launch                    [strong]
         Local state-0 launch branch.
         Writes $960D = 07h, clears $9615, then launches through $1F79.

C1:12BC  ct_c1_service7_state1_followup_setup                            [strong]
         Local state-1 deferred follow-up setup.
         Seeds $95DB = 1 and $9615 = 1; does not call $1F79 directly.

C1:12ED  ct_c1_service7_state2_followup_setup                            [strong]
         Local state-2 deferred follow-up setup.
         Seeds $95DB = 2 and $9615 = 2; does not call $1F79 directly.

C1:1369  ct_c1_service7_dynamic_opcode_launch_from_9ee4                 [strong]
         Follow-up family that gates on $A099/$9EE5 and writes $960D from $9EE4.

C1:1498  ct_c1_service7_table_driven_entry_launch                        [strong]
         Follow-up family that computes 5*($95E6 + $95E5), reads entry fields
         rooted at C1:1580, latches aux/opcode into $9F35/$960D, and launches.

C1:1561  ct_c1_service7_replay_finalize_controller                       [strong]
         Shared replay/finalize path entered when $9609 != 0 or after a
         successful fresh wrapper launch.

C1:176C  ct_c1_service7_outer_cursor_next_commit                         [strong]
         Outer controller helper that advances $9614 to the next live $99C0 entry,
         exports it to $A62D, then returns through common cleanup.

C1:1786  ct_c1_service7_outer_cursor_prev_commit                         [strong]
         Outer controller helper that moves $9614 to the previous live $99C0 entry,
         exports it to $A62D, then returns through common cleanup.

C1:179C  ct_c1_service7_outer_option_cleanup                             [strong]
         Common cleanup tail for the outer controller.
         Clears DP option bytes $EE and $EF, then returns.

C1:1F79  ct_c1_service7_common_launch_init                               [strong]
         Common launch initializer above the wrapper-opcode table.
         Injects current slot into $960F, clears result state, and dispatches via $1FF8.
```

## New / strengthened data / state labels

```text
7E:9609  ct_c1_service7_replay_phase_counter                             [strong]
         Outer in-progress / replay counter for the service-7 controller.
         Fresh launches increment it; replay/finalize paths decrement it.

7E:960F  ct_c1_service7_preferred_source_slot                            [strong]
         Current/preferred source slot for the next wrapper launch.
         Written by $1F79 from $95D5.

7E:95DB  ct_c1_service7_followup_family                                  [strong]
         Outer follow-up family selector.
         Observed values: 0 = local/plain, 1 = dynamic-opcode family,
         2 = table-driven family.

7E:95DC  ct_c1_service7_local_submode_per_slot                           [strong]
         Per-slot 3-state local query/selection submode index.
         Values cycle 0..2 and choose the 129C / 12BC / 12ED branches.

7E:95E5  ct_c1_service7_outer_index_component_lo                         [provisional]
         Outer cursor/index component clamped through a 0..2 band.
         Participates in the summed table-entry index used by 1498.

7E:95E6  ct_c1_service7_outer_index_component_hi                         [provisional]
         Outer cursor/index component adjusted in ±1 and ±3 steps.
         Participates in the summed table-entry index used by 1498.

7E:9615  ct_c1_service7_launch_family_tag                                [provisional]
         Outer launch-family tag carried into emitted record field 93F0.
         Observed values in this controller: 0, 1, 2.

7E:9F35  ct_c1_service7_table_entry_aux_byte                             [strong]
         Latched auxiliary payload byte from the selected 5-byte launch entry.

7E:9F36  ct_c1_service7_table_entry_offset                               [strong]
         Saved byte offset of the selected 5-byte launch entry rooted at C1:1580.

DP:EE    ct_c1_service7_outer_option_flags_a                             [provisional]
         Caller-provided outer option byte consumed by the current-slot controller
         and the replay/finalize path. Producers still unresolved.

DP:EF    ct_c1_service7_outer_option_flags_b                             [provisional]
         Caller-provided outer option byte spanning both local-state branches
         and result-cursor rotation. Producers still unresolved.
```

## New / strengthened inline-table labels

```text
C1:1580  ct_c1_service7_table_launch_entry_bytes                         [provisional]
         Root of the 5-byte entry table consumed by the table-driven launch family.
         Entry index = 5 * ($95E6 + $95E5).

entry +0 -> auxiliary payload latched into $9F35                         [strong]
entry +1 -> wrapper opcode latched into $960D                            [strong]
entry +2 -> sign/validity gate (BMI = reject)                            [strong]
entry +3 -> remaining-count / enabled gate (BEQ = reject)                [strong]
entry +4 -> unresolved                                                   [provisional]
```

## Notes worth carrying forward
- The outer controller above service 7 is now meaningfully classified; the ambiguity has moved downstream into the emitted `93EE..93F4` records and upstream into the producers of `EE/$EF`.
- `$960F` is no longer vague: it is the current/preferred source slot injected by the common launch initializer.
- `$9609` is now clearly a replay/follow-up counter, not scratch.
- The `1498` family proved that `$95E5/$95E6` are real index components and that the bytes rooted at `1580` are a deliberate 5-byte entry table, even though that table overlaps code bytes structurally.
- Best next move: decode the `16DA..1713` record sink and then trace its consumers.


---

## Pass 41

# Chrono Trigger (USA) — Labels Added / Strengthened in Pass 41

This file contains labels newly added or materially strengthened in pass 41.

Status tags:
- **[strong]** = safe to carry forward unless contradicted by later control-flow proof
- **[provisional]** = useful working label, but still open to rename/refinement
- **[alias]** = intentional alias/stub label for wrapper or branch-entry landing in shared logic

## New / strengthened code labels

```text
C1:16DA  ct_c1_service7_emit_record_and_enqueue_pending_slot             [strong]
         Shared sink reached after a successful outer service-7 path.
         Appends current slot into the small pending FIFO at 99D4..99D8,
         then remaps that slot through CC:FAF0 and emits per-record metadata
         into the larger table rooted at 93EE.

C1:1750  ct_c1_service7_ring_unlink_slot_clear_record_active_bit         [strong]
         Removes a slot from the 3-entry A6D9 ring and clears bit 7 in the
         corresponding emitted record status byte at 93EE + record_offset.

C1:1B17  ct_c1_service7_ring_link_slot_set_record_active_bit             [strong]
         Links a slot through the A6D9 ring and sets bit 7 in the matching
         emitted record status byte at 93EE + record_offset.

C1:B6D1  ct_c1_service7_release_record_table_reservation                 [strong]
         Uses record index * 7 to reach 93EF/93F4, clears the reservation
         latch in 93EF.bit6, and refunds one unit to entry+3 in the 5-byte
         launch table at 1580 when 93F4 matches entry+0.

C1:B96A  ct_c1_service7_consume_canonical_record_pending_and_dispatch    [strong]
         Checks the three canonical fixed records rooted at 93EE / 93F5 /
         93FC, consumes the first pending status bit (bit 6), then dispatches
         on the packed category pair from 93F3 + 7*record_index.

C1:8590  ct_c1_service7_pending_slot_fifo_pop_front                      [strong]
         Pops the front entry from the small pending-slot FIFO:
         99D4 -> out, 99D5 -> 99D4, 99D6 -> 99D5, FF -> 99D6, DEC 99D8.
```

## New / strengthened data / state labels

```text
7E:99D4  ct_c1_service7_pending_slot_fifo                                [strong]
         Root of the 3-entry visible pending-slot FIFO maintained by the
         outer sink and consumed by the pop/shift logic at 8590.

7E:99D8  ct_c1_service7_pending_slot_count                               [strong]
         Pending-slot count / append index for the FIFO at 99D4..99D6.
         Used as the write index by 16DA and decremented by the pop path.

CC:FAF0  ct_c1_service7_slot_to_record_offset_map                        [strong]
         Lookup map translating current slot IDs into record offsets for the
         emitted metadata table rooted at 93EE.

7E:93EE  ct_c1_service7_record_status_flags                              [strong]
         Status byte of emitted records.
         bit 6 = pending/consumable record flag
         bit 7 = linked/active ring marker tied to A6D9 membership

7E:93EF  ct_c1_service7_record_aux_flags_and_reservation                 [strong]
         Emitted record aux/option byte.
         Low bits come from per-slot byte 9F38[x]; bit 6 is a reservation/
         consumption latch tied to the 5-byte launch table refund path.

7E:93F0  ct_c1_service7_record_launch_family_tag                         [strong]
         Emitted launch-family tag copied from 9615 into the per-record table.

7E:93F1  ct_c1_service7_record_primary_result_slot                       [strong]
         Emitted primary result slot copied from A62D into the per-record table.

7E:93F3  ct_c1_service7_record_category_pair                             [strong]
         Packed pair of downstream dispatch categories in low/high 4-bit nibbles.
         Consumed by B580 and B96A-family logic.

7E:93F4  ct_c1_service7_record_table_entry_token                         [strong]
         Record-side copy of the 5-byte launch-table entry+0 token.
         Used later by B6D1 to locate the source table record and refund entry+3.

7E:9F38  ct_c1_service7_slot_aux_flags_for_emitted_records               [provisional]
         Per-slot aux/option byte copied into emitted record field 93EF.
         Structural role is strong; exact human-facing semantics remain open.
```

## New / strengthened record-layout notes

```text
first canonical fixed record  -> 93EE .. 93F4                              [strong]
second canonical fixed record -> 93F5 .. 93FB                              [strong]
third canonical fixed record  -> 93FC .. 9402                              [strong]

These three fixed records are the canonical trio checked by the B96A dispatcher.
They coexist with a broader record-offset space addressed through CC:FAF0.
```

## Notes worth carrying forward
- The `16DA` sink is now proven to be two coordinated write systems: a small pending-slot FIFO and a broader emitted-record table.
- `93EE.bit6` and `93EE.bit7` now have distinct, real meanings; they are not generic flag clutter.
- `93EF.bit6` is a different latch entirely, tied to refunding counts in the 5-byte launch-entry table.
- `93F3` is now structurally solved as a nibble pair even though the nibble-value meanings still need one more pass.
- Best next move: trace the producers of 9F38[x] and the downstream category-dispatch consumers behind the B96A path.


---

## Pass 42

# Chrono Trigger Disassembly Labels — Pass 42

This file contains labels newly added or materially strengthened in pass 42.

As in prior passes:
- **strong** = control flow and data role are directly supported by the ROM work in this pass
- **provisional** = structurally useful but still not safe as a final gameplay-facing name

---

## Strong labels

### C1:B575  ct_c1_service7_reconcile_canonical_record_lane_pairs          [strong]
- Initializes `B3EB..B3F3` to `FF`, seeds root lane IDs `0/1/2`,
  then reads the packed category bytes from `93F3 / 93FA / 9401`
  and reconciles them into lane-family scratch arrays plus the
  final enabled-lane mask in `B3E7..B3E9`.
- This is the concrete front-end of the downstream `93F3` family.

### 7E:B3E7  ct_c1_service7_enabled_lane0_flag                            [strong]
### 7E:B3E8  ct_c1_service7_enabled_lane1_flag                            [strong]
### 7E:B3E9  ct_c1_service7_enabled_lane2_flag                            [strong]
- Final enabled-lane flags derived from the canonical trio’s lane-ID pairs
  plus the lane-block eligibility test at `FD:A8A5`.

### FD:A8A5  ct_fd_service7_lane_block_is_eligible                        [strong]
- Tests one of three `0x80`-spaced WRAM lane blocks selected by lane ID
  `0/1/2`.
- Uses:
  - `5E4A + lane*0x80`, bit 7
  - `5E4E + lane*0x80` OR `5E53 + lane*0x80`, bit 7
  - `5E4B + lane*0x80`, bits `7/2/1` (`#86`)
- Sets `B3EA = 1` on any qualifying hit.

### 7E:B3EA  ct_fd_service7_lane_eligibility_hit                          [strong]
- Scratch result written by `FD:A8A5`.
- Nonzero means the currently tested lane family has a qualifying lane block.

### FD:A93C  ct_fd_service7_dispatch_enabled_lane_clear_phase            [strong]
- Iterates enabled lanes in `B3E7..B3E9`.
- Calls `FD:A8CE` for each enabled lane.

### FD:A8CE  ct_fd_service7_clear_canonical_record_lane                  [strong]
- Computes `X = lane * 7`.
- Clears canonical fixed-record fields:
  - `93EE + X`
  - `93EF + X`
  - `93F3 + X = FF`
- Then resets matching lane-carried state via `B158/AFAB/99DD/9F22/B188/B03A`.

### FD:A95F  ct_fd_service7_dispatch_enabled_lane_refresh_phase          [strong]
- Iterates enabled lanes in `B3E7..B3E9`.
- Calls `FD:A8FE` for each enabled lane.

### FD:A8FE  ct_fd_service7_clear_occupied_lane_and_refresh_service2     [strong]
- Checks `B188[lane]`.
- If the lane is marked/occupied, performs the same canonical-record clear
  and lane-state reset as `FD:A8CE`, then invokes `C1:B961`.

### C1:B961  ct_c1_local_service2_wrapper                                [strong]
- Exact wrapper:
  - `LDA #$02`
  - `JSR $0003`
  - `RTL`
- Invokes local service 2 through the bank-C1 dispatcher.

---

## Strengthened existing labels

### 7E:93F3  ct_c1_service7_record_lane_pair                             [strong]
- Stronger than pass 41.
- The packed byte is no longer just “small dispatch categories.”
- It is now best read as a packed pair of **lane IDs** for the canonical
  fixed records, with observed values:
  - `0`
  - `1`
  - `2`
  - `F` = none / disabled

### 7E:93EE  ct_c1_service7_record_status_flags                           [strong]
- Strengthened by `FD:A8CE` / `FD:A8FE`, which explicitly clear this field
  when a canonical record lane is reset.

### 7E:93EF  ct_c1_service7_record_aux_flags                              [strong]
- Strengthened by `FD:A8CE` / `FD:A8FE`, which explicitly clear this field
  when a canonical record lane is reset.

---

## Provisional labels

### 7E:B158  ct_c1_service7_lane_carried_value                            [provisional]
- Copied into `AFAB`, `99DD`, and `9F22` during lane clear/reset.
- Structural role is real; gameplay-facing meaning is still unresolved.

### 7E:B188  ct_c1_service7_lane_occupied_or_latched_flag                 [provisional]
- Gates the extra refresh path in `FD:A8FE`.
- Strongly looks like a lane-occupied / lane-latched byte, but still needs
  a cleaner subsystem-level proof.

### 7E:AFAB  ct_c1_service7_lane_shadow_value_0                           [provisional]
### 7E:99DD  ct_c1_service7_lane_shadow_value_1                           [provisional]
### 7E:9F22  ct_c1_service7_lane_shadow_value_2                           [provisional]
- Three destinations that receive `B158[lane]` during lane clear/reset.
- Their exact downstream semantics are still open.

### 7E:B03A  ct_c1_service7_lane_aux_reset_field                          [provisional]
- Cleared during both lane-reset helpers.
- Real reset role is proven; human-facing meaning is still open.

### 7E:9F38  ct_c1_service7_slot_aux_flags_for_emitted_records            [provisional]
- Carried forward from pass 41.
- Still a valid sink-side label because its low bits feed `93EF` on emit,
  but pass 42 did not pin a trustworthy producer path.

---

## Notes
- Pass 42 materially tightened the downstream `93F3` family: the nibble
  values now look like **lane IDs `0/1/2` plus `F = none`**, not arbitrary
  tiny dispatch values.
- The main unresolved seam has shifted again:
  1. service 2 in the contexts reached from `FD:A8FE`
  2. the carried-state bytes `B158/B188/AFAB/99DD/9F22/B03A`
  3. the upstream producer path for `9F38[x]`


---

## Pass 43

# Chrono Trigger Disassembly Labels — Pass 43

This file contains labels newly added or materially strengthened in pass 43.

As in prior passes:
- **strong** = control flow and data role are directly supported by the ROM work in this pass
- **provisional** = structurally useful but still not safe as a final gameplay-facing name

---

## Strong labels

### C1:1B19  ct_c1_service1_enqueue_lane_and_mark_record_active           [strong]
- Local service-1 entry for the 3-lane controller.
- If the current lane is not already active in `A6D9[x]`, maps it through `CC:FAF0`,
  sets `93EE.bit7` for the matching emitted record, appends the lane into
  `95D6 + pending_count`, seeds `95DC[current_lane]`, and increments `95DA`.

### C1:1B69  ct_c1_promote_pending_lane_into_active_roster               [strong]
- Pulls the head of the pending lane queue at `95D6` into the active roster.
- Clears `9F38[lane]`, seeds small per-lane state bytes, stores the lane into
  `A6D9[lane]`, compacts `95D6..95D8`, decrements `95DA`, increments `A6DE`,
  and seeds `A6DD` if no current active lane exists.

### C1:1BAA  ct_c1_service2_remove_lane_and_reseat_active_controller      [strong]
- Local service-2 entry for the same 3-lane controller.
- Deletes the input lane from either:
  - the pending-admission queue (`95D6..95D8`), or
  - the active roster (`A6D9` / `A6DE`)
- If the removed lane was the current active lane (`A6DD`), also clears/reseats
  outer selection state (`9609 / 960E / 9614 / 95DB / 99E0`), rescans the next
  live active lane, updates `A6DD` and `95D5`, then falls through to `1C3A`.

### C1:1C3A  ct_c1_service2_restore_workspace_template_0b40              [strong]
- Common tail reached from service 2.
- Copies `0x180` bytes from `D1:5800` into WRAM rooted at `0B40`.
- Exact high-level meaning of the workspace is still open, but the template-restore
  role is direct ROM proof.

### 7E:A6D9  ct_c1_active_lane_roster_marker_per_lane                    [strong]
- Three-entry per-lane active-roster membership marker.
- `FF` = absent/inactive.
- Nonnegative = lane is present in the local active controller.

### 7E:A6DD  ct_c1_current_active_lane                                   [strong]
- Current active lane for the local 3-lane controller.
- Reseated by service 2 when the current lane is removed.

### 7E:A6DE  ct_c1_active_lane_count                                     [strong]
- Active-lane count for the local 3-lane controller.
- Incremented when a pending lane is promoted; decremented when an active lane is removed.

### 7E:95D6  ct_c1_pending_lane_admission_queue                          [strong]
- Root of the 3-entry pending-admission queue consumed by `1B69` and compacted by `1BAA`.

### 7E:95DA  ct_c1_pending_lane_admission_count                          [strong]
- Pending queue count / append index for `95D6..95D8`.

### 7E:B188  ct_c1_lane_occupied_refresh_latch                           [strong]
- Per-lane occupied/refresh-required latch.
- Directly gates whether the lane-clear path at `FD:A8FE` escalates into local service 2.

---

## Provisional labels

### 7E:A6DF  ct_c1_lane_roster_change_sentinel                           [provisional]
- Forced to `FEh` in both the pending->active promotion path and the active-lane removal path.
- Structurally real, but exact downstream meaning still needs more proof.

### 7E:B158  ct_c1_lane_primary_carried_value                            [provisional]
- Per-lane carried scalar maintained beside the canonical-record lane system.
- Mirrored into `AFAB`, and exported to `99DD` / `9F22` in the clear/update families.

### 7E:AFAB  ct_c1_lane_primary_carried_value_shadow                     [provisional]
- Per-lane shadow/mirror of `B158`.

### 7E:99DD  ct_c1_lane_primary_value_export_a                           [provisional]
- Export mirror updated from the same lane-carried value family as `B158/AFAB`.

### 7E:9F22  ct_c1_lane_primary_value_export_b                           [provisional]
- Second export mirror updated from the same lane-carried value family as `B158/AFAB`.

### 7E:B03A  ct_c1_lane_secondary_dirty_latch                            [provisional]
- Secondary per-lane latch cleared beside `B188` in the lane-reset families.
- Structurally part of the same carried-state bundle, but exact semantics remain open.

### 7E:9F38  ct_c1_lane_emitted_aux_or_mask                              [provisional]
- Lane-side aux bits ORed into emitted record aux state at `93EF + record_offset`.
- Only the clear path is directly proved this pass; the positive writer is still unresolved.

---

## Strengthened existing labels

### FD:A8FE  ct_fd_service7_clear_occupied_lane_and_refresh_service2     [strong]
- Strengthened by pass 43.
- The “refresh service 2” half is now specifically understood as callback into the
  local 3-lane roster-removal/reseat controller at `C1:1BAA`.

### C1:B961  ct_c1_local_service2_wrapper                                [strong]
- Strengthened by pass 43.
- Exact wrapper into the lane-roster removal/reseat service.



---

## Pass 44

# Chrono Trigger Disassembly Labels — Pass 44

This file contains labels newly added or materially strengthened in pass 44.

As in prior passes:
- **strong** = control flow and data role are directly supported by the ROM work in this pass
- **provisional** = structurally useful but still not safe as a final gameplay-facing name

---

## Strong labels

### 7E:0B40 / 00:0B40  ct_c1_tilemap_staging_buffer_vram7a00_0180        [strong]
- `0x180`-byte WRAM staging buffer.
- Written from ROM templates at `D1:5800`, `D1:5A50`, and `D1:5BD0`.
- Uploaded by DMA from the low-bank WRAM mirror `00:0B40` to VRAM address `7A00`
  when `99E2` is nonzero.

### 7E:99E2  ct_c1_tilemap_upload_pending_counter                         [strong]
- Dirty/request latch (or small counter) for the `0B40 -> VRAM 7A00` upload.
- Multiple bank-`C1` paths `INC` it after rewriting `0B40`.
- `CF:E380` checks it, performs the DMA upload, then clears it.

### CF:E380  ct_cf_upload_pending_tilemap_0b40_to_vram_7a00             [strong]
- Cross-bank sink for the `0B40` render buffer.
- If `99E2 != 0`, configures DMA to upload `0x0180` bytes from `00:0B40`
  to VRAM address `7A00`, then clears `99E2`.

### D1:5800  ct_d1_tilemap_template_default_0b40_0180                   [strong]
- Default/reset ROM template copied into `0B40` by `C1:1C3A`.
- Same size as the upload buffer and structurally part of the same tilemap-template family.

### D1:5A50  ct_d1_tilemap_template_alt_a_0b40_0180                     [strong]
- Alternate ROM template variant copied into `0B40` by the `0EA1..0EB1` path.
- Followed by `INC $99E2`, proving it feeds the same upload path as the default template.

### D1:5BD0  ct_d1_tilemap_template_alt_b_0b40_0180                     [strong]
- Alternate ROM template variant copied into `0B40` by the `1301..1315`,
  `1594..15A9`, and `15B5..15C5` paths.
- Followed by `INC $99E2`, proving it feeds the same upload path as the default template.

---

## Strengthened existing labels

### C1:1C3A  ct_c1_service2_restore_default_tilemap_template_0b40       [strong]
- Strengthened from pass 43.
- No longer just “restore workspace template.”
- Specifically restores the default `0x180`-byte tilemap/upload template from `D1:5800`
  into `0B40`, the staging buffer later DMA-uploaded to VRAM `7A00`.

---

## Provisional labels

### 7E:0B40  ct_c1_panel_or_screen_tilemap_buffer                        [provisional]
- Human-facing interpretation of the same `0B40` staging buffer.
- The tilemap/upload role is now strong.
- The exact panel/menu/screen name is still unresolved.

### D1:5800 / D1:5A50 / D1:5BD0  ct_d1_tilemap_template_family_16x12_words [provisional]
- The three source blocks are best interpreted as a 192-word (likely 16x12) template family.
- This matrix interpretation fits both the dense row-structured data and the fixed-size VRAM upload,
  but the exact UI vocabulary is still open.

---

## Still intentionally unresolved

### 7E:9F38  ct_c1_lane_emitted_aux_or_mask                              [provisional, unchanged]
- Re-checked during pass 44.
- The newly solved `0B40` upload path did not expose a trustworthy positive writer.
- Clear/consume behavior remains real; positive producer remains unresolved.


---

## Pass 45

# Chrono Trigger Disassembly Labels — Pass 45

This file contains labels newly added or materially corrected in pass 45.

As in prior passes:
- **strong** = directly supported by control flow and data role in the ROM work of this pass
- **provisional** = structurally useful but still not safe as a final gameplay-facing name

---

## Strong labels

### C1:07FD  ct_c1_compose_three_slot_panel_strip_into_0b40              [strong]
- Checks the three active-roster entries `A6D9 / A6DA / A6DB`.
- For each occupied entry, calls `C1:0929` with one of three horizontal destination positions
  inside `0B40`.
- Chooses merged/non-merged placement by shifting the second and third segment left by one
  word when the preceding slot is absent.
- Strongest safe reading: composes a 3-position horizontal panel strip in the `0B40` tilemap buffer.

### C1:0929  ct_c1_blit_6row_panel_segment_into_0b40_merge_left_border    [strong]
- Dynamic `0B40` patcher using source data from `D1:59FC`.
- Writes 6 rows with a destination stride of `0x40` bytes per row.
- Copies either:
  - 7 words per row (full segment), or
  - 6 words per row after skipping the first source word (merge mode)
- Strongest safe reading: blits a 6-row panel segment into `0B40`, optionally omitting
  the left border so adjoining segments share a border.

### D1:59FC  ct_d1_panel_segment_template_6x7_words                       [strong]
- Unique ROM source table used by `C1:0929`.
- Resolves cleanly as 6 rows of 7 words.
- Tile values form a compact border/interior segment template rather than logic data.

### 7E:0B40 / 00:0B40  ct_c1_tilemap_strip_buffer_32x6_words_vram7a00     [strong]
- Corrected from pass 44’s provisional geometry.
- The proven row stride from `C1:0929` is `0x40` bytes, yielding a 32-word by 6-row layout
  for the `0x0180`-byte uploaded strip.

### D1:5800 / D1:5A50 / D1:5BD0  ct_d1_base_strip_template_family_32x6     [strong]
- Corrected geometrically in this pass.
- All three `0x0180`-byte base templates are best modeled as 32-word by 6-row strip layouts.
- Used as the base tilemap copied into `0B40` before dynamic patching and upload.

---

## Strengthened / corrected labels

### 7E:0B40  ct_c1_panel_or_screen_tilemap_buffer                         [provisional -> corrected context]
- Still not given a final human-facing UI name.
- But now known much more concretely as a 32x6 strip buffer with dynamic three-slot panel composition.

### D1:5800 / D1:5A50 / D1:5BD0  ct_d1_tilemap_template_family_16x12_words [withdrawn]
- Pass 45 corrects this earlier provisional geometry.
- The safer keepable geometry is `32x6`, not `16x12`.

---

## Provisional labels

### D1:5800 / D1:5A50 / D1:5BD0  ct_d1_alt_base_strip_layout_family        [provisional]
- The three templates are clearly alternate base layouts within the same 32x6 strip region.
- Exact gameplay/UI mode names are still unresolved.

### 7E:0B40  ct_c1_lane_roster_strip_tilemap_buffer                        [provisional]
- Supported by the strong link from `C1:07FD` to the active-roster state.
- Kept provisional because the final gameplay-facing subsystem name is still open.

---

## Still intentionally unresolved

### 7E:9F38  ct_c1_lane_emitted_aux_or_mask                               [provisional, unchanged]
- Re-checked again during pass 45.
- The newly solved `07FD / 0929 / 59FC` layer did not expose a trustworthy positive writer.
- Clear/consume behavior remains real; positive producer remains unresolved.


---

## Pass 46

# Chrono Trigger Disassembly Labels — Pass 46

This file contains labels newly added, corrected, or materially strengthened in pass 46.

As in prior passes:
- **strong** = directly supported by control flow and data role in the ROM work of this pass
- **provisional** = structurally useful but still not safe as a final gameplay-facing name

---

## Strong labels

### C1:081F  ct_c1_compose_three_slot_panel_strip_into_0b40              [strong]
- Corrected entry boundary for the pass-45 panel-strip composer.
- Begins with `STZ $84`, checks `A6D9/A6DA/A6DB`, selects destination offsets in `$82`,
  and repeatedly calls `C1:0929`.
- This is the actual `0B40` three-slot strip composer entry.

### C1:07BD  ct_c1_blit_companion_strip_template_a_into_0cc0_pair29      [strong]
- Outer loop = 6 rows.
- Inner loop = 7 source bytes per row.
- Reads from `CC:FA41`.
- Writes source byte to `0CC0+Y`, then constant `0x29` to `0CC1+Y`.
- Row stride = `0x40` bytes.

### C1:07EE  ct_c1_blit_companion_strip_template_b_into_0cc0_pair29      [strong]
- Same loop shape as `C1:07BD`.
- Reads from `CC:FA6B` instead of `CC:FA41`.
- Writes the same paired-byte pattern into the `0CC0` family.

### CC:FA41  ct_cc_companion_strip_template_a_6x7_bytes                  [strong]
- Compact ROM byte template consumed only by `C1:07BD` in this pass.
- Structurally matches the proven `6-row x 7-byte` loop.

### CC:FA6B  ct_cc_companion_strip_template_b_6x7_bytes                  [strong]
- Compact ROM byte template consumed only by `C1:07EE` in this pass.
- Structurally matches the proven `6-row x 7-byte` loop.

### 7E:0CC0..7E:0E08  ct_c1_companion_paired_byte_strip_buffer           [strong]
- Built with row stride `0x40`.
- Written as alternating byte pairs rather than tilemap words.
- Slice-local clear/update paths exist at `C1:086D` and `C1:08E8`.
- Strongest safe reading: a narrow companion strip buffer rebuilt alongside `0B40`.

### C1:086D  ct_c1_clear_current_companion_strip_slice_0cc0              [strong]
- Uses `95D5` to select a local slice.
- Clears two adjacent columns across six rows inside the `0CC0` companion strip family.
- Strongest safe reading: clear the current slice in the paired-byte companion strip.

### C1:08E8  ct_c1_update_current_companion_strip_slice                  [strong]
- Writes back into the same `0CC0 / 0D00` companion-strip family after slice clear.
- Uses selector tables rooted at `CC:FA23`, `CC:FA29`, and `CC:FADD`.
- Exact human-facing meaning still open, but the slice-local update role is strong.

### C1:0958  ct_c1_rebuild_companion_record_buffer_0e80                  [strong]
- Clears exactly `0x0180` bytes at `0E80+Y`.
- Then enters a 3-iteration build loop calling `C1:09B0`.
- Strongest safe reading: rebuild a full-size companion record buffer.

### 7E:0E80..7E:0FFF  ct_c1_companion_record_buffer_0x180                [strong]
- Full `0x0180`-byte region cleared and rebuilt by `C1:0958`.
- Distinct from the `0B40` tilemap-word strip and from the `0CC0` paired-byte strip.

### C1:09B0  ct_c1_emit_fixed_format_companion_record                    [strong]
- Checks the `C1:1580` per-entry control table.
- Copies 11 bytes from `CC:94A0` to `0B5E + 11*index` using `MVN`.
- Emits additional paired bytes into `0E86/0EC6` style regions with companion byte `0x2D`.
- Strongest safe reading: emit a fixed-format companion record.

### CC:94A0  ct_cc_companion_record_template_table                       [strong]
- ROM template source copied by `C1:09B0`.
- Used as structured record data, not code.

---

## Strengthened / corrected labels

### C1:07FD  ct_c1_compose_three_slot_panel_strip_into_0b40              [withdrawn as exact entry]
- Pass 45 used `07FD` as a broad anchor for the panel-strip composer.
- Pass 46 tightens the true entry to `C1:081F`.
- The earlier structural reading of the composer remains valid; the entry boundary was just too broad.

### D1:5800 / D1:5A50 / D1:5BD0  ct_d1_alt_base_strip_layout_family      [strengthened context]
- Pass 46 strengthens their caller-context roles:
  - `5800` = default/base restore through `C1:1C3A`
  - `5A50` = latched alternate via `A86A`
  - `5BD0` = transition/reset alternate in later state-advance paths

---

## Provisional labels

### D1:5800  ct_d1_base_strip_template_default                           [provisional]
- Caller context strongly suggests the default/base restore variant.
- Final gameplay-facing mode name still open.

### D1:5A50  ct_d1_base_strip_template_latched_alt                       [provisional]
- Single-shot alternate selected when `A86A` is nonzero, then that latch is cleared.
- Kept provisional until the higher-level mode name is pinned.

### D1:5BD0  ct_d1_base_strip_template_transition_alt                    [provisional]
- Copied in later state-transition/reset paths with surrounding controller bookkeeping.
- Strong structural role, but final mode name still unresolved.

### CC:FA23 / CC:FA29 / CC:FADD  ct_cc_companion_strip_selector_tables   [provisional]
- These tables clearly feed `C1:08E8` slice-local updates in the `0CC0` companion strip.
- Exact semantics of each selector lane remain open.

### 7E:0CC0..7E:0E08  ct_c1_roster_presentation_companion_strip          [provisional]
- Strongly linked to the same roster/strip refresh band as `0B40`.
- Kept provisional because the final gameplay-facing subsystem name is still unresolved.

### 7E:0E80..7E:0FFF  ct_c1_roster_presentation_companion_records        [provisional]
- Strongly linked to the same refresh band and built in three iterations.
- Still not safe to call text, icon metadata, or anything more specific yet.

---

## Still intentionally unresolved

### 7E:9F38  ct_c1_lane_emitted_aux_or_mask                               [provisional, unchanged]
- Pass 46 stayed on the strip/companion-buffer seam and did not expose a trustworthy positive writer.
- Clear/consume behavior remains real.
- Positive producer remains unresolved.


---

## Pass 47

# Chrono Trigger Disassembly Labels — Pass 47

This file contains labels newly added, corrected, or materially strengthened in pass 47.

As in prior passes:
- **strong** = directly supported by control flow and data role in the ROM work of this pass
- **provisional** = structurally useful but still not safe as a final gameplay-facing name

---

## Strong labels

### C1:0299  ct_c1_rebuild_full_companion_strip_0cc0                     [strong]
- Begins by clearing/filling the full paired-byte `0CC0` strip.
- Stamps layout-dependent fixed glyphs based on `9F20`.
- Iterates the three lane blocks and writes both static and dynamic glyph groups.
- This is the full-strip rebuild entry, not just a local mutator.

### CC:FA23..CC:FA3F  ct_cc_companion_strip_lane_anchor_offset_family    [strong]
- Family of 3-entry 16-bit offset tables.
- Every table uses `0x80` lane spacing.
- Proven live subgroups:
  - `FA23` = `0029,00A9,0129`
  - `FA29` = `001B,009B,011B`
  - `FA2F` = `0068,00E8,0168`
  - `FA35` = `005A,00DA,015A`
  - `FA3B` = `0066,00E6,0166`
- These are lane-anchor tables for distinct `0CC0` strip subfields/layouts.

### CC:FADD  ct_cc_companion_strip_lane_block_offsets_0000_0080_0100     [strong]
- Proven live words used by `C1:08BF`:
  - `0000`
  - `0080`
  - `0100`
- Exact role: the three base offsets for the lane blocks inside the `0CC0` strip.

### C1:06F0  ct_c1_render_scaled_lane_bar_into_0cc0                      [strong]
- Uses `FA35[lane] + 0x1A` as the bar anchor.
- Scales per-lane state through the hardware divide helper at `C1:00D7`.
- Emits repeated `67` / `6F` glyphs and a partial tail tile into `0CC0`.
- Strongest safe reading: render a segmented bar/meter into the lane strip.

### CC:FAE9  ct_cc_companion_record_lane_marker_offsets_0002_0082_0102   [strong]
- Proven live words:
  - `0002`
  - `0082`
  - `0102`
- Used by `C1:1918..1969` to clear/stamp one of three `0E80` lane marker positions.

### C1:1918  ct_c1_refresh_current_0e80_lane_marker_glyphs               [strong]
- Clears the old marker block selected by `991F`.
- Stamps the current marker block selected by `95E5`.
- Writes `60/61/62/63` plus companion `29` bytes into `0E80/0EC0`.
- Strongest safe reading: refresh the current lane marker glyphs inside the `0E80` companion-record region.

---

## Strengthened labels

### C1:08E8  ct_c1_fill_current_companion_strip_slice_from_anchor_table   [strengthened]
- Pass 46 proved this was a slice-local `0CC0` update helper.
- Pass 47 tightens that role:
  - it selects an anchor from `FA23` or `FA29`
  - then fills five positions with `0x29`
- This is more specific than the earlier generic “update current slice” wording.

### 7E:0CC0..7E:0E08  ct_c1_companion_paired_byte_strip_buffer           [strengthened]
- Pass 46 proved geometry and row stride.
- Pass 47 proves a full-strip rebuild entry at `C1:0299` and a segmented bar renderer at `C1:06F0`.
- The buffer is now known to be lane-structured and layout-driven, not just a passive side strip.

### 7E:0E80..7E:0FFF  ct_c1_companion_record_buffer_0x180                [strengthened]
- Pass 46 proved the writer-side rebuild path.
- Pass 47 adds:
  - lane-marker anchor table `FAE9`
  - current-lane marker refresh at `C1:1918`
  - hard read-side consumer proof in bank `C0`
- This region is now known to participate in downstream composition, not just local build logic.

---

## Provisional labels

### 7E:99DD  ct_c1_lane_display_value_for_scaled_bar                     [provisional]
- Read by `C1:06F0` as one input to the segmented bar renderer.
- Reset/clear paths still mirror it from broader lane-carried state.
- Strong structural role, but final gameplay-facing meaning still open.

### 7E:9F22  ct_c1_lane_display_divisor_or_capacity                      [provisional]
- Read by `C1:06F0` as the other scaling input to the segmented bar renderer.
- Exact human-facing meaning still unresolved.

### 7E:9F20  ct_c1_companion_strip_layout_mode_3state                    [provisional]
- Selects among multiple `FAxx` lane-anchor tables.
- Also selects where fixed glyphs are stamped in the full-strip rebuild.
- Strongly acts like a 3-state layout selector, but the mode names remain unresolved.

### 7E:0CC0..7E:0E08  ct_c1_three_lane_status_or_command_strip           [provisional]
- Pass 47 makes the three-lane, layout-driven presentation role much stronger.
- Still not safe to commit to the final gameplay-facing subsystem name.

### 7E:0E80..7E:0FFF  ct_c1_three_lane_marker_record_presentation_block  [provisional]
- Strongly tied to lane markers and downstream consumption.
- Still not safe to collapse into “text”, “command labels”, or any narrower final name.

---

## Still intentionally unresolved

### C0:A2B0..A335 consumer path                                           [unlabeled as final routine]
- Pass 47 found direct `0E00/0E80` read-side proof there.
- Exact routine entry and full higher-level purpose are still open.
- The consumer relationship is real; the final routine label is not ready yet.

### 7E:9F38  ct_c1_lane_emitted_aux_or_mask                               [provisional, unchanged]
- Pass 47 stayed on the strip/record presentation seam.
- Positive writer side remains intentionally unresolved.


---

## Pass 48

# Chrono Trigger Disassembly Labels — Pass 48

This file contains labels newly added, corrected, or materially strengthened in pass 48.

As in prior passes:
- **strong** = directly supported by control flow and data role in the ROM work of this pass
- **provisional** = structurally useful but still not safe as a final gameplay-facing name

---

## Strong labels

### C1:011F  ct_c1_format_u16_as_three_decimal_tile_bytes_949d_949f      [strong]
- Uses `9499` as the numeric working input.
- Repeatedly subtracts `0x64` and `0x0A` to derive hundreds/tens/ones.
- Maps those digits through `CC:F903`.
- Emits tile bytes to `949D`, `949E`, `949F` and sets `949C = 0xFF`.

### C1:0174  ct_c1_format_u16_as_two_decimal_tile_bytes_949e_949f        [strong]
- Repeatedly subtracts `0x0A` to derive tens and ones.
- Maps through `CC:F903`.
- Emits tile bytes to `949E`, `949F` and blanks `949C`, `949D` with `0xFF`.

### C1:104E  ct_c1_blank_leading_zero_decimal_tiles_949d_949e            [strong]
- Converts tile `0x73` at `949D` to `0xFF`.
- Converts tile `0x73` at `949E` to `0xFF` only when `949D` is already blank.
- This is a leading-zero suppression helper over the decimal tile buffer.

### CC:F903  ct_cc_decimal_digit_tile_table_73_to_7c                    [strong]
- Live digit tile codes used by `011F` and `0174` are:
  - `73 74 75 76 77 78 79 7A 7B 7C`
- Strongest safe reading: decimal digit tile codes for `0..9`.

### 7E:9499  ct_c1_decimal_tile_format_input_u16                        [strong]
- Working numeric input consumed by `011F` and `0174`.
- Loaded from per-lane record fields during `C1:0299` numeric field emission.

### 7E:949C..7E:949F  ct_c1_decimal_tile_format_output_4bytes           [strong]
- Shared 4-byte tile buffer emitted by the decimal formatter helpers.
- `949C` is used as a blank/fill slot.
- `949D..949F` hold the generated digit tiles before they are copied into the strip.

---

## Strengthened labels

### C1:0299  ct_c1_rebuild_full_companion_strip_0cc0                     [strengthened]
- Pass 47 proved this was the full rebuild entry.
- Pass 48 proves the dynamic helper-generated groups inside it are numeric fields, not generic glyph fragments.
- The strip therefore includes fixed lane glyph runs, decimal numeric fields, and later separator/bar logic.

### 7E:0CC0..7E:0E08  ct_c1_companion_paired_byte_strip_buffer           [strengthened]
- Pass 47 established full-strip rebuild and lane-anchor semantics.
- Pass 48 proves the strip contains lane-selected decimal presentation fields rendered from per-record numeric state.

### 7E:9F20  ct_c1_companion_strip_layout_mode_3state                    [strengthened]
- Pass 47 proved it selected among multiple strip layouts.
- Pass 48 tightens that role: it repositions the same numeric fields and controls whether later separator/bar logic is present.
- Strongest safe reading now: a 3-layout numeric panel mode selector.

### C0:A270..C0:A335  ct_c0_parallel_source_plane_consumer_band         [strengthened]
- Not promoted to a final high-level subsystem name.
- But this band now has stronger proven structure:
  - reads `7F:0C00/X`, `7F:0C80/X`, `7F:0E00/X`, `7F:0E80/X`
  - consumes those families as parallel source planes in a downstream copy path
- This materially strengthens the producer/consumer relationship from the strip/record side.

---

## Provisional labels

### CC:F8ED  ct_cc_live_three_lane_record_block_offsets_0000_0080_0100  [provisional]
- Proven live subgroup used by the numeric writer path:
  - `0000`
  - `0080`
  - `0100`
- Acts as the lane-selected record-block offset table for the dynamic numeric fields.
- Broader table family may contain additional entries beyond the live subgroup.

### 7E:5E30  ct_c1_lane_primary_numeric_field                           [provisional]
- Rendered through `011F` as a 3-digit decimal field in `C1:0299`.
- Structurally related to the `5E32` field by a pre-render compare.
- Final gameplay-facing meaning still open.

### 7E:5E32  ct_c1_lane_secondary_numeric_field                         [provisional]
- Rendered through `011F` as a second 3-digit decimal field.
- Its high byte is compared against `5E30` before rendering.
- Final gameplay-facing meaning still open.

### 7E:5E34  ct_c1_lane_aux_two_digit_numeric_field                     [provisional]
- Rendered through `0174` as a 2-digit decimal field.
- Final gameplay-facing meaning still open.

### 7E:A10F  ct_c1_numeric_threshold_or_warning_counter                 [provisional]
- Incremented when the pre-render compare between `5E30` and `5E32 >> 8` fails in one direction.
- Strongly acts like a counter or warning latch related to numeric inconsistency/overflow.
- Final semantics remain unresolved.

---

## Still intentionally unresolved

### Final gameplay-facing names of the three numeric fields             [unresolved]
- Pass 48 proves the fields are numeric and lane-selected.
- It does not yet prove whether they are HP/MP/level, another stat trio, or a different presentation family.

### Final routine identity of the bank-`C0` destination side            [unresolved]
- The source-plane relationship is stronger.
- The exact destination-side subsystem name is still not ready.


---

## Pass 49

# Chrono Trigger Disassembly Labels — Pass 49

This file contains labels newly added, corrected, or materially strengthened in pass 49.

As in prior passes:
- **strong** = directly supported by control flow and data role in the ROM work of this pass
- **strengthened** = previously useful label materially tightened by new proof
- **provisional** = structurally useful but still not safe as a final gameplay-facing name

---

## Strong labels

### C1:011B  ct_c1_lsr3_entry                                          [strong]
- Mid-routine entry into the `LSR` helper band.
- Executes exactly three `LSR A` operations before `RTS`.
- Corrects pass 48’s earlier loose `>> 8` interpretation.

### 7E:5E30  ct_c1_lane_current_hp                                     [strong]
- Rendered as the first 3-digit numeric lane field in `C1:0299`.
- Compared against `5E32 >> 3` in both UI and non-UI logic.
- Mutated directly and clamped against `5E32` in `C1:EC90..ECD7`.
- Strongest safe reading now: current HP.

### 7E:5E32  ct_c1_lane_max_hp                                         [strong]
- Rendered as the second 3-digit numeric lane field in `C1:0299`.
- Divided by 8 for the low-HP threshold test.
- Used as the clamp/cap for `5E30` in `C1:EC90..ECD7`.
- Strongest safe reading now: max HP.

### 7E:5E2F.bit0  ct_c1_lane_low_hp_critical_flag                      [strong]
- Cleared, then conditionally set in `C1:B094..B0B3`.
- Condition is driven by `5E30` versus `5E32 >> 3`.
- Strongest safe reading: low-HP / critical threshold flag.

### 7E:A10F  ct_c1_lane_hp_threshold_numeric_attr_selector             [strong]
- Reset per lane before numeric field generation in `C1:0299`.
- Incremented only through the `currentHP` versus `maxHP/8` compare path.
- Immediately consumed to choose between paired-byte values `0x29` and `0x2D` for the lane’s rendered digits.
- Strongest safe reading: lane-local HP-threshold presentation selector/count.

---

## Strengthened labels

### C1:0299  ct_c1_rebuild_full_companion_strip_0cc0                   [strengthened]
- Pass 47 proved this was the full strip rebuild entry.
- Pass 48 proved it contained rendered numeric fields.
- Pass 49 tightens the three dynamic fields inside it to:
  - current HP
  - max HP
  - current MP (still slightly more conservative than the HP pair)
- The routine is now best understood as a per-lane status-field strip rebuild path, not a generic glyph mixer.

### 7E:0CC0..7E:0E08  ct_c1_companion_paired_byte_strip_buffer         [strengthened]
- Previously known as a paired-byte companion strip.
- Pass 49 materially tightens its live content model:
  - fixed lane glyphs
  - HP/max HP decimal fields
  - current-MP-like decimal field
  - threshold-sensitive paired-byte selection
  - meter/bar content
- This is now much harder as a status-lane presentation buffer.

### 7E:9F20  ct_c1_companion_strip_layout_mode_3state                  [strengthened]
- Earlier passes proved it selects layout variants.
- With the HP/maxHP/MP field family now resolved harder, the layout mode is better understood as repositioning a stable status-field bundle rather than arbitrary numeric fragments.

### C1:B094..C1:B0B3  ct_c1_update_lane_low_hp_threshold_flag          [strengthened]
- Previously part of a vague flag-maintenance band.
- Pass 49 proves this exact routine clears and re-establishes `5E2F.bit0` from the `maxHP/8` versus current HP test.

---

## Provisional labels

### 7E:5E34  ct_c1_lane_current_mp                                    [provisional]
- Rendered as the third lane numeric field through the 2-digit formatter.
- Participates in a lane-selected subtract/update path at `C1:CC74..CCC5`.
- Grouped tightly with the now-strong HP pair in the same per-lane panel record.
- Strongest safe reading now: current MP.
- Kept provisional only because pass 49 did not yet pin the cleanest possible direct “tech cost / MP spend” caller chain.

### C1:CC74..C1:CCC5  ct_c1_lane_selected_resource_spend_on_5e34_family [provisional]
- Subtracts a computed quantity from exactly one of:
  - `5E34`
  - `5EB4`
  - `5F34`
- Strongly looks like a lane-selected spend/update path for the field now best read as current MP.
- Still kept provisional until the caller-side action family is nailed harder.

---

## Corrected labels / interpretations

### Previous pass-48 wording “`5E32 >> 8`”                               [corrected]
- This should be read as `5E32 >> 3` in the `C1:0299` compare path.
- The earlier wording came from reading the helper family too broadly instead of the actual `011B` entry point.

### 7E:A10F  old wording “numeric threshold or warning counter”         [replaced]
- Too vague after pass 49.
- The ROM now supports a harder reading: a lane-local HP-threshold presentation selector/count.

---

## Still intentionally unresolved

### Exact visible palette/color meaning of paired bytes `0x29` vs `0x2D` [unresolved]
- Pass 49 proves the selector role and the HP-threshold dependency.
- It does not prove the human-facing color/palette names with enough directness to freeze them.

### Exact final caller identity for the `5E34` spend path               [unresolved]
- Strongly MP-like.
- Not yet locked to the cleanest exact caller chain.

### Final destination-side subsystem name for the bank-`C0` consumer    [unresolved]
- The producer side is now status-panel-like enough to tighten further later.
- The exact destination-side label is still being kept conservative.


---

## Pass 50

# Chrono Trigger Disassembly Labels — Pass 50

This file contains labels newly added, replaced, or materially strengthened in pass 50.

As in prior passes:
- **strong** = directly supported by control flow and data role in the ROM work of this pass
- **strengthened** = previously useful label materially tightened by new proof
- **provisional** = structurally useful but still not safe as a final frozen name

---

## Strong labels

### C1:BD6F  ct_c1_apply_status_modifiers_to_lane_time_increment         [strong]
- Starts from `AFAB[x]`.
- Halves it when the `5E4D|5E52` status family has bit `0x80` set.
- Doubles it with saturation when `5E4B` bit `0x20` is set.
- Forces a minimum of `1`.
- Mirrors the adjusted value to `99DD/9F22` for visible party lanes.
- Strongest safe reading: shared status-modifier helper for the lane active-time/readiness increment.

### C1:B725  ct_c1_init_lane_active_time_gauge_exports                  [strong]
- Clears the visible lane-progress exports `99DD..99DF`.
- Seeds the visible lane-threshold/cap exports `9F22..9F24` to `0x30`.
- Also resets the nearby pending-lane/FIFO state.
- Strongest safe reading: initialization of the visible active-time/readiness gauge export family.

---

## Strengthened labels

### C1:06F0  ct_c1_render_lane_active_time_gauge_into_0cc0             [strengthened]
- Pass 47 proved this was a scaled segmented bar renderer.
- Pass 50 tightens the gameplay-facing meaning of that bar through the upstream producer family.
- Best reading now: render the party-lane active-time/readiness gauge into the `0CC0` strip.

### 7E:B158  ct_c1_lane_base_active_time_increment                     [strengthened]
- Repeatedly copied into `AFAB` before `BD6F` is applied.
- Feeds the visible lane-bar branch through the status-modified increment family.
- Best reading now: base active-time/readiness increment.

### 7E:AFAB  ct_c1_lane_active_time_increment_shadow                    [strengthened]
- Working shadow derived from `B158`.
- Modified by `BD6F` through slow-like / haste-like status effects.
- Consumed by the gauge-advance families at `BDE0/BE50/BED0`.
- Best reading now: status-adjusted active-time/readiness increment shadow.

### 7E:99DD  ct_c1_lane_active_time_gauge_progress_export              [strengthened]
- Visible lane-bar input used by `C1:06F0`.
- Initialized to zero by `B725`.
- Updated in the readiness-gauge advance families.
- Best reading now: visible active-time/readiness gauge progress export.

### 7E:9F22  ct_c1_lane_active_time_gauge_cap_export                   [strengthened]
- Second visible lane-bar input used by `C1:06F0`.
- Initialized to `0x30` by `B725`.
- Updated by the readiness-gauge advance families.
- Best reading now: visible active-time/readiness gauge threshold/cap export.

### C1:BDE0..C1:BF25  ct_c1_advance_lane_active_time_gauge_and_ready_transition_family [strengthened]
- Three sibling update families that:
  - seed `AFAB` from `B158`
  - apply `BD6F`
  - advance one or both lane-bar exports with saturation
  - set/update lane-ready side effects (`B03A`, `B188`, `93EE`)
- Best reading now: readiness-gauge advance and ready-transition family.

### 7E:0CC0..7E:0E08  ct_c1_companion_paired_byte_strip_buffer         [strengthened]
- Earlier passes had already established HP/max HP/MP numeric content and the segmented bar.
- Pass 50 tightens the bar specifically to the lane active-time/readiness gauge.
- The strip now reads more coherently as a battle-status lane display.

---

## Provisional labels

### 7E:99DE / 7E:99DF  ct_c1_lane_active_time_gauge_progress_export_1_2 [provisional]
### 7E:9F23 / 7E:9F24  ct_c1_lane_active_time_gauge_cap_export_1_2      [provisional]
- `B725` proves these are sibling exports for the other visible lanes.
- Their human-facing meaning matches lane 0 strongly.
- Kept grouped/provisional only because pass 50 focused on the branch semantics more than on per-lane alias cleanup.

### 7E:5E4B.bit5  ct_c1_lane_haste_like_rate_modifier_bit               [provisional]
### 7E:5E4D|7E:5E52 bit7  ct_c1_lane_slow_like_rate_modifier_bit_family [provisional]
- ROM proof is strong for the functional behavior:
  - one family doubles the increment
  - one family halves it
- Exact final human-facing status names are still intentionally kept one step conservative.

---

## Replaced / retired wording

### C1:06F0 old wording “render scaled lane bar into 0CC0”             [replaced]
- Too generic after pass 50.
- The ROM now supports a materially harder gameplay-facing reading: active-time/readiness gauge renderer.

### 7E:99DD old wording “display value for scaled bar”                 [replaced]
- Replaced by `ct_c1_lane_active_time_gauge_progress_export`.

### 7E:9F22 old wording “display divisor or capacity”                  [replaced]
- Replaced by `ct_c1_lane_active_time_gauge_cap_export`.

### 7E:B158 / 7E:AFAB old wording “primary carried scalar/shadow”      [replaced]
- Too abstract after the status-modified gauge-rate proof.
- Replaced by the active-time/readiness increment wording.

---

## Still intentionally unresolved

### Exact per-variant split between `99DD` and `9F22` in every ready-transition path [unresolved]
- The human-facing bar role is now hard enough.
- The exact current/frozen/threshold split per sibling advance variant is still worth tightening before freezing every sublabel.

### Exact actor-stat seed feeding `B158`                                [unresolved]
- `B158` is now materially harder as a base readiness increment.
- The cleanest exact upstream stat source is still a good next target.

### Exact final status names for the `5E4B / 5E4D / 5E52` modifier bits [unresolved]
- Functional behavior is proven.
- Exact status-name freezing is intentionally deferred one step.


---

## Pass 51

# Chrono Trigger Disassembly Labels — Pass 51

This file contains labels newly added, replaced, or materially strengthened in pass 51.

As in prior passes:
- **strong** = directly supported by control flow and data role in the ROM work of this pass
- **strengthened** = previously useful label materially tightened by new proof
- **provisional** = structurally useful but still not safe as a final frozen name

---

## Strong labels

### FD:B820..FD:B850  ct_fd_seed_visible_lane_readiness_from_speed_like_stat         [strong]
- Iterates selected visible participants.
- Clamps record byte `+0x38` to `0x10`.
- Uses the clamped value to index `CC:2E31`.
- Combines that table value with a `0x69` base and local `$2C` bias term.
- Stores the result to both `B158` and `AFAB`.
- Sets `B03A = 1` for the affected visible lane.
- Strongest safe reading: battle-side visible-lane readiness seed writer keyed by a speed-like stat.

### CC:2E31  ct_cc_speed_like_stat_to_readiness_bonus_table                           [strong]
- 16-byte signed step table:
  `CD D1 D5 D9 DD E1 E5 E9 ED F1 F5 F9 FD 01 05 09`
- Smooth +4-step ladder from negative to small positive bonus.
- Consumed directly by the `FD:B820..B850` readiness seed family.
- Strongest safe reading: speed-like stat -> readiness bonus table.

### C1:B390  ct_c1_seed_lane_gauge_exports_from_b158                                 [strong]
- Directly mirrors `B158,Y` into:
  - `AFAB,Y`
  - `99DD,Y`
  - `9F22,Y`
- Strongest safe reading: direct seed/export mirror from the upstream readiness seed value.

---

## Strengthened labels

### 7E:99DD  ct_c1_lane_active_time_gauge_current_fill_export                        [strengthened]
- `C1:06F0` loads it as the renderer numerator/current-side value.
- Goal-only update families do **not** necessarily overwrite it.
- Snap/full commit families explicitly mirror it equal to `9F22`.
- Replaces the looser “progress export” wording with a harder current-fill role.

### 7E:9F22  ct_c1_lane_active_time_gauge_goal_or_cap_export                         [strengthened]
- `C1:06F0` loads it as the denominator/goal-side value for the gauge math.
- `C1:BE00..BE2A` updates it without also updating `99DD`.
- Equal-write paths force `99DD == 9F22` to export a full/ready bar.
- Replaces the narrower pass-50 “cap export” wording with a harder goal/denominator role.

### C1:06F0  ct_c1_render_lane_active_time_gauge_into_0cc0                          [strengthened]
- Pass 50 already tied it to the readiness gauge.
- Pass 51 tightens the exact consumed pair to:
  - current fill = `99DD`
  - goal/cap = `9F22`
- The human-facing readiness-gauge name holds and the math-side split is now much cleaner.

### 7E:B158  ct_c1_lane_readiness_seed_value                                        [strengthened]
- This pass proves `B158` is a direct upstream seed into the visible lane-gauge branch.
- `C1:B390` mirrors it directly into `AFAB/99DD/9F22`.
- `FD:B820..B850` seeds it from a speed-like stat and bonus table.
- This is a stronger and safer description than the older purely generic scalar wording.

### 7E:AFAB  ct_c1_lane_readiness_work_value                                        [strengthened]
- Receives the same upstream seed as `B158` in the battle-side writer families.
- Is also the working value advanced by the later goal/snap export families.
- Stronger now as the work-value/shadow branch for the lane readiness gauge.

---

## Provisional labels

### 7E:[participant_record + 0x38]  ct_battle_participant_speed_like_stat           [provisional]
- Clamped to `0x10` by `FD:B820..B850` before indexing `CC:2E31`.
- Functionally it behaves like the stat that seeds readiness/initiative gain.
- Final human-facing freeze as exactly “speed” is deferred until the surrounding participant record layout is tighter.

### FD:B8C0..FD:B8E0  ct_fd_seed_visible_lane_readiness_sibling_family              [provisional]
- Structural sibling of `FD:B820..B850`.
- Writes to `B15B/AFAE` and sets `B03D`.
- Almost certainly the adjacent visible-lane seed family, but still worth one more pass before freezing the final name.

### 7E:B03A  ct_c1_visible_lane_readiness_seed_valid_flag                           [provisional]
- Set to `1` by the primary visible-lane seed family at `FD:B820..B850`.
- Strongly looks like a “valid/seeded/armed” lane flag.
- Final freeze deferred until the sibling `B03D` path is fully aligned.

---

## Replaced / retired wording

### 7E:99DD old wording “lane_active_time_gauge_progress_export”                    [replaced]
- Too generic after the renderer-side numerator proof.
- Replaced by `ct_c1_lane_active_time_gauge_current_fill_export`.

### 7E:9F22 old wording “lane_active_time_gauge_cap_export”                         [replaced]
- Too narrow after the goal-only update path at `C1:BE00..BE2A` and the snap/full mirror paths.
- Replaced by `ct_c1_lane_active_time_gauge_goal_or_cap_export`.

### 7E:B158 old wording “lane_base_active_time_increment”                           [soft-replaced]
- Pass 50's increment wording was useful but too narrow.
- Pass 51 proves `B158` is at least a direct upstream seed value for the readiness-gauge branch.
- Soft-replaced by `ct_c1_lane_readiness_seed_value` pending one more pass on exact subroles.

### 7E:AFAB old wording “lane_active_time_increment_shadow”                         [soft-replaced]
- Too narrow after the direct seed/export mirror proof and the later working-value advances.
- Soft-replaced by `ct_c1_lane_readiness_work_value`.

---

## Still intentionally unresolved

### Exact human-facing identity of participant record byte `+0x38`                  [unresolved]
- Functionally it behaves like the speed/readiness stat.
- Final freeze as exactly “speed” is deferred one more step.

### Exact source and meaning of local `$2C` in `FD:B820..B850`                      [unresolved]
- It is clearly part of the readiness seed formula.
- Whether it is randomness, formation bias, or another small adjustment still needs one more direct caller pass.

### Exact final role split between `B158` and `AFAB` across every update family     [unresolved]
- This pass proves both participate in the readiness branch more concretely.
- One more pass is still worth doing before freezing their final long-term names.


---

## Pass 52

# Chrono Trigger Disassembly Labels — Pass 52

This file contains labels newly added, replaced, or materially strengthened in pass 52.

As in prior passes:
- **strong** = directly supported by control flow and data role in the ROM work of this pass
- **strengthened** = previously useful label materially tightened by new proof
- **provisional** = structurally useful but still not safe as a final frozen name

---

## Strong labels

### C1:C90B  ct_c1_mul_u16_dp28_dp2a_to_dp2c_lowword                              [strong]
- Shift/add multiply helper.
- Consumes 16-bit inputs in `$28` and `$2A`.
- Writes the low word of the product to `$2C`.
- This is the real arithmetic core behind the `C1:FDBF` wrapper used in the readiness seed families.

### C1:FDBF  ct_c1_jsl_mul_u16_dp28_dp2a_to_dp2c_lowword                         [strong]
- Thin long-call wrapper:
  - `JSR $C90B`
  - `RTL`
- Useful because the seed families call it twice with different inputs.

### CC:2E31  ct_cc_battle_speed_page_speed_to_readiness_seed_adjust_table        [strong]
- 8 pages of 16 signed-byte entries each.
- Page selected by `($2990 & 7)`.
- Entry selected by `(speed - 1)`.
- Supplies the additive adjustment term in the exact readiness seed formula.

### FD:B820..FD:B850  ct_fd_seed_primary_visible_lane_readiness_from_config_and_speed [strong]
- Primary visible-lane seed family.
- Computes page = `($2990 & 7)`.
- Loads adjustment from `CC:2E31[page*16 + speed - 1]`.
- Computes final seed:
  - `0x69 - speed*6 + adjustment`
- Stores to:
  - `B158`
  - `AFAB`
- Sets `B03A = 1`.

---

## Strengthened labels

### 7E:2990 low 3 bits  ct_cfg_battle_speed_field                                [strengthened]
- This pass proves the low 3 bits are consumed directly as an 8-way page selector in the readiness seed branch.
- The whole byte is still a broader config byte, but the low field is no longer vague.
- Strongest safe reading: battle-speed option field.

### 7E:[participant_record + 0x38]  ct_battle_participant_effective_speed_byte    [strengthened]
- Previously only “speed-like stat”.
- This pass proves it is used twice in the seed formula:
  - once to select one of 16 entries within the battle-speed page
  - once as the multiplicand in `speed * 6`
- Strongest safe reading: effective/current speed byte for the battle participant record.

### 7E:B158  ct_c1_primary_lane_readiness_seed_value                              [strengthened]
- Still best kept as a seed value rather than a final gameplay-facing name.
- This pass proves the exact upstream formula feeding it.

### 7E:AFAB  ct_c1_primary_lane_readiness_work_value                              [strengthened]
- Receives the same formula result as `B158` in the primary seed family.
- Still the best working/readiness-shadow label.

### 7E:B03A  ct_c1_primary_visible_lane_readiness_seed_valid_flag                 [strengthened]
- This pass confirms it is asserted directly by the primary seed family after the exact formula store.

---

## Provisional labels

### FD:B8C0..FD:B8E0  ct_fd_seed_sibling_visible_lane_readiness_from_config_and_speed [provisional]
- Uses the same core formula as the primary family:
  - `0x69 - speed*6 + adjustment`
- Stores to:
  - `B15B`
  - `AFAE`
- Sets `B03D` only when `AF02[slot] != FF`.
- Also conditionally ORs `#$40` into `AF15[slot]` when record byte `+0x0A` has bit 0 set.
- Final freeze deferred until the higher-level semantic split between the primary/sibling pairs is tighter.

### 7E:B15B  ct_c1_sibling_lane_readiness_seed_value                              [provisional]
- Formula-aligned sibling of `B158`.
- Final freeze deferred until the exact caller/consumer split is clearer.

### 7E:AFAE  ct_c1_sibling_lane_readiness_work_value                              [provisional]
- Formula-aligned sibling of `AFAB`.
- Final freeze deferred pending more downstream consumer proof.

### 7E:B03D  ct_c1_sibling_visible_lane_readiness_seed_valid_flag                 [provisional]
- Sibling of `B03A`, but only set under an extra gate (`AF02 != FF`).
- Final freeze deferred pending tighter alignment with the lane-selection/state machinery.

### 7E:AF15 bit 6  ct_runtime_slot_sibling_seed_side_effect_flag                  [provisional]
- Set by the sibling seed family when record byte `+0x0A` has bit 0 set.
- Real side effect, but gameplay-facing meaning still unresolved.

---

## Replaced / retired wording

### “small random/bias term” in `FD:B820..FD:B850`                               [retired]
- No longer supported.
- Replaced by two exact proven roles for `$2C`:
  1. battle-speed page selector (`($2990 & 7) * 16`)
  2. `speed * 6`

### CC:2E31 old wording “speed-like stat -> readiness bonus table”               [soft-replaced]
- Too narrow after page-selection proof.
- Replaced by `ct_cc_battle_speed_page_speed_to_readiness_seed_adjust_table`.

### FD:B820..FD:B850 old wording “seed ... from speed-like stat”                 [soft-replaced]
- Too narrow after config-field/page proof.
- Replaced by `ct_fd_seed_primary_visible_lane_readiness_from_config_and_speed`.

---

## Exact formula now safe to carry forward

For the primary seed family:

```text
page  = ($2990 & 7)
speed = [participant_record + 0x38]
adj   = CC:2E31[(page * 16) + (speed - 1)]
seed  = 0x69 - (speed * 6) + adj
```

Equivalent pagewise linear forms:

```text
page 0: seed =  50 - 2*speed
page 1: seed =  75 - 3*speed
page 2: seed = 100 - 4*speed
page 3: seed = 125 - 5*speed
page 4: seed = 150 - 6*speed
page 5: seed = 175 - 7*speed
page 6: seed = 200 - 8*speed
page 7: seed = 225 - 9*speed
```

These forms are now strong enough to preserve in future passes.

---

## Still intentionally unresolved

### Exact higher-level semantic split between primary and sibling seed/export pairs [unresolved]
- `B158 / AFAB / B03A`
- `B15B / AFAE / B03D`

### Exact gameplay-facing name for the seed quantity                             [unresolved]
- “readiness seed” is now very safe structurally
- final freeze as countdown/delay/timer/etc. still wants one more downstream pass

### Exact meaning of sibling-only `AF15.bit6` side effect                        [unresolved]
- Real and worth keeping
- not yet safe to freeze


---

## Pass 53

# Chrono Trigger Disassembly Labels — Pass 53

This file contains labels newly added, replaced, or materially strengthened in pass 53.

As in prior passes:
- **strong** = directly supported by control flow and data role in the ROM work of this pass
- **strengthened** = previously useful label materially tightened by new proof
- **provisional** = structurally useful but still not safe as a final frozen name

---

## Strong labels

### 7E:B158..7E:B162  ct_battle_slot_readiness_seed_array                         [strong]
- Contiguous 11-byte readiness/base array.
- Proven by the 11-entry bulk writer at `FD:B4E0..B54D`.
- Head partition = `B158..B15A`.
- Tail partition = `B15B..B162`.

### 7E:AFAB..7E:AFB5  ct_battle_slot_readiness_work_array                         [strong]
- Contiguous 11-byte readiness/work array.
- Hard-proved by the init block at `C1:80FD..811D`:
  - `AFAB..AFAD = 01`
  - `AFAE..AFB5 = FF`
- Head partition is directly exported to visible gauge buffers at `FD:B93B..B94F`.

### 7E:B03A..7E:B044  ct_battle_slot_readiness_dirty_array                        [strong]
- Contiguous 11-byte readiness update/valid array.
- Head seeder writes the first 3 entries through `B03A,X`.
- Tail seeder writes the later entries through `B03D,X = B03A + 3 + X`.

### FD:B800..FD:B94F  ct_fd_seed_battle_slot_readiness_head_and_tail_partitions   [strong]
- Unified seed routine for the contiguous readiness arrays.
- Fixed head loop seeds slots `0..2`.
- Tail loop seeds the later runtime-slot partition starting at slot `3`.
- Ends by exporting only head work values (`AFAB..AFAD`) to the visible buffers.

---

## Strengthened labels

### 7E:B158..7E:B15A  ct_visible_head_lane_readiness_seed_array                   [strengthened]
- Previously treated as a standalone “primary pair”.
- This pass proves it is the fixed 3-entry head partition of the larger 11-slot seed array.
- These are the entries directly tied to the visible export path.

### 7E:AFAB..7E:AFAD  ct_visible_head_lane_readiness_work_array                   [strengthened]
- Head partition of `AFAB..AFB5`.
- Directly copied to:
  - `99DD..99DF`
  - `9F22..9F24`
- Strongest safe reading: the visible panel/gauge-facing work values.

### 7E:B03A..7E:B03C  ct_visible_head_lane_readiness_dirty_array                  [strengthened]
- Head partition of the contiguous readiness dirty/update array.
- Asserted directly by the head seeder.

### 7E:B15B..7E:B162  ct_runtime_tail_slot_readiness_seed_array                   [strengthened]
- Previously labeled as a separate “sibling” seed pair.
- This pass proves it is the tail partition of the same contiguous seed array rooted at `B158`.
- Seeded by the same config/speed formula as the head partition.

### 7E:AFAE..7E:AFB5  ct_runtime_tail_slot_readiness_work_array                   [strengthened]
- Tail partition of the contiguous work array rooted at `AFAB`.
- Initialized to `FF` in the startup block.
- Participates in the selector/materializer logic from `C1:9E78`.

### 7E:B03D..7E:B044  ct_runtime_tail_slot_readiness_dirty_array                  [strengthened]
- Tail partition of the contiguous readiness dirty array rooted at `B03A`.
- Set by the tail seeder only under the extra `AF02 != FF` gate.

### 7E:AEC6  ct_runtime_tail_slot_count                                           [strengthened]
- Used as the bound for the tail seeder loop in `FD:B867..B8EC`.
- Best current reading: live/populated tail-slot count rather than total capacity.

---

## Provisional labels

### FD:A811  ct_fd_runtime_tail_slot_record_ptr_table                             [provisional]
- Indexed by the tail seeder through a 16-bit table lookup.
- Supplies the record source used to read at least:
  - byte `+0x38` (effective speed in pass 52)
  - byte `+0x0A` (source of the tail-only `AF15.bit6` side effect)
- Exact record family name still wants one more pass.

### 7E:AF15 bit 6  ct_runtime_tail_slot_seed_side_effect_flag                     [provisional]
- Set only by the tail seeder when source record byte `+0x0A` has bit 0 set.
- Real and structurally isolated, but final gameplay-facing meaning is still unresolved.

### FD:B8F5..FD:B93A  ct_fd_normalize_head_readiness_work_before_visible_export    [provisional]
- This is the shared normalization/pre-export tail before the copy into `99DD..99DF` and `9F22..9F24`.
- Clearly head-export facing.
- Exact minimum/subtractive semantics still deserve one dedicated pass before freezing the name harder.

---

## Replaced / retired wording

### `ct_fd_seed_primary_visible_lane_readiness_from_config_and_speed`             [soft-replaced]
- Too narrow after the head/tail partition proof.
- Replaced by:
  - `ct_fd_seed_battle_slot_readiness_head_and_tail_partitions`

### `ct_fd_seed_sibling_visible_lane_readiness_from_config_and_speed`             [retired]
- “sibling visible lane” is no longer the right model.
- Replaced by the tail-partition reading inside the unified array family.

### `ct_c1_primary_lane_readiness_seed_value` / `ct_c1_sibling_lane_readiness_seed_value` [soft-replaced]
- Useful stepping-stones, but too fragmented now.
- Replaced by the unified array labels plus head/tail partition labels.

### `ct_c1_primary_lane_readiness_work_value` / `ct_c1_sibling_lane_readiness_work_value` [soft-replaced]
- Same issue: too fragmented after the unified-array proof.

### `ct_c1_primary_visible_lane_readiness_seed_valid_flag` / `ct_c1_sibling_visible_lane_readiness_seed_valid_flag` [soft-replaced]
- Replaced by the unified dirty-array family plus head/tail partition labels.

---

## Exact structural model now safe to carry forward

Unified readiness families:

```text
seed/base  : B158..B162   (11 entries)
work/value : AFAB..AFB5   (11 entries)
dirty/flag : B03A..B044   (11 entries)
```

Partition split:

```text
head slots 0..2   -> visible head/panel-facing partition
tail slots 3..10  -> runtime tail partition
```

Hard proof points:
- `C1:80FD..811D` initializes the work array as `3 + 8`
- `FD:B4E0..B54D` bulk-writes the seed array across 11 entries
- `FD:B800..B8EC` seeds head then tail using the same config/speed formula family
- `FD:B93B..B94F` exports only the head work values to visible buffers

---

## Still intentionally unresolved

### Exact gameplay-facing identity of the tail partition                          [unresolved]
- It is clearly runtime-slot facing
- It is clearly not exported to the 3 visible panel lanes here
- Final freeze as enemy-side/materialized reserve/etc. wants one more pass

### Exact meaning of `AF15.bit6` in the tail seeder                              [unresolved]
- Real side effect
- Not yet safe to freeze

### Exact normalization semantics of `FD:B8F5..FD:B93A`                          [unresolved]
- Strongly looks like a pre-export normalization pass
- Still wants one clean dedicated decode pass


---

## Pass 54

# Chrono Trigger Disassembly Labels — Pass 54

This file contains labels newly added, replaced, or materially strengthened in pass 54.

As in prior passes:
- **strong** = directly supported by control flow and arithmetic in the ROM work of this pass
- **strengthened** = previously useful label materially tightened by new proof
- **provisional** = structurally useful but still not safe as a final frozen gameplay-facing name

---

## Strong labels

### FD:B8F7..FD:B93A  ct_fd_normalize_active_battle_slot_readiness_to_minimum_one_before_head_export   [strong]
- Real post-seed normalization body.
- Scans the unified work array `AFAB..AFB5`.
- Selects the smallest eligible **positive** entry.
- Computes subtractive delta = `(min - 1)`.
- Subtracts that delta from every eligible positive entry.
- Leaves zero entries unchanged.
- Leaves `AEFF == FF` entries unchanged.
- Runs immediately before the head export at `B93B..B94F`.

---

## Strengthened labels

### 7E:AFAB..7E:AFB5  ct_battle_slot_readiness_work_array                         [strengthened]
- Pass 53 proved this is one unified 11-entry work array.
- Pass 54 proves it is also the target of a **minimum-positive subtractive normalization**.
- Smallest eligible positive value is forced to `1` before head export.
- Zero entries are preserved.
- `AEFF == FF` entries are preserved.

### 7E:AFAB..7E:AFAD  ct_visible_head_lane_readiness_work_array                   [strengthened]
- Still the visible head partition.
- Pass 54 proves these values are exported **after unified 11-slot normalization**, not as raw seeded values.

### 7E:AFAE..7E:AFB5  ct_runtime_tail_slot_readiness_work_array                   [strengthened]
- Tail partition still not exported directly here.
- Pass 54 proves it still participates in the same shared normalization pass as the visible head.
- This is strong evidence that head and tail are one readiness/countdown space, not parallel unrelated arrays.

### 7E:AEFF..7E:AF09  ct_battle_slot_active_entry_gate_array                      [strengthened / provisional]
- In this pass the array is used as a hard `FF`-sentinel eligibility gate.
- Entries with `AEFF[X] == FF` are excluded from:
  - minimum selection
  - subtractive normalization
- Final gameplay-facing noun is still not frozen, so keep the label slightly provisional even though the gating role here is strong.

### 7E:99DD..7E:99DF  ct_visible_head_lane_readiness_current_export               [strengthened]
- Pass 51 already pinned this as current/fill export.
- Pass 54 proves the exported values are specifically the **post-normalized head work values**.

### 7E:9F22..7E:9F24  ct_visible_head_lane_readiness_goal_export                  [strengthened]
- Pass 51 already pinned this as goal/cap export in the gauge-facing path.
- Pass 54 proves this mirror copy at `B93B..B94F` receives the same **post-normalized head work values** in this initializer path.

---

## Provisional labels

### 7E:AFAB value `0`  ct_battle_slot_readiness_zero_special_state                [provisional]
- In this routine, zero values are:
  - excluded from minimum selection
  - excluded from subtractive normalization
  - preserved across the pass
- Strong structural meaning: not an active positive countdown participant.
- Final gameplay-facing noun still wants one more downstream confirmation.

### FD:B91B..FD:B939  ct_fd_subtract_selected_minimum_minus_one_from_active_positive_readiness_entries   [provisional]
- This is the arithmetic heart of the normalization routine.
- Useful as an internal sublabel if the disassembly later wants finer block labels.
- Semantics are already well understood; kept provisional only because the project has not yet frozen sub-block naming style consistently.

---

## Replaced / retired wording

### FD:B8F5..FD:B93A  ct_fd_normalize_head_readiness_work_before_visible_export    [replaced]
- Too vague after pass 54.
- Replaced by:
  - `ct_fd_normalize_active_battle_slot_readiness_to_minimum_one_before_head_export`

### “minimum/subtractive semantics unresolved”                                   [retired]
- No longer true after the byte-level decode of `B8F7..B939`.

---

## Exact arithmetic model now safe to carry forward

Selection phase:
```text
scan AFAB..AFB5
candidate must be:
  - nonzero
  - AEFF != FF
choose the smallest such value
```

Delta:
```text
delta = selected_minimum - 1
```

Apply phase:
```text
for each slot 0..10:
  if AEFF == FF -> skip
  if AFAB == 0  -> skip
  else AFAB -= delta
```

Postcondition:
```text
smallest eligible positive AFAB entry becomes 1
zeros remain 0
AEFF==FF entries remain unchanged
```

Export:
```text
AFAB..AFAD -> 99DD..99DF and 9F22..9F24
```

---

## Notes for next pass
- Trace producers/owners of `AEFF` hard enough to freeze its noun beyond “active-entry gate”.
- Re-check the later ready-transition helpers (`BDE0`, `BE50`, `BED0`) against the newly solved subtract-to-one normalization model.
- Look for the downstream consumer that distinguishes:
  - zero
  - one
  - larger positive readiness values


---

## Pass 55

# Chrono Trigger Disassembly Labels — Pass 55

This file contains labels newly added, replaced, or materially strengthened in pass 55.

As in prior passes:
- **strong** = directly supported by control flow and data flow in this pass
- **strengthened** = previously useful label materially tightened by new proof
- **provisional** = structurally useful but not yet safe as a final frozen gameplay-facing name

---

## Strong labels

### 7E:AEFF..7E:AF09  ct_battle_slot_occupant_index_map                           [strong]
- Slot-indexed map.
- Each non-`FF` entry names the battler/participant currently assigned to that slot.
- `FF` means the slot is unoccupied.
- Proven by:
  - direct slot initialization at `FD:B24D..B27E`
  - alternate rebuild at `C1:FB06..FB2C`
  - inverse-map construction into `B1BE` at `FD:B28F..B2A3`
  - battler-structured downstream consumption at `FD:B363...`

### 7E:AF0A..7E:AF14  ct_battle_slot_default_occupant_index_map                    [strong]
- Initialized in lockstep with `AEFF`.
- Used by `C1:B279..B28E` to restore live slot occupancy.
- Shares the same `FF` empty sentinel semantics.

### 7E:B1BE..          ct_battler_to_visible_head_slot_inverse_map                 [strong]
- Rebuilt from `AEFF[0..2]` at `FD:B28F..B2A3`.
- Semantics: `B1BE[battler] = visible head slot`.
- Consumed directly by `C1:BE50..BF24`.

### 7E:AEC5           ct_visible_head_occupied_slot_count                          [strong]
- Incremented when canonical head-slot rebuilds admit a valid visible occupant.
- Reset and rebuilt in both:
  - `FD:B24D..B27E`
  - `C1:FB06..FB2C`

---

## Strengthened labels

### 7E:AEFF..7E:AF09  ct_battle_slot_active_entry_gate_array                       [replaced]
- Too weak after pass 55.
- Replaced by:
  - `ct_battle_slot_occupant_index_map`
- The gating behavior from pass 54 remains true, but it is now clearly a consequence of slot occupancy, not the primary noun.

### 7E:AF0A..7E:AF14  ct_battle_slot_occupant_index_mirror                         [strengthened]
- Pass 55 shows this is not just a mirror.
- It is the remembered/default occupant map used for restoration.

### 7E:AEC5           ct_visible_head_active_slot_count                            [strengthened]
- Tightened from generic “active slot count” wording.
- Specifically counts admitted visible-head occupants during head-map rebuild.

### 7E:B1BE..         ct_visible_lane_inverse_lookup                               [strengthened]
- Pass 55 makes the direction exact:
  - battler index -> visible head slot
- Used by targeted readiness/gauge helpers after `B2EB/B2EC` selection.

### FD:B28F..FD:B2A3  ct_fd_rebuild_visible_head_battler_to_slot_inverse_map       [strengthened]
- Previously only loosely understood as a small inverse/lookup rebuild.
- Pass 55 freezes the exact source and direction:
  - source: `AEFF[0..2]`
  - destination: `B1BE[battler] = slot`

---

## Provisional labels

### C1:B279..C1:B2C0  ct_c1_restore_or_clear_live_battle_slot_occupant_from_default_map   [provisional]
- Strong structure:
  - restores `AEFF[Y]` from `AF0A[Y]` when a remembered occupant exists
  - later clears `AEFF[Y] = FF` on failure/removal path
- Kept provisional because the exact higher-level gameplay trigger for this restore/remove operation still wants one more caller-context pass.

### FD:B24D..FD:B27E  ct_fd_initialize_head_battle_slot_occupant_maps_from_party_state     [provisional]
- The head-map construction is strong.
- The exact upstream gameplay noun for the `2980` validity source is still left slightly cautious.

### C1:FB06..C1:FB2C  ct_c1_rebuild_head_battle_slot_occupant_maps_with_extra_guard         [provisional]
- Same structural model as `FD:B24D..B27E`.
- Extra exclusion via `A09B[X]` is proven.
- Final caller-facing subsystem name still wants one more pass.

---

## Replaced / retired wording

### 7E:AEFF..7E:AF09  “active-entry gate array”                                    [retired as primary noun]
- Still true in pass-54 arithmetic terms.
- No longer the best primary label after pass 55.

### 7E:AF0A..7E:AF14  “occupant mirror”                                            [retired as primary noun]
- Too weak after restore-path proof.
- Replace with “default / remembered occupant index map”.

---

## Exact mapping model now safe to carry forward

Head rebuild:
```text
for slot in 0..2:
  if source entry valid:
    AEFF[slot] = battler_index
    AF0A[slot] = battler_index
    AEC5++
```

Inverse rebuild:
```text
for slot in 0..2:
  battler = AEFF[slot]
  if battler != FF:
    B1BE[battler] = slot
```

Restore path:
```text
if AF0A[slot] != FF:
  AEFF[slot] = AF0A[slot]
```

Clear path:
```text
AEFF[slot] = FF
```

Downstream targeting:
```text
battler = B2EB / B2EC
slot    = B1BE[battler]
operate on slot-local readiness/gauge state
```

---

## Notes for next pass
- Trace direct producer paths for tail-slot occupants beyond the visible-head rebuilders.
- Re-check the ready-transition helpers with the now-frozen occupant-map model.
- Target the downstream logic that distinguishes:
  - occupied-but-zero readiness
  - occupied-and-one-step-away readiness
  - occupied-and-larger-positive readiness


---

## Pass 56

# Chrono Trigger Labels - Pass 56

## Purpose
This file records the label promotions and semantic upgrades justified by pass 56.

Pass 56 closes the direct producer side for the tail half of the 11-slot occupant-map family.
The main upgrades are:

- freeze `AEFF..AF09` and `AF0A..AF14` as unified contiguous 11-slot map families
- promote `FD:B2A3..B2DD` into the canonical tail-map builder
- strengthen `AEC6`
- strengthen `AF15.bit7`
- harden the tail meaning of `AF02..AF09` and `AF0D..AF14`

---

## Strong labels

### 7E:AEFF..AF09  ct_battle_slot_live_occupant_map                          [strengthened]
- Unified 11-slot live occupant map.
- Slots `0..2` = visible head live occupants.
- Slots `3..10` = tail live/materialized occupants.
- `FF` means unoccupied / not live in this map.

### 7E:AF0A..AF14  ct_battle_slot_canonical_occupant_map                     [strengthened]
- Unified 11-slot canonical/remembered occupant map.
- Head half built from the visible source path.
- Tail half built from the `29C4` source-record family.

### 7E:AEC6        ct_canonical_tail_slot_count                              [strong]
- Reset by the canonical tail-map builder at `FD:B2A3`.
- Incremented once per admitted tail source record.
- Counts populated canonical tail entries, not merely currently live tail occupants.

### 7E:AF02..AF09  ct_tail_live_occupant_submap                              [strong]
- Tail subrange of the unified live occupant map.
- Receives occupant IDs from the `29C4` source family.
- May be forced to `FF` while the canonical tail map still retains the occupant.

### 7E:AF0D..AF14  ct_tail_canonical_occupant_submap                         [strong]
- Tail subrange of the unified canonical/remembered occupant map.
- Always receives the admitted occupant ID when the tail-source gate passes.

### FD:B2A3..B2DD  ct_build_tail_live_and_canonical_occupant_maps            [strong]
- Iterates 8 source records with stride `0x0C` rooted at `29C4`.
- Uses:
  - `29C5 + n*0x0C` as the admit/skip gate
  - `29C4 + n*0x0C` as the copied occupant ID
  - `29C6 + n*0x0C` as the secondary live-withhold gate
- Populates:
  - `AF02..AF09`
  - `AF0D..AF14`
  - `AF15.bit7`
  - `AEC6`

---

## Strong bit-level label upgrades

### 7E:AF15 bit 7  ct_tail_canonical_present_but_not_live_flag               [strengthened]
- Set only when the tail-source builder keeps the canonical occupant (`AF0D`) but forces the live occupant (`AF02`) to `FF`.
- Strong structural meaning: canonical tail entry exists, but it is withheld from the live/materialized tail map.
- Exact gameplay-facing noun remains cautious.

---

## Strengthened interpretive labels from earlier passes

### C1:9E78        ct_g2_cmd10_materialize_tail_slots_from_canonical_map     [strengthened]
- Earlier passes already proved the scan gates:
  - `AF0D[x] != FF`
  - `AF02[x] == FF`
  - `AF15.bit7` clear
- Pass 56 upgrades the noun:
  - this command materializes live tail slots from the canonical tail map,
    rather than merely scanning a vague runtime-slot pool.

---

## Supporting structural notes

### Unified occupant-map geometry
The following contiguous geometry is now strong enough to carry forward:

```text
AEFF..AF09  = 11-slot live occupant map
AF0A..AF14  = 11-slot canonical/remembered occupant map

slots 0..2  = visible head partition
slots 3..10 = runtime tail partition
```

This is no longer a convenient coincidence.
The visible head builder and the tail builder now prove both halves.

---

## Cautions still in force
Do **not** over-freeze the following yet:

1. `29C4..` source family as specifically enemy-only slots
   - the 8-record / 12-byte structure is strong
   - the final gameplay-facing noun still wants more caller proof
2. `AF15.bit7` as a fully flavored term like “reserve” or “hidden”
   - structural meaning is strong
   - flavor meaning still wants more proof
3. the exact higher-level reason `C1:C1DD` type `3` requires `AF15.bit7` for entries `>= 3`

---

## Suggested next seam
The best next continuation point after pass 56 is:

1. the caller/consumer logic that distinguishes tail slots with readiness:
   - `0`
   - `1`
   - `>1`
2. the higher-level caller chain that explains why some canonical tail entries are withheld from the live map (`AF15.bit7` set)
3. stronger proof for the exact gameplay-facing identity of the 8 source records rooted at `29C4`


---

## Pass 57

# Chrono Trigger Labels - Pass 57

## Purpose
This file records the label upgrades justified by pass 57.

Pass 57 materially strengthens the `AF15.bit7` branch.
The new result is not just that bit 7 marks a canonical entry that is absent from the live tail map.
It now proves a **deferred selection + materialization** flow:

- flagged tail entries are collected into a candidate list
- multiple candidates are randomly reduced to one
- a later helper materializes the chosen canonical entry back into the live tail map and clears bit 7
- normal tail consumers/count gates ignore flagged entries

---

## Strong labels

### C1:AB03..C1:AB49  ct_build_withheld_tail_candidate_list_and_random_reduce_to_one  [strong]
- Scans all 8 tail entries.
- Collects slot indices with `AF15.bit7` set into `AECC`.
- Stores the candidate count in `AECB`.
- If `AECB >= 2`, uses the existing RNG helper at `AF22` to choose one candidate, stores it in `AECC[0]`, fills the rest of `AECC[1..]` with `FF`, and forces `AECB = 1`.
- This is a real deferred-tail candidate selector, not a generic scan.

### C1:AED3..C1:AEFB  ct_materialize_deferred_tail_entry_by_canonical_occupant_id      [strong]
- Scans tail slots `0..7`.
- Matches target occupant ID in `$0E` against the canonical tail map `AF0D[x]`.
- Requires that the live tail map `AF02[x]` does not already hold the same occupant.
- On match:
  - writes the occupant into `AF02[x]`
  - clears `AF15.bit7`
- On failure sets `AF24 = 1`.
- Strongest safe reading: explicit deferred-tail materialization helper.

### 7E:AF15 bit 7  ct_tail_deferred_materialization_flag                              [strengthened]
- Stronger than pass 56's “canonical present but not live” wording.
- Bit 7 now sits inside a proved selection/materialization flow:
  - collected by `AB03`
  - ignored by ordinary live-tail consumers
  - cleared by `AED3` when the entry is materialized into `AF02`
- Safest current noun: deferred / withheld-from-live tail materialization flag.

---

## Strong structural label upgrades

### C1:8C0A..C1:8C37  ct_iterate_live_unwithheld_tail_entries_for_dispatch             [strong]
- Consumes tail entries only when:
  - `AF15.bit7` is clear
  - `AF02[x] != FF`
  - `B2B6[x] == 0`
- Passes the live occupant ID in `AF02[x]` to `AFD2`.
- Confirms withheld entries are excluded from normal live-tail dispatch.

---

## Provisional-but-useful labels

### C1:9012..C1:9043  ct_gate_tail_dispatch_by_live_unwithheld_count                  [provisional]
- Counts tail entries where:
  - `AF02[x] != FF`
  - `AF15[x] == 0`
- Compares that count against a descriptor byte from `CC:[B1D2 + 1]`.
- Dispatches to `8C3E` on one compare outcome; otherwise sets `AF24 = 1`.
- The exact human-facing noun for the descriptor byte remains open, so this should stay provisional.

---

## Contextual notes (do not globalize yet)

### 7E:AECB / 7E:AECC  global labels should remain cautious
Earlier passes already proved these are reused as general selection/candidate scratch in multiple flows.
Pass 57 adds a new **contextual** use:

- in `AB03`, `AECC` temporarily holds withheld tail-slot indices
- in `AB03`, `AECB` temporarily holds the count of those withheld candidates

Do **not** rename them globally to only the withheld-tail meaning.

---

## Cautions still in force
Do **not** over-freeze the following yet:

1. the descriptor byte at `CC:[B1D2 + 1]` as specifically a min-count or max-count field
   - the compare/gate exists
   - the final noun still wants wrapper proof
2. `AF15.bit7` as a highly flavored gameplay term
   - the mechanical meaning is now strong
   - the exact scenario/use case still wants caller proof
3. `B2B6[x]` beyond “separate per-tail gate byte”
   - this pass proves it suppresses dispatch in `8C0A`
   - the exact state meaning remains open

---

## Suggested next seam
The best next continuation point after pass 57 is:

1. identify the callers that feed `$0E` before `ct_materialize_deferred_tail_entry_by_canonical_occupant_id`
2. identify which wrapper family owns `ct_build_withheld_tail_candidate_list_and_random_reduce_to_one`
3. then return to the earlier readiness seam with the stronger tail-state model in hand


---

## Pass 58

# Chrono Trigger Labels - Pass 58

## Purpose
This file records the label upgrades justified by pass 58.

Pass 58 does **not** fully pin the final caller chain into `AED3`.
But it materially improves ownership:

- `AB03` is no longer an orphan helper
- it belongs to a real late local selector-wrapper family
- `ABC9` is now proved as its live-tail sibling
- two fixed single-entry selector-wrapper runs are now obvious
- the pointer run at `B8F3` is strong enough to label provisionally

---

## Strong labels

### C1:ABC9..C1:AC13  ct_build_live_tail_slot_candidate_list_and_random_reduce_to_one    [strong]
- Scans the unified live occupant map starting at slot index `3`.
- Uses `B252 + 3` as the upper live-tail bound.
- Appends non-`FF` live slot indices into `AECC`.
- If multiple candidates exist, uses `AF22` to choose one and exposes the chosen slot at `AECC[0]`.
- Forces `AECB = 1`.
- Strong structural sibling to pass 57's `AB03`, but over the live-tail side.

### C1:AAAB..C1:AAF8  ct_fixed_single_entry_selector_wrappers_3_through_10               [strong]
- Family of tiny wrappers:
  - `AECC = literal`
  - `AECB = 1`
  - `RTS`
- Covered literal values: `3..10`.

### C1:AB4E..C1:AB90  ct_fixed_single_entry_selector_wrappers_0_through_6                [strong]
- Family of tiny wrappers:
  - `AECC = literal`
  - `AECB = 1`
  - `RTS`
- Covered literal values: `0..6`.

---

## Strong structural label upgrades

### C1:AB9B..C1:ABC8  ct_select_one_visible_entry_0_1_2_by_min_lane_value               [strong structural]
- Compares three lane-local values:
  - `5E30`
  - `5EB0`
  - `5F30`
- Selects exactly one visible entry index:
  - `0`, `1`, or `2`
- Stores that selected entry into `AECC`
- Forces `AECB = 1`
- Exact branch polarity / final gameplay noun should still stay cautious, but the structural selector role is now strong.

### C1:AED3..C1:AEFB  ct_materialize_deferred_tail_entry_by_canonical_occupant_id      [strengthened context]
- Keep the pass-57 label.
- Pass 58 strengthens the context:
  - this helper is **not** the only tail materialization path
  - it is best treated as the **occupant-ID keyed deferred reinsertion helper**
  - slot-indexed materializers exist elsewhere (`9E78`, `86BC` style copy path)

---

## Provisional labels

### C1:B8F3..C1:B92B  ct_selector_wrapper_table_candidate                               [provisional]
- Coherent pointer run of 29 entries:
  - dynamic selector wrappers
  - fixed single-entry wrappers
  - `AB03`
  - `AB9B`
  - `ABC9`
- Strongly looks like a real local selector-wrapper table.
- The dispatch site into this table is still not pinned, so keep this provisional.

### C1:AB03..C1:AB49  ct_build_withheld_tail_candidate_list_and_random_reduce_to_one    [context strengthened]
- Keep the pass-57 label.
- Pass 58 now places it inside the same selector-wrapper family as:
  - fixed single-entry wrappers
  - the visible-slot min selector
  - the live-tail selector at `ABC9`

---

## Important corrections / caution notes

### `AECC` tail clearing in `AB03` / `ABC9`
Do **not** keep over-claiming that these routines necessarily clear the whole remainder of `AECC[1..]`.

What is definitely proved is:
- chosen result -> `AECC[0]`
- one following `FF` write
- `AECB = 1`

Because `AECB = 1`, the rest of the scratch entries are no longer semantically live anyway.

### `B8F3` should not yet be renamed as a confirmed CC-stream command table
This pass proves a coherent pointer family.
It does **not** yet prove a dispatcher equivalent to:
- `874E -> B80D`
- `8CE7 -> B85F`
- `8D88 -> B88D`
- `AC2E -> B8BB`

So keep `B8F3` as a selector-wrapper table **candidate** until the entry path is pinned.

---

## Suggested next seam
The best next continuation point after pass 58 is:

1. pin the real dispatcher into `ct_selector_wrapper_table_candidate`
2. trace which wrapper translates `AECC`-style selected slot indices into `$0E`
3. then revisit deferred-tail reinsertion with that stronger wrapper-family model


---

## Pass 59

# Chrono Trigger Labels - Pass 59

## Purpose
This file records the label corrections and upgrades justified by pass 59.

Pass 59 resolves the structural ownership problem left open in pass 58:

- `B8F3` is **not** a separate table candidate
- it is part of the already-live `AC14` dispatch table rooted at `B8BB`
- the pass-58 selector-wrapper family is now mapped to exact selector-control byte values

---

## Retired / corrected labels

### Retire
`C1:B8F3..C1:B92B  ct_selector_wrapper_table_candidate`

### Reason
This is no longer the correct structural model.
`B8F3` is not the start of an independent table.
It is the `0x1C` entry position inside the larger `AC14` dispatch table rooted at `B8BB`.

---

## Strong labels

### C1:B8BB..C1:B95F  ct_inline_selector_control_dispatch_table    [strong]
- Directly dispatched by `C1:AC2E  JSR ($B8BB,X)`.
- `X` is formed from the non-negative inline selector-control byte read by `AC14`.
- Proven table span in this pass runs from selector-control byte `0x00` through `0x52`.
- Includes the previously isolated pass-58 selector-wrapper family as the `0x27..0x38` subrange.

### C1:AC14..C1:AC45  ct_resolve_inline_selector_control_byte_into_selection_result    [strengthened]
- Reads the next selector-control byte from the CC stream.
- If negative, uses the preset path through `AED8`.
- Otherwise dispatches through `ct_inline_selector_control_dispatch_table`.
- Mirrors the resulting selection scratch from `AECC` into `AD8E` and records `B2AE = AECC`.

---

## Strong opcode-context upgrades inside the selector-control table

### selector-control `0x27..0x2E`  ct_fixed_single_entry_selector_wrappers_3_through_10    [strong]
- Exact control-byte mapping is now proved:
  - `0x27 -> AAAB`
  - `0x28 -> AAB6`
  - `0x29 -> AAC1`
  - `0x2A -> AACC`
  - `0x2B -> AAD7`
  - `0x2C -> AAE2`
  - `0x2D -> AAED`
  - `0x2E -> AAF8`

### selector-control `0x2F`  ct_build_withheld_tail_candidate_list_and_random_reduce_to_one    [strengthened]
- `AB03` is now not only structurally understood, but also placed at an exact selector-control byte value.

### selector-control `0x30..0x36`  ct_fixed_single_entry_selector_wrappers_0_through_6    [strong]
- Exact control-byte mapping is now proved:
  - `0x30 -> AB4E`
  - `0x31 -> AB59`
  - `0x32 -> AB64`
  - `0x33 -> AB6F`
  - `0x34 -> AB7A`
  - `0x35 -> AB85`
  - `0x36 -> AB90`

### selector-control `0x37`  ct_select_one_visible_entry_0_1_2_by_min_lane_value    [strengthened]
- `AB9B` now has an exact selector-control byte value.

### selector-control `0x38`  ct_build_live_tail_slot_candidate_list_and_random_reduce_to_one    [strengthened]
- `ABC9` now has an exact selector-control byte value.

---

## Important interpretation correction

### Old narrow label: “group-3 table at `B8BB`”
This wording is now too narrow.

What is directly proved is broader:
- `B8BB..B95F` is a selector-control dispatch table
- `AC14` uses it to resolve inline selector-control bytes
- the pass-58 wrapper family is simply one mid-table subrange

So future passes should stop describing `B8F3` as a separate table candidate.

---

## Still open

### `$0E` feeder into `AED3`
Pass 59 does **not** fully pin the wrapper that translates selected slot indices into the occupant ID consumed by `AED3`.

But the structural search space is now much smaller:
- ownership is confirmed under `AC14 -> B8BB`
- the best remaining candidate range is the late selector-control family:
  - `0x46..0x52`
  - `AFB6..B03A`

---

## Suggested next seam
1. decode selector-control bytes `0x39..0x52`
2. prioritize `0x46..0x52` because they are the strongest current bridge candidates toward deferred reinsertion semantics
3. then revisit the `$0E -> AED3` problem with the corrected one-table model


---

## Pass 60

# Chrono Trigger Labels - Pass 60

## Purpose
This file records the label upgrades and caution corrections justified by pass 60.

Pass 60 proves that the late selector-control band is not simply “more selector wrappers.”
It opens a distinct **late selector-pack executor** centered on:

- `AFD7..B08E`
- `CC:8B08`
- `B4AA`
- `B80D`

It also tightens the caution around the mechanically parsed tail of the `B8BB` table.

---

## Strong labels

### CC:8B08..CC:8C53  ct_late_selector_control_pointer_records                          [strong structural]
- Indexed at 4-byte stride by the late selector-control family.
- `AFD7` proves the first word of each record is used as a pointer seed.
- For `0x49..0x52`, the first-word pointers land in `CC:A77B`, `A7E5`, `A8E5`, `A96A`, `AA1F`, `AAE2`, `ABB5`, `ACDD`, `AD5B`, and `ADFF`.
- The second word of each 4-byte record remains unresolved and should not be named yet.

### C1:AFD7..C1:B08E  ct_execute_late_selector_pack_and_capture_tail_result            [strong structural]
- Top-level late-family executor proved in this pass.
- Loads a pointer from `ct_late_selector_control_pointer_records`.
- Uses `B4AA` to select/adjust the current FE/FF-delimited segment.
- Reads the current sub-op byte into `B239`.
- Dispatches the sub-op through `B80D`.
- Optionally dispatches a second chained sub-op at `+4` when `B1CF != 0`.
- Captures the resulting `AF24` status into tail-local scratch/status arrays.
- May chain to another FE-delimited segment.

### 7E:B239  ct_current_late_selector_pack_subopcode                                  [strong]
- Loaded from `CC:[B1D2 + 0]` immediately before the `B80D` dispatch.
- This is the current sub-op byte executed by the late selector-pack executor.

### 7E:B1CF  ct_late_selector_segment_has_chained_second_subopcode_flag               [strong]
- Set when `CC:[current_segment + 4] != FE`.
- Governs whether the late executor dispatches a second 4-byte sub-op from `+4`.

---

## Strong label upgrades

### C1:B4AA..C1:B4E6  ct_select_tail_local_segment_within_late_selector_pack          [strengthened structural]
- Previously just an opaque helper reached from the late family.
- Pass 60 proves it is the segment-selection / pointer-adjust helper that sits between:
  - the pointer-record seed at `AFD7`
  - and the `B80D` sub-op dispatch.
- Exact gameplay-facing noun remains open, but “late selector pack segment selector” is now justified.

### 7E:B24A..7E:B251  ct_tail_late_selector_result_status_bytes                        [strengthened structural]
- `B24A[B252]` captures `AF24` after the current late-pack sub-op execution.
- The exact meaning of each result code is still open.
- Structural role as per-tail late-executor status capture is now strong.

---

## Provisional but useful labels

### 7E:B263..7E:B26A  ct_tail_late_selector_has_following_segment_flags                [provisional]
- Incremented when another FE-delimited segment is found and execution chains forward.
- Cleared when no following segment remains.
- Strongest safe reading so far: per-tail “has additional late-pack segment / chained segment present” flag or counter.

### 7E:B242..7E:B249  ct_tail_late_selector_nonzero_result_mark_bytes                  [provisional]
- Set to `FF` on the nonzero-`AF24` path inside `ct_execute_late_selector_pack_and_capture_tail_result`.
- Exact higher-level noun remains unresolved.

---

## Important caution corrections

### Do **not** globalize late selector-control bytes `0x46..0x48` as normal standalone handlers yet
Pass 60 shows these entries land in stack-sensitive/common-tail code without enough local setup to promote them as ordinary top-level selector-control handlers.

Keep them as:
- late-range alias candidates
- overrun candidates
- or context-dependent entrypoints

but **not** as globally promoted normal standalone selectors.

### Do **not** globalize late selector-control bytes `0x51..0x52` as normal standalone handlers yet
These land deep inside the status/continuation logic of the late-pack executor and are not yet justified as clean standalone top-level control bytes.

Keep them provisional.

---

## Interpretation upgrade

### Old broad reading from pass 59
“late selector-control range `0x46..0x52` is the best bridge candidate into `$0E -> AED3` reinsertion semantics”

### New stronger reading after pass 60
The late band instead opens a different subsystem seam:

- pointer-record lookup at `CC:8B08`
- FE/FF-delimited late-pack execution
- secondary sub-op dispatch through `B80D`
- per-tail result capture in `B24A/B242/B263`

So future passes should stop treating this band as the most likely direct reinsertion bridge.

---

## Suggested next seam
1. decode the `B80D` late-pack sub-op family
2. identify downstream consumers of `B24A`, `B242`, and `B263`
3. only then re-open the deferred-tail materialization search with this late-pack executor separated out cleanly


---

## Pass 61

# Chrono Trigger Labels - Pass 61

## Purpose
This file records the architectural correction justified by pass 61.

Pass 61 proves that `C1:B80D` is the real master bank-C1 opcode dispatcher, and that the previously-carried command/selector tables are interior slices of that same master table.

It also corrects the provisional meaning of `B242[x]`.

---

## Strong labels

### C1:B80D..C1:B95F  ct_c1_master_opcode_dispatch_table                               [strong architectural]
- Root indexed `JSR` table used by the late-pack executor.
- Interior slices line up exactly with the previously solved local tables.
- Current proven slice offsets:
  - global `0x29..0x3F` -> `B85F..B88C`
  - global `0x40..0x52` -> `B88D..B8BA`
  - global `0x57..0xA9` -> `B8BB..B95F`

### C1:B85F..C1:B88C  ct_c1_group1_opcode_dispatch_slice                              [strong correction]
- Keep the useful local group-1 numbering from earlier passes.
- But this is now proved to be a slice entrypoint inside `ct_c1_master_opcode_dispatch_table`, not an independent root table.

### C1:B88D..C1:B8BA  ct_c1_group2_opcode_dispatch_slice                              [strong correction]
- Same correction as the group-1 table.
- Useful local numbering remains valid.
- Root ownership now belongs to `ct_c1_master_opcode_dispatch_table`.

### C1:B8BB..C1:B95F  ct_c1_inline_selector_control_dispatch_slice                    [strong correction]
- Same correction again for the selector-control table.
- `AC14` still dispatches here by local selector-control byte.
- But this slice is inside the same master dispatch table rooted at `B80D`.

### 7E:B242..7E:B249  ct_tail_last_executed_global_opcode_bytes                       [strong]
- Directly proved by:
  - `LDA B239`
  - `STA B242,X`
- Holds the per-tail last executed global opcode byte.
- This corrects the older provisional “nonzero result mark” read.

### C1:8C0A..C1:8CF7  ct_replay_tail_pack_segments_and_record_per_tail_state          [strong structural]
- Front-end clears/rebuilds per-tail replay state for the live, unwithheld tail map.
- Records executed global opcode bytes into `ct_tail_last_executed_global_opcode_bytes`.
- Records result/status bytes into `B24A[x]`.
- Records whether additional FE-delimited work remains into `B263[x]`.
- Advances/resumes execution from later CC bytes after segment completion.
- Proven to resume through the group-1 dispatch slice when the next resumed byte is non-negative.

---

## Strong label upgrades

### 7E:B239  ct_current_c1_master_opcode_byte                                         [strengthened]
- Previously carried as a late-pack subopcode byte.
- Pass 61 proves the stronger architectural read:
  - it is the current opcode byte fed into the master C1 dispatcher.
- In the late-pack flow, it is the current pack-sourced global opcode byte.

### 7E:B24A..7E:B251  ct_tail_last_opcode_result_status_bytes                         [strengthened]
- Pass 60 already proved these bytes capture `AF24` after execution.
- Pass 61 strengthens the surrounding controller context by pairing them directly with:
  - `ct_tail_last_executed_global_opcode_bytes`
  - `B263[x]`
- Best safe read now: per-tail last-op result/status bytes.

### 7E:B263..7E:B26A  ct_tail_has_additional_pack_segment_flags                       [strengthened]
- Still not fully finalized as a gameplay-facing noun.
- But pass 61 strengthens the structural role:
  - controller-managed per-tail flag/counter for whether later FE-delimited work remains after the current executed segment.

---

## Important corrections to older wording

### Do **not** keep calling `B80D` a dedicated late-pack subopcode table
That is now too narrow.

Use:
- **master C1 opcode dispatch table**

### Do **not** keep treating `B85F`, `B88D`, and `B8BB` as independent top-level root tables
They are still useful local slice entrypoints, but the stronger architectural ownership is now:
- all three are slices inside `ct_c1_master_opcode_dispatch_table`

### Do **not** keep the old provisional label for `B242[x]`
The bytes prove it stores the executed opcode byte itself, not a boolean/nonzero result mark.

---

## Best current architecture statement
The late-tail executor should now be described as:

- pointer-record selected (`CC:8B08`)
- FE/FF-delimited pack execution (`AFD7..B08E`)
- replay/control and per-tail state recording (`8C0A..8CF7`)
- all running over the shared `ct_c1_master_opcode_dispatch_table`

That is the cleanest carry-forward model after pass 61.

---

## Suggested next seam
1. decode the early global opcode band inside `ct_c1_master_opcode_dispatch_table`
2. pin the exact resume conditions that choose:
   - group-1 slice continuation
   - selector-control slice continuation
3. then re-open deferred-tail reinsertion from the corrected dispatcher model


---

## Pass 62

# Chrono Trigger Labels — Pass 62

## Purpose
This file records the new global-opcode mappings justified by pass 62.

The main result is that several early entries in the corrected master `C1:B80D` opcode space are now proved to be **replay/control-flow gates** rather than opaque effect bodies.

Their shared contract is:
- success -> `JSR $8C3E`
- failure -> `LDA #$01 / STA $AF24 / RTS`

---

## Strong labels

### C1:8EA7..C1:8EAA  ct_global_opcode_00_unconditional_tail_replay_step                [strong]
- Direct body is only: `JSR $8C3E ; RTS`.
- Global opcode `00` is therefore an unconditional handoff into the tail replay/controller layer.
- This is a master-table opcode mapping, not a standalone subsystem root.

### C1:9013..C1:9043  ct_global_opcode_05_gate_tail_replay_by_live_unwithheld_tail_count_max [strong]
- Reads one immediate operand byte from `CC:[B1D2 + 1]`.
- Counts tail entries where:
  - `AF02[x] != FF`
  - and `AF15[x] == 0`
- Success path is taken when the resulting count is **less than or equal to** the immediate operand.
- Success -> `JSR $8C3E`
- Failure -> `AF24 = 1`
- This strengthens the old pass-57 count gate by pinning the compare direction.

### C1:9045..C1:9081  ct_global_opcode_06_gate_tail_replay_when_96f1_96f3_triplet_gte_immediate [strong structural]
- Reads a 3-byte immediate operand from `CC:[B1D2 + 1..3]`.
- Compares that operand lexicographically against current WRAM bytes:
  - `96F1`
  - `96F2`
  - `96F3`
- Success when current triplet >= immediate triplet.
- Success -> `JSR $8C3E`
- Failure -> `AF24 = 1`
- Gameplay-facing noun for `96F1..96F3` remains intentionally open.

### C1:9082..C1:90BD  ct_global_opcode_07_gate_tail_replay_on_current_b320_compare_mode [strong structural]
- Reads compare byte from `CC:[B1D2 + 1]` and mode byte from `CC:[B1D2 + 2]`.
- Uses current slot index `B252` to read `B320[B252]`.
- Proven compare modes:
  - mode `!= 1` -> success when `B320[current] >= operand1`
  - mode `== 1` -> success when `B320[current] <= operand1`
- Success -> `JSR $8C3E`
- Failure -> `AF24 = 1`
- Final gameplay-facing noun for `B320[x]` still wants more caller proof.

### C1:97AB..C1:97BF  ct_global_opcode_20_gate_tail_replay_on_current_aeb3_nonzero      [strong structural]
- Uses current index `B252`.
- Reads `AEB3[B252]`.
- Success only when that byte is nonzero.
- Success -> `JSR $8C3E`
- Failure -> `AF24 = 1`
- Final gameplay-facing noun for `AEB3[x]` is still intentionally open.

### C1:97C0..C1:97D4  ct_global_opcode_21_gate_tail_replay_on_current_af15_zero         [strong structural]
- Immediate adjacent sibling of opcode `20`.
- Uses current index `B252`.
- Success only when `AF15[B252] == 0`.
- Success -> `JSR $8C3E`
- Failure -> `AF24 = 1`
- Useful carry-forward proof that opcode `20` is part of a real replay-gate family.

---

## Provisional labels

### 7E:96F1..7E:96F3  ct_c1_global_24bit_replay_gate_triplet_state                       [provisional]
- Pass 62 proves these three bytes are compared lexicographically against the immediate operand in global opcode `06`.
- Earlier work already showed they are globally cleared by another command family.
- The mechanical role is now real.
- The gameplay/system-facing noun still wants more caller-side proof.

---

## Important carry-forward notes

### Do not over-globalize the gate-family result yet
Pass 62 proves a real replay/control subset in the early master-table band.
That does **not** mean every early opcode is a gate.
`01` and `02` still look like heavier selector/filter bodies.

### Do not freeze gameplay nouns for `96F1..96F3`, `B320[x]`, or `AEB3[x]` yet
The byte-level mechanics are now strong.
The higher-level subsystem nouns remain open.

### Do keep the new success/failure contract in mind
For the solved subset here, the important pattern is:
- success -> replay/controller continuation through `8C3E`
- failure -> `AF24 = 1`

That is the cleanest architectural carry-forward from pass 62.


---

## Pass 63

# Chrono Trigger Labels — Pass 63

## Purpose
This file records the label upgrades and one correction justified by pass 63.

The main result is that the early master-opcode band now contains a real selector/list-transform subfamily beside the simpler replay gates.

It also corrects one stale carry-forward mistake:
- global master opcode `04` is **not** the old slice-era `B815` body
- the real master-table entry for `04` is `C1:8FDA`

---

## Strong labels

### C1:8EAB..C1:8F10  ct_global_opcode_01_filter_selected_entries_by_fd_record_threshold   [strong structural]
- Calls `AC14`, so operand `+1` is an inline selector-control byte.
- Uses the resulting `AECC/AECB` selected list as input.
- For each selected entry:
  - resolves a structured-record base via `FD:A80B`
  - requires record byte `+1D` to be non-negative
  - accepts only when record byte `+3` is less than or equal to `(record byte +5) >> 1`
- Accepted entries are incremented in-place in `AECC`.
- Writes accepted-count back to `AECB`.
- Runs `AE21`, then if `AF24 == 0` runs `AEFD` and `8C3E`.
- Empty input selection does **not** force `AF24 = 1`.
- Best carried as a selector-driven filtered-list transform, not a pure boolean gate.

### C1:8F11..C1:8F81  ct_global_opcode_02_filter_head_or_nonhead_selected_entries_by_lane_flag_mask [strong structural]
- Operand `+1` chooses which fixed selector-control byte is dispatched through `AC2C`:
  - operand1 `== 0` -> selector-control `0x01` -> visible/head occupied entries (`A3F7`)
  - operand1 `!= 0` -> selector-control `0x16` -> non-head occupied entries (`A6ED`)
- Operands `+2/+3` are used as:
  - byte offset inside the lane block
  - required bitmask
- For each selected entry:
  - reads `5E4A + selected_entry*0x80 + operand2`
  - accepts only when `(byte & operand3) == operand3`
- Accepted entries are incremented in-place in `AECC`.
- Zero survivors -> `AF24 = 1`.
- Successful survivors finalize through `AE21`, `AEFD`, and `8C3E`.

### C1:8F87..C1:8FD9  ct_global_opcode_03_filter_selected_entries_by_occupant_index_equals_immediate [strong structural]
- Calls `AC14`, so operand `+1` is an arbitrary inline selector-control byte.
- Requires a non-empty selected list from `AECC/AECB`.
- Consumes the next immediate byte and accepts only selected entries where:
  - `AEFF[selected_entry] == immediate`
- Accepted entries are incremented in-place in `AECC`.
- Zero survivors -> `AF24 = 1`.
- Successful survivors finalize through `AE21`, `AEFD`, and `8C3E`.
- Strong structural sibling to opcode `02`, but using arbitrary `AC14` selection plus occupant-equality filtering.

### C1:8FDA..C1:9012  ct_global_opcode_04_gate_tail_replay_on_live_tail_occupant_presence_mode [strong]
- Scans live tail occupant map `AF02[0..AEC6-1]` for operand1.
- Operand2 selects the sense:
  - operand2 `== 0` -> success only when operand1 is present
  - operand2 `!= 0` -> success only when operand1 is absent
- Success -> `JSR $8C3E`
- Failure -> `AF24 = 1`
- This is the corrected master-table meaning of global opcode `04`.

---

## Strong correction

### Global master opcode `04` old carry-forward mapping should be retired
Retire the stale line that treated global opcode `04` as the old group-1 local `0x04` body at `C1:B815`.

The correct master-table mapping is:

- global opcode `04 -> C1:8FDA`

This matters because pass 61 proved `B80D` is the master table and later slice tables are not independent roots.

---

## Provisional / caution notes

### `01` still wants a final gameplay noun
The record test in `01` is strong mechanically.
It is suggestive that the `FD:A80B`-selected base plus offsets `+3/+5` line up with the already-solved lane block rooted at `5E2D`, but that final noun should stay open for now.

### Do not over-freeze the in-place increment yet
In all three list-transform bodies `01/02/03`, accepted entries are incremented in-place in `AECC` before finalization.
That behavior is real.
Its final higher-level meaning is still open.

### `AE21` still wants a dedicated pass
Pass 63 strengthens the caller context around `AE21`, but does not yet freeze its final noun.
Keep treating it as an existing finalize/reduction helper whose full human-facing meaning remains open.

---

## Carry-forward summary
The early master-opcode band now has a much cleaner structure:

- `00` unconditional replay
- `01/02/03` selector/list-transform bodies
- `04/05/06/07/20/21` hard replay gates

That is the main label-level gain from pass 63.


---

## Pass 64

# Chrono Trigger Labels — Pass 64

## Purpose
This file records the label upgrades and corrections justified by pass 64.

The biggest result is that `AE21` is no longer a vague helper.
It is the reducer that collapses marked selected entries down to one chosen entry or raises `AF24`.

That forces a cleanup in how the surrounding early global opcodes are named.

---

## Strong labels

### C1:AE21..C1:AE6F  ct_reduce_marked_selected_entries_to_single_choice_or_fail   [strong structural]
- Empty input selection increments `AF24` and returns.
- Requires a bit-7-marked chosen entry to succeed.
- On success:
  - strips bit 7
  - writes the chosen entry into `AECC[0]`
  - writes `AECB = 1`
- On failure increments `AF24`.
- Multi-entry path uses a low-nibble comparison against the `C1:B163` byte stream before accepting a marked entry.
- Exact higher-level ranking noun is still open, but the reducer contract itself is now strong.

### C1:90BE..C1:912F  ct_global_opcode_08_mark_selected_entries_by_fd_record_word3_le_immediate_then_reduce   [strong structural]
- Calls `AC14`.
- Empty selection -> failure.
- Reads a 16-bit immediate threshold.
- For each selected entry:
  - resolves the `FD:A80B` record base
  - reads the 16-bit field at record offset `+3`
  - marks the entry in `AECC` with bit 7 when `record_word_+3 <= immediate_word`
- Stores the number of marked entries in `AECB`.
- Then calls `AE21`, `AEFD`, and `8C3E` on success.

### C1:918E..C1:91F8  ct_global_opcode_0A_gate_tail_replay_on_priority_selected_entry_record_mask_clear   [strong structural]
- Calls `AC14`.
- Empty selection -> failure.
- If only one entry is selected, uses it directly.
- If multiple entries are selected, reduces them to one chosen entry using WRAM vector `B23A[0..7]`.
- Operand `+1` is a record-byte offset.
- Operand `+2` is an immediate mask.
- Succeeds only when the chosen entry's `FD:A80B` record byte at that offset has no overlapping bits with the mask.
- Success goes directly to `8C3E`.
- Failure sets `AF24 = 1`.

---

## Provisional structural labels

### C1:9130..C1:918D  ct_global_opcode_09_scan_selected_entries_for_fd_record_byte_offset_gte_immediate_then_reduce   [provisional structural]
- Calls `AC14`.
- Empty selection -> failure.
- Operand `+1` is a byte offset inside the `FD:A80B` record.
- Operand `+2` is the compare byte.
- Scans the selected entries and breaks to `AE21` on the first entry where:
  - `record_byte >= immediate`
- Fails if the scan completes with no hit.
- This body does **not** mark `AECC` entries itself before calling `AE21`, so the precise final selected-entry effect should remain open.

### C1:91F9..C1:925C  ct_global_opcode_0B_scan_selected_entries_for_fd_record_byte_offset_lte_immediate_then_reduce   [provisional structural]
- Calls `AC14`.
- Empty selection -> failure.
- Operand `+1` is a byte offset inside the `FD:A80B` record.
- Operand `+2` is the compare byte.
- Scans the selected entries and breaks to `AE21` on the first entry where:
  - `record_byte <= immediate`
- Fails if the scan completes with no hit.
- Like opcode `09`, this body does not mark `AECC` entries itself before `AE21`.

---

## Important corrections

### retire the old “generic finalize helper” wording for `AE21`
Keep the stronger wording instead:

> **reduce marked selected entries to one chosen entry or fail**

### retire the old “increments selected entries in place” wording for the OR-`0x80` writes
Those writes are candidate-mark operations for `AE21`, not arithmetic increments.

This correction directly sharpens the already-solved caller family:
- opcode `01`
- opcode `02`
- opcode `03`
- opcode `08`

---

## Carry-forward family cleanup

### marked-candidate reducer family
These now belong together:

- `01`
- `02`
- `03`
- `08`

They:
- start from `AC14`
- mark candidate entries with bit 7
- call `AE21`
- continue through `AEFD` and `8C3E` if `AF24 == 0`

### direct chosen-entry gate
Opcode `0A` is not part of that family.
It reduces to one chosen entry itself and then performs a direct bit-clear replay gate.

### scan-into-reducer wrappers
Opcodes `09` and `0B` are adjacent but slightly different:
- they scan selected entries for a compare hit
- they hand off to `AE21`
- but they do not themselves mark `AECC` entries in the visible body

That distinction should be preserved until a later pass fully resolves their incoming mark-state assumptions.


---

## Pass 65

# Chrono Trigger Labels — Pass 65

## Purpose
This file records the label upgrades justified by pass 65.

The biggest result is the split inside the early master-opcode seam:
- `0C/0D/0E/0F/10` are relation-query wrappers / gates
- `11/12` are not; they are direct current-slot quad-record gates over `B19E/B19F + 4*B252`

---

## Strong structural labels

### C1:925D..C1:92A2  ct_global_opcode_0C_gate_tail_replay_on_relation_mode04_current_subject_vs_selection_head   [strong structural]
- Calls `AC14`.
- Empty selection -> `AF24 = 1`.
- Seeds relation-query mode `04` with:
  - `986F = B252 + 3`
  - `9870 = AECC[0]`
- Calls service `5` through `JSR $0003`.
- Operand `+1` selects the final zero/nonzero polarity of `9872`.
- Success writes `AECB = 1` and continues through `8C3E`.

### C1:938D..C1:93E5  ct_global_opcode_0F_gate_tail_replay_on_relation_mode08_current_subject_vs_selection_head   [strong structural]
- Calls `AC14`.
- Empty selection -> `AF24 = 1`.
- Seeds relation-query mode `08` with:
  - `986F = B252 + 3`
  - `9870 = AECC[0]`
  - `9871 = (operand2 << 2) | 1`
- Operand `+1` selects the final zero/nonzero polarity of `9872`.
- Success continues through `8C3E`.
- Pre-write `9872 = 05` is dead for normal service-5 flow because `2986` clears `9872` before dispatch.

### C1:93E6..C1:9429  ct_global_opcode_10_gate_tail_replay_on_current_subject_row_column_band_query   [strong structural]
- Does not call `AC14`.
- Selects relation mode `09/0A/0B/0C` from operands `+2/+3`.
- Uses current subject slot `986F = B252 + 3`.
- Succeeds only when the chosen mode leaves `9872 == 0`.
- Effective success regions are:
  - mode `09`: `Y>>4 >= 0x08`
  - mode `0A`: `Y>>4 < 0x08`
  - mode `0B`: `X>>4 >= 0x0B`
  - mode `0C`: `X>>4 < 0x05`

### C1:942A..C1:9473  ct_global_opcode_11_gate_tail_replay_on_current_b19e_upper_nibble_class   [strong structural]
- Direct current-slot gate, not a relation-query wrapper.
- Computes `X = B252 * 4`.
- Reads `B19E[X] & 0xF0`.
- Operand `+1` selects target class `0x40` vs `0x50`.
- Operand `+3` selects equality vs inequality.
- Success continues through `8C3E`; failure sets `AF24 = 1`.

### C1:9474..C1:94D1  ct_global_opcode_12_gate_tail_replay_on_current_b19e_b19f_pair_mode   [strong structural]
- Direct current-slot gate, not a relation-query wrapper.
- Computes `X = B252 * 4`.
- Reads:
  - `B19E[X] & 0xF0`
  - `B19F[X]`
- Operand `+1` selects target high nibble `0x40` vs `0x50`.
- Operand `+2` selects exact second-byte compare value.
- Operand `+3 == 0` -> both comparisons must match.
- Operand `+3 != 0` -> both comparisons must differ.

---

## Provisional structural labels

### C1:92A3..C1:9313  ct_global_opcode_0D_mark_non_subject_selected_entries_by_relation_mode05_zero_then_reduce   [provisional structural]
- Calls `AC14`.
- Sets current subject slot `986F = B252 + 3`.
- Uses relation-query mode `05`.
- Skips the subject slot if it appears in the selected list.
- Marks selected entries whose mode-`05` result leaves `9872 == 0`.
- Mode `05` is now known strongly enough to be the close-Y / `abs(subject_y - arg_y) < 0x20` predicate.
- Marked candidates are reduced through `AE21`.
- Final replay gate still depends on residual `9872` plus operand `+1`, so the top-level human-facing contract should stay provisional.

### C1:9314..C1:938C  ct_global_opcode_0E_mark_non_subject_selected_entries_by_parameterized_relation_mode_zero_then_reduce   [provisional structural]
- Same structural family as `0D`.
- Seeds relation mode with `986E = operand2 + 0x06`.
- Skips the current subject slot.
- Marks selected entries whose query leaves `9872 == 0`.
- Reduces them through `AE21`.
- Final replay gate still depends on residual `9872` plus operand `+1`.

---

## Supporting interpretation upgrades

### C1:2BBC  relation-query mode `05`   [strong structural support]
- Absolute Y-delta test over `1D23`.
- Leaves `9872 = 00` when `abs(subject_y - arg_y) < 0x20`.
- Leaves `9872 = FF` otherwise.

### C1:2BDA  relation-query mode `06`   [strong structural support]
- Vertical ordering test over `1D23`.
- Leaves `9872 = 00` when `subject_y < arg_y`.
- Leaves `9872 = FF` otherwise.

### C1:2CA7 / C1:2CBA / C1:2CCD / C1:2CE0   relation-query modes `09..0C`   [strong structural support]
- These are coarse row/column band predicates over the current subject slot.
- `09/0A` use `1D23 >> 4`.
- `0B/0C` use `1D0C >> 4`.

---

## Corrections to carry forward
- Do not keep describing opcode `0E` as a fixed mode-`06` wrapper. It is parameterized by operand `+2`.
- Do not keep extending the relation-query family through opcode `12`. That overstates the shared structure. `11/12` are direct record gates.
- Opcode `10` is now stronger than “mode picker” wording; it is a real current-subject row/column band gate.


---

## Pass 66

# Chrono Trigger Labels — Pass 66

## Purpose
This file records the label upgrades justified by pass 66.

Pass 66 closes most of the remaining direct-record / early-control seam opened by pass 65:

- `13/14/15` are the continuation of the current-slot record gate band
- `16/19` are pure replay aliases
- `17/1B/22` are simple gate bodies
- `18/1C/1F` are stronger structurally, but still want caution on the final noun

---

## Strong labels

### C1:94D2..C1:9513  ct_global_opcode_13_gate_tail_replay_on_current_b19e_bit4_match_mode   [strong structural]
- Computes `X = B252 * 4`.
- Reads `B19E[X] & 0x10`.
- Operand `+1` bit `0` selects the target bit state (`0x00` vs `0x10`).
- Operand `+3` selects equality vs inequality.
- Success continues through `8C3E`; failure sets `AF24 = 1`.

### C1:959A..C1:95D5  ct_global_opcode_15_gate_tail_replay_on_current_b1a0_mask_match_mode   [strong structural]
- Computes `X = B252 * 4`.
- Reads `B1A0[X]`.
- Operand `+1` is a required mask.
- Operand `+3 == 0` -> require full-mask containment.
- Operand `+3 != 0` -> require non-match.

### C1:95D6..C1:95D9  ct_global_opcode_16_unconditional_tail_replay_step_alias   [strong]
- Exact alias of the unconditional `8C3E ; RTS` replay step.

### C1:95DA..C1:95F9  ct_global_opcode_17_gate_tail_replay_on_rng_percent_below_immediate   [strong structural]
- Calls the known RNG helper at `AF22` with `A = 0x64`.
- Succeeds only when the returned value is below operand `+1`.

### C1:9652..C1:9655  ct_global_opcode_19_unconditional_tail_replay_step_alias   [strong]
- Exact alias of the unconditional `8C3E ; RTS` replay step.

### C1:96A5..C1:96D3  ct_global_opcode_1B_gate_tail_replay_on_visible_head_live_count_at_or_below_immediate   [strong structural]
- Counts non-`FF` entries in `AEFF[0..2]`.
- Uses `operand+1 + 1` internally, so the effective success predicate is:
  - visible-head live count `<= operand+1`

### C1:9728..C1:975B  ct_global_opcode_1D_gate_tail_replay_on_selected_tail_live_presence_mode   [strong structural]
- Calls `AC14`.
- Uses `AECC[0]` as the selected entry index.
- Reads `AF02[selected]`.
- Operand `+2` selects presence vs absence polarity.

### C1:975C..C1:9764  ct_global_opcode_1E_unconditional_tail_replay_then_abort   [strong structural]
- Always runs `8C3E`.
- Then always writes `AF24 = 1`.

### C1:97D5..C1:980F  ct_global_opcode_22_gate_tail_replay_on_selected_b158_threshold_mode   [strong structural]
- Calls `AC14`.
- Uses `AECC[0]` as the selected entry index.
- Reads `B158[selected]`.
- Operand `+1` is the threshold.
- Operand `+2 == 0` -> success on `< threshold`
- Operand `+2 != 0` -> success on `>= threshold`

---

## Provisional / strengthened labels

### C1:9514..C1:9599  ct_global_opcode_14_gate_tail_replay_on_current_b19e_bit4_clear_selector_mode   [provisional structural]
- Two-form handler.
- In the primary form (`operand+2 == 0`):
  - requires current `B19E[X]` bit 4 clear
  - uses `B19E[X] & 0x0F` to index `AF0A[...]`
  - compares that byte against operand `+1`
  - operand `+3` selects equality vs inequality
- In the alternate form (`operand+2 != 0`):
  - still requires current `B19E[X]` bit 4 clear
  - then effectively collapses to:
    - operand `+3 == 0` -> fail
    - operand `+3 != 0` -> success
- The apparent `01/02/05` compare chain in the alternate branch should not be overclaimed as real content logic.

### C1:95FA..C1:9651  ct_global_opcode_18_reduce_selected_entries_by_indirect_table_byte_equals_immediate   [provisional structural]
- Calls `AC14`.
- Scans selected entries in `AECC`.
- Resolves an `FD:A80B` record-rooted value and uses it as the `Y` component of `LDA ($0A),Y`.
- On equality with operand `+1`, reduces through `AE21`, then `AEFD`, then `8C3E`.
- Keep provisional because the base-pointer setup through `$0A/$0B` still wants harder confirmation.
- Important context: master opcodes `23..28` all alias back to this same body.

### C1:9656..C1:96A4  ct_global_opcode_1A_gate_tail_replay_on_live_tail_occupant_search_mode   [strengthened structural]
- Scans the live-tail occupant submap `AF02[0..AEC6-1]` for operand `+1`.
- Dead leading `LDA $B252` should be ignored; the real scan starts from `X = 0`.
- Operand `+2` enables a mode that skips current-slot hits and requires another matching live-tail entry.
- Operand `+3` controls the final success gate once a usable match is found.

### C1:96D4..C1:9727  ct_global_opcode_1C_optionally_replay_on_selected_head_canonical_membership_then_abort   [provisional structural]
- Calls `AC14`.
- Searches `AF0A[0..2]` for a byte equal to `AECC[0]`.
- Uses operand `+2` plus optional `AEFF[x] != FF` live-head confirmation to decide whether to call `8C3E`.
- Always exits with `AF24 = 1`, even after replay.

### C1:9765..C1:97AA  ct_global_opcode_1F_gate_tail_replay_on_relation_mode0E_current_subject_vs_selection_head   [strengthened structural]
- Calls `AC14`.
- Seeds relation-query mode `0E` with:
  - `986F = B252 + 3`
  - `9870 = AECC[0]`
- Operand `+1` selects the final zero/nonzero gate on `9872`.
- Success forces `AECB = 1` and continues through `8C3E`.
- Keep the wrapper label strong-structural, but do not pretend mode `0E`'s underlying noun is already frozen.

---

## Supporting interpretation upgrades

### C1:2CF3..C1:2D80  relation-query mode `0E` body   [strengthened context]
- This mode is no longer best imagined as a trivial boolean compare.
- The body pulls projected position pairs from `1D0C/1D23`, computes two subject-relative squared-distance-like values, differences them, normalizes the result through `0116`, and returns a value through `9873`.
- That is why opcode `1F` should stay “mode-0E wrapper” rather than a fake-final gameplay noun.

---

## Important corrections to carry forward

### Opcode `14`
Do not keep over-claiming a rich subtype decoder in the `operand+2 != 0` branch.
That branch collapses far more bluntly than it first appears.

### Opcode `1A`
Do not keep describing the scan as starting from `B252`.
The `LDA $B252` is dead before `TDC/TAX`.

### Opcode `1C`
Do not describe it as a normal replay gate.
It always writes `AF24 = 1` after the optional replay call.

### Opcode `1F`
Do not finalize mode `0E` from wrapper shape alone.
The wrapper is clear; the underlying mode noun is still open.

---

## Suggested next seam
- Alias cluster `23..28`
- then `29..2F`
- plus a direct decode pass over relation-query mode `0E` at `2CF3`


---

## Pass 67

# Chrono Trigger Labels — Pass 67

## Purpose
This file records the label upgrades justified by pass 67.

Pass 67 closes the master-table seam immediately after global opcode `22`:

- exact alias run `23..28 -> 95FA`
- promotion of old group-1 local `00..06` into real global-master opcodes `29..2F`
- stronger bridge labels for the saved-seed writers feeding later seeded group-2 families

---

## Strong labels

### C1:9810..C1:9839  ct_global_opcode_29_persist_selected_head_and_inline_param_to_current_5e15_5e0d   [strong structural]
- Advances the stream, calls `AC14`, reads one inline byte, and stores:
  - `AEE5 -> 5E0D[current]`
  - `AECC[0] -> 5E15[current]`
- Strong bridge to later seeded group-2 opcode `01`.

### C1:983A..C1:98C3  ct_global_opcode_2A_2B_ordered_first_choice_persist_shared_body   [strong structural]
- Calls `AC14`.
- If multiple selected entries exist, collapses them to the first entry matching the external priority list in `B23A[0..7]`.
- Copies the chosen entry into `AECC[0]`.
- Then splits on `AEE3`:
  - non-`2` path persists into `5E0D[current] / 5E15[current]`
  - `2` path persists into `B16E[current]`
- Failure writes `B242[current] = FF` and `AF24 = 2`.

### C1:98C4..C1:98C4  ct_global_opcode_2C_rts_noop_alias   [strong]
- Exact single-byte `RTS`.

### C1:98C5..C1:995F  ct_global_opcode_2D_random_4way_stream_advance   [strong]
- Promoted global-master ownership of the already-solved group-1 random 4-way stream-control body.
- Uses RNG split ranges and `FD:BA4A`-driven stream advance.

### C1:9960..C1:9960  ct_global_opcode_2E_rts_noop_alias   [strong]
- Exact single-byte `RTS`.

### C1:9961..C1:9961  ct_global_opcode_2F_rts_noop_alias   [strong]
- Exact single-byte `RTS`.

---

## Exact opcode-alias entries

### Global `23..28`
All six master-table entries point directly to the existing opcode-`18` body at `C1:95FA`.

Carry-forward aliases:
- `23` = `ct_global_opcode_18_reduce_selected_entries_by_indirect_table_byte_equals_immediate`   [exact alias]
- `24` = same   [exact alias]
- `25` = same   [exact alias]
- `26` = same   [exact alias]
- `27` = same   [exact alias]
- `28` = same   [exact alias]

---

## Split labels inside the shared `2A/2B` body

### global opcode `2A`
Working global label:
- `ct_global_opcode_2A_reduce_selection_by_b23a_priority_then_persist_to_current_5e15_5e0d`   [strong structural]

Why:
- ordered-first-choice collapse through `B23A`
- stores chosen entry to `5E15[current]`
- stores one inline byte to `5E0D[current]`

### global opcode `2B`
Working global label:
- `ct_global_opcode_2B_reduce_selection_by_b23a_priority_then_persist_to_current_b16e`   [strong structural]

Why:
- ordered-first-choice collapse through `B23A`
- stores chosen entry to `B16E[current]`
- skips two stream bytes
- strong bridge to later seeded group-2 opcode `02`

---

## Important carry-forward notes

### `23..28`
Do not create six fake semantic labels here.
They are exact table aliases of opcode `18`.

### `2A/2B`
Do not flatten these into one final noun without mentioning the `AEE3` split.
The entrypoint is shared, but the persistent target differs in a way that matters:
- `5E15/5E0D`
- versus `B16E`

### `2D`
Do not leave this behind under old “group-1 opcode `04`” wording in later reports.
Its correct master-table identity is now:
- global opcode `2D`

---

## Suggested next seam
- promote / remap the rest of old group-1 local `07..16` into global `30..3F`
- then do the same ownership cleanup for old group-2 local `00..12` into global `40..52`


---

## Pass 68

# Chrono Trigger Labels — Pass 68

## Purpose
This file records the label upgrades justified by pass 68.

Pass 68 finishes the promotion of the old local `B85F` and `B88D` slices into their correct master-table globals:

- global `30..3F`
- global `40..56`

It also materially strengthens two old provisional bodies:

- `C1:9967`
- `C1:9981`

---

## Strong labels

### C1:9967..C1:9977  ct_global_opcode_32_capture_inline_param1_to_aee4   [strong structural]
- Reads the current stream byte at `CC:[B1D2 + 1]`.
- Stores it into `AEE4`.
- Does not locally advance `B1D2`.
- Best current reading: tiny inline-parameter capture body for later follow-up state.

### C1:9981..C1:99B3  ct_global_opcode_39_3F_gate_on_materializable_canonical_tail_slot_exists   [strong structural]
- Scans 8 tail slots.
- Accepts only when:
  - `AF0D[x] != FF`
  - `AF02[x] == FF`
  - `AF15.bit7` clear
- Success clears `AF24`; zero accepted entries force `AF24 = 2`.
- Exact alias body for global opcodes `39` and `3F`.

### C1:99B8..C1:99BD  ct_global_opcode_40_set_group2_continuation_2   [strong]
- Writes `B3B8 = 2` and returns.

### C1:99BE..C1:9A38  ct_global_opcode_41_seed_single_from_5e15_finalize   [strong structural]
- Promoted master ownership of the old group-2 `01` body.
- Seeds one entry from `5E15[current]`.
- Captures inline parameters into `AEE4/AEE5`.
- Uses unique long helper `FD:AB01`.
- Finalizes through `AC89/ACCE` with `B3B8 = 0`.

### C1:9A39..C1:9B45  ct_global_opcode_42_seed_from_b16e_validate_commit   [strong structural]
- Table-entry wrapper lands in `9A3D`.
- Seeds one entry from `B16E[current]`.
- Optionally resolves inline selectors through `AC14`.
- Validates through `C1DD` and commits through `AD09/AD35/FDAAD2/AC89/ACCE`.

### C1:9DCE..C1:9E61  ct_global_opcode_4D_bitmask_state_control   [strong]
- Promoted master ownership of the old group-2 `0D` state-control body.
- Operand bits drive a mix of per-slot and global control writes.

### C1:9E63..C1:9E77  ct_global_opcode_4F_optional_cd0033_then_set_continuation_2   [strong]
- If operand 1 is nonzero, calls `JSL $CD0033`.
- Then writes `B3B8 = 2` and returns.

### C1:9E78..C1:9F59  ct_global_opcode_50_materialize_tail_slots_from_canonical_map_finalize   [strong]
- Promoted master ownership of the old group-2 `10` body.
- Scans canonical/live/deferred tail state through `AF0D/AF02/AF15`.
- Builds selected entries and follow-up masks.
- Best current noun: materialize eligible tail slots from canonical map, then finalize.

### C1:9F5A..C1:9FD1  ct_global_opcode_51_group_base_write4_pairs   [strong]
- Promoted master ownership of the old group-2 `11` writer body.

### C1:9FD2..C1:A14D  ct_global_opcode_52_group_base_write5_pairs_validate   [strong]
- Promoted master ownership of the old group-2 `12` writer-plus-validation body.

### C1:A14E..C1:A187  ct_global_opcode_53_sat_signed_delta_to_current_b158   [strong]
- Promoted master ownership of the old group-2 `13` saturating signed-delta body.

### C1:A396..C1:A3D0  ct_global_opcode_56_wrapper_fused_fd_a990   [strong]
- Promoted master ownership of the old group-2 `16` thin wrapper around `FD:A990`.

---

## Exact alias / stub labels

### pure `RTS`
- `31` = `ct_global_opcode_31_rts_noop_alias`   [exact alias]
- `33` = `ct_global_opcode_33_rts_noop_alias`   [exact alias]
- `35` = `ct_global_opcode_35_rts_noop_alias`   [exact alias]
- `36` = `ct_global_opcode_36_rts_noop_alias`   [exact alias]
- `37` = `ct_global_opcode_37_rts_noop_alias`   [exact alias]
- `38` = `ct_global_opcode_38_rts_noop_alias`   [exact alias]
- `43` = `ct_global_opcode_43_rts_noop_alias`   [exact alias]
- `4E` = `ct_global_opcode_4E_rts_noop_alias`   [exact alias]

### `STZ AF24 ; RTS`
- `30` = `ct_global_opcode_30_clear_short_circuit_and_return`   [exact alias]
- `34` = `ct_global_opcode_34_clear_short_circuit_and_return`   [exact alias]
- `3A` = `ct_global_opcode_3A_clear_short_circuit_and_return`   [exact alias]
- `3B` = `ct_global_opcode_3B_clear_short_circuit_and_return`   [exact alias]
- `3C` = `ct_global_opcode_3C_clear_short_circuit_and_return`   [exact alias]
- `3D` = `ct_global_opcode_3D_clear_short_circuit_and_return`   [exact alias]
- `3E` = `ct_global_opcode_3E_clear_short_circuit_and_return`   [exact alias]

### exact shared body
- `39` = `ct_global_opcode_39_gate_on_materializable_canonical_tail_slot_exists`   [exact shared-body alias]
- `3F` = same body as `39`   [exact shared-body alias]

---

## Promoted-but-still-provisional master labels
These are useful ownership corrections, but not strong enough yet for flavored subsystem names.

- `44` = `ct_global_opcode_44_varctrl_shared_entry_a`   [provisional]
- `45` = `ct_global_opcode_45_varctrl_shared_entry_b`   [provisional]
- `46` = `ct_global_opcode_46_body`   [provisional]
- `47` = `ct_global_opcode_47_body`   [provisional]
- `48` = `ct_global_opcode_48_body`   [provisional]
- `49` = `ct_global_opcode_49_body`   [provisional]
- `4A` = `ct_global_opcode_4A_body`   [provisional]
- `4B` = `ct_global_opcode_4B_body`   [provisional]
- `4C` = `ct_global_opcode_4C_body`   [provisional]
- `54` = `ct_global_opcode_54_multi_target_sat_adjust`   [provisional]
- `55` = `ct_global_opcode_55_multi_target_sat_adjust`   [provisional]

---

## Important carry-forward notes

### `32`
Do not over-rename this to a gameplay-facing noun.
The strong fact is narrower and safer:
- it captures the current inline byte into `AEE4`

### `39 / 3F`
Do not blur these back into generic “slot available” wording.
The proved gate is specifically on:
- canonical tail present
- live tail absent
- deferred-materialization bit clear

### `40..56`
Do not keep referring to these as only old group-2 locals in later reports.
Their correct master identities are now:
- global `40..56`

### `44..4C`
Promotion does **not** mean those bodies are newly solved.
Keep the provisional tone until caller/state evidence tightens them.

---

## Suggested next seam
- promote global `57..5F` into master ownership
- then continue through the early `B8BB` slice
- with special focus on whether `44..4C` can be renamed more strongly from caller evidence


---

## Pass 69

# Chrono Trigger Labels — Pass 69

## Purpose
This file records the label upgrades justified by pass 69.

Pass 69 promotes the selector-control slice at `C1:B8BB..C1:B95F` into its correct master-table range:

- global `57..A9`

It also materially decodes the first promoted selector band:

- global `57..5F`

and carries forward already-earned selector results into their proper master identities.

---

## Strong labels

### C1:A3F6  ct_global_opcode_57_rts_noop_alias   [strong]
- Exact single-byte RTS alias.
- First entry in the promoted selector-control master slice.

### C1:A3F7..C1:A410  ct_global_opcode_58_select_visible_head_occupied_live_slots   [strong structural]
- Scans `AEFF[0..2]`.
- Appends occupied visible-head live slot indices into `AECC`.
- Stores the resulting count in `AECB`.

### C1:A411..C1:A42D  ct_global_opcode_59_select_all_occupied_live_slots   [strong structural]
- Calls the `57/58`-band visible selector first.
- Then appends occupied live slots `3..10` from `AEFF`.
- Stores the final count in `AECB`.

### C1:A42E..C1:A43C  ct_global_opcode_5A_select_current_tail_local_live_slot   [strong structural]
- Writes `B252 + 3` into `AECC[0]`.
- Forces `AECB = 1`.

### C1:A43D..C1:A451  ct_global_opcode_5B_select_current_quad_record_low_nibble_entry   [strong structural]
- Reads `B19E + 4*B252`.
- Masks to the low nibble.
- Stores that value into `AECC[0]`.
- Forces `AECB = 1`.

### C1:A4AF..C1:A4DF  ct_global_opcode_5D_select_target_relation_mode_00   [strong structural]
- Promoted master/global ownership of the pass-30 relation-query target selector for mode `00`.

### C1:A4E0..C1:A507  ct_global_opcode_5E_select_target_relation_mode_01   [strong structural]
- Promoted master/global ownership of the pass-30 relation-query target selector for mode `01`.

### C1:A508..C1:A540  ct_global_opcode_5F_select_one_visible_entry_0_1_2_by_min_current_hp   [strong structural]
- Compares visible-head lane values at `5E30`, `5EB0`, and `5F30`.
- Selects exactly one visible entry index `0..2` with the minimum current-HP value.
- Stores that result into `AECC[0]`.
- Forces `AECB = 1`.

### C1:A6ED..C1:A708  ct_global_opcode_6D_select_nonhead_occupied_live_slots   [strong structural]
- Scans `AEFF[3..10]`.
- Appends occupied non-head live slot indices into `AECC`.
- Stores the resulting count in `AECB`.

### C1:A709..C1:A736  ct_global_opcode_6E_select_target_relation_mode_02   [strong structural]
- Promoted master/global ownership of the pass-30 relation-query target selector for mode `02`.

### C1:A737..C1:A764  ct_global_opcode_6F_select_target_relation_mode_03   [strong structural]
- Promoted master/global ownership of the pass-30 relation-query target selector for mode `03`.

### C1:AB03..C1:AB49  ct_global_opcode_86_build_withheld_tail_candidate_list_and_random_reduce_to_one   [strong]
- Promoted master/global ownership of the pass-57 withheld-tail selector body.

### C1:AB9B..C1:ABC8  ct_global_opcode_8E_select_one_visible_entry_0_1_2_by_min_lane_value   [strong structural]
- Promoted master/global ownership of the pass-58 visible min selector.

### C1:ABC9..C1:AC13  ct_global_opcode_8F_build_live_tail_slot_candidate_list_and_random_reduce_to_one   [strong]
- Promoted master/global ownership of the pass-58 live-tail selector body.

### C1:AFD7..C1:B08E  ct_global_opcode_A0_execute_late_selector_pack_and_capture_tail_result   [strong structural]
- Promoted master/global ownership of the pass-60 late selector-pack executor.

---

## Provisional labels

### C1:A452..C1:A4AE  ct_global_opcode_5C_select_random_visible_head_live_slot_after_optional_refresh   [provisional structural]
- If DP scratch `$24` is zero, runs `B279` across visible entries `0..2` before the selection attempt.
- Then randomly chooses one occupied visible-head live slot.
- Exposes the chosen visible slot in `AECC[0]`.
- Leaves `AECB = 0` on failure.
- The exact higher-level noun of the `$24` gate still wants one more caller-context pass.

---

## Exact promoted fixed-selector globals

### global `7E..85`  fixed single-entry selectors `3..10`   [strong]
- `7E` = literal entry `3`
- `7F` = literal entry `4`
- `80` = literal entry `5`
- `81` = literal entry `6`
- `82` = literal entry `7`
- `83` = literal entry `8`
- `84` = literal entry `9`
- `85` = literal entry `10`

### global `87..8D`  fixed single-entry selectors `0..6`   [strong]
- `87` = literal entry `0`
- `88` = literal entry `1`
- `89` = literal entry `2`
- `8A` = literal entry `3`
- `8B` = literal entry `4`
- `8C` = literal entry `5`
- `8D` = literal entry `6`

---

## Important carry-forward notes

### `57..5F`
These are no longer just “selector-control locals.”
Their correct master identities are now:

- global `57..5F`

### `5C`
Do not over-rename the DP `$24` gate yet.
The safe frozen fact is:
- optional pre-refresh path through `B279`
- then random visible-head occupied-slot selection

### `6D/6E/6F`
These were already effectively solved in earlier selector work.
Pass 69 mainly corrects their **master ownership**, not just their local naming.

### `86/8E/8F/A0`
Same story:
- the semantics were already earned
- the new part is their correct position in the master `B80D` space

---

## Toolkit correction
Pass 69 also updates the worksheet generator so master opcode coverage is no longer truncated at `0x3F`.

The generator now matches the currently proved master span:

- `00..A9`

That prevents future workspace refreshes from silently dropping promoted master rows.

---

## Suggested next seam
- decode the parameterized selector family at global `60..6C`
- then tighten the still-open promoted selector globals at `70..7D`
- then revisit the late promoted range `90..A9`


---

## Pass 70

# Chrono Trigger Labels — Pass 70

## Purpose
This file records the label upgrades justified by pass 70.

Pass 70 closes the promoted master/selector-control band:

- global `60..6C`
- selector-control local `09..15`

It also names the shared helper pipeline that those opcodes use.

---

## Strong labels

### C1:AD68..C1:ADA0  ct_build_visible_fd_offset_nonzero_candidates_and_reduce   [strong structural]
- Clears `AECB`, `AF20`, and `AF21`.
- Forces `AF1F = FF`.
- Runs `AE70` across visible entries `0`, `1`, and `2`.
- Then runs `ADA1` to reduce the resulting candidate list.

### C1:AE70..C1:AECF  ct_scan_one_visible_entry_for_fd_offset_mask_candidate   [strong structural]
- Scans one visible entry indexed by `AF1E`.
- Uses the FD record root table at `FD:A80B`.
- Tests `(record[offset_from_$0A] & AF1F) != 0`.
- Also requires `record[+1D]` to be nonnegative.
- Appends accepted visible entry indices into `AECC` and increments `AECB`.
- Annotates the stored candidate with `0x40` / `0x80` marks from `record[+20]` and tracks those counts in `AF20` / `AF21`.

### C1:ADA1..C1:AE20  ct_reduce_visible_fd_candidates_by_b23a_priority_and_optional_relation_redirect   [strong structural]
- Consumes candidate bytes already staged in `AECC/AECB`.
- Uses `B23A` as the ordered reduction stream.
- Prefers `0x80`-marked candidates when any are present.
- Falls back to the first ordinary `B23A` priority match otherwise.
- If the chosen candidate carries `0x40`, redirects through `A4E0`.
- Otherwise collapses to a single low-nibble entry in `AECC[0]` with `AECB = 1`.

### C1:A541..C1:A54A  ct_global_opcode_60_select_visible_entries_by_positive_fd_record_byte_1D   [strong structural]
- Sets selector offset `0x1D`.
- Uses the shared visible FD-offset family at `AD68`.
- Practical contract: positive `record[+1D]`, then reduce.

### C1:A54B..C1:A554  ct_global_opcode_61_select_visible_entries_by_nonzero_fd_record_byte_1E   [strong structural]
- Sets selector offset `0x1E`.
- Uses the shared visible FD-offset family at `AD68`.
- Also inherits the shared nonnegative `record[+1D]` gate.

### C1:A555..C1:A55E  ct_global_opcode_62_select_visible_entries_by_nonzero_fd_record_byte_1F   [strong structural]
- Sets selector offset `0x1F`.
- Uses the shared visible FD-offset family at `AD68`.
- Also inherits the shared nonnegative `record[+1D]` gate.

### C1:A55F..C1:A568  ct_global_opcode_63_select_visible_entries_by_nonzero_fd_record_byte_20   [strong structural]
- Sets selector offset `0x20`.
- Uses the shared visible FD-offset family at `AD68`.
- Also inherits the shared nonnegative `record[+1D]` gate.

### C1:A569..C1:A572  ct_global_opcode_64_select_visible_entries_by_nonzero_fd_record_byte_21   [strong structural]
- Sets selector offset `0x21`.
- Uses the shared visible FD-offset family at `AD68`.
- Also inherits the shared nonnegative `record[+1D]` gate.

### C1:A573..C1:A5A2  ct_global_opcode_65_select_visible_entries_by_fd_record_byte_1E_mask_02   [strong structural]
- Uses the shared visible FD-offset/mask pipeline.
- Tests `record[+1E] & 0x02`.
- Also inherits the shared nonnegative `record[+1D]` gate.

### C1:A5A3..C1:A5D2  ct_global_opcode_66_select_visible_entries_by_fd_record_byte_1E_mask_80   [strong structural]
- Uses the shared visible FD-offset/mask pipeline.
- Tests `record[+1E] & 0x80`.
- Also inherits the shared nonnegative `record[+1D]` gate.

### C1:A5D3..C1:A602  ct_global_opcode_67_select_visible_entries_by_fd_record_byte_1E_mask_04   [strong structural]
- Uses the shared visible FD-offset/mask pipeline.
- Tests `record[+1E] & 0x04`.
- Also inherits the shared nonnegative `record[+1D]` gate.

### C1:A603..C1:A632  ct_global_opcode_68_select_visible_entries_by_fd_record_byte_21_mask_04   [strong structural]
- Uses the shared visible FD-offset/mask pipeline.
- Tests `record[+21] & 0x04`.
- Also inherits the shared nonnegative `record[+1D]` gate.

### C1:A633..C1:A662  ct_global_opcode_69_select_visible_entries_by_fd_record_byte_21_mask_40   [strong structural]
- Uses the shared visible FD-offset/mask pipeline.
- Tests `record[+21] & 0x40`.
- Also inherits the shared nonnegative `record[+1D]` gate.

### C1:A663..C1:A692  ct_global_opcode_6A_select_visible_entries_by_fd_record_byte_20_mask_10   [strong structural]
- Uses the shared visible FD-offset/mask pipeline.
- Tests `record[+20] & 0x10`.
- Also inherits the shared nonnegative `record[+1D]` gate.

### C1:A693..C1:A6C2  ct_global_opcode_6B_select_visible_entries_by_fd_record_byte_01_mask_08   [strong structural]
- Uses the shared visible FD-offset/mask pipeline.
- Tests `record[+01] & 0x08`.
- Also inherits the shared nonnegative `record[+1D]` gate.

### C1:A6C3..C1:A6EC  ct_global_opcode_6C_select_occupied_live_tail_slots_except_current   [strong structural]
- Computes the current tail-local live slot as `B252 + 3`.
- Scans live slots `3..10`.
- Appends every occupied slot except that current one into `AECC`.
- Stores the resulting count in `AECB`.

---

## Strong promoted selector-control locals

### selector `09`  ct_select_visible_entries_by_positive_fd_record_byte_1D   [strong structural]
- Local selector-control ownership of global `60`.

### selector `0A`  ct_select_visible_entries_by_nonzero_fd_record_byte_1E   [strong structural]
- Local selector-control ownership of global `61`.

### selector `0B`  ct_select_visible_entries_by_nonzero_fd_record_byte_1F   [strong structural]
- Local selector-control ownership of global `62`.

### selector `0C`  ct_select_visible_entries_by_nonzero_fd_record_byte_20   [strong structural]
- Local selector-control ownership of global `63`.

### selector `0D`  ct_select_visible_entries_by_nonzero_fd_record_byte_21   [strong structural]
- Local selector-control ownership of global `64`.

### selector `0E`  ct_select_visible_entries_by_fd_record_byte_1E_mask_02   [strong structural]
- Local selector-control ownership of global `65`.

### selector `0F`  ct_select_visible_entries_by_fd_record_byte_1E_mask_80   [strong structural]
- Local selector-control ownership of global `66`.

### selector `10`  ct_select_visible_entries_by_fd_record_byte_1E_mask_04   [strong structural]
- Local selector-control ownership of global `67`.

### selector `11`  ct_select_visible_entries_by_fd_record_byte_21_mask_04   [strong structural]
- Local selector-control ownership of global `68`.

### selector `12`  ct_select_visible_entries_by_fd_record_byte_21_mask_40   [strong structural]
- Local selector-control ownership of global `69`.

### selector `13`  ct_select_visible_entries_by_fd_record_byte_20_mask_10   [strong structural]
- Local selector-control ownership of global `6A`.

### selector `14`  ct_select_visible_entries_by_fd_record_byte_01_mask_08   [strong structural]
- Local selector-control ownership of global `6B`.

### selector `15`  ct_select_occupied_live_tail_slots_except_current   [strong structural]
- Local selector-control ownership of global `6C`.

---

## Honest caution
Do not over-name these as concrete gameplay nouns yet:

- `B23A`
- the `0x40` redirect mark
- the `0x80` preferred mark

What pass 70 proves is the reducer mechanics, not the final human-facing noun.

---

## Suggested next seam
- decode the promoted selector-control master band at global `70..7D`


---

## Pass 71

# Chrono Trigger Labels — Pass 71

## Purpose
This file records the label upgrades justified by pass 71.

Pass 71 closes the promoted selector-control master band:

- global `70..7D`

It also promotes the matching selector-control locals:

- selector `19..26`

---

## Strong global labels

### C1:A765..C1:A7A8  ct_global_opcode_70_select_one_nonhead_occupied_live_slot_by_min_nonzero_fd_record_word_03   [strong structural]
- Scans occupied live slots `3..10`.
- Resolves each slot through `FD:A80B + slot*2`.
- Compares the 16-bit word at `record + 3`.
- Keeps the smallest nonzero value and stores the corresponding slot into `AECC[0]`.
- Forces `AECB = 1`.

### C1:A7A9..C1:A7E4  ct_global_opcode_71_select_nonhead_occupied_live_slots_excluding_primary_seed_by_positive_fd_record_byte_1D   [strong structural]
- Nonhead counterpart of the pass-70 visible FD-byte selector family.
- Scans live slots `3..10`.
- Skips the primary-seed slot indexed by `B18B`.
- Uses `AE70 -> ADA1` to select/reduce candidates.

### C1:A7E5..C1:A818  ct_global_opcode_72_select_nonhead_occupied_live_slots_by_positive_fd_record_byte_1D   [strong structural]
- Nonhead counterpart of global `60`.
- Scans occupied live slots `3..10` through `AE70 -> ADA1`.
- No `B18B` exclusion.

### C1:A819..C1:A854  ct_global_opcode_73_select_nonhead_occupied_live_slots_excluding_primary_seed_by_nonzero_fd_record_byte_1E   [strong structural]
- Tests `record[+1E]` through the shared `AE70 -> ADA1` reducer path.
- Also inherits the shared nonnegative `record[+1D]` gate.
- Skips the primary-seed slot indexed by `B18B`.

### C1:A855..C1:A888  ct_global_opcode_74_select_nonhead_occupied_live_slots_by_nonzero_fd_record_byte_1E   [strong structural]
- Nonhead counterpart of global `61`.
- Uses the shared `AE70 -> ADA1` reducer path.
- No `B18B` exclusion.

### C1:A889..C1:A8C4  ct_global_opcode_75_select_nonhead_occupied_live_slots_excluding_primary_seed_by_nonzero_fd_record_byte_1F   [strong structural]
- Tests `record[+1F]` through the shared `AE70 -> ADA1` reducer path.
- Skips the primary-seed slot indexed by `B18B`.

### C1:A8F9..C1:A934  ct_global_opcode_77_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1E_mask_02   [strong structural]
- Uses the shared nonhead FD-offset/mask pipeline.
- Tests `record[+1E] & 0x02`.
- Skips the primary-seed slot indexed by `B18B`.

### C1:A935..C1:A970  ct_global_opcode_78_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1E_mask_80   [strong structural]
- Uses the shared nonhead FD-offset/mask pipeline.
- Tests `record[+1E] & 0x80`.
- Skips the primary-seed slot indexed by `B18B`.

### C1:A971..C1:A9AC  ct_global_opcode_79_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1E_mask_04   [strong structural]
- Uses the shared nonhead FD-offset/mask pipeline.
- Tests `record[+1E] & 0x04`.
- Skips the primary-seed slot indexed by `B18B`.

### C1:A9AD..C1:A9E8  ct_global_opcode_7A_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_21_mask_40   [strong structural]
- Uses the shared nonhead FD-offset/mask pipeline.
- Tests `record[+21] & 0x40`.
- Skips the primary-seed slot indexed by `B18B`.

### C1:A9E9..C1:AA24  ct_global_opcode_7B_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1D_mask_02   [strong structural]
- Uses the shared nonhead FD-offset/mask pipeline.
- Tests `record[+1D] & 0x02`.
- Skips the primary-seed slot indexed by `B18B`.

### C1:AA25..C1:AA60  ct_global_opcode_7C_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_19_mask_01   [strong structural]
- Uses the shared nonhead FD-offset/mask pipeline.
- Tests `record[+19] & 0x01`.
- Skips the primary-seed slot indexed by `B18B`.

### C1:AA61..C1:AAAA  ct_global_opcode_7D_select_one_nonhead_occupied_live_slot_excluding_primary_seed_by_min_nonzero_fd_record_word_03   [strong structural]
- Same minimum-word selector family as global `70`.
- Scans occupied live slots `3..10`.
- Skips the primary-seed slot indexed by `B18B`.
- Chooses the smallest nonzero `record_word(+3)` candidate and stores its slot into `AECC[0]`.

---

## Provisional global label

### C1:A8C5..C1:A8F8  ct_global_opcode_76_select_nonhead_occupied_live_slots_by_nonzero_fd_record_byte_1F   [provisional structural]
- Structurally matches the no-exclusion sibling of global `75`.
- Intended to test `record[+1F]` through the shared `AE70 -> ADA1` reducer path.
- But the loop update stores back into `$0E` with `STA $0E` at `C1:A8E9` instead of the expected `STX $0E`.
- Keep the family interpretation, but preserve explicit caution until runtime confirms the practical behavior.

---

## Strong promoted selector-control locals

### selector `19`  ct_select_one_nonhead_occupied_live_slot_by_min_nonzero_fd_record_word_03   [strong structural]
- Local selector-control ownership of global `70`.

### selector `1A`  ct_select_nonhead_occupied_live_slots_excluding_primary_seed_by_positive_fd_record_byte_1D   [strong structural]
- Local selector-control ownership of global `71`.

### selector `1B`  ct_select_nonhead_occupied_live_slots_by_positive_fd_record_byte_1D   [strong structural]
- Local selector-control ownership of global `72`.

### selector `1C`  ct_select_nonhead_occupied_live_slots_excluding_primary_seed_by_nonzero_fd_record_byte_1E   [strong structural]
- Local selector-control ownership of global `73`.

### selector `1D`  ct_select_nonhead_occupied_live_slots_by_nonzero_fd_record_byte_1E   [strong structural]
- Local selector-control ownership of global `74`.

### selector `1E`  ct_select_nonhead_occupied_live_slots_excluding_primary_seed_by_nonzero_fd_record_byte_1F   [strong structural]
- Local selector-control ownership of global `75`.

### selector `20`  ct_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1E_mask_02   [strong structural]
- Local selector-control ownership of global `77`.

### selector `21`  ct_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1E_mask_80   [strong structural]
- Local selector-control ownership of global `78`.

### selector `22`  ct_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1E_mask_04   [strong structural]
- Local selector-control ownership of global `79`.

### selector `23`  ct_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_21_mask_40   [strong structural]
- Local selector-control ownership of global `7A`.

### selector `24`  ct_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_1D_mask_02   [strong structural]
- Local selector-control ownership of global `7B`.

### selector `25`  ct_select_nonhead_occupied_live_slots_excluding_primary_seed_by_fd_record_byte_19_mask_01   [strong structural]
- Local selector-control ownership of global `7C`.

### selector `26`  ct_select_one_nonhead_occupied_live_slot_excluding_primary_seed_by_min_nonzero_fd_record_word_03   [strong structural]
- Local selector-control ownership of global `7D`.

---

## Provisional promoted selector-control local

### selector `1F`  ct_select_nonhead_occupied_live_slots_by_nonzero_fd_record_byte_1F   [provisional structural]
- Local selector-control ownership of global `76`.
- Carries the same explicit caution about the anomalous `STA $0E` loop-update byte.

---

## Honest caution
Two details should stay explicitly attached to this band:

- globals `70` and `7D` do not show an explicit empty/no-hit failure path
- global `76` / selector `1F` has a real byte-level loop-update anomaly at `C1:A8E9`

That means the overall family is strong, but those exact edge behaviors still deserve runtime confirmation.

---

## Suggested next seam
- revisit the late promoted band at global `90..A9`
- keep global `76` / selector `1F` on the runtime shortlist


---

## Pass 72

# Chrono Trigger Labels — Pass 72

## Purpose
This file records the label upgrades justified by pass 72.

Pass 72 re-opened the promoted late selector-control master band:

- global `90..A9`
- selector-control locals `39..52`

The most important correction is that globals `9D..A9` are not clean standalone top-level bodies.
They are **internal alias entries** into the late-pack executor blob.

---

## Strong global labels

### C1:8876..C1:88C4  ct_global_opcode_90_update_lane_afb6_b045_and_release_5E4B_bit7_on_expiry   [strong structural]
- Uses `B179[0]` or fallback `AEC7`, then maps through `B163` to a lane ID.
- Sets `AFB6[lane] = 1` and copies `B0D4[lane] -> AF27[lane]`.
- Decrements `B045[lane]` and reloads it to `0x0A` on expiry.
- Clears `5E4B + lane*0x80` bit `0x80` and clears `AFB6[lane]` when the countdown expires.

### C1:88C5..C1:8974  ct_global_opcode_91_conditionally_seed_afc1_af32_and_ad9c_from_lane_geometry   [strong structural]
- Uses `B179[1]` or fallback `AEC7`, then maps through `B163` to a lane ID.
- Requires `5E4A.bit7` set and `5E4B.bit6` clear for the helper path.
- Sets `AFC1[lane] = 1`, computes `AF32[lane] = B0DF[lane] + 5E64[lane_block]`.
- Seeds `AD9C/AD9E` and runs the `EBF8` helper chain.
- Clears `B186` with `AND #$17FF` before return.

### C1:8975..C1:89B8  ct_global_opcode_92_update_lane_afcc_b05b_and_clear_afcc_on_expiry   [strong structural]
- Uses `B17B` or fallback `AEC7`, then maps through `B163` to a lane ID.
- Sets `AFCC[lane] = 1` and copies `B0EA[lane] -> AF3D[lane]`.
- Decrements `B05B[lane]` and reloads it to `0x0A` on expiry.
- Clears `AFCC[lane]` when the countdown expires.

### C1:89B9..C1:8A04  ct_global_opcode_93_update_lane_afd7_b066_and_release_5E4D_bit7_on_expiry   [strong structural]
- Uses `B17C` or fallback `AEC7`, then maps through `B163` to a lane ID.
- Sets `AFD7[lane] = 1` and copies `B0F5[lane] -> AF48[lane]`.
- Decrements `B066[lane]` and reloads it to `0x0A` on expiry.
- Clears `5E4D + lane*0x80` bit `0x80` and clears `AFD7[lane]` on expiry.

### C1:8A05..C1:8A50  ct_global_opcode_94_update_lane_afe2_b071_and_release_5E4D_bit6_on_expiry   [strong structural]
- Uses `B17D` or fallback `AEC7`, then maps through `B163` to a lane ID.
- Sets `AFE2[lane] = 1` and copies `B100[lane] -> AF53[lane]`.
- Decrements `B071[lane]` and reloads it to `0x0A` on expiry.
- Clears `5E4D + lane*0x80` bit `0x40` and clears `AFE2[lane]` on expiry.

### C1:8A51..C1:8A9C  ct_global_opcode_95_update_lane_afed_b07c_and_release_5E4E_bit6_on_expiry   [strong structural]
- Uses `B17E` or fallback `AEC7`, then maps through `B163` to a lane ID.
- Sets `AFED[lane] = 1` and copies `B10B[lane] -> AF5E[lane]`.
- Decrements `B07C[lane]` and reloads it to `0x0A` on expiry.
- Clears `5E4E + lane*0x80` bit `0x40` and clears `AFED[lane]` on expiry.

### C1:8A9D  ct_global_opcode_96_rts_alias   [strong]
- Exact `RTS` entry.

### C1:8A9E  ct_global_opcode_97_rts_alias   [strong]
- Exact `RTS` entry.

### C1:8A9F..C1:8B0F  ct_global_opcode_98_capture_lane_b12c_variant_into_af7f_and_optionally_run_ec7f   [strong structural]
- Uses `B179[8]` or fallback `AEC7`, then maps through `B163` to a lane ID.
- Sets `B00E[lane] = 1` and copies `B12C[lane] -> AF7F[lane]`.
- Applies status-based halve/double transforms from lane-block flags.
- Clears `B186` with `AND #$1FEF`.
- Optionally runs the `EBF8 -> EC7F` helper chain when `5E4B.bit4` is set.

### C1:8B10..C1:8BB8  ct_global_opcode_99_update_lane_b019_b0a8_and_on_expiry_conditionally_seed_ad9c   [strong structural]
- Uses `B179[9]` or fallback `AEC7`, then maps through `B163` to a lane ID.
- Sets `B019[lane] = 1` and copies `B137[lane] -> AF8A[lane]`.
- Applies status-based halve/double transforms from lane-block flags.
- Decrements `B0A8[lane]`.
- On expiry, conditionally seeds `AD9C/AD9E` through the helper chain when the lane-block gates allow it.

### C1:8BB9..C1:8C07  ct_global_opcode_9A_update_lane_b024_b0b3_and_release_5E4E_bit2_on_expiry   [strong structural]
- Uses `B179[0x0A]` or fallback `AEC7`, then maps through `B163` to a lane ID.
- Sets `B024[lane] = 1` and copies `B142[lane] -> AF95[lane]`.
- Decrements `B0B3[lane]` and reloads it to `0x0A` on expiry.
- Clears `5E4E + lane*0x80` bit `0x04` and clears `B024[lane]` on expiry.

### C1:8C08  ct_global_opcode_9B_rts_alias   [strong]
- Exact `RTS` entry.

---

## Provisional global label

### C1:8461..C1:8625  ct_global_opcode_9C_service7_lane_controller_and_active_time_update   [provisional structural]
- Large lane/service controller, not a tiny wrapper.
- Clears controller scratch, iterates lane-related state through the `B179/B163` mapping, checks occupancy/readiness bytes and lane-block state, and calls already-known service/readiness helpers like `BD6F`, `B575`, and `B725`.
- Writes readiness/active-time style state such as `B03A`.
- Final gameplay-facing noun intentionally left open until the helper chain around `8CF9 / B923 / BCE1 / B223` is decoded more tightly.

---

## Strong internal-alias global labels

### C1:AFB6..C1:AFC0  ct_global_opcode_9D_late_pack_helper_internal_alias_seed_dp28_from_fd_ba61   [strong structural]
- Internal helper/lead-in alias before the late-pack executor blob.
- Seeds scratch through `FD:BA61`, `DP28/29`, `C92A`, and a `PLX` return tail.
- Not a clean standalone top-level command body.

### C1:AFC1..C1:AFCB  ct_global_opcode_9E_late_pack_helper_internal_alias_call_c92a_and_plx_return   [strong structural]
- Internal alias into the same helper tail used by `9D`.
- Falls through to `PLX ; STX $2C ; RTS`.
- Not a clean standalone top-level command body.

### C1:AFCC..C1:AFD4  ct_global_opcode_9F_late_pack_helper_internal_alias_plx_return   [strong structural]
- Internal alias that lands directly in the `PLX` return tail ahead of the late-pack blob.
- Not a clean standalone top-level command body.

### C1:AFD7..C1:AFE1  ct_global_opcode_A0_late_pack_executor_internal_alias_after_cc_record_load   [strong correction]
- The master pointer lands two bytes inside the real `CC:8B08` pointer-load sequence.
- Keep as an internal late-pack executor alias, not as the clean top-level initializer.

### C1:AFE2..C1:AFEC  ct_global_opcode_A1_late_pack_executor_internal_alias_clear_af24_and_probe_second_subop   [strong structural]
- Internal alias in the common late-pack executor path.
- Clears `AF24`, probes byte `+4` for the `FE` chained-subop case, and falls into the shared segment selector path.

### C1:AFED..C1:AFF7  ct_global_opcode_A2_late_pack_executor_internal_alias_arm_second_subop_flag   [strong structural]
- Internal alias in the same common path.
- Lives inside the `CMP #$FE` / `B1CF` second-subop arming logic.

### C1:AFF8..C1:B002  ct_global_opcode_A3_late_pack_executor_internal_alias_after_segment_select   [strong structural]
- Internal alias after `B4AA` segment selection.
- Fetches the current opcode byte into `B239` and falls into the shared dispatch path.

### C1:B003..C1:B00D  ct_global_opcode_A4_late_pack_executor_internal_alias_dispatch_current_b239_opcode   [strong structural]
- Internal alias that dispatches the current `B239` opcode through the master table.

### C1:B00E..C1:B018  ct_global_opcode_A5_late_pack_executor_internal_alias_advance_to_second_subop   [strong structural]
- Internal alias for the chained second-subop advance path.
- Advances `B1D2` by `+4`, reloads `B239`, and falls back into the shared dispatch.

### C1:B019..C1:B023  ct_global_opcode_A6_late_pack_executor_internal_alias_dispatch_second_subop   [strong structural]
- Internal alias after the chained second-subop reload.
- Dispatches the second `B239` opcode and falls into result capture.

### C1:B024..C1:B02E  ct_global_opcode_A7_late_pack_executor_internal_alias_capture_af24_result   [strong structural]
- Internal alias at the result-capture start.
- Mirrors `AF24` into `B24A[tail]` and enters the special-case / nonzero-result logic.

### C1:B02F..C1:B039  ct_global_opcode_A8_late_pack_executor_internal_alias_special_case_af24_eq_02   [strong structural]
- Internal alias inside the result-capture tail.
- Special-cases `AF24 == 2` before the broader nonzero-result path.

### C1:B03A..C1:B08E  ct_global_opcode_A9_late_pack_executor_internal_alias_nonzero_af24_path   [strong structural]
- Internal alias into the nonzero-result handling and FE/FF continuation logic.
- Includes the path that marks `B242`, advances FE-delimited segments, and increments or clears `B263`.

---

## Strong promoted selector-control locals

### selector `39`  ct_update_lane_afb6_b045_and_release_5E4B_bit7_on_expiry   [strong structural]
- Local selector-control ownership of global `90`.

### selector `3A`  ct_conditionally_seed_afc1_af32_and_ad9c_from_lane_geometry   [strong structural]
- Local selector-control ownership of global `91`.

### selector `3B`  ct_update_lane_afcc_b05b_and_clear_afcc_on_expiry   [strong structural]
- Local selector-control ownership of global `92`.

### selector `3C`  ct_update_lane_afd7_b066_and_release_5E4D_bit7_on_expiry   [strong structural]
- Local selector-control ownership of global `93`.

### selector `3D`  ct_update_lane_afe2_b071_and_release_5E4D_bit6_on_expiry   [strong structural]
- Local selector-control ownership of global `94`.

### selector `3E`  ct_update_lane_afed_b07c_and_release_5E4E_bit6_on_expiry   [strong structural]
- Local selector-control ownership of global `95`.

### selector `3F`  ct_rts_alias   [strong]
- Local selector-control ownership of global `96`.

### selector `40`  ct_rts_alias_2   [strong]
- Local selector-control ownership of global `97`.

### selector `41`  ct_capture_lane_b12c_variant_into_af7f_and_optionally_run_ec7f   [strong structural]
- Local selector-control ownership of global `98`.

### selector `42`  ct_update_lane_b019_b0a8_and_on_expiry_conditionally_seed_ad9c   [strong structural]
- Local selector-control ownership of global `99`.

### selector `43`  ct_update_lane_b024_b0b3_and_release_5E4E_bit2_on_expiry   [strong structural]
- Local selector-control ownership of global `9A`.

### selector `44`  ct_rts_alias_3   [strong]
- Local selector-control ownership of global `9B`.

### selector `46`  ct_late_pack_helper_internal_alias_seed_dp28_from_fd_ba61   [strong structural]
- Local selector-control ownership of global `9D`.

### selector `47`  ct_late_pack_helper_internal_alias_call_c92a_and_plx_return   [strong structural]
- Local selector-control ownership of global `9E`.

### selector `48`  ct_late_pack_helper_internal_alias_plx_return   [strong structural]
- Local selector-control ownership of global `9F`.

### selector `49`  ct_late_pack_executor_internal_alias_after_cc_record_load   [strong correction]
- Local selector-control ownership of global `A0`.
- Carries the same explicit correction that this is not the clean top-level initializer.

### selector `4A`  ct_late_pack_executor_internal_alias_clear_af24_and_probe_second_subop   [strong structural]
- Local selector-control ownership of global `A1`.

### selector `4B`  ct_late_pack_executor_internal_alias_arm_second_subop_flag   [strong structural]
- Local selector-control ownership of global `A2`.

### selector `4C`  ct_late_pack_executor_internal_alias_after_segment_select   [strong structural]
- Local selector-control ownership of global `A3`.

### selector `4D`  ct_late_pack_executor_internal_alias_dispatch_current_b239_opcode   [strong structural]
- Local selector-control ownership of global `A4`.

### selector `4E`  ct_late_pack_executor_internal_alias_advance_to_second_subop   [strong structural]
- Local selector-control ownership of global `A5`.

### selector `4F`  ct_late_pack_executor_internal_alias_dispatch_second_subop   [strong structural]
- Local selector-control ownership of global `A6`.

### selector `50`  ct_late_pack_executor_internal_alias_capture_af24_result   [strong structural]
- Local selector-control ownership of global `A7`.

### selector `51`  ct_late_pack_executor_internal_alias_special_case_af24_eq_02   [strong structural]
- Local selector-control ownership of global `A8`.

### selector `52`  ct_late_pack_executor_internal_alias_nonzero_af24_path   [strong structural]
- Local selector-control ownership of global `A9`.

---

## Provisional promoted selector-control local

### selector `45`  ct_service7_lane_controller_and_active_time_update   [provisional structural]
- Local selector-control ownership of global `9C`.
- Large lane/service controller; final gameplay-facing noun still left open.

---

## Honest caution
Three things should stay explicit after this pass:

- global `9C` / selector `45` is still open even though it is clearly a real controller
- the `91 / 98 / 99` helper chain still lacks a final gameplay-facing noun
- globals `9D..A9` are **internal aliases**, so they should not be treated like ordinary standalone opcode bodies in future passes


---

## Pass 73

# Chrono Trigger Labels — Pass 73

## Purpose
This file records the label upgrades justified by pass 73.

Pass 73 re-opened the helper/controller seam left by pass 72:

- global `9C`
- selector-control local `45`
- helper chain around:
  - `C1:8CF9`
  - `C1:E89F`
  - `C1:EBF8`
  - `C1:EC7F`

The main architectural correction is that the `AD9C/AD9E/EBF8/EC7F` family is now best read as a concrete **pending signed stat-delta packet system**, not vague lane-geometry glue.

---

## Strong helper labels

### C1:E89F..C1:E8BE  ct_c1_compute_ad9c_packet_offset_from_ad9b_and_b1fd   [strong]
- Computes `DP0E = 0x2C * AD9B + 4 * B1FD`.
- Uses the already-locked `C90B` 16-bit multiply helper.
- This is the exact packet-slot offset calculator for one 4-byte entry inside a `0x2C`-byte record family.

### C1:E8C0..C1:E8E0  ct_c1_compute_ad9c_packet_offset_from_ad9b_and_b18b   [strong]
- Computes `DP10 = 0x2C * AD9B + 4 * B18B`.
- Companion packet-slot offset calculator using `B18B` instead of `B1FD`.

### C1:EBF8..C1:EC38  ct_c1_queue_signed_pending_stat_delta_packet_into_b328_family   [strong structural]
- Mirrors `B202 -> B203` and negates `AD89` when `B202.bit7` is set.
- Computes a 4-byte packet slot offset from `B2C7` and the `0x2C` record stride.
- Writes the signed 16-bit amount into `B328[offset]` and the packet flag byte into `B32B[offset]`.
- Strongest safe reading: queue one signed pending HP/secondary-stat delta packet.

### C1:EC39..C1:EC7E  ct_c1_clear_nonpersistent_pending_stat_delta_channels   [strong structural]
- Scans the three parallel packet families rooted at `B328`, `B354`, and `B380`.
- If none of the corresponding flag bytes carry bit `0x20`, clears the channel data.
- Also clears associated scratch/export bytes such as `AEB2`, `AEB0`, and `AE82` on the loop tail.

### C1:EC7F..C1:ED87  ct_c1_apply_pending_stat_delta_channels_and_clamp_lane_currents   [strong structural]
- Calls the non-persistent channel clearer first.
- Applies queued signed packet amounts into `5E30/5E32` for the primary current/cap pair.
- Applies queued signed packet amounts into the parallel `5E34/5E36` pair for packets on the secondary-stat route.
- Clamps the resulting current values and performs lane refresh side effects such as `5E4A.bit7` handling and `FD:ABA2` calls when needed.

### C1:8CF9..C1:8EA6  ct_c1_run_tail_lane_selector_control_stream_and_materialize_head_state   [strong structural]
- Initializes current-tail context from `AEC8`, `B252`, and `B18B` and clears selection/result scratch.
- Chooses the command-stream pointer from the saved per-tail pointer pair `B1D4/B1E4` or the continuation pointer in `B273`.
- Fetches the current `CC` byte into `AEE3` and dispatches through the selector-control table at `B88D`.
- Uses `AD8E/AECC/AECB/AE91` and visible-head vacancy scans to materialize or update head-slot assignment/state.
- Maintains saved continuation state such as `B1D4`, `B2C0`, and `AE55`.

---

## Strengthened global label

### C1:8461..C1:883B  ct_global_opcode_9C_service7_tail_lane_admission_reseat_and_readiness_refresh_controller   [strong structural]
- Walks the tail-lane band through `B315/B252/B18B` and the `B179/B163` mapping.
- Services eligible occupied tail lanes, invoking `8CF9` to run the tail selector-control/materialization stream.
- On the follow-up path mirrors `B158 -> AFAB`, applies `BD6F` readiness modifiers, and sets `B03A = 1`.
- Then runs canonical/head-visible reconciliation and readiness-gauge export refresh through helpers such as `B575` and `B725`.
- Strongest safe reading: service-7 tail-lane admission/reseat plus readiness-refresh controller.

---

## Strengthened promoted selector-control local

### C1:8461..C1:883B  ct_service7_tail_lane_admission_reseat_and_readiness_refresh_controller   [strong structural]
- Local selector-control ownership of global `9C`.
- Carries the same upgraded reading: outer controller for eligible tail-lane admission/reseat, readiness-shadow refresh, and downstream canonical/head-visible reconciliation.

---

## Honest caution
Three things should stay explicit even after this pass:

- the fourth byte in each 4-byte packet record remains unresolved here
- the final gameplay-facing noun of the `5E34/5E36` pair is still slightly below fully frozen
- `8CF9` is now structurally strong, but some continuation/result fields like `B242` and `AE55` still want a tighter pass


---

## Pass 74

# Chrono Trigger Labels — Pass 74

## Purpose
This file records the label upgrades justified by pass 74.

Pass 74 re-opened the late seam left by pass 73:

- globals `91 / 98 / 99`
- shared helper tail:
  - `C1:895B`
  - `C1:AC57`
  - `C1:AC85`
  - `FD:ACEE`
- continuation/materialization state:
  - `B2C0`
  - `AE55`

The main architectural correction is that globals `91` and `99` are **dual-path packet callers** rather than generic geometry/helper seeders:

- they populate transient `AD9C` packet workspace
- they queue a live signed stat-delta packet through `EBF8`
- they run the shared fixed-`7F` follow-up/apply tail
- they clear the transient workspace through `FD:ACEE`

By contrast, global `98` is the stripped-down fast path that directly queues + applies one packet without the transient workspace.

---

## Strengthened global opcode labels

### C1:88C5..C1:8974  ct_global_opcode_91_compute_scaled_lane_delta_queue_live_packet_and_run_followup_7f_tail   [strong structural]
- Uses `B179[1]` or `AEC7` through the `B163` lane mapping.
- Requires `5E4A.bit7` set and `5E4B.bit6` clear for the packet path.
- Sets `AFC1[lane] = 1` and `AF32[lane] = B0DF[lane] + 5E64[lane_block]`.
- Computes a scaled amount through `5E32/33`, a `5E64`-derived scale, and `C92A`.
- Mirrors that amount into transient packet workspace at `AD9C[offset]` with mode `3` in `AD9E[offset]`.
- Clears `B202`, queues the live packet through `EBF8`, then runs `A=0x7F ; JSR 895B ; JSL FD:ACEE`.
- Strongest safe reading: scaled lane-derived dual-path packet caller with shared `7F` follow-up/apply tail.

### C1:8A9F..C1:8B0F  ct_global_opcode_98_capture_lane_b12c_variant_into_af7f_and_optionally_apply_one_point_primary_delta   [strong structural]
- Uses `B179[8]` or `AEC7` through the `B163` lane mapping.
- Captures `B12C[lane] -> AF7F[lane]` with status-based halve/double transforms.
- When `5E4B.bit4` is set, seeds `AD89 = 1`, `B1FD = lane`, `B202 = 0`, then runs `EBF8 -> EC7F` directly.
- Because the packet is primary-route and unsigned, this is the direct one-point primary-stat decrement fast path.

### C1:8B10..C1:8BB8  ct_global_opcode_99_update_lane_b019_b0a8_and_on_expiry_queue_secondary_plus5_packet_with_followup_7f_tail   [strong structural]
- Uses `B179[9]` or `AEC7` through the `B163` lane mapping.
- Updates `B019/AF8A/B0A8` on the mapped lane with the already-proved timer front end.
- On expiry and lane/block gate success, seeds `AD89 = 5`, `B1FD = lane`, mirrors the amount into transient packet workspace mode `2`, sets `B202 = 0xC0`, then runs `EBF8`.
- The `0xC0` flag byte gives the queued live packet signed-negate + secondary-route behavior.
- Finishes through `A=0x7F ; JSR 895B ; JSL FD:ACEE`.
- Strongest safe reading: timed secondary-route packet caller with the same shared `7F` follow-up/apply tail used by global `91`.

---

## New helper labels

### C1:895B..C1:8974  ct_c1_seed_fixed_followup_context_from_a_and_run_ac57_tail   [strong structural]
- Copies incoming `A` into `AE93`.
- Seeds fixed context bytes: `AE91 = 0`, `AE92 = 2`, `AE94 = 0`, `AE95 = 0`, `AE96 = 0x80`.
- Runs `JSR AC57` and returns.
- Used by both globals `91` and `99` with `A = 0x7F`.

### C1:AC57..C1:AC5D  ct_c1_run_common_followup_tail_then_apply_pending_stat_deltas   [strong structural]
- Calls `BFA4` first.
- Then calls `AC85`.
- Structural role: bridge the shared follow-up-context tail into pending stat-delta packet apply.

### C1:AC85..C1:AC88  ct_c1_apply_pending_stat_delta_channels_wrapper   [strong]
- Exact wrapper: `JSR EC7F ; RTS`.

### FD:ACEE..FD:ACFC  ct_fd_clear_ad9b_and_transient_ad9c_packet_workspace   [strong structural]
- Clears `AD9B`.
- Clears exactly `0xB0` bytes starting at `AD9C`.
- This proves the transient packet workspace spans `AD9C..AE4B`.

---

## Strengthened state labels

### 7E:AD89..7E:AD8A  ct_c1_pending_stat_delta_packet_amount_seed   [strong structural]
- 16-bit amount consumed by `EBF8` before queue write.
- Negated first when `B202.bit7` is set.

### 7E:AD9B  ct_c1_transient_packet_workspace_record_index   [strong structural]
- Record selector used by the `0x2C * record + 4 * slot` packet-workspace addressing formula.
- Explicitly cleared by `FD:ACEE`.

### 7E:AD9C..7E:AE4B  ct_c1_transient_packet_workspace_records_4x11x4   [strong structural]
- Transient packet workspace proven by the `0x2C` record stride and the `0xB0`-byte clear size in `FD:ACEE`.
- Strongest safe structure: 4 records × 11 slots × 4 bytes.

### 7E:AE55  ct_c1_materialization_descriptor_option_flags   [provisional strengthened]
- Loaded from table-driven descriptor bytes around `CC:6FCC...`.
- Consumed by the `8CF9` tail.
- Bit `3` suppresses arming the alternate continuation pointer in `B2C0`.
- Other bits still need more proof.

### 7E:B1FD  ct_c1_pending_stat_delta_packet_target_slot   [strong structural]
- Per-slot selector used by packet offset helpers like `E89F` and by `EBF8` queue writes.
- Seeded directly from the mapped lane in globals `98` and `99`.

### 7E:B202  ct_c1_pending_stat_delta_packet_flag_byte   [strong structural]
- Packet flag source mirrored into `B203` by `EBF8`.
- Bit `7` = signed-negate before queue write.
- Bit `6` = secondary-route packet path.
- Bit `5` = persistent / do-not-auto-clear channel behavior.

### 7E:B2C0  ct_c1_alternate_continuation_pointer_armed_flag   [strong structural]
- At `8CF9` entry, chooses the alternate continuation pointer in `B273` when nonzero.
- At `8CF9` tail, armed when the chosen `AECC` is in the nonhead range and `AE55.bit3` does not suppress continuation.

---

## Honest caution
Three things should stay explicit even after this pass:

- the exact human-facing meanings of transient packet workspace modes `2` and `3` are still open
- the exact consumer inside the fixed-`7F` follow-up tail is still not fully locked
- `AE55` is now materially tighter, but only bit `3` is safe to treat as pinned here


---

## Pass 75

# Chrono Trigger Labels — Pass 75

## Purpose
This file records the label upgrades justified by pass 75.

Pass 75 cleaned up the fixed-`7F` follow-up seam left open by pass 74.

The biggest correction is direct:

- `C1:BFA4` is not unresolved
- it is an exact `LDA #$04 ; JSR $0003 ; RTS` wrapper

That sharpens the shared tail behind globals `91` and `99`:

- `895B` seeds the fixed follow-up context
- `AC57` runs the local service-`04` hook
- `AC85 -> EC7F` applies pending stat-delta channels

Pass 75 also promoted the nearby current-tail runner and two downstream queue/accumulator helpers.

---

## Strengthened helper labels

### C1:BFA4..C1:BFA9  ct_c1_invoke_local_service_04_wrapper   [strong]
- Exact bytes: `LDA #$04 ; JSR $0003 ; RTS`.
- This is no longer a fuzzy helper blob.
- Structural role: tiny wrapper into the local service/dispatcher family with service id `04`.

### C1:BF7F..C1:BFA0  ct_c1_copy_17_byte_followup_descriptor_profile_from_cc213f_by_b18c   [strong structural]
- Computes `0x11 * B18C`.
- Copies `0x11` bytes from `CC:213F + 0x11*B18C` into `AEE6..AEF6`.
- Strongest safe reading: load the current follow-up/descriptor profile record selected by `B18C`.

### C1:BFAA..C1:C029  ct_c1_initialize_current_tail_followup_context_load_current_descriptor_and_run_common_tail   [strong structural]
- Sets `B1FC.bit1` on entry and clears it on exit.
- Clears `AE93/AE94/AE95/AE96/AE99/AE9A/AE9B`, sets `AE97=AE98=0xFF`, seeds `AE90=0`, `AE91=B18B`, `AE92=1`.
- Seeds single-entry selection state through `AECC=AD8E`, `AECB=1`, and `AE94=AD09()`.
- If `AEFF[B18B] != 0xFF`, resolves `CC:2583[occupant] -> B18C`, loads the 17-byte descriptor/profile through `BF7F`, and checks `AF23`.
- On success runs `AC57`, optionally arms `B2C0` when `AECC>=3`, clears transient packet workspace through `FD:ACEE`, clears `B1FC.bit1`, and returns.

### C1:AC57..C1:AC5D  ct_c1_run_service_04_hook_then_apply_pending_stat_deltas   [strong correction]
- Exact body: `JSR BFA4 ; JSR AC85 ; RTS`.
- Because `BFA4` is now exact, this tail is no longer just a vague bridge.
- Strongest safe reading: run the service-`04` follow-up hook, then apply pending stat-delta channels.

---

## Strengthened downstream helper labels

### FD:ABA2..FD:AC6D  ct_fd_accumulate_slot_descriptor_vectors_and_optional_unique_token_queues   [provisional strengthened]
- Requires `AF12[slot].bit6` clear and `AF0A[slot] != 0xFF`.
- Uses `AF0A[slot]` as an index into a 7-byte descriptor family via `DP28=index ; DP2A=7 ; JSL C1:FDBF`.
- Accumulates record components from `CC:5E00/02/06 + 7*index` into `B28C`, `B2A5`, and `B2DB/B2DD`.
- Under extra gates, inserts unique 8-bit tokens into the first free entries of `B2A7..B2A9` and `B2AA..B2AC`, setting `B2AF.bit5` when it does so.
- Final gameplay-facing nouns for those accumulators and token queues remain open.

### FD:AC6E..FD:ACEE  ct_fd_consume_pending_slot_queue_and_attempt_admission_materialization   [provisional strengthened]
- Uses `B3B9` as a nonzero queue gate/cursor seed and mirrors it into `B315`.
- Pulls pending slot ids from `B3AC[B315]` until exhausted or rejected.
- Validates pending slots against lane/block flags in the `5E4A/5E4B/5E78/5E7A/5E7B` neighborhood.
- On accepted slots may set `AFAB[slot]=1`, seeds `B18B=slot` and `AD8E=selected value`, then dispatches the downstream materialization/helper path through `C1:FDC7`.
- Clears `B3B9` when the queue walk finishes.
- Exact queue owner noun still wants one more pass.

---

## Strengthened RAM/state labels

### 7E:AEE6..7E:AEF6  ct_c1_current_followup_descriptor_profile_record_17bytes   [strong structural]
- Destination of the `BF7F` copy.
- Holds the currently loaded 17-byte follow-up/descriptor profile selected by `B18C`.

### 7E:B1FC  ct_c1_followup_context_flags   [provisional strengthened]
- `BFAA` sets bit `0x02` on entry and clears it before return.
- Strongest safe reading so far: this byte carries active/in-progress follow-up-context flags rather than being generic scratch.

---

## Honest caution
Even after this pass:

- `AEE6..AEF6` is structurally a descriptor/profile record, but the per-byte field nouns are still open.
- `FD:ABA2`'s accumulators and token queues are real, but not yet frozen to final gameplay-facing names.
- `FD:AC6E` is clearly a queue-consumer / admission runner, but the owning subsystem noun still needs one more tightening pass.


---

## Pass 76

# Chrono Trigger Labels — Pass 76

## Purpose
This file records the label upgrades justified by pass 76.

Pass 75 proved that the late fixed follow-up tail enters service `04`, but it still left service `04` itself too vague.

Pass 76 closes that gap by proving:

- `AE92` is the service-04 mode byte
- `431D` is the local service-04 mode dispatcher
- the two already-proved late callers split into different service-04 modes:
  - `BFAA` -> mode `1`
  - `895B` -> mode `2`
- both active modes converge into the same shared output/materialization runner at `4833`

This is the first pass where service `04` can be described as a real local subsystem rather than a generic hook.

---

## Strengthened helper labels

### C1:431D..C1:432A  ct_c1_service04_mode_dispatcher_by_ae92   [strong]
- Loads `AE92`, clamps any value `>= 4` to mode `0`, then dispatches through the jump table at `C1:7A63`.
- Proven table entries:
  - mode `0` -> `475A`
  - mode `1` -> `432C`
  - mode `2` -> `45A0`
  - mode `3` -> `475B`
- This is the real local mode dispatcher behind service `04`.

### C1:432C..C1:459F  ct_c1_service04_mode1_load_current_context_profiles_by_source_slot_and_run_common_emit_tail   [strong structural]
- Mode-1 front end reached when `AE92 = 1`.
- Splits immediately on `AE91 < 3` vs `AE91 >= 3`.
- Head-slot branch uses transformed slot state plus parallel bank-`CD` table families around `4000/4007/400E` and `4015/401A/401F`.
- Tail-slot branch reduces `AE91 - 3`, uses `9853[tail_local]`, and loads tail-family profiles from `CD:4926...` or `CD:4F26...` depending on `AE93`.
- Both branches populate the `9877 / 987A / 987B / 987E / 9881 / 9884` working neighborhood and converge into `4833`.
- Strongest safe reading: service-04 mode-1 current-context profile loader/emitter front end.

### C1:45A0..C1:4758  ct_c1_service04_mode2_load_fixed_followup_profiles_by_source_slot_and_run_common_emit_tail   [strong structural]
- Mode-2 front end reached when `AE92 = 2`.
- This is the exact service-04 mode used by `895B`, and therefore by the fixed-`7F` follow-up path already proved in passes 74–75.
- Head-slot branch loads a 7-byte record from `CD:45A6 + 7*AE93` into the `9877..9884` working bytes plus `987C`.
- Tail-slot branch loads the matching 7-byte record family from `CD:5526 + 7*AE93`.
- Both branches converge into `4833` after the shared bank-`D1/CD/CE` derivation chain.
- Strongest safe reading: service-04 mode-2 fixed-follow-up profile loader/emitter front end.

### C1:4833..C1:48E7  ct_c1_service04_common_output_materialization_and_emit_finalize_runner   [strong structural]
- Shared convergence tail used by both active service-04 modes proved in this seam.
- Consumes the working bytes built in the `9877..9885` neighborhood.
- Runs `JSL CD:0015` and `JSL CD:002A` unconditionally.
- Runs `JSL CD:0018` only when `AE93 != 0x37`, `AE94 == 0`, and `987C != 0xFF`.
- Calls `48EC`, prepares the `7E:2D00..` workspace for a `C3:0002` call, then runs `4943` eight times.
- Emits sixteen 6-byte output records into the `5D00..` family while setting `A07B[...] = 1`.
- Final gameplay-facing noun for the emitted thing remains open, but the common output/materialization role is now strong.

### C1:48EC..C1:493F  ct_c1_service04_parse_ce_profile_stream_into_a280_a2a0_work_vectors   [provisional strengthened]
- Consumes `9885` as the source index.
- Walks a bank-`CE` byte stream and partitions entries into the `A280..` and `A2A0..` work-vector families.
- This is clearly a service-04-local stream/parser helper for the shared output tail, not unrelated scratch logic.

### C1:4943..C1:49FD  ct_c1_service04_build_one_output_record_batch_into_a2d3_and_a45x_workspace   [provisional strengthened]
- Consumed exactly eight times from the shared `4833` runner.
- Builds one intermediate output batch into the `A2D3..` / `4500..` workspace neighborhood before final emission into `5D00..`.
- Final emitted-object noun still needs one more pass, so the label stays structural.

---

## Strengthened state labels

### 7E:AE91  ct_c1_service04_source_or_current_slot_selector   [strong structural]
- Service-04 modes `1` and `2` immediately branch on whether `AE91 < 3` or `AE91 >= 3`.
- This byte selects the source/current slot family for the active service-04 profile loader.

### 7E:AE92  ct_c1_service04_mode_selector   [strong]
- Directly consumed by `431D`.
- Values `0..3` select service-04 mode handlers through the `7A63` table.
- Values `>=4` fall back to mode `0`.

### 7E:AE93  ct_c1_service04_profile_or_pattern_index   [strong structural]
- Used directly as the record selector in service-04 mode `2` via `X = 7 * AE93`.
- Also gates family selection inside mode `1` and suppresses/permits parts of the shared `4833` tail.
- This is no longer generic follow-up scratch; it is a real service-04 profile/pattern index.

### 7E:AE94  ct_c1_service04_optional_cd0018_stage_suppress_or_override_flag   [provisional strengthened]
- The shared `4833` runner only enters the optional `JSL CD:0018` stage when `AE94 == 0`.
- Strongest safe reading so far: suppress/override flag for one optional service-04 substage.

### 7E:9877..7E:9885  ct_c1_service04_working_profile_and_derived_output_bytes   [provisional strengthened]
- Modes `1` and `2` both populate this neighborhood before entering the shared `4833` runner.
- The bytes are then consumed by the bank-`CD/D1/CE` derivation chain and the output/materialization tail.
- Exact per-byte nouns remain open, but this is now clearly a service-04 working-profile/output buffer family.

---

## Honest caution
Even after this pass:

- service-04 modes `0` and `3` at `475A / 475B` are still open
- the final gameplay-facing noun for the `4833 / 48EC / 4943` output is still not frozen
- the 17-byte `CC:213F -> AEE6..AEF6` descriptor fields still want a dedicated pass now that the service-04 mode picture is cleaner


---

## Pass 77

# Chrono Trigger Labels — Pass 77

## Purpose
This file records the label upgrades justified by pass 77.

Pass 76 proved that service `04` is a real local mode-dispatch family and that modes `1` and `2` both converge into the shared runner at `4833`.

Pass 77 closes the next exact seam:

- mode `0` is just `RTS`
- mode `3` is the missing high-range fixed-profile front end
- `48EC` parses a segmented CE stream into group start pointers and counts
- `4943` decodes one packed fragment batch into conditional 4-byte workspace records
- the `5D00..` output-slot stride is **8 bytes**, not the mistaken 6-byte wording from pass 76

That still stops short of a fully frozen player-facing noun, but the output family is now much less vague.

---

## Strengthened helper labels

### C1:475A..C1:475A  ct_c1_service04_mode0_noop_rts   [strong]
- Exact body is only `RTS`.
- This is the true mode-`0` target behind the `431D` service-04 dispatcher.
- Any `AE92 >= 4` fallback therefore collapses to no-op service-04 behavior.

### C1:475B..C1:4832  ct_c1_service04_mode3_load_high_range_fixed_followup_profiles_and_run_common_emit_tail   [strong structural]
- Computes `X = 7 * (AE93 - 0xBC)`.
- Loads a 7-byte profile record from `CD:5C26 + 7*(AE93 - 0xBC)` into the same working-byte family used by mode `2`: `9877 / 987A / 987B / 987E / 9881 / 9884 / 987C`.
- Runs the same shared derivation chain and falls into the common `4833` runner.
- Strongest safe reading: service-04 mode-3 high-range fixed-follow-up profile-loader front end.

### C1:48EC..C1:493F  ct_c1_service04_parse_segmented_ce_fragment_group_stream_into_a280_starts_and_a2a0_counts   [strong structural]
- Seeds `A280[0] = 9885`, clears local counters, then parses control classes from the top bits of the `CE:0000,X` stream.
- `0x00..0x1F` high-bit class ends the stream.
- Negative/high-bit tokens open new groups and seed their first counted 4-byte unit.
- `0x20`-class tokens commit a zero count to `A2A0[current_group]`.
- `0x40/0x60`-class tokens commit the accumulated 4-byte-unit count to `A2A0[current_group]`.
- Builds up to `0x10` group start pointers in `A280` and per-group counts in `A2A0`.
- Strongest safe reading: segmented CE fragment-group stream parser.

### C1:4943..C1:49FD  ct_c1_service04_decode_one_packed_fragment_batch_into_a2d3_and_a450_quad_workspace   [strong structural]
- Uses `A650` to choose the current output-row base through `CC:F7C0`.
- Uses `A652` as the current cursor into the packed `2D00..` stream.
- Splits the initial control byte into high/low nibble controls, copies the low-nibble-count compact bytes into `A2D3..`, then conditionally emits 4-byte records into the `4500..` workspace when shifted `A2D3` bytes carry out.
- Uses `CC:F820` lookup bytes while building those 4-byte records.
- Increments `A05B[current_row]` for each emitted record.
- Runs four internal subpasses per call before returning.
- Strongest safe reading: packed fragment/quad batch decoder into the service-04 working output workspace.

### C1:4833..C1:48E7  ct_c1_service04_common_output_materialization_and_emit_finalize_runner   [strong correction]
- Pass 76 already pinned this as the shared convergence tail for active service-04 modes.
- Pass 77 corrects one important detail: the `5D00..` output family is indexed by `JSR 0112`, and `0112 = ASL; ASL; ASL; RTS`, so the loop seeds **16 output slots at 8-byte stride**, not 6-byte records.
- The loop clears bytes `+0/+1`, seeds bytes `+2/+3` from the `D1:50A2 / D1:50A3` family, and marks `A07B[slot] = 1`.

---

## Strengthened RAM/state labels

### 7E:A280..7E:A29F  ct_c1_service04_ce_fragment_group_start_pointers_16_words   [strong structural]
- Seeded by `48EC`.
- Holds the parsed CE-stream start pointer for each fragment group.
- Initial entry `0` is seeded from `9885` before group parsing advances.

### 7E:A2A0..7E:A2AF  ct_c1_service04_ce_fragment_group_unit_counts_16_bytes   [strong structural]
- Written by `48EC` alongside `A280`.
- Holds the committed per-group count of 4-byte units derived from the segmented CE stream.

### 7E:A2D3..7E:A2E2  ct_c1_service04_current_packed_fragment_decode_bytes   [provisional strengthened]
- Filled by `4943` from the packed `2D00..` stream using the low-nibble count from the batch header byte.
- The bytes are shifted in-place and their carry result controls whether 4-byte records are emitted into the `4500..` workspace.

### 7E:A05B..7E:A07A  ct_c1_service04_per_row_emitted_fragment_record_counts   [provisional strengthened]
- `4943` clears `A05B[current_row]` on row start.
- It increments the same entry once for each emitted 4-byte workspace record.
- Strongest safe reading so far: per-row emitted fragment/quad record counts.

### 7E:A650  ct_c1_service04_current_fragment_output_row_index   [strong structural]
- Used by `4943` to choose a row base through `CC:F7C0`.
- Also indexes the `A05B` produced-record count family.

### 7E:A652  ct_c1_service04_current_packed_fragment_stream_cursor   [strong structural]
- The active `2D00..` cursor used by `4943`.
- Advanced repeatedly as compact fragment data and emitted-record payload bytes are consumed.

### 7E:5D00..7E:5D7F  ct_c1_service04_output_slot_records_16x8_stride   [provisional strengthened]
- Pass 77 corrects the stride math: this family is addressed at `5D00 + 8*slot`.
- The shared `4833` tail seeds bytes `+0/+1` to zero and bytes `+2/+3` from the `D1:50A2 / D1:50A3` family for sixteen slots.
- Final gameplay-facing noun of the slot record remains one notch below frozen.

### 7E:A07B..7E:A08A  ct_c1_service04_output_slot_active_flags_16_bytes   [provisional strengthened]
- The shared `4833` tail stores `1` here for each of the sixteen seeded output slots.
- Strongest safe reading so far: per-slot active/emit flags for the `5D00..` output record family.

---

## Honest caution
Even after this pass:

- I have **not** fully frozen the final player-facing noun of the emitted `4500.. -> 5D00..` object family.
- I have **not** decoded `C3:0002`, which still matters because it materializes the packed `2D00..` stream consumed by `4943`.
- I have **not** frozen the exact per-byte meanings of the 7-byte mode-2/mode-3 profile records.
- `A2D3` and `A05B` are materially tighter than before, but they still stop just short of a perfect final noun.


---

## Pass 78

# Chrono Trigger Labels — Pass 78

## Purpose
This file records the label upgrades justified by pass 78.

Pass 77 grounded the service-04 output path but left the front-half builder/materializer stages too fuzzy.

Pass 78 closes that specific seam:

- `C3:0002` is now pinned as a packed-stream-to-WRAM materializer veneer
- `C3:0557` is the real unpack/materialize worker returning output size in `0306`
- `CD:0015` and `CD:002A` are now pinned as the two fixed packed row-section builders for the `2D00..` workspace
- `CD:0018` is now pinned as the optional selector-driven auxiliary fragment-stage initializer / expander
- `2D00..` gets a tighter noun as a packed fragment-row stream workspace

This still stops short of a final gameplay-facing noun for the downstream `4500.. -> 5D00..` family, but the pre-decode pipeline is now materially clearer.

---

## Strengthened helper labels

### C3:0002..C3:0004  ct_c3_unpack_stream_to_caller_selected_wram_buffer_veneer   [strong]
- Exact body is `JMP $0557`.
- Used by service-04 and many other callers as the standard packed-stream-to-WRAM entry.
- Caller passes source pointer in `0300..0302`, destination pointer in `0303..0305`, and receives output size in `0306`.

### C3:0557..C3:08A8  ct_c3_unpack_packed_stream_to_wram_via_2180_and_return_output_size   [strong structural]
- Writes destination address through `$2181/$2183` and output bytes through `$2180`, proving it materializes directly into caller-selected WRAM.
- Contains multiple inner packed decode variants, but all branches are output materializers in the same family.
- Exit path stores `Y - start_dest_offset` into `0306`, so the returned value is output byte count / destination advance.

### CD:0015..CD:0017  ct_cd_build_first_four_packed_fragment_row_sections_into_2d00_veneer   [strong]
- Exact body is `JMP $1323`.
- Called unconditionally from `C1:4833` with `A = 987A`.

### CD:002A..CD:002C  ct_cd_build_last_two_packed_fragment_row_sections_into_2d00_veneer   [strong]
- Exact body is `JMP $1314`.
- Called unconditionally from `C1:4833` with `A = 987B`.

### CD:1314..CD:1322  ct_cd_build_last_two_packed_fragment_row_sections_into_2d00   [strong structural]
- Seeds `CACE = A`, `CACF = 4`, `CAD0 = 6`, then falls into the shared row-section builder.
- Therefore covers section ids `4..5`.
- Uses the `CD:1308` base-offset table to target `2D00 + 0014 / 0016`.

### CD:1323..CD:13C8  ct_cd_build_first_four_packed_fragment_row_sections_into_2d00   [strong structural]
- Seeds `CACE = A`, `CACF = 0`, `CAD0 = 4`.
- Therefore covers section ids `0..3`.
- Uses the same shared builder machinery as `1314`, targeting `2D00 + 000C / 000E / 0010 / 0012`.

### CD:1308..CD:1313  ct_cd_packed_fragment_row_section_base_offsets_000c_000e_0010_0012_0014_0016   [strong]
- Proven six-word table used by the shared `CD:1314/1323` builder loop.
- Supplies the six fixed base offsets for the `2D00..` row-section workspace.

### CD:0018..CD:001A  ct_cd_optional_selector_driven_auxiliary_fragment_stage_veneer   [strong]
- Exact body is `JMP $0D28`.
- Called conditionally from `C1:4833` only when `AE94 == 0`, `987C != FF`, and `AE93 != 37`.

### CD:0D28..CD:0D32  ct_cd_optional_selector_driven_auxiliary_fragment_stage   [strong structural]
- Clears `5D9B`, treats input `A` as the selector, runs `0EBD`, then runs `0D33`.
- This is the top-level coordinator for the optional pre-decode auxiliary stage.

### CD:0D33..CD:0D5F  ct_cd_clear_auxiliary_fragment_work_tables_and_expand_ca93_descriptor_list   [strong structural]
- Clears the `CA32 / CA52 / CA72` work families over the local loop.
- Then walks `CA93[...]` until `FF`, calling `15D5` for each live descriptor.
- Strongest safe reading: descriptor-list expander into auxiliary fragment work tables.

### CD:0EBD..CD:0F9F  ct_cd_init_auxiliary_fragment_stage_by_selector_and_battle_layout   [strong structural]
- Consumes the selector passed through `X` and checks live battle-layout / side-state bytes (`A017/A018`, `2A21`, `2C66/67`, etc.).
- Seeds the `CC91 / CC93 / CC95 / CCA2` family and related local state before the later `0D33` expansion stage.
- Strongest safe reading: selector/battle-layout initializer for the optional auxiliary fragment stage.

---

## Strengthened RAM/state labels

### 7E:0300..7E:0302  ct_c3_unpack_source_pointer   [strong structural]
- Caller-provided source pointer consumed by the standard `C3:0002 -> C3:0557` unpack/materialize worker.

### 7E:0303..7E:0305  ct_c3_unpack_destination_pointer   [strong structural]
- Caller-provided destination pointer for the same worker.
- `C3:0557` writes through the WRAM port using this destination address.

### 7E:0306..7E:0307  ct_c3_unpack_output_size_or_destination_advance   [strong structural]
- Exact worker exit stores `Y - start_dest_offset` here.
- Service-04 immediately uses it as the termination point for the materialized `2D00..` workspace.

### 7E:2D00..7E:2DFF  ct_c1_service04_packed_fragment_row_stream_workspace   [strong correction]
- Pass 77 proved this is a packed stream consumed by `4943`.
- Pass 78 tightens that noun: `CD:0015/002A` populate six fixed row-sections at offsets `000C/000E/0010/0012/0014/0016`, and `C3:0002` materializes packed bytes into the same workspace.
- Strongest safe reading: packed fragment-row stream workspace for the service-04 decode path.

### 7E:CA32..7E:CA8F  ct_cd_auxiliary_fragment_work_tables_primary_secondary_tertiary   [provisional strengthened]
- Cleared by `CD:0D33` before descriptor expansion.
- Populated indirectly from the `CA93` descriptor list via `15D5`.
- Final gameplay-facing noun still needs one more pass, but these are now clearly the core auxiliary-stage work tables.

### 7E:CA93..7E:CA9F  ct_cd_auxiliary_fragment_descriptor_list   [provisional strengthened]
- Walked by `CD:0D33` until `FF`.
- Each live byte triggers a `15D5` descriptor-expansion pass into the `CA32/52/72` work families.

---

## Honest caution
Even after this pass:

- I have **not** fully decoded the four transform/materialization modes under `CD:13E6`.
- I have **not** frozen the final gameplay-facing noun of the `CA32/52/72` auxiliary work families.
- I have **not** fully frozen the downstream noun of the `4500.. -> 5D00..` output family.
- The strongest proof on `C3:0557` is family role, WRAM-port output, and returned output size — not a full codec taxonomy.


---

## Pass 79

# Chrono Trigger Labels — Pass 79

## Purpose
This file records the label upgrades justified by pass 79.

Pass 78 proved the late service-04 path was a real packed-row/materialization pipeline, but the transform modes and the optional `CA32..` stage were still too fuzzy.

Pass 79 closes that seam:

- `CD:13E6` is now pinned as a four-mode **tile-orientation** jump table
- `C0:FD00` is now pinned as a **bit-reverse lookup table**
- `1509 / 1445 / 13F6 / 13EE` now read cleanly as **direct / H-flip / V-flip / HV-flip** tile materializers
- `15D5` and `1609` now pin the optional `CA32..` path as a **two-slot auxiliary descriptor stream interpreter**
- `5D9B` and `CCEA` are materially tighter as stage-level gate/progression bytes for that optional auxiliary stage

This still stops short of the final gameplay-facing noun for the downstream `4500.. -> 5D00..` emit family, but the late path is now much more clearly graphics/tile-oriented.

---

## Strengthened helper labels

### CD:13E6..CD:13ED  ct_cd_tile_orientation_mode_ptr_table_direct_hflip_vflip_hvflip   [strong]
- Exact four-entry local jump table used by the shared `1323/1314` row builder.
- Entry order is now pinned as:
  - `1509` = direct
  - `1445` = horizontal flip
  - `13F6` = vertical flip
  - `13EE` = horizontal + vertical flip

### CD:1509..CD:15D4  ct_cd_materialize_one_32byte_4bpp_tile_block_from_d0_source_with_optional_second_block_merge   [strong structural]
- Uses the low 13 bits of the active source word as the `D0` source index, multiplied by 8.
- Always materializes one 32-byte tile-shaped block into the active `2D00..` row section.
- Bit `0x2000` controls whether a second `D0` source block is merged into the upper half.
- Safest reading: direct tile materializer over one or two `D0` source blocks.

### CD:1488..CD:1508  ct_cd_materialize_base_tile_planes_and_masked_upper_half_from_d0_source_block   [strong structural]
- Shared helper used by `1509`.
- Builds the first `0x10` bytes directly from `D0`, then derives the paired `+0x10` upper half under selector mask `$5F`.
- Strongest safe reading: base 32-byte tile-block materializer helper.

### CD:13F6..CD:1444  ct_cd_materialize_tile_then_apply_vertical_flip_to_both_plane_halves   [strong structural]
- Calls the direct tile materializer, then uses the internal `13FE` helper twice.
- The helper swaps word pairs `00<->0E`, `02<->0C`, `04<->0A`, `06<->08` and advances `Y` by `0x10`.
- Therefore reverses row order in both 16-byte plane halves of one 32-byte tile block.
- Strongest safe reading: vertical-flip tile materializer.

### CD:1445..CD:1484  ct_cd_materialize_tile_then_apply_horizontal_flip_via_c0_fd00_bit_reverse   [strong structural]
- Calls the direct tile materializer, then rewrites the resulting bytes through `C0:FD00`.
- `C0:FD00` is a plain bit-reverse map, so this is the tile horizontal-flip path.

### CD:13EE..CD:13F5  ct_cd_materialize_tile_then_apply_hv_flip_composite_path   [strong structural]
- Exact body is `PHY ; JSR 13F6 ; PLY ; JMP 144A`.
- So it composes the vertical-flip path with the bit-reverse horizontal-flip body.
- Strongest safe reading: horizontal + vertical flip tile materializer.

### C0:FD00..C0:FDFF  ct_c0_bit_reverse_lookup_256   [strong]
- Exact 256-byte bit-reversal table.
- Example mappings: `01->80`, `02->40`, `03->C0`.
- Used directly by the `1445` horizontal-flip tile path.

### D1:646C..D1:652B  ct_d1_auxiliary_descriptor_pointer_table   [strong structural]
- `15D5` multiplies the descriptor id by two and reads a pointer from this table.
- The returned pointer seeds one active runtime slot in the optional auxiliary descriptor stage.

### CD:15D5..CD:1608  ct_cd_expand_one_auxiliary_descriptor_id_into_one_active_runtime_slot   [strong structural]
- Looks up a descriptor pointer from `D1:646C`.
- Seeds the active slot's stream pointer and cadence bytes.
- Increments the slot active flag.
- Strongest safe reading: expand one descriptor id into one active runtime stream slot.

### CD:1609..CD:16A5  ct_cd_tick_two_auxiliary_descriptor_runtime_slots_and_interpret_ready_tokens   [strong structural]
- Runs only while the optional auxiliary stage is active.
- Walks the two active `CA32` runtime slots.
- Decrements each slot countdown and calls `1654` whenever the countdown expires.
- `1654` treats `<80` bytes as data tokens, `7F` as a dedicated advance token, `FF` as end-of-slot, and `>=80` as command tokens dispatched through the large local jump table.
- Strongest safe reading: two-slot auxiliary descriptor stream scheduler/interpreter.

### CD:16B5..CD:17A6  ct_cd_auxiliary_descriptor_token_dispatch_table   [strong structural]
- Large local dispatch table reached from `16A6` for command bytes `>= 0x80`.
- Exact handler nouns remain open, but the dispatch-table role is now settled.

---

## Strengthened RAM/state labels

### 7E:2D00..7E:2DFF  ct_c1_service04_packed_tile_row_or_tile_batch_workspace   [strong correction]
- Pass 78 already proved this is a packed row/materialization workspace consumed by `4943`.
- Pass 79 strengthens the noun: the local `CD:13E6` builder modes are exact tile orientation modes over 32-byte tile-shaped blocks.
- Strongest safe reading now: packed tile-row / tile-batch workspace for the late service-04 graphics assembly path.

### 7E:CA32..7E:CA4F  ct_cd_two_auxiliary_descriptor_runtime_slot_structs_2x16   [strong structural]
- `0D33` clears this range in 16-byte slot steps.
- `15D5` seeds each active slot from a descriptor pointer looked up in `D1:646C`.
- `1609` ticks these slots, decrements their countdowns, and interprets stream tokens through `1654`.
- Strongest safe reading: two active runtime slot structs for the optional auxiliary descriptor stage.

### 7E:CA52..7E:CA8F  ct_cd_secondary_and_tertiary_auxiliary_descriptor_work_families   [provisional strengthened]
- Cleared alongside the active runtime slot family in `0D33`.
- Exact field meanings still need another pass, but these are parallel work families for the same optional auxiliary stage.

### 7E:CA93..7E:CA9F  ct_cd_auxiliary_descriptor_id_list_first_two_seed_runtime_slots   [strong correction]
- `0D33` only consumes the first two live ids here because the runtime expansion loop advances `X` by `0x10` and stops at `0x20`.
- So the first two live entries seed the two active runtime slots in `CA32..CA4F`.

### 7E:5D9B  ct_cd_optional_auxiliary_descriptor_stage_active_flag   [strong structural]
- Cleared at stage start by `0D28`.
- Checked by `1609` before any runtime-slot ticking occurs.
- Cleared again when the stage-level local completion condition is met.

### 7E:CCEA  ct_cd_optional_auxiliary_descriptor_stage_progress_byte   [provisional strengthened]
- `1609` only services runtime slots while this byte is zero.
- Incremented when the local two-slot service pass reaches its completion condition.
- Strongest safe reading: stage-level progression/completion byte for the optional auxiliary descriptor stage.

---

## Honest caution
Even after this pass:

- I have **not** fully frozen the artist-facing noun of the `D0` source entries.
- I have **not** fully frozen the final gameplay/object noun of the downstream `4500.. -> 5D00..` emit family.
- I have **not** decoded the entire `16B5..` token-handler table end-to-end.
- I have **not** fully frozen the exact field meanings of the `CA52 / CA72` parallel work families.


---

## Pass 80

# Chrono Trigger Labels — Pass 80

## Purpose
This file records the label upgrades justified by pass 80.

Pass 79 proved that the optional `CD:0018` side was a two-slot auxiliary descriptor stream interpreter, but the big `16B5..` command space still had no real sub-families.

Pass 80 closes the first important chunk of that seam:

- `1654` is now pinned as a real **one-token auxiliary stream interpreter**
- raw bytes `< 0x7F` now tie directly to a derived `D0`-side tile-block source pointer
- `0x7F` is an exact **advance/skip token**
- the first real command families under `0x80..0xFF` are now pinned as:
  - extended sub-dispatch
  - countdown seed
  - paired-delta transform
  - repeat/rewind loop control
  - immediate absolute write
  - indexed 2-word pair copy
  - conditional rewind
  - direct staging writes

This still does **not** freeze the full final noun of the downstream `4500.. -> 5D00..` emit family, but the optional auxiliary stage is now much more clearly a graphics/tile-support VM.

---

## Strengthened helper labels

### CD:1654..CD:169F  ct_cd_interpret_one_auxiliary_stream_token_and_derive_d0_tile_block_request_or_dispatch_command   [strong structural]
- Pulls one byte from the current active auxiliary runtime-slot stream.
- `0x7F` increments the stream pointer only.
- `< 0x7F` biases the token by `CA3A,X`, derives a `D0`-rooted tile-block source pointer into `CA18`, and increments `CA17`.
- `>= 0x80` dispatches through the command-token table at `16B5`.
- Strongest safe reading: one-token interpreter for the auxiliary stream VM.

### CD:16A6..CD:16B4  ct_cd_dispatch_one_auxiliary_command_token_80_ff_by_low7_id   [strong]
- Saves the active slot base in `$43`.
- Advances the stream pointer by one byte.
- Dispatches command tokens `0x80..0xFF` through `16B5` using the token's low 7 bits.

### CD:16B5..CD:17A6  ct_cd_auxiliary_command_token_ptr_table_80_ff   [strong correction]
- This is not just a generic dispatch table anymore.
- It is now pinned as the main 128-command token pointer table for the auxiliary stream VM.

### CD:2A4A..CD:2A8E  ct_cd_auxiliary_token_80_extended_subopcode_dispatcher_32way   [strong structural]
- Token `0x80` reads the following stream byte, doubles it, and dispatches through the local table at `2A51`.
- Strongest safe reading: extended/meta command family with 32 secondary sub-opcodes.

### CD:2DCB..CD:2DD5  ct_cd_auxiliary_token_81_seed_slot_reload_and_current_countdown   [strong]
- Writes the same immediate byte to `CA38,X` and `CA39,X`.
- Exact role: seed reload + current countdown for the active auxiliary runtime slot.

### CD:2DD6..CD:2E9F  ct_cd_auxiliary_token_82_apply_one_of_eight_paired_16bit_delta_ops_to_ca5e_ca60   [strong structural]
- Low 5 bits + 1 of the immediate byte become the magnitude.
- High 3 bits select one of eight local sub-ops through `2DEA`.
- Those sub-ops apply all sign-combination variants over the paired 16-bit fields at `CA5E,X` and `CA60,X`.
- Strongest safe reading: paired-delta operator token for the auxiliary VM.

### CD:2DEA..CD:2DF9  ct_cd_auxiliary_token_82_paired_delta_subop_ptr_table_8   [strong]
- Exact eight-entry local pointer table used by token `0x82`.
- Dispatches the paired add/subtract variants over `CA5E/CA60`.

### CD:2EA2..CD:2EB4  ct_cd_auxiliary_token_83_seed_repeat_resume_pointer_and_repeat_count   [strong]
- Stores the current stream pointer to `CA72,X`.
- Stores `immediate + 1` to `CA74,X`.
- Exact role: repeat-loop seed token.

### CD:2EB5..CD:2EC7  ct_cd_auxiliary_token_84_repeat_until_countdown_exhausted_then_consume_trailing_byte   [strong structural]
- Decrements `CA74,X`.
- While nonzero, rewinds the stream pointer back to `CA72,X`.
- When exhausted, consumes one trailing byte and falls through.

### CD:2EC8..CD:2EDD  ct_cd_auxiliary_token_85_seed_repeat_resume_pointer_and_clear_ca3a   [strong structural]
- Same repeat-loop seed pattern as token `0x83`.
- Also clears `CA3A,X`.

### CD:2EDE..CD:2EF6  ct_cd_auxiliary_token_86_repeat_with_iteration_counter_in_ca3a   [strong structural]
- Same repeat-loop behavior as token `0x84`.
- Increments `CA3A,X` each loop iteration.
- Clears `CA3A,X` when the loop terminates.

### CD:17A9..CD:17BD  ct_cd_auxiliary_token_f9_write_immediate_byte_to_absolute_target   [strong]
- Reads one immediate byte and the following absolute 16-bit destination address.
- Writes the byte directly to that destination.

### CD:17BE..CD:17DE  ct_cd_auxiliary_token_f8_copy_one_indexed_2word_pair_between_2000_2200_tables   [strong structural]
- Reads a source index and destination index from the stream.
- Copies one 2-word record from the `$2000/$2200` table families at the source index to the destination index.

### CD:17DF..CD:17E4  ct_cd_auxiliary_token_f7_store_immediate_to_ce0e   [strong]
- Exact tiny handler: store next stream byte to `CE0E`.

### CD:17E5..CD:17FE  ct_cd_auxiliary_token_f6_conditional_stream_rewind_by_immediate_when_ce10_allows   [strong structural]
- Uses `CE10` as a one-shot latch/gate.
- If the gate condition passes, subtracts the immediate byte from the stream pointer and then clears `CE10`.

### CD:17FF..CD:1804  ct_cd_auxiliary_token_f5_store_immediate_to_cd46   [strong]
- Exact tiny handler: store next stream byte to `CD46`.

### CD:1805..CD:1809  ct_cd_auxiliary_token_f4_call_d1_ebff   [strong]
- Exact wrapper token: `JSL D1:EBFF ; RTS`.

### CD:180A..CD:1812  ct_cd_auxiliary_token_f3_store_immediate_to_cd45_and_increment_cd44   [strong]
- Stores the immediate byte to `CD45`.
- Increments `CD44`.
- Strongest safe reading: seed the one-shot rewind/gate state later consumed by token `0xF2`.

### CD:1813..CD:1829  ct_cd_auxiliary_token_f2_conditional_stream_rewind_by_immediate_when_cd44_allows   [strong structural]
- Structural sibling of token `0xF6`.
- Uses `CD44` as the latch/gate and subtracts the immediate byte from the stream pointer when active.

### CD:182A..CD:1830  ct_cd_auxiliary_token_f1_copy_5d8f_into_indexed_caa4_slot   [strong]
- Reads one immediate slot index byte.
- Copies stage/global byte `5D8F` into `CAA4 + index`.

### CD:184B..CD:184F  ct_cd_auxiliary_token_f0_call_d1_efd0   [strong]
- Exact wrapper token: `JSL D1:EFD0 ; RTS`.

---

## Strengthened RAM/state labels

### 7E:CA17  ct_cd_auxiliary_pending_d0_tile_block_request_count_or_flag   [strong structural]
- Incremented by the raw-data token path in `1654`.
- Cleared/consumed by the `06xx` auxiliary graphics-side follow-up.
- Strongest safe reading: pending auxiliary tile-block request count/flag.

### 7E:CA18..7E:CA19  ct_cd_auxiliary_current_derived_d0_tile_block_source_ptr   [strong structural]
- Written by the raw-data token path in `1654` after biasing the token with `CA3A`.
- Consumed by the `06xx` auxiliary graphics-side follow-up.
- Strongest safe reading: current derived `D0` tile-block source pointer.

### 7E:CA3A..7E:CA49  ct_cd_auxiliary_runtime_slot_stream_bias_or_iteration_bytes_2x16   [provisional strengthened]
- `1654` adds `CA3A,X` to raw data-token values before deriving the `D0`-side source pointer.
- Token `0x86` increments `CA3A,X` per loop iteration and clears it on termination.
- Strongest safe reading: slot-local stream bias / iteration side-effect bytes.

### 7E:CA5E..7E:CA71  ct_cd_auxiliary_runtime_slot_paired_16bit_accumulator_fields   [strong structural]
- Token `0x82` applies eight exact paired add/subtract variants over `CA5E,X` and `CA60,X`.
- That proves these are real 16-bit accumulator-like fields, not generic scratch.
- Final gameplay-facing noun still needs another pass.

### 7E:CA72..7E:CA85  ct_cd_auxiliary_runtime_slot_repeat_resume_ptr_and_repeat_count_fields   [strong structural]
- Tokens `0x83..0x86` prove the role of these fields.
- `CA72,X` = loop resume pointer.
- `CA74,X` = repeat countdown.

### 7E:CD44  ct_cd_auxiliary_token_f2_rewind_latch_count   [provisional strengthened]
- Incremented by token `0xF3`.
- Consumed and cleared by token `0xF2` after conditional rewind.

### 7E:CD45  ct_cd_auxiliary_token_f3_rewind_immediate_staging_byte   [provisional strengthened]
- Written by token `0xF3`.
- Structural sibling state for the `0xF2` conditional rewind family.

### 7E:CD46  ct_cd_auxiliary_token_f5_immediate_staging_byte   [provisional strengthened]
- Directly written by token `0xF5`.
- Final gameplay-facing noun still open.

### 7E:CE0E  ct_cd_auxiliary_token_f7_immediate_staging_byte   [provisional strengthened]
- Directly written by token `0xF7`.
- Final gameplay-facing noun still open.

### 7E:CE10  ct_cd_auxiliary_token_f6_rewind_gate_latch   [provisional strengthened]
- Consumed and cleared by token `0xF6` after the conditional rewind path.
- Strongest safe reading: one-shot rewind gate/latch for the `0xF6` token.

---

## Honest caution
Even after this pass:

- I have **not** finished the full `0x80..0xFF` token table.
- I have **not** decoded all 32 sub-ops under token `0x80`.
- I have **not** frozen the final player-facing noun of the downstream `4500.. -> 5D00.. -> A07B` family.
- I have **not** frozen the exact final noun of the paired `CA5E/CA60` accumulator fields.
- I have **not** frozen the exact gameplay meaning of the `CD44/CD45/CD46` and `CE0E/CE10` latch bytes.


---

## Pass 81

# Chrono Trigger Labels — Pass 81

## Purpose
This file records the label upgrades justified by pass 81.

Pass 80 proved that token `0x80` inside the auxiliary `CD:0018` stream VM is a secondary sub-dispatch through `CD:2A51`, but the sub-op table still had no real internal structure.

Pass 81 closes the first strong chunk of that gap:

- the table is now pinned as a **29-entry live sub-op family (`0x00..0x1C`)**, not a clean 32-entry block
- the upper tail now contains several exact wrappers/latches
- `0x15..0x17` now read as a real **E500/E850 strided table-control band**
- `0x0F..0x14` now read as a real **state/preset-builder band**
- `0x00`, `0x0E`, and `0x13` now read as one shared **BB/BC parallel-table builder family**

I still do **not** freeze the final gameplay-facing noun of every affected table.
These labels stay structural where proof is still one notch short.

---

## Strengthened helper labels

### CD:2A51..CD:2A89  ct_cd_auxiliary_token_80_extended_subopcode_ptr_table_29_live_entries   [strong correction]
- The table reached from token `0x80` does **not** expose a clean 32-entry live namespace.
- Straight ROM parsing gives live sub-op targets for `0x00..0x1C` only.
- After that, the bytes are ordinary code, not more valid pointer entries.
- Strongest safe reading: 29-entry live extended sub-op family.

### CD:2AA5..CD:2AA9  ct_cd_auxiliary_token_80_subop_18_call_d1_e91a   [strong]
- Exact wrapper: `JSL D1:E91A ; RTS`.

### CD:2AA1..CD:2AA4  ct_cd_auxiliary_token_80_subop_19_increment_ce10_rewind_gate   [strong]
- Exact one-byte latch setter.
- Increments `CE10` and returns.
- Strongest safe reading: arm/set path for the rewind gate later consumed by token `0xF6`.

### CD:2A9C..CD:2AA0  ct_cd_auxiliary_token_80_subop_1a_call_d1_e899   [strong]
- Exact wrapper: `JSL D1:E899 ; RTS`.

### CD:2A8B..CD:2A96  ct_cd_auxiliary_token_80_subop_1b_increment_8byte_strip_at_9ffa   [strong structural]
- Starts with zeroed X and increments `9FFA,X` across eight consecutive byte positions.
- Final noun of the `9FFA..A001` strip is still open.

### CD:2A97..CD:2A9B  ct_cd_auxiliary_token_80_subop_1c_call_d1_e8c1   [strong]
- Exact wrapper: `JSL D1:E8C1 ; RTS`.

### CD:2AEF..CD:2B04  ct_cd_auxiliary_token_80_subop_15_clear_strided_e500_e502_pair_table   [strong structural]
- Walks in 4-byte steps and clears `E500,X` and `E502,X` until `X == 0x06A0`.
- Strongest safe reading: clear pass over a strided pair-table family.

### CD:2AC6..CD:2AEE  ct_cd_auxiliary_token_80_subop_16_run_tripled_setup_then_decrement_active_e500_by_10_where_e850_live   [strong structural]
- Calls the shared local setup helper three times.
- Walks the same strided family and subtracts `0x0010` from `E500,X` when `E850,X` is nonzero.
- Final gameplay-facing noun of the `E500/E850` families remains open.

### CD:2AAA..CD:2AC5  ct_cd_auxiliary_token_80_subop_17_d1_e984_anchored_local_setup_entry   [provisional strengthened]
- Anchored by the exact wrapper call to `D1:E984`.
- Also advances `CD3B` and falls into a local lookup/copy follow-up.
- Strongest safe reading so far: local setup entry belonging to the same `E500/E850`-side family as sub-ops `0x15/0x16`.

### CD:2B5C..CD:2B63  ct_cd_auxiliary_token_80_subop_0f_clear_99b5_at_index_from_cd00   [strong]
- Loads `CD00` into X and clears `99B5,X`.

### CD:2B45..CD:2B5B  ct_cd_auxiliary_token_80_subop_10_seed_e0_into_parallel_bb_bc_highbyte_tables   [strong structural]
- Writes `0xE0` into `BB07,Y`, `BB87,Y`, and `BC07,Y` in a repeated stride pattern.
- Strongest safe reading: preset builder for three parallel high-byte tables.

### CD:2B27..CD:2B44  ct_cd_auxiliary_token_80_subop_11_seed_mirrored_pair_around_80_and_arm_99d2_bit7   [strong structural]
- Sets `99D2.bit7`.
- Copies `99D3` into `05A5` and `0599`.
- Copies `0x80 - 99D3` into `05A6` and `059A`.
- Strongest safe reading: mirrored/complement pair seed around midpoint `0x80`.

### CD:2B12..CD:2B26  ct_cd_auxiliary_token_80_subop_12_clamp_5da1_to_31_d4   [strong]
- Exact clamp of `5DA1` into `[0x31, 0xD4]`.

### CD:2D39..CD:2DC9  ct_cd_auxiliary_token_80_subop_13_seed_5d9a_then_build_parallel_bb_bc_tables   [strong structural]
- Writes `5D9A = 1`.
- Seeds `A = 0x14`.
- Falls into the shared `2D53` parallel-table builder tail.

### CD:2B05..CD:2B11  ct_cd_auxiliary_token_80_subop_14_seed_cd3a_0060_and_007c_0040   [strong]
- Exact constant seeds:
  - `CD3A = 0x0060`
  - `$007C = 0x0040`

### CD:2D44..CD:2DC9  ct_cd_auxiliary_token_80_subop_0e_build_parallel_bb_bc_tables_fixed_a04   [strong structural]
- Seeds `A = 0x04` and falls into the shared `2D53` builder tail.

### CD:2D4A..CD:2DC9  ct_cd_auxiliary_token_80_subop_00_countdown_variant_of_parallel_bb_bc_table_builder   [strong structural]
- Clears/uses `CD04` and then enters the shared `2D53` builder tail.
- Strongest safe reading: countdown/variation member of the same table-builder family as `0x0E` and `0x13`.

### CD:2D53..CD:2DC9  ct_cd_auxiliary_token_80_shared_parallel_bb06_bb86_bc06_and_bb07_bb87_bc07_builder_tail   [strong structural]
- Shared convergence tail used by sub-ops `0x00`, `0x0E`, and `0x13`.
- Writes repeated-stride values into:
  - `BB06/BB07`
  - `BB86/BB87`
  - `BC06/BC07`
- Final gameplay-facing noun of these three parallel arrays remains one notch below frozen.

---

## Strengthened RAM/state labels

### 7E:CE10  ct_cd_auxiliary_token_f6_rewind_gate_latch   [stronger support]
- Pass 80 already proved that token `0xF6` consumes and clears this latch.
- Pass 81 adds the clean setter path: token `0x80:19` increments it directly.
- Strongest safe reading: rewind gate/latch, not generic scratch.

### 7E:9FFA..7E:A001  ct_cd_auxiliary_token_80_subop_1b_8byte_counter_or_flag_strip   [provisional strengthened]
- Incremented across eight consecutive byte positions by sub-op `0x1B`.
- Final noun remains open.

### 7E:E500..7E:EB9F (strided pair family)  ct_cd_auxiliary_token_80_strided_e500_e502_pair_table_family   [provisional strengthened]
- Sub-op `0x15` clears `E500/E502` in 4-byte steps.
- Sub-op `0x16` subtracts `0x0010` from active `E500` entries where companion `E850` markers are live.
- Strongest safe reading: linked strided pair-table family with an activity/marker companion table.

### 7E:E850..7E:EEEF (strided marker family)  ct_cd_auxiliary_token_80_strided_e850_activity_marker_family   [provisional strengthened]
- Read by sub-op `0x16` as the gate for whether the matching `E500` entry is decremented.
- Final noun still open.

### 7E:99B5..  ct_cd_auxiliary_token_80_indexed_clearable_state_bytes   [provisional strengthened]
- Sub-op `0x0F` clears one indexed byte chosen by `CD00`.

### 7E:99D2  ct_cd_auxiliary_token_80_mirrored_pair_arm_flags   [provisional strengthened]
- Sub-op `0x11` sets bit 7 before seeding the mirrored/complement pair around `99D3`.

### 7E:99D3  ct_cd_auxiliary_token_80_mirrored_pair_seed_byte   [provisional strengthened]
- Used by sub-op `0x11` as the source byte whose complement around `0x80` is also emitted.

### 7E:5DA1  ct_cd_auxiliary_token_80_clamped_state_byte_31_d4   [provisional strengthened]
- Sub-op `0x12` clamps this byte into `[0x31, 0xD4]`.

### 7E:5D9A  ct_cd_auxiliary_token_80_parallel_table_builder_arm_latch   [provisional strengthened]
- Set to `1` by sub-op `0x13` before entering the shared `2D53` builder tail.

### 7E:CD04  ct_cd_auxiliary_token_80_parallel_table_builder_countdown_or_variation_byte   [provisional strengthened]
- Cleared/updated by sub-op `0x00` before entering the shared `2D53` builder tail.

### 7E:CD3A  ct_cd_auxiliary_token_80_constant_seed_word_0060   [provisional strengthened]
- Set to `0x0060` by sub-op `0x14`.

### 7E:BB06.. / 7E:BB86.. / 7E:BC06.. and companions  ct_cd_auxiliary_token_80_parallel_bb_bc_builder_tables   [provisional strengthened]
- Sub-op `0x10` seeds the `+1` high-byte members with `0xE0`.
- Sub-ops `0x00`, `0x0E`, and `0x13` all converge into the shared `2D53` tail that writes the wider family.
- Final noun still open, but these are clearly parallel structured tables, not scratch.

---

## Honest caution
Even after this pass:

- I have **not** frozen the final noun of the `E500/E850` strided families.
- I have **not** frozen the final noun of the `BB06/07`, `BB86/87`, and `BC06/07` tables.
- I have **not** decoded the exact downstream helpers at `D1:E899`, `D1:E8C1`, `D1:E91A`, and `D1:E984`.
- I have **not** tied the newly-decoded `0x80` sub-op state all the way into the final `4500 -> 5D00 -> A07B` emit noun.


---

## Pass 82

# Chrono Trigger Labels — Pass 82

## Purpose
This file records the label upgrades justified by pass 82.

Pass 81 proved that token `0x80` in the auxiliary `CD:0018` VM reaches exact D1-bank wrappers, but the D1 targets still had no strong nouns.

Pass 82 closes that gap:

- sub-op `0x17` can now be tightened from a fuzzy anchored entry to an **exact wrapper** to `D1:E984`
- `D1:E899` and `D1:E8C1` are now pinned as exact **`0x7FFF` sentinel-fill helpers** for paired palette-band work tables
- `D1:E91A` and `D1:E984` are now pinned as complementary **promote/copy** vs **seed/snapshot** helpers
- `D0:FD00..D0:FD5F` is now pinned as the exact ROM-side **48-color seed block**
- `0520..0543` and `0544..0567` are now much more strongly tied together as two adjacent **3-record palette/effect descriptor slabs**

This still does **not** freeze the final gameplay-facing noun of every `20xx/21xx/22xx/23xx` band.
The labels stay structural where the last step still needs runtime proof.

---

## Strengthened helper labels

### CD:2AAA..CD:2AAE  ct_cd_auxiliary_token_80_subop_17_exact_wrapper_call_d1_e984   [strong correction]
- Exact body: `JSL D1:E984 ; RTS`.
- The local code at `CD:2AAF..` belongs to the shared helper used by sub-op `0x16`, not to sub-op `0x17`.

### D1:E899..D1:E8C0  ct_d1_fill_palette_band_pairs_2040_2240_and_2120_2320_with_7fff_sentinel   [strong]
- Fills `7E:2040..20FF` and `7E:2240..22FF` with `0x7FFF`.
- Then fills `7E:2120..217F` and `7E:2320..237F` with the same sentinel.
- Exact structural role: paired palette-band/table sentinel initializer.

### D1:E8C1..D1:E8D4  ct_d1_fill_palette_band_pair_21a0_23a0_with_7fff_sentinel   [strong]
- Fills `7E:21A0..21FF` and `7E:23A0..23FF` with `0x7FFF`.
- Exact smaller sibling of `D1:E899`.

### D1:E91A..D1:E983  ct_d1_promote_first_48color_palette_band_and_restore_active_3record_descriptor_slab   [strong structural]
- Copies `7E:2040..209F` into `7E:20A0..20FF` and `7E:22A0..22FF`, then clears `7E:2040..209F` and `7E:2240..229F`.
- Copies `7E:0544..0567` back into `7E:0520..0543`.
- Adds `0x30` to the `+1` byte of each copied 12-byte record.
- Seeds `0520/052C/0538` and `CD2F..CD31` with `0x30`.
- Clears `CD32..CD34` and `CDC8`.
- Increments `CE12`.
- Strongest safe reading: promote/copy helper for one palette-band pair plus one active descriptor slab restore/arm step.

### D1:E984..D1:E9EB  ct_d1_seed_first_48color_palette_band_from_d0_fd00_and_snapshot_active_descriptor_slab_outward   [strong structural]
- Increments `CDC8` and `CE0F`.
- Copies ROM data from `D0:FD00..FD5F` into `7E:2040..209F` and `7E:2240..229F`.
- Copies `7E:0520..0543` outward into `7E:0544..0567`.
- Subtracts `0x30` from the `+1` byte of each copied 12-byte record.
- Seeds `0548/0554/0560` with `0x0100`.
- Seeds `0544/0550/055C` and `CD32..CD34` with `0x30`.
- Increments `CE12`.
- Strongest safe reading: complementary seed/snapshot helper paired with `D1:E91A`.

### D0:FD00..D0:FD5F  ct_d0_palette_band_seed_block_48colors_for_d1_e984   [strong]
- Exact fixed ROM table copied by `D1:E984` into `7E:2040..209F` and `7E:2240..229F`.
- Not compressed and not computed locally.

---

## Strengthened RAM/state labels

### 7E:0520..7E:0543  ct_palette_effect_descriptor_active_slab_3x12byte_records   [stronger support]
- Passes 8–9 already proved `0520 + n*0C` is a palette/effect descriptor family.
- Pass 82 adds exact slab-level proof: `D1:E91A` restores `0544..0567 -> 0520..0543`, and `D1:E984` snapshots `0520..0543 -> 0544..0567`.
- Strongest safe reading: active 3-record descriptor slab.

### 7E:0544..7E:0567  ct_palette_effect_descriptor_secondary_slab_3x12byte_records   [stronger support]
- Exact `0x24`-byte partner slab adjacent to `0520..0543`.
- `D1:E91A` copies this slab back into the active slab.
- `D1:E984` copies the active slab outward into this slab and biases fields afterward.

### 7E:2040..7E:209F  ct_d1_first_48color_palette_band_work_pair_a   [provisional strengthened]
- Seeded from `D0:FD00` by `D1:E984`.
- Later promoted/cleared by `D1:E91A`.
- Final gameplay-facing band noun still open.

### 7E:2240..7E:229F  ct_d1_first_48color_palette_band_work_pair_b   [provisional strengthened]
- Exact partner band written alongside `7E:2040..209F` by both `D1:E984` and `D1:E91A`.
- Final noun still open.

### 7E:20A0..7E:20FF  ct_d1_promoted_48color_palette_band_pair_a   [provisional strengthened]
- Filled only by `D1:E91A` from `7E:2040..209F`.
- Strongest safe reading: promoted/latched counterpart of the first work band.

### 7E:22A0..7E:22FF  ct_d1_promoted_48color_palette_band_pair_b   [provisional strengthened]
- Exact partner band written alongside `7E:20A0..20FF` by `D1:E91A`.

### 7E:2120..7E:217F and 7E:2320..7E:237F  ct_d1_secondary_palette_band_pairs_seeded_to_7fff   [provisional strengthened]
- Seeded to `0x7FFF` by `D1:E899`.
- Later consumed by the nearby `D1:E71D..E77A` swap path.
- Final higher-level noun remains open.

### 7E:21A0..7E:21FF and 7E:23A0..7E:23FF  ct_d1_tertiary_palette_band_pairs_seeded_to_7fff   [provisional strengthened]
- Seeded to `0x7FFF` by `D1:E8C1`.
- Also tied to the nearby `D1:E71D..E77A` swap/exchange seam.

### 7E:CD2F..7E:CD31  ct_d1_palette_band_control_triplet_a_seeded_by_e91a   [provisional strengthened]
- Seeded to `0x30` by `D1:E91A`.
- Exact final noun remains open.

### 7E:CD32..7E:CD34  ct_d1_palette_band_control_triplet_b_seeded_by_e984_or_cleared_by_e91a   [provisional strengthened]
- Cleared by `D1:E91A`.
- Seeded to `0x30` by `D1:E984`.
- Strongest safe reading: paired control/state triplet for the same subcluster.

### 7E:CDC8  ct_d1_palette_band_seed_snapshot_latch   [provisional strengthened]
- Incremented by `D1:E984`.
- Cleared by `D1:E91A`.
- Strongest safe reading: latch/flag tied to the seed-vs-promote half-cycle.

### 7E:CE0F  ct_d1_palette_band_seed_count_or_arm_latch   [provisional strengthened]
- Incremented by `D1:E984`.
- No matching clear is yet proven in this pass.
- Final noun remains open.

### 7E:CE12  ct_d1_palette_band_promote_snapshot_pending_counter   [provisional strengthened]
- Incremented by both `D1:E91A` and `D1:E984`.
- Also consumed nearby at `D1:F42B..F46C`.
- Strongest safe reading: shared pending-step / handshake counter for this subcluster.

---

## Honest caution
Even after this pass:

- I have **not** frozen the final human-facing noun of the `2040/20A0/2120/21A0/2240/22A0/2320/23A0` palette-band families.
- I have **not** finished the downstream `CE12 / CDC8 / CE0F` control logic.
- I have **not** closed the exact relationship to the later swap path at `D1:E71D..E77A`.
- I have **not** yet tied this subcluster all the way into the final higher-level battle/UI mode name.


---

## Pass 83

# Chrono Trigger Labels — Pass 83

## Purpose
This file records the label upgrades justified by pass 83.

Pass 82 closed the meanings of the `D1:E899 / E8C1 / E91A / E984` palette-band helpers.
Pass 83 closes a real chunk of the downstream consumer logic:

- `D1:F411` is now exact as an 8-slot descriptor-header shadow helper
- `D1:F431` and `D1:F457` are now exact as the suspend vs restore halves of a local one-shot gate
- `CD2F..CD36` is now pinned as the real 8-byte shadow array, correcting the too-narrow pass-82 focus on `CD2F..CD34`
- `CFFF` is now pinned locally as the suspend-vs-restore selector
- `D1:E70A..E77B` is now pinned as the exact 48-word exchange path for the `2120/21A0` and `2320/23A0` band pairs

I am still keeping the final gameplay-facing nouns of `CFFF`, `A101`, `2A21.bit1`, and the `0575.bit6` toggle one notch below frozen.

---

## Strengthened helper labels

### D1:F411..D1:F426  ct_d1_snapshot_palette_descriptor_header_bytes_8slots_to_cd2f_cd36   [strong]
- Walks the 8-slot `0520 + n*0C` descriptor queue.
- Copies the first byte of each slot (`0520/052C/0538/0544/0550/055C/0568/0574`) into `CD2F..CD36`.
- Exact structural role: descriptor-header shadow helper.

### D1:F427..D1:F430  ct_d1_select_descriptor_header_suspend_or_restore_by_cfff   [strong structural]
- Reads `CFFF`.
- `CFFF != 0` jumps to the shadow-and-suspend path at `D1:F431`.
- `CFFF == 0` jumps to the restore path at `D1:F457`.

### D1:F431..D1:F456  ct_d1_arm_ce12_shadow_descriptor_headers_and_suspend_family_10_slots   [strong structural]
- Returns immediately when `CE12 != 0`.
- Otherwise increments `CE12`, snapshots all 8 descriptor headers through `D1:F411`, and scans the full 8-slot queue.
- Clears only non-negative `0x1x` header bytes in `0520 + n*0C`.
- Strongest safe reading: one-shot shadow-and-suspend path for the positive palette-animation family.

### D1:F457..D1:F473  ct_d1_restore_shadowed_descriptor_headers_from_cd2f_cd36_and_clear_ce12   [strong structural]
- Returns immediately when `CE12 == 0`.
- Otherwise clears `CE12` and restores `CD2F..CD36` back into the first byte of all 8 descriptor slots.
- Strongest safe reading: one-shot restore half paired with `D1:F431`.

### D1:E70A..D1:E77B  ct_d1_optional_exchange_secondary_and_tertiary_palette_band_pairs   [strong structural]
- Clears `A101`.
- Tests `2A21.bit1`; when set, toggles bit `0x40` in `0575`.
- Exchanges the full 48-word pairs `2120..217F <-> 21A0..21FF` and `2320..237F <-> 23A0..23FF`.
- Decrements direct-page `$40` and returns.
- Strongest safe reading: selector-sensitive band-exchange helper.

---

## Strengthened RAM/state labels

### 7E:0520..7E:057F  ct_palette_effect_descriptor_queue_8x12byte_records   [strong structural]
- Passes 8–9 already proved the `0x0C` stride and 8-slot queue shape.
- Pass 83 adds exact header-walk proof through `D1:F411` / `D1:F457`, covering slot headers at `0520/052C/0538/0544/0550/055C/0568/0574`.
- Strongest safe reading: full 8-record palette/effect descriptor queue.

### 7E:0568..7E:057F  ct_palette_effect_descriptor_tail_slab_2x12byte_records   [stronger support]
- The tail two descriptor slots are now surfaced directly by `D1:F411` / `D1:F457` via header bytes at `0568` and `0574`.
- Pass 82 did not touch these tail slots directly; pass 83 proves they participate in the same header-shadow gate.

### 7E:CD2F..7E:CD36  ct_palette_effect_descriptor_header_shadow_bytes_8slots   [strong correction]
- Exact shadow array for the first byte of all 8 `0520 + n*0C` descriptor slots.
- Written by `D1:F411`, restored by `D1:F457`.
- Pass 82's narrower `CD2F..CD34` interpretation is now tightened into this larger 8-byte mirror.

### 7E:CD35..7E:CD36  ct_palette_effect_descriptor_header_shadow_tail_slots_6_7   [strong addition]
- Tail two bytes of the new 8-slot shadow array.
- Correspond to descriptor headers at `0568` and `0574`.

### 7E:CFFF  ct_d1_palette_descriptor_suspend_restore_selector   [provisional strengthened]
- `CFFF != 0` selects the shadow-and-suspend path at `D1:F431`.
- `CFFF == 0` selects the restore path at `D1:F457`.
- Mapped-ROM proof for nonzero writers is still incomplete, so the final gameplay-facing noun remains open.

### 7E:CE12  ct_d1_palette_band_promote_snapshot_pending_counter   [stronger local gate support]
- Earlier passes already proved that `E91A` and `E984` increment `CE12`.
- Pass 83 proves local one-shot gate behavior in `D1:F431 / D1:F457`: nonzero blocks re-arm, zero blocks restore, and restore clears it.
- Strongest safe reading: locally gate-like latch behavior inside this D1 consumer pair, even if the wider cluster noun still wants caution.

---

## Honest caution
Even after this pass:

- I have **not** frozen the final gameplay-facing noun of `CFFF`.
- I have **not** frozen the exact higher-level role of `A101`, `2A21.bit1`, or the `0575.bit6` toggle in `D1:E70A`.
- I have **not** claimed that `CE12` is globally nothing but a latch; the local gate behavior is exact, but the wider cluster may still be richer.
- I have **not** yet tied this whole D1 control cluster all the way to the final battle/UI presentation noun.


---

## Pass 84

# Chrono Trigger Labels — Pass 84

## Purpose
This file records the label upgrades justified by pass 84.

Pass 83 proved the local gate behavior of `D1:F426 / F431 / F457`,
but the actual writers for `7E:CFFF` were still open.

Pass 84 closes that external control seam:

- auxiliary token `0xE6` at `CD:18C2..18C7` is now exact as the direct immediate-write token for `CFFF`
- the older primary slot-script VM has exact hard set / hard clear helpers at `C1:58DB` and `C1:58E4`
- `CFFF` can now be tightened from vague selector to a stronger **zero/nonzero suspend/restore mode byte**
- `CDC8` can now be tightened locally as the seed-vs-promote phase-side byte of the `E984 <-> E91A` half-cycle
- `CE0F` can now be tightened locally as a seed-side arm/epoch byte
- the D1 reset cluster explicitly clears `CFFF / CE0F / CE12`

I am still keeping the final gameplay-facing nouns of the palette-band pages and the exact reader(s) of `CDC8 / CE0F` one notch below frozen.

---

## Strengthened helper labels

### CD:18C2..CD:18C7  ct_cd_auxiliary_token_e6_store_immediate_to_cfff   [strong]
- Exact body: `LDA [$40] ; STA $CFFF ; RTS`.
- Table decode from `CD:16B5` proves this is auxiliary token `0xE6`.
- Strongest safe reading: direct stream-write token for the D1 suspend/restore mode byte.

### C1:58DB..C1:58E3  ct_c1_primary_slot_vm_force_cfff_nonzero_and_return_success   [strong]
- Exact body: `LDA #$01 ; STA $CFFF ; JMP $75BB`.
- Strongest safe reading: primary-script convenience helper that forces the D1 gate into nonzero/suspend mode.

### C1:58E4..C1:58EB  ct_c1_primary_slot_vm_clear_cfff_and_return_success   [strong]
- Exact body: `STZ $CFFF ; LDA #$01 ; JMP $75BB`.
- Strongest safe reading: primary-script convenience helper that forces the D1 gate into zero/restore mode.

### D1:F260..D1:F297  ct_d1_reset_control_cluster_state_including_ce0f_ce12_and_cfff   [strong structural]
- Exact writes in this subsection clear `CE0E / CE0F / CE10 / CE12 / CFFF` and seed neighboring D1 control bytes.
- Strongest safe reading: local reset/init subsection for the D1 palette/control cluster.

---

## Strengthened RAM/state labels

### 7E:CFFF  ct_d1_palette_descriptor_suspend_restore_mode_byte   [strong structural]
- Local D1 consumer at `D1:F426` tests only zero vs nonzero.
- `00` selects the restore path at `D1:F457`.
- Any nonzero value selects the suspend path at `D1:F431`.
- Written directly by auxiliary token `0xE6` at `CD:18C2`.
- Also forced to `1` or `0` by primary-slot helpers at `C1:58DB` and `C1:58E4`.
- Cleared by the D1 reset subsection at `D1:F295`.
- Strongest safe reading: externally writable zero/nonzero mode byte for the D1 descriptor-header suspend/restore gate.

### 7E:CDC8  ct_d1_palette_seed_vs_promote_phase_byte   [stronger support]
- `D1:E984` increments it during the seed/snapshot half.
- `D1:E97D` clears it during the promote/restore half.
- No exact external reader is frozen yet.
- Strongest safe reading: local phase-side byte for the `E984 <-> E91A` first-band seed/promote cycle.

### 7E:CE0F  ct_d1_palette_seed_side_arm_or_epoch_byte   [stronger support]
- `D1:E987` increments it during the seed/snapshot half.
- `D1:F26E` clears it in the D1 reset subsection.
- No exact reader is frozen yet.
- Strongest safe reading: seed-side arm/epoch byte in the same D1 control cluster.

### 7E:CE12  ct_d1_palette_suspend_restore_gate_latch_or_pending_count   [stronger local reset support]
- Pass 83 already proved the local one-shot gate behavior at `D1:F431 / F457`.
- Pass 84 adds explicit reset proof: `D1:F277` clears it in the D1 reset subsection.
- Strongest safe reading remains: local suspend/restore gate latch with wider pending-count caution still allowed outside the local pair.

---

## Honest caution
Even after this pass:

- I have **not** proven that nonzero `CFFF` values carry distinct live meanings beyond the local zero/nonzero branch.
- I have **not** frozen the final gameplay-facing noun of the `2040/20A0/2120/21A0/2240/22A0/2320/23A0` palette-band families.
- I have **not** frozen the exact external reader(s) of `CDC8` or `CE0F`.
- I have **not** yet explained why the suspend path clears positive `0x1x` descriptor headers while sparing the signed `0x8x` family.


---

## Pass 85

# Chrono Trigger Labels — Pass 85

## Purpose
This file records the label upgrades justified by pass 85.

Pass 84 froze the `CFFF` writer at auxiliary token `0xE6`,
but the neighboring late auxiliary tail at `0xE0..0xE8` was still only partly mapped.

Pass 85 closes most of that tail as exact handlers:

- `0xE8`, `0xE7`, and `0xE0` are now exact wrappers into D1
- `0xE5` is an exact indexed increment helper over `5D80 + index`
- `0xE4` is an exact immediate stage + `5DA0`-index snapshot helper
- `0xE3` is an exact indexed six-byte snapshot/copy helper from `5DA0..5DA5` into `CAEA..CAF5`
- `0xE2` and `0xE1` are exact immediate writes to `CD2E` and `CD2D`

I am still keeping the final gameplay-facing nouns of the `5D80`, `5DA0..5DA5`, and `CAEA..CAF5` families one notch below frozen.

---

## Strengthened helper labels

### CD:1874..CD:1878  ct_cd_auxiliary_token_e8_call_d1_fb72   [strong]
- Exact body: `JSL D1:FB72 ; RTS`.
- Strongest safe reading: wrapper token into the D1-side helper at `FB72`.

### CD:1879..CD:187D  ct_cd_auxiliary_token_e7_call_d1_fb68   [strong]
- Exact body: `JSL D1:FB68 ; RTS`.
- Strongest safe reading: wrapper token into the D1-side helper at `FB68`.

### CD:18C8..CD:18CE  ct_cd_auxiliary_token_e5_increment_indexed_5d80_byte   [strong structural]
- Exact body: `LDA [$40] ; TAX ; INC $5D80,X ; RTS`.
- Strongest safe reading: indexed byte-strip increment helper over the `5D80` family.

### CD:18CF..CD:18DE  ct_cd_auxiliary_token_e4_store_immediate_to_cd24_snapshot_5da0_index_to_cd25_and_increment_cd23   [strong structural]
- Exact body stores one immediate byte to `CD24`, copies current `5DA0` into `X` and `CD25`, then increments `CD23`.
- Strongest safe reading: local immediate-stage plus current-index snapshot/count helper.

### CD:18DF..CD:1906  ct_cd_auxiliary_token_e3_copy_current_5da0_5da5_sixbyte_vector_into_indexed_caea_record   [strong structural]
- Exact body copies `5DA0/5DA2/5DA4/5DA1/5DA3/5DA5` into `CAEA/CAEE/CAF2/CAEC/CAF0/CAF4` using the immediate byte as X index.
- Strongest safe reading: indexed six-byte snapshot/copy helper from the current live `5DA0..5DA5` vector family.

### CD:1907..CD:190C  ct_cd_auxiliary_token_e2_store_immediate_to_cd2e   [strong]
- Exact body: `LDA [$40] ; STA $CD2E ; RTS`.
- Strongest safe reading: direct immediate store token for `CD2E`.

### CD:190D..CD:1912  ct_cd_auxiliary_token_e1_store_immediate_to_cd2d   [strong]
- Exact body: `LDA [$40] ; STA $CD2D ; RTS`.
- Strongest safe reading: direct immediate store token for `CD2D`.

### CD:1913..CD:1917  ct_cd_auxiliary_token_e0_call_d1_f47c   [strong]
- Exact body: `JSL D1:F47C ; RTS`.
- Strongest safe reading: wrapper token into the D1-side helper at `F47C`.

---

## Strengthened RAM/state labels

### 7E:CD23  ct_cd_auxiliary_5da0_snapshot_stage_count_byte   [stronger structural]
- Incremented by auxiliary token `0xE4` after mirroring the current `5DA0` byte into `CD25`.
- Strongest safe reading: local count/state byte for the `E4` snapshot-stage helper family.

### 7E:CD24  ct_cd_auxiliary_immediate_stage_selector_byte   [stronger structural]
- Written directly by auxiliary token `0xE4` from the following stream byte.
- Strongest safe reading: local immediate selector/control byte for the same snapshot-stage helper family.

### 7E:CD25  ct_cd_auxiliary_snapshot_of_current_5da0_index_byte   [stronger structural]
- Written by auxiliary token `0xE4` from the current live byte at `5DA0`.
- Strongest safe reading: mirrored current-index byte for the same local stage family.

### 7E:CD2D  ct_cd_auxiliary_immediate_control_byte_e1   [stronger structural]
- Written directly by auxiliary token `0xE1` from the stream.
- Final higher-level noun remains open.

### 7E:CD2E  ct_cd_auxiliary_immediate_control_byte_e2   [stronger structural]
- Written directly by auxiliary token `0xE2` from the stream.
- Final higher-level noun remains open.

### 7E:CAEA..7E:CAF5  ct_cd_auxiliary_indexed_sixbyte_snapshot_records_from_5da0_vector   [strong structural]
- Auxiliary token `0xE3` copies the current `5DA0..5DA5` six-byte live vector into one indexed destination record rooted here.
- Exact write pattern is interleaved: `CAEA/CAEC/CAEE/CAF0/CAF2/CAF4`.
- Strongest safe reading: indexed destination record family for six-byte snapshots of the current `5DA0` live vector.

### 7E:5D80..7E:5DFF  ct_cd_auxiliary_indexed_byte_counter_strip   [provisional strengthened]
- Auxiliary token `0xE5` increments one byte in this strip using the immediate operand as index.
- Final gameplay-facing noun remains open, but this is clearly an indexed byte strip actively mutated by the auxiliary VM.

### 7E:5DA0..7E:5DA5  ct_cd_auxiliary_current_sixbyte_live_vector   [strong structural]
- Auxiliary token `0xE3` snapshots these six live bytes outward into the indexed `CAEA..CAF5` record family.
- Auxiliary token `0xE4` reads `5DA0` specifically as the current index/selector byte mirrored into `CD25`.
- Strongest safe reading: current six-byte live vector family consumed by the late auxiliary token cluster.

---

## Honest caution
Even after this pass:

- I have **not** frozen the final gameplay-facing noun of the `5D80` strip.
- I have **not** frozen the final noun of the `5DA0..5DA5` live vector family.
- I have **not** frozen the final noun of the indexed destination record family at `CAEA..CAF5`.
- I have **not** yet tied this `0xE0..0xE8` control family all the way into the final presentation/system noun.
- I have **not** yet frozen the first exact external reader(s) of `CDC8` and `CE0F`.


---

## Pass 86

# Chrono Trigger Labels — Pass 86

## Purpose
This file records the label upgrades justified by pass 86.

Pass 85 left `5DA0..5DA5` and `CAEA..CAF5` one notch too generic,
and it still lacked the first exact external reader of `CDC8`.

Pass 86 tightens both seams:

- `CE:E18E..E1A4` is now the first exact external reader of `CDC8`
- `CDC8` now has exact nonzero-gated clear behavior over `CD47..CDC6`
- `D1:F5CD..F5F2` is an exact D1-side snapshot helper for the `5DA0 -> CAEA` family
- `D1:EC27..EC5B` and `D1:EDCD..EE95` prove that `5DA0 / 5DA1` behave like a coordinate-style axis pair
- `5DA0..5DA5` can now be tightened from a generic six-byte vector to a stronger **current three-pair point bundle** noun

I am still keeping the final presentation/system noun one notch below frozen.

---

## Strong labels

### CE:E18E..CE:E1A4  ct_ce_clear_cd47_cdc6_work_strip_only_when_cdc8_nonzero   [strong structural]
- Exact body: `LDA $CDC8 ; BEQ return ; TDC ; TAX ; REP #$20 ; STZ $CD47,X ; INX ; INX ; CPX #$0080 ; BNE loop ; TDC ; SEP #$20 ; RTL`.
- Exact behavior: if `CDC8 == 0`, return immediately. If `CDC8 != 0`, clear the exact `0x80`-byte strip `CD47..CDC6`.
- Strongest safe reading: first exact external `CDC8` reader; nonzero-gated clear helper for one D1-adjacent work strip.

### D1:EC27..D1:EC5B  ct_d1_build_four_endpoint_pairs_from_mulhi_and_current_5da0_5da1_pair_then_call_f9af   [strong structural]
- Reads one immediate/index through `[$40]`, transforms the `4217` multiply-result high byte, builds four endpoint pairs in `CD0D..CD1B`, uses `5DA0` with `-0x10/+0x10`, uses `5DA1` as the paired byte for both records, then calls `D1:F9AF`.
- Strongest safe reading: D1 helper that converts the current `5DA0/5DA1` pair plus one transformed multiply-derived byte into four coordinate/endpoint pairs for downstream geometry-style processing.

### D1:EDCD..D1:EE95  ct_d1_expand_current_5da0_5da1_axis_pair_by_cd3a_cd3b_into_four_plane_span_strips   [strong structural]
- Selector `[$40] == 0` path uses `5DA0` and `CD3A`, clamps low/high bounds, and fills one of two four-plane strip families with the computed byte at stride 4.
- Selector `[$40] != 0` path uses `5DA1` and `CD3B`, clamps bounds, and clears one of two corresponding four-plane strip families across the computed span.
- Strongest safe reading: D1 axis-span helper consuming the current `5DA0/5DA1` pair as horizontal/vertical coordinates.

### D1:F5CD..D1:F5F2  ct_d1_snapshot_current_5da0_5da5_three_pair_bundle_into_indexed_caea_record   [strong structural]
- Exact body copies `5DA0/5DA2/5DA4/5DA1/5DA3/5DA5` into `CAEA/CAEE/CAF2/CAEC/CAF0/CAF4` using the immediate byte from `[$40]` as X index.
- Strongest safe reading: D1-side reusable snapshot helper for the current three-pair bundle into one indexed `CAEA..CAF5` record.

---

## Strengthened RAM/state labels

### 7E:CDC8  ct_d1_seed_side_nonzero_gate_for_cdc8_conditioned_work_strip_clear   [stronger structural]
- `D1:E984` increments it during the seed/snapshot half.
- `D1:E97D` clears it during the promote/restore half.
- `CE:E18E..E1A4` is the first exact external reader: nonzero gates clearing of `CD47..CDC6`; zero skips the clear entirely.
- Strongest safe reading: seed-side nonzero gate byte for at least one D1-adjacent work-strip clear path.

### 7E:CD47..7E:CDC6  ct_d1_cdc8_conditioned_0x80byte_work_strip   [strong structural]
- `CE:E18E..E1A4` clears this exact `0x80`-byte range only when `CDC8 != 0`.
- Final higher-level noun remains open, but the clear footprint is exact.

### 7E:5DA0..7E:5DA5  ct_cd_d1_current_three_pair_point_bundle   [strong structural]
- Pass 85 already proved exact snapshot order into `CAEA..CAF5`.
- `D1:EC27..EC5B` proves `5DA0/5DA1` behave as a paired coordinate-like byte pair.
- `D1:EDCD..EE95` proves the same pair drives expanding horizontal/vertical span helpers.
- Strongest safe reading: current three-pair point/coordinate bundle shared by the late auxiliary cluster and D1 helpers.

### 7E:CAEA..7E:CAF5  ct_cd_d1_indexed_snapshot_records_of_current_three_pair_point_bundle   [strong structural]
- Auxiliary token `0xE3` and D1 helper `F5CD..F5F2` both snapshot the current `5DA0..5DA5` bundle into one indexed record rooted here.
- Exact interleaved write pattern remains `CAEA/CAEC/CAEE/CAF0/CAF2/CAF4`.
- Strongest safe reading: indexed snapshot record family for the current three-pair point bundle.

---

## Alias / wrapper / caution labels

### 7E:CDC8  ct_d1_palette_seed_vs_promote_phase_byte   [alias / caution retained]
- Pass 84 already justified this local noun from `E984 <-> E91A`.
- Pass 86 does **not** invalidate that reading; it adds exact external clear-gate behavior.
- Keep both readings in play until a wider cluster noun is frozen.

---

## Honest caution
Even after this pass:

- I have **not** frozen the final gameplay-facing noun of the `5DA0..5DA5` bundle.
- I have **not** proven whether the three pairs are literal vertices, corners, or another nearby geometric/effect record.
- I have **not** frozen the first exact external reader of `CE0F`.
- I have **not** promoted `CD23 / CD24 / CD25` beyond their pass-85 local staging noun, because the remaining valid mapped hits are still not clean enough.
