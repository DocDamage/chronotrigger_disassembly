# Next Session Start Here

1. Read `notes/community_research_first.md`
2. Open these in order:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `dossiers/D1_dossier.md`
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - `chrono_trigger_disasm_pass85.md`
   - `chrono_trigger_labels_pass85.md`
   - `chrono_trigger_disasm_pass86.md`
   - `chrono_trigger_labels_pass86.md`
3. Active top-of-stack seam after pass 86:
   - freeze the first exact external reader(s) of `CE0F`
   - validate whether `CD23 / CD24 / CD25` have any real valid-mapped consumers beyond their local `0xE4` staging role
   - push one step deeper into `D1:F9AF / F8EB / F9E7` so the new `5DA0..5DA5` three-pair bundle noun can be tightened toward its final presentation/system role
   - decide whether the `CD47..CDC6` strip is best described as a seeded geometry/effect work strip, mask strip, or another stricter noun once a real producer/consumer pair is found
4. Specific cleanup targets:
   - explain the exact higher-level relationship between `D1:EC27..EC5B`, `D1:EDCD..EE95`, and `D1:F9AF`
   - decide whether the three pairs in `5DA0..5DA5` are literal vertices/corners, axis anchors, or another geometric bundle
   - tighten the exact writer/producer for `CD47..CDC6` before promoting its noun further
   - keep discarding low-half alias noise and trust only valid HiROM-mapped code references
5. Runtime confirmation shortlist:
   - first exact external reader(s) of `CE0F`
   - first exact producer(s) of `CD47..CDC6`
   - downstream consumer(s) of `CAEA..CAF5`
   - downstream consumer(s) of the endpoint scratch built at `CD0D..CD1B`
