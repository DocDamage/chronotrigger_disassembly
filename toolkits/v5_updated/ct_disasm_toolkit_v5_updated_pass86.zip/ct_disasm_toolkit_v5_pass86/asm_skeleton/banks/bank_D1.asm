; Chrono Trigger bank D1 skeleton
; Generated from current evidence. This is not a complete reassemblable bank yet.

.bank $D1

; D1:5800 [strong] pass 44
ct_d1_tilemap_template_default_0b40_0180:
    ; TODO: lift real code/data for D1:5800
    ; Default/reset ROM template copied into `0B40` by `C1:1C3A`. Same size as the upload buffer and structurally part of the same tilemap-templat

; D1:5800 [unspecified] pass 44
__D1_5A50___D1_5BD0__ct_d1_tilemap_template_family_16x12_words__provisional_:
    ; TODO: lift real code/data for D1:5800
    ; The three source blocks are best interpreted as a 192-word (likely 16x12) template family. This matrix interpretation fits both the dense ro

; D1:5800 [unspecified] pass 45
__D1_5A50___D1_5BD0__ct_d1_base_strip_template_family_32x6______strong_:
    ; TODO: lift real code/data for D1:5800
    ; Corrected geometrically in this pass. All three `0x0180`-byte base templates are best modeled as 32-word by 6-row strip layouts. Used as the

; D1:5800 [provisional] pass 45
__D1_5A50___D1_5BD0__ct_d1_tilemap_template_family_16x12_words__withdrawn_:
    ; TODO: lift real code/data for D1:5800
    ; Pass 45 corrects this earlier provisional geometry. The safer keepable geometry is `32x6`, not `16x12`.

; D1:5800 [provisional] pass 45
__D1_5A50___D1_5BD0__ct_d1_alt_base_strip_layout_family_________provisional_:
    ; TODO: lift real code/data for D1:5800
    ; The three templates are clearly alternate base layouts within the same 32x6 strip region. Exact gameplay/UI mode names are still unresolved.

; D1:5800 [provisional] pass 46
__D1_5A50___D1_5BD0__ct_d1_alt_base_strip_layout_family_______strengthened_context_:
    ; TODO: lift real code/data for D1:5800
    ; Pass 46 strengthens their caller-context roles: `5800` = default/base restore through `C1:1C3A` `5A50` = latched alternate via `A86A` `5BD0`

; D1:5800 [provisional] pass 46
ct_d1_base_strip_template_default:
    ; TODO: lift real code/data for D1:5800
    ; Caller context strongly suggests the default/base restore variant. Final gameplay-facing mode name still open.

; D1:59FC [strong] pass 45
ct_d1_panel_segment_template_6x7_words:
    ; TODO: lift real code/data for D1:59FC
    ; Unique ROM source table used by `C1:0929`. Resolves cleanly as 6 rows of 7 words. Tile values form a compact border/interior segment templat

; D1:5A50 [strong] pass 44
ct_d1_tilemap_template_alt_a_0b40_0180:
    ; TODO: lift real code/data for D1:5A50
    ; Alternate ROM template variant copied into `0B40` by the `0EA1..0EB1` path. Followed by `INC $99E2`, proving it feeds the same upload path a

; D1:5A50 [provisional] pass 46
ct_d1_base_strip_template_latched_alt:
    ; TODO: lift real code/data for D1:5A50
    ; Single-shot alternate selected when `A86A` is nonzero, then that latch is cleared. Kept provisional until the higher-level mode name is pinn

; D1:5BD0 [strong] pass 44
ct_d1_tilemap_template_alt_b_0b40_0180:
    ; TODO: lift real code/data for D1:5BD0
    ; Alternate ROM template variant copied into `0B40` by the `1301..1315`, Followed by `INC $99E2`, proving it feeds the same upload path as the

; D1:5BD0 [provisional] pass 46
ct_d1_base_strip_template_transition_alt:
    ; TODO: lift real code/data for D1:5BD0
    ; Copied in later state-transition/reset paths with surrounding controller bookkeeping. Strong structural role, but final mode name still unre

; D1:646C..D1:652B [strong] pass 79
ct_d1_auxiliary_descriptor_pointer_table:
    ; TODO: lift real code/data for D1:646C..D1:652B
    ; `15D5` multiplies the descriptor id by two and reads a pointer from this table. The returned pointer seeds one active runtime slot in the op

; D1:E70A..D1:E77B [strong] pass 83
ct_d1_optional_exchange_secondary_and_tertiary_palette_band_pairs:
    ; TODO: lift real code/data for D1:E70A..D1:E77B
    ; Clears `A101`. Tests `2A21.bit1`; when set, toggles bit `0x40` in `0575`. Exchanges the full 48-word pairs `2120..217F <-> 21A0..21FF` and `

; D1:E899..D1:E8C0 [strong] pass 82
ct_d1_fill_palette_band_pairs_2040_2240_and_2120_2320_with_7fff_sentinel:
    ; TODO: lift real code/data for D1:E899..D1:E8C0
    ; Fills `7E:2040..20FF` and `7E:2240..22FF` with `0x7FFF`. Then fills `7E:2120..217F` and `7E:2320..237F` with the same sentinel. Exact struct

; D1:E8C1..D1:E8D4 [strong] pass 82
ct_d1_fill_palette_band_pair_21a0_23a0_with_7fff_sentinel:
    ; TODO: lift real code/data for D1:E8C1..D1:E8D4
    ; Fills `7E:21A0..21FF` and `7E:23A0..23FF` with `0x7FFF`. Exact smaller sibling of `D1:E899`.

; D1:E91A..D1:E983 [strong] pass 82
ct_d1_promote_first_48color_palette_band_and_restore_active_3record_descriptor_slab:
    ; TODO: lift real code/data for D1:E91A..D1:E983
    ; Copies `7E:2040..209F` into `7E:20A0..20FF` and `7E:22A0..22FF`, then clears `7E:2040..209F` and `7E:2240..229F`. Copies `7E:0544..0567` bac

; D1:E984..D1:E9EB [strong] pass 82
ct_d1_seed_first_48color_palette_band_from_d0_fd00_and_snapshot_active_descriptor_slab_outward:
    ; TODO: lift real code/data for D1:E984..D1:E9EB
    ; Increments `CDC8` and `CE0F`. Copies ROM data from `D0:FD00..FD5F` into `7E:2040..209F` and `7E:2240..229F`. Copies `7E:0520..0543` outward 

; D1:F260..D1:F297 [strong] pass 84
ct_d1_reset_control_cluster_state_including_ce0f_ce12_and_cfff:
    ; TODO: lift real code/data for D1:F260..D1:F297
    ; Exact writes in this subsection clear `CE0E / CE0F / CE10 / CE12 / CFFF` and seed neighboring D1 control bytes. Strongest safe reading: loca

; D1:F411..D1:F426 [strong] pass 83
ct_d1_snapshot_palette_descriptor_header_bytes_8slots_to_cd2f_cd36:
    ; TODO: lift real code/data for D1:F411..D1:F426
    ; Walks the 8-slot `0520 + n*0C` descriptor queue. Copies the first byte of each slot (`0520/052C/0538/0544/0550/055C/0568/0574`) into `CD2F..

; D1:F427..D1:F430 [strong] pass 83
ct_d1_select_descriptor_header_suspend_or_restore_by_cfff:
    ; TODO: lift real code/data for D1:F427..D1:F430
    ; Reads `CFFF`. `CFFF != 0` jumps to the shadow-and-suspend path at `D1:F431`. `CFFF == 0` jumps to the restore path at `D1:F457`.

; D1:F431..D1:F456 [strong] pass 83
ct_d1_arm_ce12_shadow_descriptor_headers_and_suspend_family_10_slots:
    ; TODO: lift real code/data for D1:F431..D1:F456
    ; Returns immediately when `CE12 != 0`. Otherwise increments `CE12`, snapshots all 8 descriptor headers through `D1:F411`, and scans the full 

; D1:F457..D1:F473 [strong] pass 83
ct_d1_restore_shadowed_descriptor_headers_from_cd2f_cd36_and_clear_ce12:
    ; TODO: lift real code/data for D1:F457..D1:F473
    ; Returns immediately when `CE12 == 0`. Otherwise clears `CE12` and restores `CD2F..CD36` back into the first byte of all 8 descriptor slots. 

