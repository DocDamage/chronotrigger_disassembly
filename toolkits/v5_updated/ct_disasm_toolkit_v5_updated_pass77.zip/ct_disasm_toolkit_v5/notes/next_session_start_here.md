# Next Session Start Here

1. Read `notes/community_research_first.md`
2. Open these in order:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `dossiers/C1_dossier.md`
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - latest pass + labels
3. Active top-of-stack seam after pass 77:
   - decode `C3:0002` so the packed `2D00..` stream feeding `4943` gets a real noun
   - crack `CD:0015 / CD:0018 / CD:002A` so the pre-parse service-04 stages stop being black boxes
   - tighten the final noun of the `4500.. / 5D00.. / A07B` output-slot family
4. Specific cleanup targets:
   - decide the best final noun for the `4833 / 48EC / 4943` output family now that the 8-byte slot stride is proven
   - freeze the final roles of `9877..9885`
   - re-open the mode-3 callers at `BADA / BB15`
   - return to the per-byte field semantics of the 17-byte `CC:213F -> AEE6..AEF6` descriptor records
5. Runtime confirmation shortlist:
   - current-tail path `BFAA -> AC57 -> service04 mode1`
   - fixed-`7F` path `895B -> AC57 -> service04 mode2`
   - high-range path `BADA/BB15 -> AC57 -> service04 mode3`
   - shared tail `4833` and the `48EC / 4943` parser-decoder pair
