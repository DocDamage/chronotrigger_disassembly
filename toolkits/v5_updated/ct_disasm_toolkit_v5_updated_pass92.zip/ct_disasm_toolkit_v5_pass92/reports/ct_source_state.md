# Source State Report

- Total label rows represented: **604**
- Frozen/stable ranges: **417**

## Banks
- 7E: `source/banks/wram_7E.asm`  groups=143 rows=225
- 7F: `source/banks/wram_7F.asm`  groups=1 rows=1
- C0: `source/banks/bank_C0.asm`  groups=7 rows=7
- C1: `source/banks/bank_C1.asm`  groups=195 rows=215
- C3: `source/banks/bank_C3.asm`  groups=2 rows=2
- CC: `source/banks/bank_CC.asm`  groups=10 rows=13
- CD: `source/banks/bank_CD.asm`  groups=70 rows=72
- CE: `source/banks/bank_CE.asm`  groups=3 rows=3
- CF: `source/banks/bank_CF.asm`  groups=1 rows=1
- D0: `source/banks/bank_D0.asm`  groups=1 rows=1
- D1: `source/banks/bank_D1.asm`  groups=34 rows=43
- FD: `source/banks/bank_FD.asm`  groups=18 rows=21

## Notes
- This is a scaffold-first source tree, not a byte-perfect assembled disassembly yet.
- Use the rebuild/diff report to track assembler integration progress.
