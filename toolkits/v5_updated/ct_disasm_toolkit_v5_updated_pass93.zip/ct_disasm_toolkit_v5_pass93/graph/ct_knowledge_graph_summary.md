# Knowledge Graph Summary

- Nodes: **1036**
- Edges: **1453**

## Bank coverage from label graph
- `7E` -> **246** label-linked nodes
- `C1` -> **223** label-linked nodes
- `CD` -> **72** label-linked nodes
- `D1` -> **43** label-linked nodes
- `FD` -> **23** label-linked nodes
- `CC` -> **13** label-linked nodes
- `C0` -> **7** label-linked nodes
- `C2` -> **4** label-linked nodes
- `CE` -> **3** label-linked nodes
- `C3` -> **2** label-linked nodes
- `C7` -> **2** label-linked nodes
- `7F` -> **1** label-linked nodes
- `CF` -> **1** label-linked nodes
- `D0` -> **1** label-linked nodes

## Runtime-confirmed addresses
- none yet

## Strong current graph take
- The graph is now good enough to tie pass evidence, bank ownership, master opcode coverage, and imported runtime proof together in one place.

