# Code/Data Scoring

## Bank 7E
- `CD00-CDFF` -> **likely_code** (score 100, labels 23, strong 13)
- `AF00-AFFF` -> **likely_code** (score 89, labels 24, strong 6)
- `AE00-AEFF` -> **likely_code** (score 58, labels 16, strong 8)
- `CA00-CAFF` -> **likely_code** (score 44, labels 13, strong 8)
- `B100-B1FF` -> **likely_code** (score 42, labels 18, strong 5)
- `9F00-9FFF` -> **likely_code** (score 38, labels 19, strong 0)
- `B200-B2FF` -> **likely_code** (score 34, labels 10, strong 6)
- `CE00-CEFF` -> **likely_code** (score 33, labels 8, strong 4)
- `A600-A6FF` -> **likely_code** (score 29, labels 6, strong 5)
- `AD00-ADFF` -> **likely_code** (score 18, labels 3, strong 3)

## Bank 7F
- `0100-01FF` -> **likely_data** (score 1, labels 1, strong 0)

## Bank C0
- `FD00-FDFF` -> **likely_code** (score 14, labels 1, strong 1)
- `A200-A2FF` -> **mixed** (score 9, labels 2, strong 0)
- `0000-00FF` -> **mixed** (score 6, labels 2, strong 2)
- `1B00-1BFF` -> **mixed** (score 6, labels 2, strong 2)

## Bank C1
- `A500-A5FF` -> **likely_code** (score 45, labels 9, strong 9)
- `AF00-AFFF` -> **likely_code** (score 43, labels 9, strong 9)
- `AB00-ABFF` -> **likely_code** (score 35, labels 8, strong 7)
- `9700-97FF` -> **likely_code** (score 30, labels 6, strong 5)
- `9900-99FF` -> **likely_code** (score 30, labels 6, strong 6)
- `8A00-8AFF` -> **likely_code** (score 27, labels 6, strong 6)
- `B000-B0FF` -> **likely_code** (score 27, labels 7, strong 6)
- `A600-A6FF` -> **likely_code** (score 24, labels 6, strong 6)
- `AC00-ACFF` -> **likely_code** (score 24, labels 4, strong 4)
- `B800-B8FF` -> **likely_code** (score 22, labels 6, strong 5)

## Bank C2
- `0000-00FF` -> **mixed** (score 6, labels 2, strong 2)
- `5700-57FF` -> **likely_data** (score 3, labels 1, strong 1)
- `5800-58FF` -> **likely_data** (score 3, labels 1, strong 1)

## Bank C3
- `0000-00FF` -> **likely_data** (score 3, labels 1, strong 1)
- `0500-05FF` -> **likely_data** (score 3, labels 1, strong 1)

## Bank C7
- `0000-00FF` -> **likely_data** (score 3, labels 1, strong 1)
- `0100-01FF` -> **likely_data** (score 3, labels 1, strong 1)

## Bank CC
- `FA00-FAFF` -> **likely_code** (score 21, labels 6, strong 5)
- `2E00-2EFF` -> **mixed** (score 7, labels 3, strong 2)
- `F800-F8FF` -> **mixed** (score 5, labels 1, strong 0)
- `F900-F9FF` -> **mixed** (score 5, labels 1, strong 1)
- `9400-94FF` -> **mixed** (score 4, labels 1, strong 1)
- `8B00-8BFF` -> **likely_data** (score 3, labels 1, strong 1)

## Bank CD
- `1800-18FF` -> **likely_code** (score 33, labels 11, strong 11)
- `2A00-2AFF` -> **likely_code** (score 31, labels 11, strong 10)
- `2D00-2DFF` -> **likely_code** (score 21, labels 7, strong 7)
- `1300-13FF` -> **likely_code** (score 18, labels 6, strong 6)
- `1600-16FF` -> **likely_code** (score 15, labels 5, strong 5)
- `1700-17FF` -> **likely_code** (score 15, labels 5, strong 5)
- `2B00-2BFF` -> **likely_code** (score 15, labels 5, strong 5)
- `2E00-2EFF` -> **likely_code** (score 12, labels 4, strong 4)
- `0000-00FF` -> **mixed** (score 9, labels 3, strong 3)
- `0200-02FF` -> **mixed** (score 9, labels 3, strong 3)

## Bank CE
- `E000-E0FF` -> **mixed** (score 6, labels 1, strong 1)
- `E100-E1FF` -> **mixed** (score 6, labels 1, strong 1)
- `EE00-EEFF` -> **mixed** (score 4, labels 1, strong 1)

## Bank CF
- `E300-E3FF` -> **mixed** (score 5, labels 1, strong 1)

## Bank D0
- `FD00-FDFF` -> **likely_data** (score 3, labels 1, strong 1)

## Bank D1
- `F400-F4FF` -> **likely_code** (score 34, labels 6, strong 6)
- `F900-F9FF` -> **likely_code** (score 16, labels 4, strong 4)
- `E900-E9FF` -> **likely_code** (score 13, labels 2, strong 2)
- `EE00-EEFF` -> **likely_code** (score 13, labels 3, strong 3)
- `E800-E8FF` -> **likely_code** (score 10, labels 2, strong 2)
- `ED00-EDFF` -> **likely_code** (score 10, labels 2, strong 2)
- `F500-F5FF` -> **likely_code** (score 10, labels 2, strong 2)
- `5800-58FF` -> **mixed** (score 9, labels 7, strong 1)
- `F800-F8FF` -> **mixed** (score 7, labels 2, strong 2)
- `FD00-FDFF` -> **mixed** (score 7, labels 1, strong 1)

## Bank FD
- `B800-B8FF` -> **likely_code** (score 32, labels 9, strong 4)
- `A800-A8FF` -> **likely_code** (score 21, labels 5, strong 4)
- `A900-A9FF` -> **likely_code** (score 12, labels 2, strong 2)
- `AC00-ACFF` -> **mixed** (score 8, labels 2, strong 1)
- `B200-B2FF` -> **mixed** (score 8, labels 3, strong 1)
- `AB00-ABFF` -> **likely_data** (score 3, labels 1, strong 0)
- `B900-B9FF` -> **likely_data** (score 2, labels 1, strong 0)

