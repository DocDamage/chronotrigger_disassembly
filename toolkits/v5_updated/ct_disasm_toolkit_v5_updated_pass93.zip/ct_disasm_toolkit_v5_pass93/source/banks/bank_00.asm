; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_00
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; 00:1E00  top-status=provisional  labels=1
; =============================================================================
; [provisional] pass 93 :: ct_c7_low_bank_command_packet_header_workspace
; qualifier: provisional strengthened
; notes: Pass 93 proves `C7:0140..019D` sets `D = 0x1E00` and consumes exact header bytes from this low-bank workspace. Exact proven fields now include: `1E00` = packet opcode / opcode family selector `1E05` = signed control byte that can divert into the special path at `01A1` Strongest safe reading: low-bank command-packet header workspace consumed by the `C7:0004 -> 0140` dispatcher.  I have **not** frozen the final high-level noun of the downstream `58B2 / 5BF5 / 5C3E / 5C77` handler families. I have **not** frozen the final gameplay-facing noun of the broader pass-88/89 lane+raster workspace. I have **not** returned to the first exact clean-code external reader of `CE0F` yet. I do now have enough exact structure to stop calling `C2:0003`, `C2:0009`, and `C7:0004` generic mystery addresses.
; source: chrono_trigger_labels_pass93.md
L_00_1E00_ct_c7_low_bank_command_packet_header_workspace:
    ; TODO: reconstruct body / data for 00:1E00
    ; known span hint: 00:1E00..00:1E05

