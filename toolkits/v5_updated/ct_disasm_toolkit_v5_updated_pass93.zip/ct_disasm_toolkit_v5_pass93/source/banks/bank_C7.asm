; -----------------------------------------------------------------------------
; AUTO-GENERATED Chrono Trigger V5 source scaffold :: bank_C7
; This file is intentionally assembler-neutral scaffolding.
; Labels, provenance, notes, and confidence are preserved from the evidence DB.
; TODO blocks remain until byte-accurate reconstruction exists.
; -----------------------------------------------------------------------------

; =============================================================================
; C7:0004  top-status=strong  labels=1
; =============================================================================
; [strong] pass 93 :: ct_c7_branch_to_0140_low_bank_packet_dispatcher_veneer
; qualifier: strong
; notes: Exact body: `JMP $0140`. Lands at exact target `C7:0140`. Strongest safe reading: veneer for the low-bank packet opcode-family dispatcher behind all the `1E00..` command-packet submit helpers.
; source: chrono_trigger_labels_pass93.md
C7_0004_ct_c7_branch_to_0140_low_bank_packet_dispatcher_veneer:
    ; TODO: reconstruct body / data for C7:0004
    ; known span hint: C7:0004..C7:0006

; =============================================================================
; C7:0140  top-status=strong  labels=1
; =============================================================================
; [strong] pass 93 :: ct_c7_dispatch_1e00_packet_opcode_families_into_low_bank_handlers
; qualifier: strong structural
; notes: Exact prologue saves `B`, `D`, flags, `A`, `X`, and `Y`. Sets exact direct page to `D = 0x1E00`. Forces `DB = 0x00`. Reads exact packet header bytes from the `1E00..` workspace, including `1E00` and `1E05`. If `1E05` is negative, diverts into the special path at `01A1`. If `1E00 == 00`, exits immediately. Exact opcode-family split from `1E00` is now frozen: `0x10..0x17` -> indexed indirect jump through table `0AD9` `0x18..0x2F` -> `JMP $061C` `0x30..0x3F` -> `JMP $071D` `0x70` -> `JMP $08E3` `0x71` -> `JMP $0755` Unsupported / finished paths clear exact byte `1E00` before restoring state and returning with `RTL`. Strongest safe reading: exact low-bank packet opcode-family dispatcher over the `1E00..` command packet workspace.
; source: chrono_trigger_labels_pass93.md
C7_0140_ct_c7_dispatch_1e00_packet_opcode_families_into_low_bank_handlers:
    ; TODO: reconstruct body / data for C7:0140
    ; known span hint: C7:0140..C7:019D

