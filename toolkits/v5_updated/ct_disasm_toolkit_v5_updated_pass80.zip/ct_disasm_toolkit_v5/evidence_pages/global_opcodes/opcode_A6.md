# Global Opcode A6

- Status: **strong structural**
- Dispatch address: **C1:B019**
- Evidence pass: **72**
- Notes: Internal alias after the chained second-subop reload. Dispatches the second B239 opcode and falls into result capture.

## Matching label evidence
- pass 72: `C1:B019..C1:B023` **ct_global_opcode_A6_late_pack_executor_internal_alias_dispatch_second_subop** (strong)
  - Internal alias after the chained second-subop reload. Dispatches the second `B239` opcode and falls into result capture.
