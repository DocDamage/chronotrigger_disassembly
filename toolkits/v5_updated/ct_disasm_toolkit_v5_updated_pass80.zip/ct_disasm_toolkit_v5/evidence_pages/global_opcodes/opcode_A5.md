# Global Opcode A5

- Status: **strong structural**
- Dispatch address: **C1:B00E**
- Evidence pass: **72**
- Notes: Internal alias for the chained second-subop advance path. Moves B1D2 by +4, reloads B239, and falls back into shared dispatch.

## Matching label evidence
- pass 72: `C1:B00E..C1:B018` **ct_global_opcode_A5_late_pack_executor_internal_alias_advance_to_second_subop** (strong)
  - Internal alias for the chained second-subop advance path. Advances `B1D2` by `+4`, reloads `B239`, and falls back into the shared dispatch.
