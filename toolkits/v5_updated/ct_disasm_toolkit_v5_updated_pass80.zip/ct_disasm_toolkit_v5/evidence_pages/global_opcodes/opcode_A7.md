# Global Opcode A7

- Status: **strong structural**
- Dispatch address: **C1:B024**
- Evidence pass: **72**
- Notes: Internal alias at the result-capture start. Mirrors AF24 into B24A[tail] and enters the special-case / nonzero-result logic.

## Matching label evidence
- pass 72: `C1:B024..C1:B02E` **ct_global_opcode_A7_late_pack_executor_internal_alias_capture_af24_result** (strong)
  - Internal alias at the result-capture start. Mirrors `AF24` into `B24A[tail]` and enters the special-case / nonzero-result logic.
