# Next Session Start Here

1. Read `notes/community_research_first.md`
2. Open these in order:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `dossiers/C1_dossier.md`
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - latest pass + labels
3. Active top-of-stack seam after pass 80:
   - finish token `0x80` sub-dispatch at `CD:2A51`
   - finish the surrounding auxiliary command families at `0x88..0x9F`
   - re-open `C1:4943` and the downstream `4500.. / 5D00.. / A07B` family with the cleaner auxiliary-script proof in hand
4. Specific cleanup targets:
   - decide whether `CA5E/CA60` are best modeled as x/y, min/max, or another paired accumulator noun
   - tighten the exact nouns of `CD44/CD45/CD46` and `CE0E/CE10`
   - decide whether the raw `<0x7F` auxiliary tokens should be frozen as tile-block ids, tile-source ids, or a still tighter noun
   - map the D1-side helper calls reached by `0xF0` and `0xF4`
5. Runtime confirmation shortlist:
   - auxiliary stream path `1654` for raw `<0x7F` data-token handling into `CA18/CA17`
   - repeat-loop families `0x83/0x84/0x85/0x86` over `CA72/CA74/CA3A`
   - paired-delta family `0x82` over `CA5E/CA60`
   - output path `BFAA/895B -> CD:0015/002A -> optional CD:0018 -> C3:0002 -> 4943 -> 5D00`
