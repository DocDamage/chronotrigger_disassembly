; Chrono Trigger bank D1 skeleton
; Generated from current evidence. This is not a complete reassemblable bank yet.

.bank $D1

; D1:5800 [strong] pass 44
ct_d1_tilemap_template_default_0b40_0180:
    ; TODO: lift real code/data for D1:5800
    ; Default/reset ROM template copied into `0B40` by `C1:1C3A`. Same size as the upload buffer and structurally part of the same tilemap-templat

; D1:5800 [unspecified] pass 44
__D1_5A50___D1_5BD0__ct_d1_tilemap_template_family_16x12_words__provisional_:
    ; TODO: lift real code/data for D1:5800
    ; The three source blocks are best interpreted as a 192-word (likely 16x12) template family. This matrix interpretation fits both the dense ro

; D1:5800 [unspecified] pass 45
__D1_5A50___D1_5BD0__ct_d1_base_strip_template_family_32x6______strong_:
    ; TODO: lift real code/data for D1:5800
    ; Corrected geometrically in this pass. All three `0x0180`-byte base templates are best modeled as 32-word by 6-row strip layouts. Used as the

; D1:5800 [provisional] pass 45
__D1_5A50___D1_5BD0__ct_d1_tilemap_template_family_16x12_words__withdrawn_:
    ; TODO: lift real code/data for D1:5800
    ; Pass 45 corrects this earlier provisional geometry. The safer keepable geometry is `32x6`, not `16x12`.

; D1:5800 [provisional] pass 45
__D1_5A50___D1_5BD0__ct_d1_alt_base_strip_layout_family_________provisional_:
    ; TODO: lift real code/data for D1:5800
    ; The three templates are clearly alternate base layouts within the same 32x6 strip region. Exact gameplay/UI mode names are still unresolved.

; D1:5800 [provisional] pass 46
__D1_5A50___D1_5BD0__ct_d1_alt_base_strip_layout_family_______strengthened_context_:
    ; TODO: lift real code/data for D1:5800
    ; Pass 46 strengthens their caller-context roles: `5800` = default/base restore through `C1:1C3A` `5A50` = latched alternate via `A86A` `5BD0`

; D1:5800 [provisional] pass 46
ct_d1_base_strip_template_default:
    ; TODO: lift real code/data for D1:5800
    ; Caller context strongly suggests the default/base restore variant. Final gameplay-facing mode name still open.

; D1:59FC [strong] pass 45
ct_d1_panel_segment_template_6x7_words:
    ; TODO: lift real code/data for D1:59FC
    ; Unique ROM source table used by `C1:0929`. Resolves cleanly as 6 rows of 7 words. Tile values form a compact border/interior segment templat

; D1:5A50 [strong] pass 44
ct_d1_tilemap_template_alt_a_0b40_0180:
    ; TODO: lift real code/data for D1:5A50
    ; Alternate ROM template variant copied into `0B40` by the `0EA1..0EB1` path. Followed by `INC $99E2`, proving it feeds the same upload path a

; D1:5A50 [provisional] pass 46
ct_d1_base_strip_template_latched_alt:
    ; TODO: lift real code/data for D1:5A50
    ; Single-shot alternate selected when `A86A` is nonzero, then that latch is cleared. Kept provisional until the higher-level mode name is pinn

; D1:5BD0 [strong] pass 44
ct_d1_tilemap_template_alt_b_0b40_0180:
    ; TODO: lift real code/data for D1:5BD0
    ; Alternate ROM template variant copied into `0B40` by the `1301..1315`, Followed by `INC $99E2`, proving it feeds the same upload path as the

; D1:5BD0 [provisional] pass 46
ct_d1_base_strip_template_transition_alt:
    ; TODO: lift real code/data for D1:5BD0
    ; Copied in later state-transition/reset paths with surrounding controller bookkeeping. Strong structural role, but final mode name still unre

; D1:646C..D1:652B [strong] pass 79
ct_d1_auxiliary_descriptor_pointer_table:
    ; TODO: lift real code/data for D1:646C..D1:652B
    ; `15D5` multiplies the descriptor id by two and reads a pointer from this table. The returned pointer seeds one active runtime slot in the op

