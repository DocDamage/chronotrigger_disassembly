# Next Session Start Here

1. Read `notes/community_research_first.md`
2. Open these in order:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `dossiers/C1_dossier.md`
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - latest pass + labels
3. Active top-of-stack seam:
   - promoted master-table globals after pass 67
   - primary targets: `30..3F`, then `40..52`
4. Specific cleanup targets:
   - strengthen `9967` and `9981` in global terms
   - decide whether `B23A` can be named more strongly from caller evidence
   - keep the `5E15/5E0D` vs `B16E` seeded-family bridge explicit
5. Runtime confirmation targets live in:
   - `targets/trace_packs/`
   - `notes/bsnes_trace_targets.md`
