# Next Session Start Here

1. Read `notes/community_research_first.md`
2. Open these in order:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `dossiers/C1_dossier.md`
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - latest pass + labels
3. Active top-of-stack seam:
   - promoted master-table globals after pass 71
   - primary target: `90..A9`
4. Specific cleanup targets:
   - decode the late promoted selector/master band at `90..A9`
   - keep opcode `76` / selector `1F` on the runtime-confirmation shortlist because of the anomalous `STA $0E` loop update at `C1:A8E9`
   - preserve the now-proved nonhead selector-family wording around globals `70..7D`
5. Runtime confirmation targets live in:
   - `targets/trace_packs/`
   - `notes/bsnes_trace_targets.md`
