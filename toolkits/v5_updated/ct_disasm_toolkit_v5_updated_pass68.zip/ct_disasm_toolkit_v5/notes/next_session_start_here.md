# Next Session Start Here

1. Read `notes/community_research_first.md`
2. Open these in order:
   - `reports/ct_workspace_report.md`
   - `reports/ct_completion_score.md`
   - `reports/ct_conflict_report.md`
   - `graph/ct_knowledge_graph_summary.md`
   - `dossiers/C1_dossier.md`
   - `chrono_trigger_master_handoff_session2.md`
   - `chrono_trigger_master_index_handoff.md`
   - latest pass + labels
3. Active top-of-stack seam:
   - promoted master-table globals after pass 68
   - primary targets: `57..5F`, then continue through the early `B8BB` slice
4. Specific cleanup targets:
   - strengthen the first promoted `B8BB`-slice globals in master terms
   - decide whether `44..4C` can be named more strongly from caller/state evidence
   - keep the `AF0D / AF02 / AF15` canonical-vs-live tail wording explicit around global `50`
5. Runtime confirmation targets live in:
   - `targets/trace_packs/`
   - `notes/bsnes_trace_targets.md`
