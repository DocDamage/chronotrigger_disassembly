# Chrono Trigger Workspace Report

## Current top-of-stack
- Latest pass: **95**
- Current live seam: **Do not go broad. The cleanest next move now is: 1. Finish the tail of the 01A1 special path 04B1..061B plus helper 0655 2. Tighten the helper pair called at the top of 01A1 0734 0A39 3. Only then go back to CE0F**
- Completion estimate: **~68.1%**

## Label database
- Total label rows: **659**
- Strong: **449**
- Provisional: **140**
- Alias: **1**
- Caution: **2**
- Runtime evidence rows: **0**

## Coverage worksheets
- Master C1 global opcode worksheet rows: **170**
- Selector-control worksheet rows: **83**
- Service-7 wrapper worksheet rows: **8**

## Xref cache
- Hot targets cached: **33**

## Generated artifacts
- `reports/ct_completion_score.md`
- `reports/ct_conflict_report.md`
- `reports/code_data_score.md`
- `graph/ct_knowledge_graph_summary.md`
- `reports/ct_unresolved_dashboard.md`
- `reports/ct_dispatch_family_report.md`
- `reports/ct_apu_packet_summary.md`
- `reports/ct_source_state.md`
- `reports/ct_rebuild_diff_report.md`
- `asm_skeleton/banks/`

## Immediate next work
1. Read `notes/next_session_start_here.md` and stay on that seam before going broad.
2. Use `reports/ct_dispatch_family_report.md` when you are dealing with veneers, opcode families, or packet dispatchers.
3. Use `reports/ct_apu_packet_summary.md` when the work touches the C7 sound/APU packet side.
4. Import runtime evidence when static ownership proof stalls.

## Still required for full disassembly
- Complete bank-by-bank code/data separation across the untouched ROM banks
- Finish decompressor grammar / format work
- Freeze subsystem ownership boundaries across banks
- Build a rebuildable source tree and validate against ROM fingerprints
